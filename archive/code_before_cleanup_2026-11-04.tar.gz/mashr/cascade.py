"""Fast loop: the orchestrator's single call per question, and the executor for the architecture it
chose (an ordered list of stages; later stages run only when their free runtime condition holds)."""
import json
import re
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from .mas import MODEL, extract
from .pool import check_plan, fallback_plan, orchestrator_prompt

ANSWER_FMT = "End your response with a final line of the form '#### <number>'."
PROMPT_WEIGHT = 0.2   # cost = generated tokens + 0.2 * prompt tokens (all calls, incl. orchestrator)
TASK = {
    "solve": "Consider the earlier work and give your own revised solution.",
    "review": "Check the earlier work for errors and give the answer you believe is correct.",
    "decide": "Decide the single correct final answer.",
}


def majority(answers):
    """Most common non-missing answer; ties go to the earliest listed agent."""
    xs = [a for a in answers if a is not None]
    if not xs:
        return None
    c = Counter(xs)
    top = max(c.values())
    return next(a for a in xs if c[a] == top)


def cost(calls) -> float:
    return sum(c["gen_tokens"] + PROMPT_WEIGHT * c["prompt_tokens"] for c in calls)


class Cascade:
    def __init__(self, llm, model: str = MODEL, seed: int = 0):
        self.llm, self.model, self.seed = llm, model, seed

    def orchestrate(self, pool: dict, question: str):
        r = self.llm.chat(self.model, [{"role": "system", "content": orchestrator_prompt(pool)},
                                       {"role": "user", "content": f"Problem: {question}\n\n"
                                                                   "Your JSON architecture:"}],
                          thinking="off", max_tokens=500, seed=self.seed)
        plan, probs = None, ["no JSON object"]
        m = re.search(r"\{.*\}", r.text, re.S)
        if m:
            try:
                plan, probs = check_plan(pool, json.loads(m.group(0)))
            except json.JSONDecodeError as e:
                probs = [f"bad JSON: {e}"]
        call = {"agent": "orchestrator", "stage": None, "prompt_tokens": r.prompt_tokens,
                "gen_tokens": r.gen_tokens, "invalid": plan is None, "problems": probs[:3]}
        return (plan or fallback_plan(pool)), call

    def _agent(self, pool, name, spec, stage, user):
        system = pool["agents"][name]["role"]
        if spec.get("skills"):
            system += "\n\nSkills to apply:\n" + "\n".join(f"- {pool['skills'][x]}"
                                                           for x in spec["skills"])
        r = self.llm.chat(self.model, [{"role": "system", "content": system},
                                       {"role": "user", "content": user}],
                          thinking=spec.get("thinking", "off"), max_tokens=2048, seed=self.seed)
        return {"agent": name, "text": r.text, "answer": extract(r.text),
                "call": {"agent": name, "stage": stage, "thinking": spec.get("thinking", "off"),
                         "prompt_tokens": r.prompt_tokens, "gen_tokens": r.gen_tokens}}

    def run(self, pool: dict, question: str, plan: dict) -> dict:
        calls, trace, history, seen = [], [], [], []   # seen: every answer produced so far
        final = None
        for i, st in enumerate(plan["stages"]):
            disagree = None in seen or len(set(seen)) > 1
            if i > 0 and st["if"] == "disagree" and not disagree:
                trace.append({"stage": i, "type": st["type"], "ran": False})
                continue
            if not history:
                user = f"Problem: {question}\n\n{ANSWER_FMT}"
            else:
                shown = "\n\n".join(f"[{o['agent']}, stage {j + 1} {t}]\n{o['text']}"
                                    for j, t, o in history)
                user = (f"Problem: {question}\n\nEarlier work:\n{shown}\n\n"
                        f"{TASK[st['type']]} {ANSWER_FMT}")
            with ThreadPoolExecutor(len(st["agents"])) as ex:
                outs = list(ex.map(lambda kv: self._agent(pool, kv[0], kv[1], i, user),
                                   st["agents"].items()))
            calls += [o["call"] for o in outs]
            history += [(i, st["type"], o) for o in outs]
            ans = [o["answer"] for o in outs]
            seen += ans
            before = final
            final = majority(ans) if majority(ans) is not None else before
            trace.append({"stage": i, "type": st["type"], "ran": True, "answers": ans,
                          "majority": final, "before": before})
        return {"answer": final, "calls": calls, "trace": trace}
