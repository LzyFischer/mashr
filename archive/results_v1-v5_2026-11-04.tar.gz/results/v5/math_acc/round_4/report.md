# Diagnostic report (dev-A)

Organization: acc 95.3%, cost 13056/question, of which the HR 1852 (HR prompt 5112 chars). Full system: acc 91.3%, cost 17252. 17 distinct architectures, 1.5 nodes per question. HR outputs: repaired 0, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 5850 | 13285 | algebraist.low 4, solver.low 4, coder.high 3 |
| Algebra L5 | 18 | 100% | 100% | 8202 | 15585 | algebraist.high 4, algebraist.low 4, coder.low 2 |
| Counting & Probability L4 | 8 | 100% | 100% | 7559 | 15676 | combinator.low 3, coder.high 1, solver.low 1 |
| Counting & Probability L5 | 9 | 100% | 89% | 17440 | 19103 | combinator.high>verifier.max 3, combinator.low 2, coder.high>verifier.max 2 |
| Geometry L4 | 5 | 100% | 100% | 9586 | 15889 | geometer.low 2, coder.low 1, solver.low 1 |
| Geometry L5 | 7 | 57% | 57% | 32996 | 22647 | coder.high,geometer.high>verifier.max 3, coder.high>verifier.max 2, geometer.high>coder.high>verifier.max 2 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 14400 | 18210 | solver.high>verifier.max 4, algebraist.low 2, coder.high>verifier.max 2 |
| Intermediate Algebra L5 | 17 | 88% | 71% | 20213 | 21465 | coder.high>verifier.max 6, solver.high>verifier.max 3, coder.high 3 |
| Number Theory L4 | 9 | 100% | 100% | 11723 | 17149 | coder.high>verifier.max 2, coder.high 2, solver.high>verifier.max 1 |
| Number Theory L5 | 16 | 94% | 88% | 11848 | 18165 | coder.high 8, coder.low 4, coder.high>verifier.max 4 |
| Prealgebra L4 | 12 | 100% | 100% | 4569 | 10794 | coder.low 5, solver.low 3, combinator.low 2 |
| Prealgebra L5 | 9 | 100% | 89% | 11049 | 17096 | coder.low 3, combinator.low 2, coder.high>verifier.max 1 |
| Precalculus L4 | 3 | 100% | 100% | 22174 | 20027 | solver.high 1, coder.high,geometer.high>verifier.max 1, coder.high>verifier.max 1 |
| Precalculus L5 | 6 | 83% | 83% | 25649 | 22960 | coder.high,geometer.high>verifier.max 2, coder.high>verifier.max 2, geometer.high>coder.high>verifier.max 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.high>verifier.max | 26 | 92% | 22934 |
| coder.high | 21 | 100% | 9020 |
| coder.low | 19 | 95% | 5300 |
| solver.high>verifier.max | 12 | 92% | 18576 |
| solver.low | 12 | 100% | 4908 |
| algebraist.low | 11 | 100% | 4134 |
| combinator.low | 10 | 100% | 4549 |
| solver.high | 10 | 100% | 8092 |
| coder.high,geometer.high>verifier.max | 9 | 78% | 32602 |
| algebraist.high | 5 | 100% | 8326 |
| combinator.high>verifier.max | 3 | 100% | 22907 |
| geometer.low | 3 | 100% | 5131 |
| geometer.high>coder.high>verifier.max | 3 | 67% | 35216 |
| combinator.high | 2 | 100% | 8532 |
| algebraist.high>verifier.max | 2 | 100% | 14784 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| coder.high | 57 | 74% | 100% | 8116 | - | - | - |
| verifier.max (with inputs) | 56 | 89% | 27% | 11839 | 18 | 14 | - |
| solver.high | 22 | 86% | 91% | 6859 | - | - | - |
| coder.low | 19 | 95% | 100% | 3447 | - | - | - |
| geometer.high | 13 | 46% | 100% | 8184 | - | - | - |
| solver.low | 12 | 100% | 100% | 3019 | - | - | - |
| algebraist.low | 11 | 100% | 64% | 2243 | - | - | - |
| combinator.low | 10 | 100% | 100% | 2659 | - | - | - |
| algebraist.high | 7 | 100% | 86% | 6945 | - | - | - |
| combinator.high | 5 | 100% | 100% | 10364 | - | - | - |
| geometer.low | 3 | 100% | 100% | 3619 | - | - | - |
| coder.high (with inputs) | 3 | 0% | 100% | 8612 | 3 | - | 2 |
| solver.high (with inputs) | 1 | 100% | 100% | 7495 | 1 | 1 | - |

## Leave-one-out on 57 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.max (output) | 56 | 14 | 0 | 42 | 11839 |
| coder.high (input) | 39 | 4 | 1 | 34 | 3056 |
| geometer.high (input) | 13 | 0 | 2 | 11 | 7140 |
| solver.high (input) | 12 | 0 | 0 | 12 | 47 |
| combinator.high (input) | 3 | 0 | 0 | 3 | 3596 |
| algebraist.high (input) | 2 | 0 | 0 | 2 | -4967 |
| solver.high (output) | 1 | 1 | 0 | 0 | 7495 |

HR output problems: minor: line 1: non-node argument ignored (5)

## Organization wrong, full system right (1)
- [Number Theory L5] A relatively prime date is a date for which the number of the month and the number of the day are relatively prime. For example, June 17 is a relatively prime date because the greatest common factor of 6 and 17 is 1. How many relatively prime dates are in the month with the fewes
  architecture: c = coder("low"); return c; answered 13, correct 10

Both wrong: 6.

## Most expensive correct questions (possible waste)
- [Intermediate Algebra L4, cost 38249] Find the largest constant $m,$ so that for any positive real numbers $a,$ $b,$ $c,$ and $d,$
\[\sqrt{\frac{a}{b + c + d}} + \sqrt{\frac{b}{a + c + d}} + \sqrt{\frac{c}{a + b + d}} 
  architecture: a = coder("high"); b = geometer("high"); v = verifier("max", a, b); return v
- [Precalculus L4, cost 38020] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\
  architecture: c = coder("high"); g = geometer("high"); v = verifier("max", c, g); return v
- [Geometry L5, cost 36298] Square $ABCD$ has center $O,\ AB=900,\ E$ and $F$ are on $AB$ with $AE<BF$ and $E$ between $A$ and $F, m\angle EOF =45^\circ,$ and $EF=400.$ Given that $BF=p+q\sqrt{r},$ where $p,q
  architecture: g = geometer("high"); c = coder("high", g); v = verifier("max", c); return v
- [Intermediate Algebra L5, cost 31033] Consider the set of 30 parabolas defined as follows: all parabolas have as focus the point $(0,0)$ and the directrix lines have the form $y=ax+b$ with $a$ and $b$ integers such tha
  architecture: c = coder("high"); v = verifier("max", c); return v
- [Precalculus L5, cost 30938] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection
  architecture: c = coder("high"); g = geometer("high"); v = verifier("max", c, g); return v