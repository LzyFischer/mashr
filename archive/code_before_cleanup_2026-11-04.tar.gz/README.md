# MAS-HR: organizational learning for multi-agent systems

An HR model staffs a multi-agent team per question; dataset-level RSI redesigns the organization
(roster, skills, SOPs, the HR's handbook) under an accuracy floor to cut cost. Two time scales:

- **fast loop (per question, online)**: the HR (Qwen3.5-9B, no thinking) reads its handbook and the
  question, and outputs one structured plan: SOP, who fills each stage, thinking level, which of
  their skills to switch on, an optional short note. A rule engine runs the SOP; later stages run
  only when a runtime signal fires (disagreement, low self-reported confidence, missing answer,
  long output).
- **slow loop (per dataset, offline)**: a big model (Qwen3.8-27B, thinking) reads a performance report
  with leave-one-out attribution per employee, proposes edit operations (hire, fire, rehire, skills,
  SOPs, handbook), and a dev-B gate accepts the cheapest candidate that stays within eps of the full
  team's accuracy.

Report: `docs/report_2026-10-18.md`. Moved out of `~/project/harness-rsi` on 2026-10-18.

## Layout

```
mashr/llm.py       Tinker sampling, per-call thinking budget, sqlite cache, in-flight dedupe
mashr/org.py       the organization: schema, validation, 12 edit ops, the HR's rendered handbook
mashr/orgexec.py   HR call + SOP executor with rule-engine escalation          (current version)
mashr/orgrsi.py    org-RSI loop: founding, report + leave-one-out, propose/repair, gate, test
mashr/mas.py, hr.py, rsi.py, run.py   first version (fixed 5 roles, rules-only RSI), GSM8K pilot
data/{gsm8k,math}/  GSM8K (openai/grade-school-math), MATH splits (openai/prm800k)
results/mashr/cache.sqlite   shared call cache (~100 MB)
results/rsi/gsm8k_r1/        first version, GSM8K
results/orgrsi/math_{hand,found}/   current version, MATH L4-5 integer answers
```

## Run

```
P=~/miniconda3/envs/tinker/bin/python
set -a; source ~/.config/hrsi/tinker.env; set +a
$P -m mashr.orgrsi --dataset math --rounds 5 --k 3 --n-dev-a 150 --n-dev-b 200 --n-test 156 \
   --loo-n 60 --init found --out results/orgrsi/math_found      # or --init hand
bash results/orgrsi/run_math.sh     # both inits; the second starts after the reference is cached
```

Two processes share the cache but not the in-flight dedupe: do not start identical evaluations in
parallel processes (the second would resample instead of waiting).
