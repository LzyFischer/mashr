# MAS-HR: residual harness for harnesses

An HR model (the meta-agent) designs a team for every question; dataset-level RSI improves the
organization the HR works with. Two time scales:

- **fast loop (per question)**: the HR (Qwen3.5-9B, thinking medium) reads its handbook, the employees,
  the tool and skill lists and the problem, and writes the team as Python-like code (parsed, never
  executed) plus notes. Each node = an employee (its role: the *self harness*) with a thinking level,
  its input nodes, and the *residual harness* the HR hands it for this problem: tools (Python
  functions preloaded in its sandbox; no tools = no Python), skills (how-to texts) and a note.
- **slow loop (per dataset, offline)**: a designer (Qwen3.8-27B, thinking high) reads a diagnostic
  report of the current organization on dev-A and proposes edit operations on the roles, the skill
  library and the HR handbook (every op says why it belongs on that layer); a dev-B gate picks the
  winner; test is run once at the end.

## Layout

```
mashr/llm.py      sampling (Tinker, or local vLLM for MASHR_LOCAL_MODELS), thinking budgets, sqlite cache
mashr/ledger.py   time and token cost per stage (costs.json)
mashr/tools.py    the tool library (hand-written, each with a sandbox test)
mashr/org.py      the organization: schema, limits, HR prompt, parser of the HR's code, edit ops, baselines
mashr/engine.py   Python sandbox, answer extraction, cost; Engine = HR call + plan executor
mashr/rsi.py      the RSI loop: design, dev-A report, proposals, dev-B gate, test
mashr/bench.py    datasets (math, aflow_math, gsmhard, aime): splits, answer formats, graders
scripts/          run.sh (an RSI run), dump_prompts, test_ablation, prepare_bench
data/             MATH (prm800k splits), data/bench/ (built by scripts/prepare_bench.py)
results/          see results/README.md: cache/ (LLM call cache), v6/ (runs of this code)
docs/             reports; ahe_prompts.md (the AHE paper's prompts, for comparison)
archive/          tarballs: code of v1-v5, their results, v6 smoke/aborted runs (2026-11-04 cleanup)
```

## Run

```
scripts/run.sh math <name> --seed 0 --objective acc --rounds 5 --k 3 --n-dev-b 50 \
    --hr-thinking medium --baselines single_off,coder_off_tools,solve_verify_off
```

`scripts/run.sh` sources the Tinker env (designer), points the employees and the HR at local vLLM
(Qwen/Qwen3.5-9B on port 8001) and writes `results/v6/<name>/` (log.txt, round_N/report.md,
trace.json, final_pool.json, test.json, costs.json, console.out). Set `MASHR_MAX_THINK=off` to disable the
employees' thinking. Phase 2 (cost): `--init-pool <final_pool.json> --objective cost`.
`scripts/run_dump_prompts.sh <name>` writes every prompt and example runs of a finished run to
`results/v6/<name>/prompts_and_examples.md`.

Two processes share the cache but not the in-flight dedupe: do not start identical evaluations in
parallel processes (the second would resample instead of waiting).
