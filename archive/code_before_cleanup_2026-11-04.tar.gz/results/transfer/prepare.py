"""Build the transfer test sets in data/transfer/ from the raw downloads in data/_download/.

  aime.jsonl      AIME 2022-2024 (AI-MO/aimo-validation-aime, 90) + AIME 2025 (MathArena/aime_2025, 30)
  gsmhard.jsonl   GSM-Hard v2 (reasoning-machines/gsm-hard, 1319); numeric targets, 303 not integers
  aflow_math.jsonl  AFlow's MATH Level 5 test split (486; validate split not used), gold = last \\boxed{}
                    of the reference solution; in_dev marks problems that are in our RSI dev-A/dev-B

  ~/miniconda3/envs/mem/bin/python -I results/transfer/prepare.py   (run from the project root)
"""
import json
import os
import re
import sys

import pandas as pd

sys.path.insert(0, os.getcwd())
from mashr.orgrsi import load_items  # noqa: E402

D, OUT = "data/_download", "data/transfer"
os.makedirs(OUT, exist_ok=True)
norm = lambda s: re.sub(r"\s+", " ", s).strip().lower()


def last_boxed(s):
    i = s.rfind("\\boxed")
    if i < 0:
        return None
    j = s.find("{", i)
    depth, k = 0, j
    while k < len(s):
        depth += {"{": 1, "}": -1}.get(s[k], 0)
        if depth == 0:
            return s[j + 1:k].strip()
        k += 1
    return None


def write(name, rows):
    with open(os.path.join(OUT, name), "w") as f:
        f.write("\n".join(json.dumps(r) for r in rows) + "\n")
    print(name, len(rows))


a = pd.read_parquet(f"{D}/hf/aime_22_24.parquet")
aime = [{"id": f"aime-{r.url.split('/')[-2].replace('_Problems', '')}-{r.url.split('_')[-1]}",
         "question": r.problem, "gold": str(int(r.answer)),
         "bucket": " ".join(r.url.split("/")[-2].split("_")[:3]), "hard": True}
        for r in a.itertuples()]
for r in (json.loads(l) for l in open(f"{D}/hf/MathArena__aime_2025.jsonl")):
    aime.append({"id": f"aime-2025-{r['problem_idx']}", "question": r["problem"],
                 "gold": str(int(r["answer"])), "bucket": "2025 AIME", "hard": True})
write("aime.jsonl", aime)

g = [json.loads(l) for l in open(f"{D}/hf/gsmhardv2.jsonl")]
write("gsmhard.jsonl", [{"id": f"gsmhard-{i}", "question": r["input"], "gold": float(r["target"]),
                         "bucket": "GSM-Hard", "hard": False,
                         "integer_gold": float(r["target"]) == int(float(r["target"]))}
                        for i, r in enumerate(g)])

dev = {norm(it["question"]) for it in load_items("math", "train", 0, 350)}
m = [json.loads(l) for l in open(f"{D}/aflow/x/math_test.jsonl")]
rows = []
for i, r in enumerate(m):
    gold = last_boxed(r["solution"])
    if gold is None:
        print("no boxed answer, skipped:", r["problem"][:80])
        continue
    rows.append({"id": f"aflow-math-{i}", "question": r["problem"], "gold": gold,
                 "bucket": f"{r['type']} L5", "hard": True, "in_dev": norm(r["problem"]) in dev})
write("aflow_math.jsonl", rows)
