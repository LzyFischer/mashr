# Diagnostic report (dev-A)

Organization: acc 92.7%, cost 14586/question, of which the HR 1832 (HR prompt 5436 chars). Full system: acc 91.3%, cost 17252. 15 distinct architectures, 1.9 nodes per question. HR outputs: repaired 0, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 11496 | 13285 | solver.high>verifier.high 6, coder.high>verifier.high 4, solver.high 3 |
| Algebra L5 | 18 | 100% | 100% | 12253 | 15585 | solver.high>verifier.high 8, algebraist.high>verifier.high 5, solver.high 3 |
| Counting & Probability L4 | 8 | 100% | 100% | 13205 | 15676 | combinator.high>verifier.high 3, coder.high>verifier.high 2, solver.high>verifier.high 2 |
| Counting & Probability L5 | 9 | 89% | 89% | 18827 | 19103 | combinator.high>verifier.high 3, coder.high,solver.high>verifier.high 2, coder.high 1 |
| Geometry L4 | 5 | 100% | 100% | 10991 | 15889 | solver.high>verifier.high 2, coder.high 2, coder.low 1 |
| Geometry L5 | 7 | 57% | 57% | 19876 | 22647 | coder.high>verifier.high 2, coder.high 1, coder.high,solver.high>verifier.high 1 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 15607 | 18210 | solver.high>verifier.high 9, coder.high>verifier.high 1, solver.high>coder.high>verifier.high 1 |
| Intermediate Algebra L5 | 17 | 71% | 71% | 19038 | 21465 | solver.high>verifier.high 9, coder.high>verifier.high 3, solver.high>coder.high>verifier.high 2 |
| Number Theory L4 | 9 | 100% | 100% | 12951 | 17149 | solver.high>verifier.high 4, coder.high>verifier.high 2, coder.high 1 |
| Number Theory L5 | 16 | 100% | 88% | 14410 | 18165 | coder.high>verifier.high 7, solver.high>verifier.high 3, coder.high 3 |
| Prealgebra L4 | 12 | 100% | 100% | 10507 | 10794 | solver.high>verifier.high 5, solver.high 2, coder.low 2 |
| Prealgebra L5 | 9 | 100% | 89% | 12931 | 17096 | coder.high>verifier.high 4, solver.high 3, combinator.high>verifier.high 1 |
| Precalculus L4 | 3 | 100% | 100% | 18601 | 20027 | solver.high>verifier.high 2, coder.high>verifier.high 1 |
| Precalculus L5 | 6 | 67% | 83% | 19188 | 22960 | coder.high,solver.high>verifier.high 1, solver.high>verifier.high 1, solver.high>coder.high>verifier.high 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| solver.high>verifier.high | 52 | 96% | 15614 |
| coder.high>verifier.high | 30 | 90% | 15073 |
| solver.high | 14 | 100% | 8288 |
| coder.high | 13 | 92% | 7680 |
| combinator.high>verifier.high | 8 | 100% | 15563 |
| algebraist.high>verifier.high | 8 | 100% | 11645 |
| coder.high,solver.high>verifier.high | 6 | 83% | 23942 |
| solver.high>coder.high>verifier.high | 6 | 83% | 23239 |
| coder.high,coder.high>verifier.high | 4 | 25% | 27178 |
| coder.low | 4 | 100% | 3995 |
| coder.high,geometer.high>verifier.high | 1 | 100% | 25370 |
| algebraist.high | 1 | 100% | 3010 |
| combinator.high | 1 | 100% | 8433 |
| geometer.high>verifier.high | 1 | 100% | 21349 |
| coder.high,combinator.high>verifier.high | 1 | 100% | 24248 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| verifier.high (with inputs) | 117 | 91% | 79% | 6799 | 17 | 9 | - |
| solver.high | 78 | 92% | 95% | 6841 | - | - | - |
| coder.high | 59 | 71% | 85% | 6730 | - | - | - |
| combinator.high | 10 | 100% | 90% | 7963 | - | - | - |
| algebraist.high | 9 | 78% | 56% | 4306 | - | - | - |
| coder.high (with inputs) | 6 | 67% | 83% | 7582 | 2 | 1 | 1 |
| coder.low | 4 | 100% | 50% | 2097 | - | - | - |
| geometer.high | 2 | 100% | 100% | 7307 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.high (output) | 60 | 4 | 0 | 56 | 6652 |
| solver.high (input) | 37 | 2 | 0 | 35 | 6275 |
| coder.high (input) | 22 | 1 | 0 | 21 | 5665 |
| combinator.high (input) | 4 | 0 | 0 | 4 | 5322 |
| algebraist.high (input) | 4 | 0 | 0 | 4 | 2109 |
| geometer.high (input) | 1 | 1 | 0 | 0 | 7431 |

HR output problems: minor: line 1: non-node argument ignored (3); minor: line 2: non-node argument ignored (1)

## Organization wrong, full system right (2)
- [Precalculus L5] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection = perspective(6,3,2);

triple A, B, C, D, E, F, G, H;

A = (1,1,0);
B = (1,-1,0);
C = (-1,-1,0);
D 
  architecture: c = coder("high"); return c; answered 2, correct 225
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  architecture: a = coder("high"); v = verifier("high", a); return v; answered 90, correct 85

Both wrong: 9.

## Most expensive correct questions (possible waste)
- [Geometry L5, cost 26771] Square $ABCD$ has center $O,\ AB=900,\ E$ and $F$ are on $AB$ with $AE<BF$ and $E$ between $A$ and $F, m\angle EOF =45^\circ,$ and $EF=400.$ Given that $BF=p+q\sqrt{r},$ where $p,q
  architecture: a = solver("high"); c = coder("high", a); v = verifier("high", a, c); return v
- [Precalculus L5, cost 26725] Three unit circles are drawn so they are mutually tangent, as shown below.  A blue circle that is externally tangent to all three unit circles is drawn.  Finally, three red circles
  architecture: s = solver("high"); r = coder("high", s); v = verifier("high", s, r); return v
- [Prealgebra L5, cost 25865] Let $a$ and $b$ be distinct positive divisors of $80.$ What is the smallest possible value of $ab$ which is not a divisor of $80?$
  architecture: a = coder("high"); b = coder("high"); v = verifier("high", a, b); return v
- [Counting & Probability L5, cost 25827] In how many different ways can 3 men and 4 women be placed into two groups of two people and one group of three people if there must be at least one man and one woman in each group
  architecture: a = combinator("high"); v = verifier("high", a); return v
- [Intermediate Algebra L5, cost 25490] During the car ride home, Michael looks back at his recent math exams. A problem on Michael's calculus mid-term gets him starting thinking about a particular quadratic,\[x^2-sx+p,\
  architecture: a = solver("high"); v = verifier("high", a); return v