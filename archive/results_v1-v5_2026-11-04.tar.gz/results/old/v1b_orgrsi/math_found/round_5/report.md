# Performance report (dev-A)

Organization: acc 92.0%, cost 7988/question. Full team: acc 91.3%, cost 27271. Invalid HR outputs (default plan used): 1.

## By category
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 94% | 100% | 3910 | 19590 | single 14, team 3 |
| Algebra L5 | 18 | 100% | 100% | 5309 | 23083 | single 14, team 4 |
| Counting & Probability L4 | 8 | 100% | 100% | 5173 | 22644 | single 5, team 3 |
| Counting & Probability L5 | 9 | 78% | 89% | 8347 | 32029 | team 6, single 3 |
| Geometry L4 | 5 | 100% | 100% | 6466 | 24771 | single 3, team 2 |
| Geometry L5 | 7 | 57% | 57% | 19280 | 39998 | team 7 |
| Intermediate Algebra L4 | 14 | 93% | 100% | 9867 | 28859 | team 9, single 5 |
| Intermediate Algebra L5 | 17 | 82% | 71% | 14858 | 36267 | team 16, single 1 |
| Number Theory L4 | 9 | 100% | 100% | 4812 | 26425 | single 8, team 1 |
| Number Theory L5 | 16 | 94% | 88% | 6615 | 29063 | single 12, team 4 |
| Prealgebra L4 | 12 | 100% | 100% | 2153 | 15420 | single 11, team 1 |
| Prealgebra L5 | 9 | 100% | 100% | 6961 | 26009 | team 5, single 4 |
| Precalculus L4 | 3 | 100% | 67% | 10227 | 31364 | team 2, single 1 |
| Precalculus L5 | 6 | 83% | 83% | 15560 | 38717 | team 6 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| single.check | 81 | 2 | 1 | 0 | 0 |
| single.decide | 81 | 0 | 0 | 0 | 0 |
| single.draft | 81 | 81 | 0 | 0 | 0 |
| team.decide | 69 | 10 | 10 | 3 | 0 |
| team.review | 69 | 31 | 23 | 13 | 0 |
| team.solve | 69 | 69 | 0 | 0 | 0 |

## Employees: leave-one-out replay on 60 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| algebra | 46 | 1 | 2 | 43 | 5011 |
| careful | 33 | 3 | 1 | 29 | 5779 |
| counter | 31 | 1 | 0 | 30 | 4951 |
| critic | 31 | 16 | 0 | 15 | 7527 |
| fast | 1 | 0 | 0 | 1 | 3538 |
| judge | 9 | 3 | 0 | 6 | 8193 |
Needed / uses by difficulty: algebra@Algebra L4: 0/3; algebra@Algebra L5: 0/4; algebra@Counting & Probability L5: 0/2; algebra@Geometry L4: 0/2; algebra@Geometry L5: 0/4; algebra@Intermediate Algebra L4: 0/7; algebra@Intermediate Algebra L5: 1/11; algebra@Number Theory L4: 0/1; algebra@Number Theory L5: 0/1; algebra@Prealgebra L4: 0/1; algebra@Prealgebra L5: 0/2; algebra@Precalculus L4: 0/2; algebra@Precalculus L5: 0/6; careful@Algebra L4: 0/3; careful@Algebra L5: 0/3; careful@Counting & Probability L4: 0/1; careful@Counting & Probability L5: 0/2; careful@Geometry L4: 0/2; careful@Geometry L5: 1/5; careful@Intermediate Algebra L4: 0/6; careful@Intermediate Algebra L5: 1/3; careful@Number Theory L5: 0/2; careful@Prealgebra L4: 0/1; careful@Prealgebra L5: 0/2; careful@Precalculus L4: 1/1; careful@Precalculus L5: 0/2; counter@Algebra L5: 0/1; counter@Counting & Probability L4: 0/1; counter@Counting & Probability L5: 0/4; counter@Geometry L5: 0/2; counter@Intermediate Algebra L4: 0/3; counter@Intermediate Algebra L5: 0/10; counter@Number Theory L4: 0/1; counter@Number Theory L5: 1/3; counter@Prealgebra L5: 0/1; counter@Precalculus L4: 0/1; counter@Precalculus L5: 0/4; critic@Counting & Probability L5: 1/2; critic@Geometry L4: 0/1; critic@Geometry L5: 3/5; critic@Intermediate Algebra L4: 1/3; critic@Intermediate Algebra L5: 4/10; critic@Number Theory L5: 2/2; critic@Prealgebra L5: 1/3; critic@Precalculus L4: 0/1; critic@Precalculus L5: 4/4; fast@Prealgebra L5: 0/1; judge@Geometry L5: 0/2; judge@Intermediate Algebra L4: 0/1; judge@Intermediate Algebra L5: 2/5; judge@Precalculus L5: 1/1

## HR usage
Employees assigned (questions): judge 133, critic 128, algebra 83, careful 54, counter 48, fast 33
Skills switched on (times): final_format 434, sanity_check 424, verify_by_substitution 193, algebraic_substitution 65, solve_linear 36, geometry_area 34, coordinate_lines 30, diagram_extract 23, check_units 21, counting_digits 15, fraction_percent 14, polynomial_roots 13, number_factors 13, combinatorics_cases 12, parabola_vertex 9, complex_roots 8, exponent_rules 7, complete_square 7, inverse_function 6, inclusion_exclusion 6, permutations_restrictions 4, gcd_coprime 4, divisibility 4, matrix_power 2, functional_equation 2, modular_answer_count 2, surd_power_rounding 2, sequence_sum 1, near_power_zeros 1
Guide notes written: 99
Invalid HR outputs, first problems: ["first stage 'draft' has nobody assigned"]

## Saved wrong: org failed, full team succeeded (3)
- [Counting & Probability L5] The number of increasing sequences of positive integers $a_1 \le a_2 \le a_3 \le \cdots \le a_{10} \le 2007$ such that $a_i-i$ is even for $1\le i \le 10$ can be expressed as ${m \choose n}$ for some positive integers $m > n$. Compute the remainder when $m$ is divided by 1000.
  plan: single draft=[counter:low+counting_digits/combinatorics_cases/sanity_check/final_format]; answered 1, correct 8
- [Algebra L4] Homewood Middle School has 1200 students, and 730 of these students attend a summer picnic. If two-thirds of the girls in the school and one-half of the boys in the school attend the picnic, how many girls attend the picnic?  (Assume that each student in the school is either a bo
  plan: single draft=[fast:off+check_units/fraction_percent/solve_linear/sanity_check/final_format] check=[critic:low+verify_by_substitution/sanity_check/final_format] decide=[judge:high+sanity_check/final_format]; answered 780, correct 520
- [Intermediate Algebra L4] Find the largest constant $m,$ so that for any positive real numbers $a,$ $b,$ $c,$ and $d,$
\[\sqrt{\frac{a}{b + c + d}} + \sqrt{\frac{b}{a + c + d}} + \sqrt{\frac{c}{a + b + d}} + \sqrt{\frac{d}{a + b + c}} > m.\]
  plan: team solve=[careful:low+diagram_extract/sanity_check/final_format, algebra:low+algebraic_substitution/sanity_check/verify_by_substitution/final_format] review=[critic:low+sanity_check/final_format] decide=[judge:high+sanity_check/final_format] guide: algebra: "Apply Holder's inequality or Cauchy-Schwarz to find the lower bound."; critic: "Verify the logic and the tightness of the bound found."; careful: "Analyze the inequality structure and test boundary cases."; judge: "Select the largest valid constant m based on evidence."; answered 0, correct 2

Both wrong: 9.

## Most expensive correctly-solved questions (possible waste)
- [Intermediate Algebra L5, cost 25786] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes th
  plan: team solve=[careful:low+diagram_extract/coordinate_lines/sanity_check/final_format, algebra:low+coordinate_lines/parabola_vertex/geometry_area/sanity_check/final_format] review=[critic:low+verify_by_substitution/sanity_check/final_format] decide=[judge:high+sanity_check/final_format] guide: algebra: "Maximize area function using vertex formula or derivative, verify bounds."; critic: "Check setup, arithmetic, logic, and final answer against constraints."; careful: "Extract coordinates, find line equations, define intersection points, calculate area function."; judge: "Select the best answer and justify based on evidence."
- [Precalculus L5, cost 25608] Three unit circles are drawn so they are mutually tangent, as shown below.  A blue circle that is externally tangent to all three unit circles is drawn.  Finally, three red circles
  plan: team solve=[algebra:low+sanity_check/final_format, careful:low+diagram_extract/algebraic_substitution/verify_by_substitution/sanity_check/final_format] review=[critic:low+verify_by_substitution/sanity_check/final_format] decide=[judge:high+sanity_check/final_format] guide: careful: "Set up Soddy circle equations for red circles tangent to 2 unit and 1 blue. Solve system."; critic: "Verify algebraic steps and final form against problem constraints."; algebra: "Extract coords of 3 unit circles, find blue circle radius via Descartes, then red circles."; judge: "Confirm final answer matches required form and sum a+b+c+d."
- [Intermediate Algebra L5, cost 25054] Let
\[x^8 + 98x^4 + 1 = p(x) q(x),\]where $p(x)$ and $q(x)$ are monic, non-constant polynomials with integer coefficients.  Find $p(1) + q(1).$
  plan: team solve=[algebra:low+algebraic_substitution/polynomial_roots/verify_by_substitution/sanity_check/final_format, counter:low+number_factors/gcd_coprime/sanity_check/final_format] review=[critic:low+verify_by_substitution/sanity_check/final_format/polynomial_roots] decide=[judge:high+sanity_check/final_format] guide: counter: "Analyze integer constraints and potential factorizations over Z."; judge: "Select correct sum based on verified factorization."; algebra: "Factor x^8+98x^4+1 by identifying roots of unity or completing square structure."; critic: "Verify factorization and check p(1)+q(1) against constraints."
- [Number Theory L5, cost 17124] Let $\tau (n)$ denote the number of positive integer divisors of $n$ (including $1$ and $n$). Find the sum of the six least positive integers $n$ that are solutions to $\tau (n) + 
  plan: team solve=[counter:low+number_factors/sanity_check/final_format/combinatorics_cases, algebra:low+algebraic_substitution/sanity_check/final_format/verify_by_substitution] review=[critic:low+verify_by_substitution/sanity_check/final_format/combinatorics_cases] decide=[judge:high+sanity_check/final_format]
- [Precalculus L5, cost 16674] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection
  plan: team solve=[careful:low+diagram_extract/geometry_area/coordinate_lines/sanity_check/final_format, algebra:low+geometry_area/sanity_check/final_format] review=[critic:low+verify_by_substitution/sanity_check/final_format] decide=[judge:high+sanity_check/final_format] guide: careful: "Extract vertices, find intersection polygon. Algebra: Compute area via cross product. Critic: Verify logic. Judge: Pick best."