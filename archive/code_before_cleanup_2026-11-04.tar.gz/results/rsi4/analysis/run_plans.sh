#!/bin/bash
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
PYTHONPATH=. ~/miniconda3/envs/tinker/bin/python results/rsi4/analysis/plans.py results/rsi4/analysis/plans.json > results/rsi4/analysis/plans.out 2>&1
