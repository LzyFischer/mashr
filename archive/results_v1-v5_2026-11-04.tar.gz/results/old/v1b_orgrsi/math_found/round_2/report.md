# Performance report (dev-A)

Organization: acc 93.3%, cost 11210/question. Full team: acc 91.3%, cost 27271. Invalid HR outputs (default plan used): 4.

## By category
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 6131 | 19590 | single 15, team 2 |
| Algebra L5 | 18 | 94% | 100% | 8640 | 23083 | single 11, team 5, self 2 |
| Counting & Probability L4 | 8 | 100% | 100% | 9032 | 22644 | single 4, team 4 |
| Counting & Probability L5 | 9 | 100% | 89% | 14955 | 32029 | team 8, single 1 |
| Geometry L4 | 5 | 100% | 100% | 10440 | 24771 | single 3, team 2 |
| Geometry L5 | 7 | 71% | 57% | 21460 | 39998 | team 7 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 12218 | 28859 | team 10, single 4 |
| Intermediate Algebra L5 | 17 | 71% | 71% | 19338 | 36267 | team 16, single 1 |
| Number Theory L4 | 9 | 100% | 100% | 6173 | 26425 | single 8, team 1 |
| Number Theory L5 | 16 | 94% | 88% | 9948 | 29063 | single 10, team 6 |
| Prealgebra L4 | 12 | 100% | 100% | 3447 | 15420 | single 12 |
| Prealgebra L5 | 9 | 100% | 100% | 11013 | 26009 | team 6, single 3 |
| Precalculus L4 | 3 | 100% | 67% | 14544 | 31364 | team 3 |
| Precalculus L5 | 6 | 83% | 83% | 18964 | 38717 | team 6 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| single.check | 72 | 36 | 0 | 0 | 0 |
| single.decide | 72 | 0 | 0 | 0 | 0 |
| single.draft | 72 | 72 | 0 | 0 | 0 |
| team.decide | 76 | 13 | 12 | 5 | 0 |
| team.review | 76 | 74 | 20 | 9 | 0 |
| team.solve | 76 | 76 | 0 | 0 | 0 |

## Employees: leave-one-out replay on 60 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| algebra | 40 | 2 | 0 | 38 | 4273 |
| careful | 37 | 1 | 0 | 36 | 4888 |
| counter | 30 | 1 | 0 | 29 | 5221 |
| critic | 53 | 6 | 0 | 47 | 4938 |
| judge | 6 | 4 | 0 | 2 | 7700 |
Needed / uses by difficulty: algebra@Algebra L4: 0/2; algebra@Algebra L5: 0/2; algebra@Counting & Probability L4: 0/2; algebra@Counting & Probability L5: 1/5; algebra@Geometry L4: 0/2; algebra@Geometry L5: 1/2; algebra@Intermediate Algebra L4: 0/5; algebra@Intermediate Algebra L5: 0/9; algebra@Number Theory L4: 0/1; algebra@Number Theory L5: 0/2; algebra@Prealgebra L5: 0/3; algebra@Precalculus L4: 0/2; algebra@Precalculus L5: 0/3; careful@Algebra L4: 0/2; careful@Algebra L5: 0/2; careful@Counting & Probability L4: 0/3; careful@Counting & Probability L5: 1/5; careful@Geometry L4: 0/2; careful@Geometry L5: 0/1; careful@Intermediate Algebra L4: 0/4; careful@Intermediate Algebra L5: 0/8; careful@Number Theory L5: 0/3; careful@Prealgebra L5: 0/3; careful@Precalculus L4: 0/2; careful@Precalculus L5: 0/2; counter@Algebra L4: 0/1; counter@Algebra L5: 0/2; counter@Counting & Probability L4: 0/3; counter@Counting & Probability L5: 0/4; counter@Geometry L4: 0/1; counter@Geometry L5: 1/1; counter@Intermediate Algebra L4: 0/2; counter@Intermediate Algebra L5: 0/8; counter@Number Theory L4: 0/2; counter@Number Theory L5: 0/3; counter@Prealgebra L5: 0/1; counter@Precalculus L5: 0/2; critic@Algebra L4: 0/6; critic@Algebra L5: 0/6; critic@Counting & Probability L4: 0/2; critic@Counting & Probability L5: 1/3; critic@Geometry L4: 1/4; critic@Geometry L5: 1/2; critic@Intermediate Algebra L4: 0/6; critic@Intermediate Algebra L5: 1/7; critic@Number Theory L4: 0/3; critic@Number Theory L5: 0/4; critic@Prealgebra L4: 0/1; critic@Prealgebra L5: 1/4; critic@Precalculus L4: 0/2; critic@Precalculus L5: 1/3; judge@Counting & Probability L5: 1/1; judge@Geometry L5: 1/1; judge@Intermediate Algebra L5: 1/3; judge@Precalculus L5: 1/1

## HR usage
Employees assigned (questions): judge 123, critic 112, careful 104, algebra 73, counter 63, fast 43
Skills switched on (times): final_format 471, reread_question 469, confidence_calibration 450, sanity_check 370, verify_by_substitution 261, algebraic_substitution 106, check_units 49, solve_linear 48, geometry_area 35, coordinate_lines 27, combinatorics_cases 22, number_factors 19, diagram_extract 18, fraction_percent 17, counting_digits 14, exponent_rules 13, polynomial_roots 9, complex_roots 7, permutations_restrictions 6, parabola_vertex 6, gcd_coprime 6, inverse_function 5, inclusion_exclusion 5, divisibility 5, matrix_power 4, complete_square 4, sequence_sum 3, functional_equation 2, near_power_zeros 2, surd_power_rounding 1
Guide notes written: 79
Invalid HR outputs, first problems: ['bad JSON: Invalid \\escape: line 1 column 750 (char 749)']; ['bad JSON: Unterminated string starting at: line 1 column 578 (char 577)']; ["bad JSON: Expecting ',' delimiter: line 1 column 223 (char 222)"]; ["bad JSON: Expecting ',' delimiter: line 14 column 4 (char 263)"]

## Saved wrong: org failed, full team succeeded (3)
- [Algebra L5] How many zeros are in the expansion of $999,\!999,\!999,\!998^2$?
  plan: self (answered 23); answered 23, correct 11
- [Intermediate Algebra L5] Let
\[x^8 + 98x^4 + 1 = p(x) q(x),\]where $p(x)$ and $q(x)$ are monic, non-constant polynomials with integer coefficients.  Find $p(1) + q(1).$
  plan: team solve=[careful:off, algebra:off, counter:off] review=[critic:off] decide=[judge:off]; answered 1, correct 20
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: team solve=[careful:low+reread_question/check_units/coordinate_lines/geometry_area/verify_by_substitution/sanity_check, algebra:low+reread_question/algebraic_substitution/verify_by_substitution, counter:low+reread_question/sanity_check] review=[critic:low+reread_question/verify_by_substitution/geometry_area/sanity_check] decide=[judge:high] guide: algebra: "Maximize area function of theta. Check endpoints and critical points."; counter: "Verify domain of theta and behavior at boundaries."; careful: "Model lines as functions of time theta. Find intersections."; answered -1, correct 85

Both wrong: 7.

## Most expensive correctly-solved questions (possible waste)
- [Intermediate Algebra L5, cost 29707] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  plan: team solve=[algebra:low+reread_question/algebraic_substitution/functional_equation/verify_by_substitution/final_format/confidence_calibration, counter:low+reread_question/final_format/confidence_calibration] review=[careful:low+reread_question/algebraic_substitution/verify_by_substitution/sanity_check/final_format/confidence_calibration, critic:low+reread_question/verify_by_substitution/sanity_check/functional_equation/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: algebra: "Derive f(2^k) recursively, then handle 2002 via decomposition."; judge: "Confirm the unique solution and format the final answer."; critic: "Ensure no arithmetic errors in the recursive step or final calculation."; counter: "Check base cases k=1,2,3 to find pattern for powers of 2."; careful: "Verify the derived formula against small inputs and constraints."
- [Counting & Probability L5, cost 26123] A bored student walks down a hall that contains a row of closed lockers, numbered $1$ to $1024$. He opens the locker numbered 1, and then alternates between skipping and opening ea
  plan: team solve=[careful:low+reread_question/check_units/sanity_check/verify_by_substitution/final_format/confidence_calibration, counter:low+reread_question/combinatorics_cases/inclusion_exclusion/number_factors/gcd_coprime/sanity_check/final_format/confidence_calibration] review=[algebra:low+reread_question/algebraic_substitution/verify_by_substitution/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: algebra: "Model the second pass sequence mathematically."; counter: "Identify lockers that remain closed after first pass."; careful: "Track first pass open/close pattern carefully."; judge: "Verify the specific number 1023 against constraints."
- [Geometry L5, cost 25356] The graphs of the equations
$y=k, \qquad y=\sqrt{3}x+2k, \qquad y=-\sqrt{3}x+2k,$
are drawn in the coordinate plane for $k=-10,-9,-8,\ldots,9,10.\,$ These 63 lines cut part of the 
  plan: team solve=[counter:low+reread_question/sanity_check/final_format/confidence_calibration, algebra:low+reread_question/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/geometry_area/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: algebra: "Verify intersection points form equilateral triangles and count regions systematically."; critic: "Confirm no overlapping counts and correct interpretation of 'such triangles'."; counter: "Check if side length 2/sqrt(3) matches distance between parallel lines."
- [Number Theory L5, cost 25242] Let $\tau (n)$ denote the number of positive integer divisors of $n$ (including $1$ and $n$). Find the sum of the six least positive integers $n$ that are solutions to $\tau (n) + 
  plan: team solve=[careful:low+reread_question/solve_linear/sanity_check/verify_by_substitution/final_format/confidence_calibration, counter:low+reread_question/counting_digits/number_factors/gcd_coprime/sequence_sum/divisibility/sanity_check/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: counter: "Focus on n where tau(n) is 1, 2, 3, or 4 to sum to 7."; judge: "Sum the first 6 valid n values found."; careful: "Must check n and n+1 divisor counts simultaneously for small integers."; critic: "Verify all 6 candidates satisfy the equation exactly."
- [Precalculus L5, cost 24042] Let $\omega$ be a nonreal root of $x^3 = 1,$ and let
\[\mathbf{M} = \begin{pmatrix} -\omega^2 & - \omega \\ 1 & 0 \end{pmatrix}.\]Find the sum of the entries of $\mathbf{M} + \math
  plan: team solve=[algebra:low+reread_question/algebraic_substitution/matrix_power/verify_by_substitution/final_format/confidence_calibration, counter:low+reread_question/sanity_check/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/matrix_power/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: counter: "Verify periodicity and sum entries directly."; judge: "Select final answer based on verified sum."; algebra: "Compute periodicity of powers, then sum geometric series of matrices."; critic: "Check matrix multiplication and sum logic."