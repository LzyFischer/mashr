# Diagnostic report (dev-A)

Organization: acc 96.7%, cost 11976/question, of which the HR 3211 (HR prompt 6714 chars). Full system: acc 100.0%, cost 16876. 20 distinct architectures, 1.5 nodes per question. HR outputs: repaired 0, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 7 | 100% | 100% | 7647 | 13738 | solver.low 2, solver.high[T][S]>verifier.high[T]? 1, solver.high 1 |
| Algebra L5 | 4 | 100% | 100% | 8403 | 15069 | solver.low[T] 1, solver.high 1, solver.high[S] 1 |
| Counting & Probability L5 | 4 | 100% | 100% | 9000 | 17490 | counter.high[T][S] 2, coder.high[T] 1, counter.high[T][S]>verifier.high[T] 1 |
| Geometry L4 | 1 | 100% | 100% | 7107 | 9832 | solver.low[T][S] 1 |
| Intermediate Algebra L4 | 1 | 100% | 100% | 10558 | 16257 | coder.high[T][S]>verifier.high[T]? 1 |
| Intermediate Algebra L5 | 4 | 100% | 100% | 23216 | 22389 | coder.high[T][S]>verifier.max[T] 1, coder.high[T][S]>verifier.low[T]? 1, coder.high[T][S],solver.high[T][S]>verifier.max[T]? 1 |
| Number Theory L4 | 1 | 100% | 100% | 10522 | 17624 | solver.high[T][S]>verifier.max[T]? 1 |
| Number Theory L5 | 3 | 100% | 100% | 13015 | 18225 | solver.high[T][S]>verifier.max[T] 1, coder.high[T][S]>verifier.max[T] 1, coder.low[T] 1 |
| Prealgebra L4 | 1 | 100% | 100% | 4830 | 9334 | coder.low[T] 1 |
| Prealgebra L5 | 3 | 67% | 100% | 11449 | 19272 | coder.high[T][S],solver.high[T]>verifier.max[T]? 1, solver.low 1, solver.high[T][S]>verifier.max[T]? 1 |
| Precalculus L5 | 1 | 100% | 100% | 36863 | 24783 | coder.xhigh[T][S],solver.xhigh[T][S]>verifier.max[T] 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| solver.low | 3 | 100% | 5653 |
| coder.high[T][S]>verifier.max[T] | 2 | 100% | 16669 |
| solver.low[T] | 2 | 100% | 7062 |
| counter.high[T][S] | 2 | 100% | 10610 |
| solver.high | 2 | 100% | 7778 |
| coder.low[T] | 2 | 100% | 6487 |
| solver.high[T][S]>verifier.max[T] | 2 | 100% | 19012 |
| solver.high[T][S]>verifier.max[T]? | 2 | 100% | 10452 |
| solver.low[T][S] | 2 | 100% | 7226 |
| solver.high[T][S]>verifier.high[T]? | 1 | 100% | 10345 |
| coder.high[T][S]>verifier.high[T]? | 1 | 100% | 10558 |
| coder.high[T][S]>verifier.low[T]? | 1 | 100% | 18700 |
| geometer.high[T][S] | 1 | 100% | 10451 |
| coder.high[T][S],solver.high[T]>verifier.max[T]? | 1 | 0% | 20039 |
| coder.xhigh[T][S],solver.xhigh[T][S]>verifier.max[T] | 1 | 100% | 36863 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| solver.high | 10 | 80% | 90% | 7105 | - | - | - |
| verifier.max (with inputs) | 9 | 89% | 0% | 5261 | 1 | 1 | - |
| coder.high | 7 | 71% | 100% | 8611 | - | - | - |
| solver.low | 7 | 100% | 100% | 3443 | - | - | - |
| verifier.high (with inputs) | 3 | 100% | 0% | 680 | - | - | - |
| counter.high | 3 | 100% | 67% | 5256 | - | - | - |
| coder.low | 3 | 100% | 100% | 4000 | - | - | - |
| verifier.low (with inputs) | 1 | 100% | 0% | 0 | - | - | - |
| geometer.high | 1 | 100% | 100% | 7029 | - | - | - |
| solver.xhigh | 1 | 100% | 100% | 11949 | - | - | - |
| coder.xhigh | 1 | 100% | 100% | 11395 | - | - | - |

## Leave-one-out on 10 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.max (output) | 7 | 1 | 0 | 6 | 6764 |
| coder.high (input) | 6 | 2 | 0 | 4 | 6777 |
| solver.high (input) | 5 | 1 | 0 | 4 | 6854 |
| verifier.high (output) | 2 | 0 | 0 | 2 | 0 |
| verifier.low (output) | 1 | 0 | 0 | 1 | 0 |
| solver.xhigh (input) | 1 | 0 | 0 | 1 | 16456 |
| coder.xhigh (input) | 1 | 0 | 0 | 1 | 13067 |

## Residual harness (what the HR gave each node)
| item | nodes given it | node answer correct when given | node answer correct otherwise |
|---|---|---|---|
| note | 46 | 90% | - |
| tool:python | 34 | 89% | 92% |
| tool:check_answer | 19 | 93% | 88% |
| skill:case_split | 12 | 83% | 93% |
| tool:exact_solve | 10 | 90% | 90% |
| skill:substitute_back | 10 | 100% | 87% |
| no tools (no Python) | 6 | 100% | 88% |
| skill:exact_enumeration | 5 | 80% | 91% |
| tool:brute_force | 3 | 50% | 92% |
| tool:simplify_exact | 2 | 50% | 92% |
| tool:number_theory | 2 | 100% | 89% |
| tool:coord_geometry | 1 | 100% | 90% |
| skill:coordinate_area | 1 | 100% | 90% |
| skill:small_cases | 1 | 0% | 92% |

only_if="disagree": 7 nodes, skipped 6 (inputs agreed); question correct when skipped 83%, when run 100%.
Notes: 46 nodes got one, mean 131 chars. Example: Convert radicals to fractional exponents, equate powers of 2, solve for Q.

## Residual ablation on 10 questions (that component removed from every node)
'needed' = right becomes wrong without it; 'harmful' = wrong becomes right without it.
| removed | questions | needed | harmful | no effect |
|---|---|---|---|---|
| notes | 10 | 0 | 1 | 9 |
| skills | 7 | 0 | 0 | 7 |
| tools | 9 | 0 | 1 | 8 |

HR output problems: minor: line 1: unknown tools/skills ['brute_force'] dropped (1)

## Organization wrong, full system right (1)
- [Prealgebra L5] The area of the shaded region is 78 square inches. All angles are right angles and all measurements are given in inches. What is the perimeter of the non-shaded region?

[asy]size(101);
filldraw(((0,0)--(0,8)--(10,8)--(10,-2)--(6,-2)--(6,0)--cycle^^(2.5,3)--(2.5,5)--(7.5,5)--(7.5
  architecture: a = coder("high", tools=['python', 'brute_force'], skills=['case_split', 'exact_enumeration'])  # note: Calculate total area of the outer polygon (88) and inner rectangle (12.5). Deter; b = solver("high", tools=['python', 'simplify_exact'])  # note: Compute perimeter directly from coordinates once configuration is fixed.; v = verifier("max", a, b, tools=['python', 'check_answer'], only_if="disagree")  # note: Verify perimeter calculation against area constraint.; return v; answered 10, correct 14

Both wrong: 0.

## Most expensive correct questions (possible waste)
- [Precalculus L5, cost 36863] Let $\omega$ be a nonreal root of $x^3 = 1,$ and let
\[\mathbf{M} = \begin{pmatrix} -\omega^2 & - \omega \\ 1 & 0 \end{pmatrix}.\]Find the sum of the entries of $\mathbf{M} + \math
  architecture: a = solver("xhigh", tools=['python', 'exact_solve', 'check_answer'], skills=['case_split', 'substitute_back'])  # note: Verify M^3=I and calculate M+M^2+I entries sum.; b = coder("xhigh", tools=['python', 'exact_solve', 'check_answer'], skills=['case_split', 'exact_enumeration'])  # note: Compute sum using M^3=I cycle and matrix multiplication.; v = verifier("max", a, b, tools=['python', 'check_answer'])  # note: Final verification of sum of entries.; return v
- [Intermediate Algebra L5, cost 33705] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  architecture: a = solver("high", tools=['exact_solve'], skills=['case_split'])  # note: f(x) + f(2^n - x) = n^2 for 2^{n-1} < x < 2^n. Reduce 2002 -> 46 -> 18 -> 14 -> ; b = coder("high", tools=['python', 'check_answer'], skills=['small_cases'])  # note: f(2^k) = (k+1)^2 / 2. Verify f(2)=2.; v = verifier("max", a, b, tools=['python', 'check_answer'], only_if="disagree")  # note: Check f(2002) = 96 satisfies f(2002) + f(46) = 121, f(46) + f(18) = 36, etc.; return v
- [Intermediate Algebra L5, cost 20915] Find the sum of all complex numbers $z$ that satisfy
\[z^3 + z^2 - |z|^2 + 2z = 0.\]
  architecture: a = solver("high", tools=['python', 'exact_solve', 'check_answer'], skills=['case_split', 'substitute_back'])  # note:  1. Identify z=0 is a solution. 2. For z!=0, derive condition z^2 + z + 2 = conj; b = verifier("max", a, tools=['python', 'check_answer'])  # note:  Verify the sum of valid roots matches the derived answer. Check if any extraneo; return b
- [Intermediate Algebra L5, cost 19545] During the car ride home, Michael looks back at his recent math exams. A problem on Michael's calculus mid-term gets him starting thinking about a particular quadratic,\[x^2-sx+p,\
  architecture: a = coder("high", tools=['python', 'exact_solve', 'check_answer'], skills=['case_split', 'substitute_back'])  # note: Let S_k = r_1^k + r_2^k. Use Newton sums S_k = s S_{k-1} - p S_{k-2}. Condition ; b = verifier("max", a, tools=['python', 'check_answer'])  # note: Verify s=2, p=1 satisfies all S_k equalities. Check target value calculation. No; return b
- [Intermediate Algebra L5, cost 18700] There is a unique polynomial $P(x)$ of degree $8$ with rational coefficients and leading coefficient $1,$ which has the number \[\sqrt{2} + \sqrt{3} + \sqrt{5}\]as a root. Compute 
  architecture: a = coder("high", tools=['python', 'exact_solve'], skills=['case_split'])  # note: The minimal polynomial has roots $\pm\sqrt{2}\pm\sqrt{3}\pm\sqrt{5}$. Compute $P; b = verifier("low", a, tools=['python', 'check_answer'], only_if="disagree")  # note: Re-calculate the product to verify the integer result matches.; return b