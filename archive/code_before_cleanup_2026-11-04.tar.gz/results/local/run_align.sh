#!/bin/bash
# alignment test: local vLLM (GPU 3, port 8001) vs Tinker on MATH test; designer not used
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
export MASHR_LOCAL_MODELS=Qwen/Qwen3.5-9B MASHR_LOCAL=http://localhost:8001/v1
PYTHONPATH=. ~/miniconda3/envs/tinker/bin/python results/local/align.py results/local/align.json > results/local/align.out 2>&1
