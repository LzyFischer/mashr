# Diagnostic report (dev-A)

Organization: acc 94.7%, cost 19295/question, of which the HR 1845 (HR prompt 3964 chars). 26 distinct architectures, 2.5 nodes per question. HR outputs: repaired 0, written again 2, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Counting & Probability L5 | 40 | 92% | - | 22128 | 0 | coder.high>verifier.high 10, coder.low>verifier.low 8, reader.low>coder.high>verifier.high 5 |
| Number Theory L5 | 42 | 100% | - | 18358 | 0 | coder.high>verifier.high 24, coder.low>verifier.low 6, coder.high>solver.high>verifier.high 2 |
| Prealgebra L5 | 44 | 95% | - | 14766 | 0 | coder.low>verifier.low 23, coder.high>verifier.high 7, reader.low>coder.high>verifier.high 6 |
| Precalculus L5 | 24 | 88% | - | 24519 | 0 | coder.high>verifier.high 8, coder.high>solver.high>verifier.high 4, reader.low>coder.high,solver.high>verifier.max 3 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.high>verifier.high | 49 | 96% | 16316 |
| coder.low>verifier.low | 37 | 100% | 9477 |
| reader.low>coder.high>verifier.high | 11 | 82% | 22075 |
| reader.low>coder.high,solver.high>verifier.max | 8 | 75% | 35423 |
| coder.high>solver.high>verifier.high | 7 | 86% | 24897 |
| coder.high,solver.high>verifier.high | 7 | 86% | 26732 |
| reader.low>coder.high>solver.high>verifier.max | 6 | 100% | 37156 |
| reader.low>coder.high,solver.high>verifier.high | 4 | 100% | 24455 |
| coder.low>verifier.high | 3 | 100% | 15638 |
| coder.high,solver.high>verifier.max | 2 | 100% | 34633 |
| reader.high>coder.high>verifier.max | 1 | 100% | 21501 |
| reader.low>coder.high>verifier.max | 1 | 100% | 21586 |
| reader.low,solver.high>verifier.max | 1 | 100% | 24275 |
| solver.high>coder.low>verifier.high | 1 | 100% | 29531 |
| coder.max>verifier.max | 1 | 100% | 29622 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| verifier.high (with inputs) | 86 | 93% | 97% | 7423 | 20 | 14 | 5 |
| coder.high | 68 | 88% | 97% | 7471 | - | - | - |
| coder.low | 41 | 93% | 98% | 4003 | - | - | - |
| verifier.low (with inputs) | 38 | 100% | 100% | 3792 | 3 | 3 | 1 |
| reader.low | 34 | 38% | 100% | 4620 | - | - | - |
| coder.high (with inputs) | 32 | 84% | 84% | 7908 | 20 | 15 | 1 |
| solver.high (with inputs) | 30 | 80% | 100% | 7767 | 15 | 9 | 1 |
| verifier.max (with inputs) | 25 | 92% | 16% | 11693 | 8 | 6 | - |
| solver.high | 12 | 67% | 100% | 9778 | - | - | - |
| coder.low (with inputs) | 2 | 100% | 100% | 4920 | - | - | - |
| coder.xhigh | 2 | 50% | 100% | 11875 | - | - | - |
| solver.max | 2 | 100% | 50% | 16342 | - | - | - |
| reader.high | 1 | 100% | 100% | 7360 | - | - | - |
| coder.max | 1 | 100% | 100% | 20484 | - | - | - |
| coder.xhigh (with inputs) | 1 | 100% | 100% | 11637 | 1 | 1 | - |
| reader.low (with inputs) | 1 | 100% | 100% | 4394 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| coder.high (input) | 42 | 2 | 2 | 38 | 7144 |
| verifier.high (output) | 32 | 2 | 1 | 29 | 7228 |
| solver.high (input) | 19 | 1 | 2 | 16 | 8516 |
| reader.low (input) | 16 | 2 | 1 | 13 | 2132 |
| verifier.max (output) | 15 | 5 | 0 | 10 | 12474 |
| coder.low (input) | 14 | 1 | 0 | 13 | 4012 |
| verifier.low (output) | 13 | 1 | 0 | 12 | 3979 |
| coder.xhigh (input) | 2 | 0 | 0 | 2 | 7928 |
| reader.high (input) | 1 | 0 | 0 | 1 | -607 |
| coder.max (input) | 1 | 0 | 0 | 1 | 7314 |

HR output problems: minor: line 1: non-node argument ignored (12)

## Organization wrong (8)
- [Counting & Probability L5] Let $N$ be the number of positive integers that are less than or equal to $2003$ and whose base-$2$ representation has more $1$'s than $0$'s. Find the remainder when $N$ is divided by $1000$.
  architecture: c = coder("high"); v = verifier("high", c); return v; answered 99 (from 7Cj, j>=3): $\binom{7}{3}=35$. $\binom{7}{4}=35$. $\binom{7}{5}=21$. $\binom{7}{6}=7$. $\, correct 155
- [Counting & Probability L5] A standard six-sided fair die is rolled four times. The probability that the product of all four numbers rolled is a perfect square is $\tfrac{m}{n}$, where $m$ and $n$ are relatively prime positive integers. Find $m+n$.
  architecture: c = coder("high"); s = solver("high", c); v = verifier("high", c, s); return v; answered 749, correct 187
- [Prealgebra L5] A square and a regular heptagon  are coplanar and share a common side $\overline{AD}$, as shown. What is the degree measure of exterior angle $BAC$?  Express your answer as a common fraction.

[asy]
for(int i=0; i <=7; ++i) {
draw(dir(360*i/7+90)--dir(360*(i+1)/7+90));
}
pair A =
  architecture: r = reader("low"); c = coder("high", r); s = solver("high", r); v = verifier("max", r, c, s); return v; answered \frac{1530}{7}, correct \frac{990}{7}^\circ
- [Precalculus L5] In the diagram below, triangle $ABC$ has been reflected over its median $\overline{AM}$ to produce triangle $AB'C'$.  If $AE = 6$, $EC =12$, and $BD = 10$, then find $AB$.

[asy]
size(250);
pair A,B,C,D,M,BB,CC,EE;
B = (0,0);
D = (10,0);
M = (15,0);
C=2*M;
A = D + (scale(1.2)*rot
  architecture: r = reader("low"); c = coder("high", r); s = solver("high", r); out = verifier("max", r, c, s); return out; answered \frac{4\sqrt{141}}{3}, correct 8\sqrt{3}
- [Prealgebra L5] Each of the boxes in the figure below is a square. How many different squares can be traced using the lines in the figure?

[asy]
unitsize(0.2inch);
draw((0,1)--(1,1)--(1,4)--(0,4)--(0,1));
draw((1,1)--(1,0)--(2,0)--(2,5)--(1,5)--(1,4));
draw((2,0)--(3,0)--(3,5)--(2,5));
draw((3,
  architecture: r = reader("low"); c = coder("high", r); v = verifier("high", r, c); return v; answered *   $H_0$ ($1-4, correct 38
- [Precalculus L5] In triangle $ABC$, $3 \sin A + 4 \cos B = 6$ and $4 \sin B + 3 \cos A = 1$. Find all possible values of $\angle C,$ in degrees.  Enter all the possible values, separated by commas.
  architecture: a = solver("high"); c = coder("high"); v = verifier("high", a, c); return v; answered 121 \cos B + 33\sqrt{3} \sin B = 1, correct 30^\circ
- [Counting & Probability L5] Five standard six-sided dice are rolled.  We are told there is no three-of-a-kind, but there is a pair of dice that show the same number.  These two dice are set aside, and the other three dice are re-rolled.  What is the probability that after re-rolling these three dice, at lea
  architecture: r = reader("low"); c = coder("high", r); out = verifier("high", r, c); return out; answered - If I have $\{1,1,2,2,3\}$, and I am told "There is a pair", I point to the 1s. "These two dice, correct \frac{4}{9}
- [Precalculus L5] Let $a$ and $b$ be angles such that
\[\cos (a + b) = \cos a + \cos b.\]Find the maximum value of $\cos a.$
  architecture: c = coder("high"); v = verifier("high", c); return v; answered So the valid interval for $u$ is $[-1, -1+\sqrt{, correct \sqrt{3} - 1

## Most expensive correct questions (possible waste)
- [Counting & Probability L5, cost 62618] Matt will arrange four identical, dotless dominoes (shaded 1 by 2 rectangles) on the 5 by 4 grid below so that a path is formed from the upper left-hand corner $A$ to the lower rig
  architecture: r = reader("low"); c = coder("high", r); s = solver("high", r, c); out = verifier("max", r, c, s); return out
- [Counting & Probability L5, cost 38452] In an office at various times during the day, the boss gives the secretary a letter to type, each time putting the letter on top of the pile in the secretary's in-box. When there i
  architecture: c = coder("high"); s = solver("high"); out = verifier("max", c, s); return out
- [Counting & Probability L5, cost 37716] Two quadrilaterals are considered the same if one can be obtained from the other by a rotation and a translation. How many different convex cyclic quadrilaterals are there with int
  architecture: c = coder("xhigh"); s = solver("high", c); v = verifier("max", c, s); return v
- [Precalculus L5, cost 37109] On the complex plane, the parallelogram formed by the points 0, $z,$ $\frac{1}{z},$ and $z + \frac{1}{z}$ has area $\frac{35}{37}.$  If the real part of $z$ is positive, let $d$ be
  architecture: r = reader("low"); c = coder("high", r); s = solver("high", r, c); v = verifier("max", r, c, s); return v
- [Number Theory L5, cost 36975] For a positive integer $n$ and nonzero digits $a$, $b$, and $c$, let $A_n$ be the $n$-digit integer each of whose digits is equal to $a$; let $B_n$ be the $n$-digit integer each of
  architecture: a = solver("max"); b = coder("high"); c = verifier("max", a, b); return c