"""Alignment test: the same systems on MATH test (156, integer L4-5) with the 9B served locally by vLLM
vs on Tinker (Tinker numbers from results/rsi5/math_acc/test.json, already computed).

  MASHR_LOCAL_MODELS=Qwen/Qwen3.5-9B MASHR_LOCAL=http://localhost:8001/v1 \
    PYTHONPATH=. $P results/local/align.py results/local/align.json
"""
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor

from mashr.exec5 import Engine
from mashr.ledger import Ledger
from mashr.llm import LLM, LOCAL_MODELS
from mashr.org5 import BASELINES, HAND, parse_program
from mashr.orgrsi import load_items
from mashr.rsi5 import evaluate, summarize

assert "Qwen/Qwen3.5-9B" in LOCAL_MODELS, "set MASHR_LOCAL_MODELS=Qwen/Qwen3.5-9B"
llm = LLM()
led = Ledger(llm, lambda m: print(m, flush=True))
eng = Engine(llm)
test = load_items("math", "test", 0, 156)
tinker = json.load(open("results/rsi5/math_acc/test.json"))
final = json.load(open("results/rsi5/math_acc/final_pool.json"))
jobs = {"single_high": (HAND, parse_program(HAND, BASELINES["single_high"])[0]),
        "single_max": (HAND, parse_program(HAND, BASELINES["single_max"])[0]),
        "org_final": (final, None)}
res = {}
with led.stage("local alignment (3 systems x 156)"):
    with ThreadPoolExecutor(len(jobs)) as ex:
        out = dict(zip(jobs, ex.map(lambda j: summarize(evaluate(eng, j[0], test, j[1])),
                                    jobs.values())))
for k, s in out.items():
    t = tinker[k]
    res[k] = {"local": s, "tinker": t}
    print(f"{k:12s} local {s['acc']:.3f} @{s['cost'] / 1000:.1f}k | tinker {t['acc']:.3f} "
          f"@{t['cost'] / 1000:.1f}k", flush=True)
json.dump(res, open(sys.argv[1], "w"), indent=1)
led.dump(sys.argv[1].replace(".json", "_costs.json"))
