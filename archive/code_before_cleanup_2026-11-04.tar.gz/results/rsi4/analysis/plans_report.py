"""Summarize plans.json: per-architecture accuracy/cost by level, the per-question oracle router, and
the best router that only knows the level (L4/L5)."""
import json
import sys

d = json.load(open(sys.argv[1]))
items, P = d["items"], d["plans"]
n = len(items)
lv = {"L4": [i for i, it in enumerate(items) if not it["hard"]],
      "L5": [i for i, it in enumerate(items) if it["hard"]]}
acc = lambda k, ix: sum(P[k][i]["correct"] for i in ix) / len(ix)
cost = lambda k, ix: sum(P[k][i]["cost"] for i in ix) / len(ix)

print(f"{'architecture':24s} {'all':>6s} {'L4':>6s} {'L5':>6s} {'cost':>7s} {'L4 cost':>8s} {'L5 cost':>8s}")
for k in sorted(P, key=lambda k: cost(k, range(n))):
    print(f"{k:24s} {acc(k, range(n)):6.1%} {acc(k, lv['L4']):6.1%} {acc(k, lv['L5']):6.1%} "
          f"{cost(k, range(n)):7.0f} {cost(k, lv['L4']):8.0f} {cost(k, lv['L5']):8.0f}")

# oracle: cheapest architecture that is right; if none, the cheapest overall (counted wrong)
ok = c = 0
for i in range(n):
    right = [k for k in P if P[k][i]["correct"]]
    pick = min(right or P, key=lambda k: P[k][i]["cost"])
    ok += P[pick][i]["correct"]
    c += P[pick][i]["cost"]
print(f"\noracle router (cheapest right architecture per question): acc {ok / n:.1%}, cost {c / n:.0f}")
print(f"solved by no architecture: {sum(not any(P[k][i]['correct'] for k in P) for i in range(n))}")

# level-aware router: for each level the architecture pair maximizing acc - lambda * cost
for lam in (0, 2e-6, 5e-6):
    best = {l: max(P, key=lambda k: acc(k, ix) - lam * cost(k, ix)) for l, ix in lv.items()}
    a = sum(acc(best[l], ix) * len(ix) for l, ix in lv.items()) / n
    cc = sum(cost(best[l], ix) * len(ix) for l, ix in lv.items()) / n
    print(f"level router (lambda {lam:g}/token): L4 -> {best['L4']}, L5 -> {best['L5']}: "
          f"acc {a:.1%}, cost {cc:.0f}")
