# Diagnostic report (dev-A)

Pool: acc 90.0%, cost 6361/question (6045 generated, 1581 prompt tokens; cost = generated + 0.2 x prompt). Full system: acc 91.3%, cost 17252. Orchestrator: mode fixed, recipe adaptive_checked. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 3755 | 13285 | base_solve>code_check?>final_pick? 17 |
| Algebra L5 | 18 | 100% | 100% | 3605 | 15585 | base_solve>code_check?>final_pick? 18 |
| Counting & Probability L4 | 8 | 100% | 100% | 5024 | 15676 | base_solve>code_check?>final_pick? 8 |
| Counting & Probability L5 | 9 | 89% | 89% | 7520 | 19103 | base_solve>code_check?>final_pick? 9 |
| Geometry L4 | 5 | 100% | 100% | 5468 | 15889 | base_solve>code_check?>final_pick? 5 |
| Geometry L5 | 7 | 57% | 57% | 9893 | 22647 | base_solve>code_check?>final_pick? 7 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 7424 | 18210 | base_solve>code_check?>final_pick? 14 |
| Intermediate Algebra L5 | 17 | 65% | 71% | 10173 | 21465 | base_solve>code_check?>final_pick? 17 |
| Number Theory L4 | 9 | 100% | 100% | 6737 | 17149 | base_solve>code_check?>final_pick? 9 |
| Number Theory L5 | 16 | 88% | 88% | 6633 | 18165 | base_solve>code_check?>final_pick? 16 |
| Prealgebra L4 | 12 | 100% | 100% | 2983 | 10794 | base_solve>code_check?>final_pick? 12 |
| Prealgebra L5 | 9 | 100% | 89% | 5738 | 17096 | base_solve>code_check?>final_pick? 9 |
| Precalculus L4 | 3 | 67% | 100% | 7909 | 20027 | base_solve>code_check?>final_pick? 3 |
| Precalculus L5 | 6 | 67% | 83% | 11029 | 22960 | base_solve>code_check?>final_pick? 6 |

## First steps (by block): accuracy of their answer
| block | uses | answer correct | mean cost |
|---|---|---|---|
| base_solve | 150 | 84% | 4381 |

## Later steps (block and condition): how often they ran and changed the answer
| step | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| code_check if hard | 150 | 57 | 24 | 8 | 0 | 4986 |
| final_pick if shaky | 150 | 7 | 4 | 2 | 1 | 1831 |

## Signals after the first step (150 questions, 24 with a wrong answer at that point)
Would this signal/condition catch the wrong first answers? fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 0 | 0% | 0% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 1 | 0% | 0% |
| agree < 1 | 0 | 0% | 0% |
| agree < 0.67 | 0 | 0% | 0% |
| tokens > 1000 | 148 | 16% | 100% |
| tokens > 2000 | 144 | 17% | 100% |
| tokens > 4000 | 57 | 42% | 100% |
| [shaky] fail or missing | 0 | 0% | 0% |
| [hard] tokens >= 4000 or tool_error or missing | 57 | 42% | 100% |

## Leave-one-out replay on 57 questions with 2+ agent turns
Remove the agent from that step (agent@block<step>) or the whole step, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| step code_check2 if hard | 57 | 9 | 0 | 48 | 5211 |
| step final_pick3 if shaky | 7 | 2 | 1 | 4 | 1831 |

## Orchestrator usage
Recipes picked: adaptive_checked 150
Architectures: base_solve>code_check?>final_pick? 150
Blocks: base_solve 150, code_check 150, final_pick 150; never used: none
Conditions: always 150, hard 150, shaky 150
Agent assignments: solver 150, coder 150, judge 150
Skills switched on: format_answer 450, reread_question 300, python_checks 300, exact_arithmetic 150, verify_by_substitution 150, case_enumeration 150, coordinate_geometry 150
Skills never switched on: none

## Pool wrong, full system right (4)
- [Intermediate Algebra L5] A nonzero polynomial with rational coefficients has all of the numbers \[1+\sqrt{2}, \; 2+\sqrt{3}, \;3+\sqrt{4},\; \dots, \;1000+\sqrt{1001}\]as roots. What is the smallest possible degree of such a polynomial?
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]; answered 29, correct 1970
- [Precalculus L4] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\frac{a + b \sqrt{c}}{d},$ where $a,$ $b,$ $c,$ $d$ are positive integers, in simplest form.  Find $a
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]; answered 7, correct 8
- [Precalculus L5] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection = perspective(6,3,2);

triple A, B, C, D, E, F, G, H;

A = (1,1,0);
B = (1,-1,0);
C = (-1,-1,0);
D 
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]; answered 2, correct 225
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]; answered 6, correct 85

Both wrong: 11.

## Most expensive correct questions (possible waste)
- [Intermediate Algebra L5, cost 16530] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]
- [Precalculus L5, cost 15316] Three unit circles are drawn so they are mutually tangent, as shown below.  A blue circle that is externally tangent to all three unit circles is drawn.  Finally, three red circles
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]
- [Intermediate Algebra L4, cost 15211] The equations $x^3 + Ax + 10 = 0$ and $x^3 + Bx^2 + 50 = 0$ have two roots in common.  Then the product of these common roots can be expressed in the form $a \sqrt[b]{c},$ where $a
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]
- [Counting & Probability L5, cost 14495] In how many different ways can 3 men and 4 women be placed into two groups of two people and one group of three people if there must be at least one man and one woman in each group
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]
- [Counting & Probability L5, cost 14298] The number of increasing sequences of positive integers $a_1 \le a_2 \le a_3 \le \cdots \le a_{10} \le 2007$ such that $a_i-i$ is even for $1\le i \le 10$ can be expressed as ${m \
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if hard[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration/coordinate_geometry] > final_pick if shaky[judge:off+format_answer/reread_question]