#!/bin/bash
# iterative RSI, phase 2 (cost): start from the phase-1 (accuracy) final organization; keep accuracy
# within delta of its own dev-B accuracy and cut cost.   usage: results/phase2/run.sh <dataset>
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
case "$1" in
  math) init=results/rsi5/math_acc/final_pool.json ;;
  *)    init=results/bench/$1/final_pool.json ;;
esac
~/miniconda3/envs/tinker/bin/python -m mashr.rsi5 --dataset "$1" --init-pool "$init" --objective cost \
  --rounds 5 --k 3 --loo-n 60 --out "results/phase2/$1" > "results/phase2/$1.out" 2>&1
