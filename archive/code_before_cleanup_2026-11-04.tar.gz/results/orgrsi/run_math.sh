#!/bin/bash
# org-RSI on MATH L4-5 (integer answers), hand-written vs founded initial organization
cd "$(dirname "$0")/../.."
set -a; source ~/.config/hrsi/tinker.env; set +a
P=~/miniconda3/envs/tinker/bin/python
A="--dataset math --rounds 5 --k 3 --n-dev-a 150 --n-dev-b 200 --n-test 156 --loo-n 60"
$P -m mashr.orgrsi $A --init hand  --out results/orgrsi/math_hand  > results/orgrsi/math_hand.out 2>&1 &
# start the second run only after the first has cached the full-team reference (shared cache)
until grep -q "floor on dev-B" results/orgrsi/math_hand/log.txt 2>/dev/null; do sleep 10; done
$P -m mashr.orgrsi $A --init found --out results/orgrsi/math_found > results/orgrsi/math_found.out 2>&1 &
wait
