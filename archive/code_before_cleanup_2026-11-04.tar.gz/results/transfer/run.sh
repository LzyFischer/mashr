#!/bin/bash
# transfer test: AIME 2022-2025, AFlow MATH L5 test, GSM-Hard (final org, round-0 org, single max)
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
PYTHONPATH=. ~/miniconda3/envs/tinker/bin/python results/transfer/run.py aime aflow_math gsmhard > results/transfer/run.out 2>&1
