"""Single solver (cot) on dev-A Level 5 at growing thinking budgets: accuracy, cost, and how often the
reasoning hits the budget. Writes budget.json."""
import json, sys
from concurrent.futures import ThreadPoolExecutor
from mashr.exec4 import Engine
from mashr.llm import LLM, THINK_BUDGET
from mashr.org4 import check_plan
from mashr.orgrsi import load_items
from mashr.rsi4 import evaluate
from plans import POOL

eng = Engine(LLM())
items = [it for it in load_items("math", "train", 0, 150) if it["hard"]]
levels = sys.argv[2].split(",")
def run(th):
    p = check_plan(POOL, {"stages": [{"nodes": [f"solver:{th}:cot"]}]})[0]
    return th, evaluate(eng, POOL, items, p)
with ThreadPoolExecutor(len(levels)) as ex:
    res = dict(ex.map(run, levels))
out = {}
for th, rows in res.items():
    b = THINK_BUDGET[th]
    cut = [r["calls"][0]["gen_tokens"] >= b for r in rows]
    out[th] = {"n": len(rows), "acc": sum(r["correct"] for r in rows) / len(rows),
               "cost": sum(r["cost"] for r in rows) / len(rows), "cut": sum(cut),
               "acc_cut": sum(r["correct"] for r, c in zip(rows, cut) if c) / max(1, sum(cut)),
               "acc_done": sum(r["correct"] for r, c in zip(rows, cut) if not c) / max(1, len(rows) - sum(cut)),
               "rows": [{"id": r["id"], "correct": r["correct"], "pred": r["pred"], "cost": r["cost"]} for r in rows]}
    print(th, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in out[th].items() if k != "rows"})
json.dump(out, open(sys.argv[1], "w"))
