# Diagnostic report (dev-A)

Organization: acc 80.0%, cost 26412/question, of which the HR 2049 (HR prompt 4993 chars). 60 distinct architectures, 2.3 nodes per question. HR outputs: repaired 1, written again 12, fallback 1.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| AIME 1983 | 2 | 100% | - | 19024 | 0 | algebra.high,coder.high>verifier.high 1, coder.low 1 |
| AIME 1985 | 3 | 33% | - | 20058 | 0 | geometry.high,solver.high>verifier.high 1, solver.high>verifier.high 1, coder.high>verifier.high 1 |
| AIME 1986 | 4 | 100% | - | 40334 | 0 | coder.high,discrete.high>verifier.high 1, solver.high>verifier.low 1, discrete.max>coder.high>verifier.high>judge.high 1 |
| AIME 1987 | 3 | 100% | - | 13213 | 0 | solver.high 2, geometry.high>verifier.high 1 |
| AIME 1988 | 1 | 0% | - | 18696 | 0 | discrete.high>verifier.high 1 |
| AIME 1989 | 2 | 50% | - | 13060 | 0 | solver.high>verifier.high 1, solver.high 1 |
| AIME 1991 | 1 | 100% | - | 61723 | 0 | geometry.max,solver.max>verifier.max>judge.max 1 |
| AIME 1992 | 2 | 100% | - | 28332 | 0 | geometry.high,solver.high>verifier.high 1, discrete.max>verifier.max 1 |
| AIME 1993 | 4 | 100% | - | 26105 | 0 | coder.high,solver.high>verifier.high 1, solver.high>coder.low 1, discrete.max>verifier.max 1 |
| AIME 1994 | 1 | 0% | - | 10126 | 0 | coder.high 1 |
| AIME 1995 | 2 | 100% | - | 19289 | 0 | solver.max 1, coder.high>verifier.high 1 |
| AIME 1996 | 2 | 100% | - | 26550 | 0 | coder.low,solver.high>verifier.high 1, discrete.high,solver.high>verifier.high 1 |
| AIME 1997 | 1 | 100% | - | 13892 | 0 | coder.high>verifier.high 1 |
| AIME 1999 | 6 | 83% | - | 13649 | 0 | solver.high 2, geometry.high>verifier.high 1, coder.high,solver.high>verifier.high 1 |
| AIME 2000 | 3 | 67% | - | 19981 | 0 | solver.high 1, algebra.high,solver.high>verifier.high 1, solver.high,solver.high>verifier.high 1 |
| AIME 2001 | 6 | 100% | - | 31173 | 0 | coder.high,solver.high>verifier.high 2, discrete.high 1, coder.high>verifier.high 1 |
| AIME 2002 | 3 | 67% | - | 27826 | 0 | discrete.high>verifier.high>judge.high 1, coder.high,solver.high>verifier.high>judge.high 1, geometry.high>solver.high>verifier.high 1 |
| AIME 2003 | 5 | 80% | - | 27064 | 0 | discrete.max 1, coder.high,geometry.high>verifier.high 1, solver.high 1 |
| AIME 2004 | 8 | 50% | - | 17277 | 0 | solver.high 2, geometry.high,solver.high>verifier.high 1, coder.high,discrete.high>verifier.high 1 |
| AIME 2005 | 8 | 100% | - | 19713 | 0 | solver.high 3, geometry.high 1, coder.high,solver.high>verifier.high 1 |
| AIME 2006 | 9 | 100% | - | 31274 | 0 | coder.high,solver.xhigh>verifier.high 2, solver.high 2, coder.max,geometry.max,solver.max>verifier.max>judge.max 1 |
| AIME 2007 | 5 | 40% | - | 18163 | 0 | coder.low>verifier.low 1, algebra.high>solver.high>verifier.high 1, coder.high,solver.high>verifier.high>judge.high 1 |
| AIME 2008 | 5 | 100% | - | 26610 | 0 | coder.max,solver.max>verifier.max 1, algebra.high,geometry.high>verifier.high 1, geometry.high,solver.high>verifier.high 1 |
| AIME 2009 | 3 | 100% | - | 14469 | 0 | solver.high 2, algebra.high>solver.high>verifier.high 1 |
| AIME 2010 | 5 | 60% | - | 15760 | 0 | solver.high 2, discrete.high>verifier.high 1, coder.high,solver.high>verifier.high 1 |
| AIME 2011 | 6 | 100% | - | 35964 | 0 | coder.high,geometry.high>verifier.high 1, coder.high,solver.high>verifier.high 1, coder.max,solver.max>verifier.max 1 |
| AIME 2012 | 3 | 67% | - | 19351 | 0 | coder.high 1, discrete.high>solver.high>verifier.high 1, solver.high>verifier.high 1 |
| AIME 2013 | 3 | 67% | - | 51582 | 0 | coder.max,discrete.max>verifier.max>judge.max 1, coder.max,discrete.max,geometry.max>verifier.max 1, coder.low>solver.low 1 |
| AIME 2014 | 7 | 57% | - | 41157 | 0 | coder.high>verifier.high 2, discrete.high>coder.high>verifier.high 1, algebra.max,coder.max>verifier.max 1 |
| AIME 2015 | 8 | 88% | - | 19192 | 0 | solver.high 2, solver.high>verifier.high 1, coder.high,solver.high>verifier.high>judge.high 1 |
| AIME 2016 | 4 | 50% | - | 37616 | 0 | geometry.high>solver.high>verifier.high 2, coder.max,discrete.max>verifier.max>judge.max 1, solver.low 1 |
| AIME 2017 | 6 | 83% | - | 27434 | 0 | discrete.high,solver.high>verifier.high 1, solver.high 1, coder.max 1 |
| AIME 2018 | 6 | 67% | - | 29713 | 0 | solver.high 1, coder.max>verifier.high 1, coder.high,solver.high>verifier.high>judge.high 1 |
| AIME 2019 | 1 | 100% | - | 55891 | 0 | coder.max,discrete.max>verifier.max>judge.max 1 |
| AIME 2020 | 6 | 100% | - | 37695 | 0 | discrete.low 1, coder.max,discrete.max,solver.max>verifier.max>judge.max 1, coder.max,solver.max>verifier.max 1 |
| AIME 2021 | 6 | 83% | - | 27079 | 0 | discrete.high,solver.high>verifier.high 1, coder.high 1, coder.high>solver.high>verifier.high 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| solver.high | 23 | 78% | 9539 |
| coder.high>verifier.high | 9 | 67% | 19461 |
| coder.high | 8 | 75% | 11598 |
| coder.high,solver.high>verifier.high | 8 | 75% | 26917 |
| solver.high>verifier.high | 6 | 100% | 15351 |
| geometry.high,solver.high>verifier.high | 5 | 60% | 28683 |
| coder.high,solver.high>verifier.high>judge.high | 4 | 75% | 36246 |
| discrete.high>verifier.high | 4 | 50% | 16054 |
| coder.max,discrete.max>verifier.max>judge.max | 3 | 100% | 63685 |
| geometry.high>solver.high>verifier.high | 3 | 67% | 28093 |
| discrete.high,solver.high>verifier.high | 3 | 67% | 26667 |
| geometry.high>verifier.high | 3 | 100% | 17706 |
| coder.low,solver.high>verifier.high | 3 | 100% | 23181 |
| coder.max,solver.max>verifier.max | 3 | 100% | 59460 |
| coder.high,discrete.high>verifier.high | 3 | 67% | 34506 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| verifier.high (with inputs) | 76 | 78% | 99% | 8519 | 22 | 10 | 3 |
| solver.high | 61 | 70% | 100% | 7679 | - | - | - |
| coder.high | 44 | 59% | 98% | 9446 | - | - | - |
| discrete.high | 25 | 80% | 96% | 8914 | - | - | - |
| verifier.max (with inputs) | 21 | 90% | 29% | 14182 | 7 | 5 | - |
| coder.max | 19 | 84% | 100% | 22344 | - | - | - |
| geometry.high | 18 | 44% | 100% | 8043 | - | - | - |
| judge.max (with inputs) | 13 | 85% | 31% | 13116 | 5 | 3 | - |
| solver.max | 11 | 55% | 100% | 20084 | - | - | - |
| discrete.max | 11 | 64% | 82% | 18331 | - | - | - |
| solver.high (with inputs) | 9 | 67% | 100% | 8066 | 4 | 1 | 1 |
| coder.low | 7 | 71% | 100% | 5340 | - | - | - |
| algebra.high | 7 | 86% | 100% | 7586 | - | - | - |
| judge.high (with inputs) | 6 | 83% | 67% | 6553 | 3 | 2 | - |
| geometry.max | 4 | 75% | 100% | 20064 | - | - | - |
| verifier.low (with inputs) | 3 | 67% | 100% | 3885 | 1 | - | - |
| solver.xhigh | 3 | 100% | 100% | 11537 | - | - | - |
| coder.high (with inputs) | 2 | 0% | 100% | 8442 | 2 | - | - |
| solver.low | 2 | 50% | 100% | 4948 | - | - | - |
| geometry.xhigh | 2 | 100% | 100% | 11725 | - | - | - |
| solver.low (with inputs) | 2 | 50% | 100% | 4866 | 1 | - | - |
| discrete.low | 1 | 100% | 100% | 4396 | - | - | - |
| algebra.max | 1 | 0% | 100% | 20517 | - | - | - |
| coder.low (with inputs) | 1 | 100% | 100% | 4361 | - | - | - |
| discrete.xhigh | 1 | 0% | 100% | 12343 | - | - | - |
| verifier.xhigh (with inputs) | 1 | 100% | 100% | 9456 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.high (output) | 45 | 5 | 3 | 37 | 8419 |
| solver.high (input) | 31 | 1 | 1 | 29 | 7919 |
| coder.high (input) | 21 | 2 | 2 | 17 | 10644 |
| geometry.high (input) | 12 | 0 | 0 | 12 | 8386 |
| discrete.high (input) | 11 | 0 | 3 | 8 | 8218 |
| coder.max (input) | 10 | 1 | 0 | 9 | 20205 |
| solver.max (input) | 6 | 1 | 0 | 5 | 20624 |
| verifier.max (input) | 6 | 0 | 0 | 6 | 13662 |
| judge.max (output) | 6 | 3 | 0 | 3 | 12350 |
| algebra.high (input) | 5 | 1 | 0 | 4 | 7646 |
| discrete.max (input) | 4 | 0 | 0 | 4 | 17591 |
| coder.low (input) | 4 | 0 | 0 | 4 | 4531 |
| verifier.high (input) | 4 | 0 | 0 | 4 | 8336 |
| judge.high (output) | 4 | 1 | 0 | 3 | 6524 |
| verifier.max (output) | 4 | 3 | 0 | 1 | 15404 |
| geometry.max (input) | 2 | 0 | 0 | 2 | 13351 |
| verifier.low (output) | 1 | 0 | 0 | 1 | 5539 |
| algebra.max (input) | 1 | 0 | 0 | 1 | 17512 |
| solver.xhigh (input) | 1 | 0 | 0 | 1 | 11604 |

HR output problems: minor: line 1: non-node argument ignored (8); minor: line 2: non-node argument ignored (3); syntax error: invalid syntax (line 1) (1); nodes ['b'] feed nothing (1)

## Organization wrong (30)
- [AIME 2004] Let $ABC$ be a triangle with sides 3, 4, and 5, and $DEFG$ be a 6-by-7 rectangle. A segment is drawn to divide triangle $ABC$ into a triangle $U_1$ and a trapezoid $V_1$ and another segment is drawn to divide rectangle $DEFG$ into a triangle $U_2$ and a trapezoid $V_2$ such that 
  architecture: a = geometry("high"); b = solver("high"); v = verifier("high", a, b); return v; answered 0.09375, correct 35
- [AIME 2017] Call a set $S$ product-free if there do not exist $a, b, c \in S$ (not necessarily distinct) such that $a b = c$ . For example, the empty set and the set $\{16, 20\}$ are product-free, whereas the sets $\{4, 16\}$ and $\{2, 8, 16\}$ are not product-free. Find the number of produc
  architecture: a = discrete("high"); b = solver("high"); out = verifier("high", a, b); return out; answered 2, correct 252
- [AIME 2007] An integer is called parity-monotonic if its decimal representation $a_{1}a_{2}a_{3}\cdots a_{k}$ satisfies $a_{i}<a_{i+1}$ if $a_{i}$ is odd , and $a_{i}>a_{i+1}$ if $a_{i}$ is even . How many four-digit parity-monotonic integers are there?
  architecture: a = coder("low"); b = verifier("low", a); return b; answered 4, correct 640
- [AIME 2018] Find the number of functions $f$ from $\{0, 1, 2, 3, 4, 5, 6\}$ to the integers such that $f(0) = 0$ , $f(6) = 12$ , and \[|x - y|  \leq  |f(x) - f(y)|  \leq  3|x - y|\] for all $x$ and $y$ in $\{0, 1, 2, 3, 4, 5, 6\}$ .
  architecture: a = coder("max"); out = verifier("high", a); return out; answered 2, correct 185
- [AIME 2014] A rectangle has sides of length $a$ and 36. A hinge is installed at each vertex of the rectangle, and at the midpoint of each side of length 36. The sides of length $a$ can be pressed toward each other keeping those two sides parallel so the rectangle becomes a convex hexagon as 
  architecture: a = coder("high"); b = verifier("high", a); return b; answered 24, correct 720
- [AIME 2000] In the middle of a vast prairie, a firetruck is stationed at the intersection of two perpendicular straight highways. The truck travels at $50$ miles per hour along the highways and at $14$ miles per hour across the prairie. Consider the set of points that can be reached by the f
  architecture: a = solver("high"); return a; answered 25, correct 731
- [AIME 2004] Consider a string of $n$ $7$ 's, $7777\cdots77,$ into which $+$ signs are inserted to produce an arithmetic expression. For example, $7+77+777+7+7=875$ could be obtained from eight $7$ 's in this way. For how many values of $n$ is it possible to insert $+$ signs so that the resul
  architecture: a = discrete("high"); b = coder("high"); v = verifier("high", a, b); return v; answered 6, correct 108
- [AIME 2010] Let $N$ be the number of ways to write $2010$ in the form $2010 = a_3 \cdot 10^3 + a_2 \cdot 10^2 + a_1 \cdot 10 + a_0$ , where the $a_i$ 's are integers, and $0 \le a_i \le 99$ . An example of such a representation is $1\cdot 10^3 + 3\cdot 10^2 + 67\cdot 10^1 + 40\cdot 10^0$ . F
  architecture: d = discrete("high"); v = verifier("high", d); return v; answered 100, correct 202
- [AIME 2007] The graph of the equation $9x+223y=2007$ is drawn on graph paper with each square representing one unit in each direction. How many of the $1$ by $1$ graph paper squares have interiors lying entirely below the graph and entirely in the first quadrant ?
  architecture: a = solver("high"); return a; answered 2, correct 888
- [AIME 2003] Let $A = (0,0)$ and $B = (b,2)$ be points on the coordinate plane. Let $ABCDEF$ be a convex equilateral hexagon such that $\angle FAB = 120^\circ,$ $\overline{AB}\parallel \overline{DE},$ $\overline{BC}\parallel \overline{EF,}$ $\overline{CD}\parallel \overline{FA},$ and the y-co
  architecture: a = geometry("high"); b = coder("high"); v = verifier("high", a, b); return v; answered 2, correct 51

## Most expensive correct questions (possible waste)
- [AIME 2006, cost 95901] Given that $x, y,$ and $z$ are real numbers that satisfy: \begin{align*} x &= \sqrt{y^2-\frac{1}{16}}+\sqrt{z^2-\frac{1}{16}}, \\ y &= \sqrt{z^2-\frac{1}{25}}+\sqrt{x^2-\frac{1}{25
  architecture: a = solver("max"); b = coder("max"); c = geometry("max"); v = verifier("max", a, b, c); out = judge("max", a, b, c, v); return out
- [AIME 2020, cost 95684] Let $P(x)$ be a quadratic polynomial with complex coefficients whose $x^2$ coefficient is $1.$ Suppose the equation $P(P(x))=0$ has four distinct solutions, $x=3,4,a,b.$ Find the s
  architecture: a = solver("max"); b = coder("max"); c = discrete("max"); v = verifier("max", a, b, c); out = judge("max", a, b, c, v); return out
- [AIME 2013, cost 89751] Triangle $AB_0C_0$ has side lengths $AB_0 = 12$ , $B_0C_0 = 17$ , and $C_0A = 25$ . For each positive integer $n$ , points $B_n$ and $C_n$ are located on $\overline{AB_{n-1}}$ and 
  architecture: a = coder("max"); b = geometry("max"); c = discrete("max"); v = verifier("max", a, b, c); return v
- [AIME 2016, cost 82818] Centered at each lattice point in the coordinate plane are a circle radius $\frac{1}{10}$ and a square with sides of length $\frac{1}{5}$ whose sides are parallel to the coordinate
  architecture: a = coder("max"); b = discrete("max"); v = verifier("max", a, b); out = judge("max", a, b, v); return out
- [AIME 2003, cost 67566] The sum of the areas of all triangles whose vertices are also vertices of a 1 by 1 by 1 cube is $m + \sqrt{n} + \sqrt{p},$ where $m, n,$ and $p$ are integers. Find $m + n + p.$
  architecture: a = coder("max"); b = solver("max"); v = verifier("max", a, b); out = judge("max", a, b, v); return out