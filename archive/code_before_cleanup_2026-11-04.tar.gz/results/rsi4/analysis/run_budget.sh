#!/bin/bash
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
PYTHONPATH=.:results/rsi4/analysis ~/miniconda3/envs/tinker/bin/python results/rsi4/analysis/budget.py results/rsi4/analysis/budget.json low,high,xhigh,max > results/rsi4/analysis/budget.out 2>&1
