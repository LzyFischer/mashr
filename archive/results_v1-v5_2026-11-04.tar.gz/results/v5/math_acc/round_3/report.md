# Diagnostic report (dev-A)

Organization: acc 93.3%, cost 11566/question, of which the HR 1845 (HR prompt 5433 chars). Full system: acc 91.3%, cost 17252. 20 distinct architectures, 1.4 nodes per question. HR outputs: repaired 0, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 6709 | 13285 | solver.low 5, coder.high 3, algebraist.high>verifier.high 3 |
| Algebra L5 | 18 | 100% | 100% | 8197 | 15585 | solver.high 6, algebraist.low 3, algebraist.high 3 |
| Counting & Probability L4 | 8 | 100% | 100% | 9085 | 15676 | combinator.high 4, coder.high 2, combinator.high>verifier.high 1 |
| Counting & Probability L5 | 9 | 89% | 89% | 13775 | 19103 | combinator.high>verifier.high 4, combinator.low 2, coder.high>verifier.high 2 |
| Geometry L4 | 5 | 100% | 100% | 10684 | 15889 | solver.low 2, coder.high 1, coder.high>verifier.max 1 |
| Geometry L5 | 7 | 86% | 57% | 21929 | 22647 | coder.high>verifier.max 4, coder.high 1, coder.high>verifier.high 1 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 12613 | 18210 | algebraist.high>verifier.high 5, solver.high 4, coder.high 1 |
| Intermediate Algebra L5 | 17 | 71% | 71% | 16367 | 21465 | solver.high 4, algebraist.high>verifier.high 3, solver.high>verifier.high 2 |
| Number Theory L4 | 9 | 100% | 100% | 10221 | 17149 | solver.high 3, combinator.high>verifier.high 1, coder.high>verifier.high 1 |
| Number Theory L5 | 16 | 88% | 88% | 10262 | 18165 | coder.high 5, coder.low 3, solver.high 2 |
| Prealgebra L4 | 12 | 100% | 100% | 5969 | 10794 | solver.low 4, coder.low 3, combinator.low 3 |
| Prealgebra L5 | 9 | 100% | 89% | 11380 | 17096 | geometer.high>verifier.max 3, solver.low 2, combinator.high 1 |
| Precalculus L4 | 3 | 100% | 100% | 16648 | 20027 | solver.high 1, coder.high>geometer.high>verifier.max 1, algebraist.high>verifier.max 1 |
| Precalculus L5 | 6 | 83% | 83% | 22441 | 22960 | coder.high>verifier.high 2, coder.high,geometer.high>verifier.max 1, geometer.high>verifier.max 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| solver.high | 23 | 96% | 8051 |
| solver.low | 16 | 100% | 4801 |
| coder.high | 16 | 100% | 8571 |
| coder.low | 13 | 100% | 5184 |
| coder.high>verifier.high | 13 | 62% | 17217 |
| algebraist.high>verifier.high | 12 | 92% | 15122 |
| coder.high>verifier.max | 8 | 100% | 23532 |
| combinator.high | 7 | 100% | 7466 |
| combinator.high>verifier.high | 7 | 86% | 18264 |
| combinator.low | 6 | 100% | 5472 |
| solver.high>verifier.high | 6 | 100% | 15282 |
| algebraist.high | 5 | 100% | 6615 |
| geometer.high>verifier.max | 4 | 100% | 21519 |
| algebraist.low | 3 | 100% | 3750 |
| algebraist.high>verifier.max | 3 | 67% | 27346 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| coder.high | 40 | 70% | 98% | 7335 | - | - | - |
| verifier.high (with inputs) | 39 | 82% | 95% | 7217 | 8 | 4 | - |
| solver.high | 32 | 97% | 91% | 6526 | - | - | - |
| verifier.max (with inputs) | 21 | 95% | 38% | 12142 | 7 | 6 | - |
| algebraist.high | 20 | 75% | 75% | 6395 | - | - | - |
| solver.low | 16 | 100% | 100% | 2951 | - | - | - |
| combinator.high | 14 | 93% | 86% | 7467 | - | - | - |
| coder.low | 13 | 100% | 92% | 3436 | - | - | - |
| geometer.high | 8 | 88% | 100% | 7850 | - | - | - |
| combinator.low | 6 | 100% | 100% | 3573 | - | - | - |
| algebraist.low | 3 | 100% | 33% | 1842 | - | - | - |
| geometer.high (with inputs) | 1 | 100% | 100% | 5296 | 1 | 1 | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.high (output) | 39 | 4 | 0 | 35 | 7217 |
| coder.high (input) | 24 | 4 | 0 | 20 | 4811 |
| verifier.max (output) | 21 | 6 | 0 | 15 | 12142 |
| algebraist.high (input) | 15 | 0 | 1 | 14 | 6940 |
| solver.high (input) | 9 | 0 | 0 | 9 | 3661 |
| geometer.high (input) | 8 | 2 | 0 | 6 | 405 |
| combinator.high (input) | 7 | 0 | 0 | 7 | 7033 |

HR output problems: minor: line 1: non-node argument ignored (5)

## Organization wrong, full system right (2)
- [Geometry L5] $ABCD$, a rectangle with $AB = 12$ and $BC = 16$, is the base of pyramid $P$, which has a height of $24$. A plane parallel to $ABCD$ is passed through $P$, dividing $P$ into a frustum $F$ and a smaller pyramid $P'$. Let $X$ denote the center of the circumsphere of $F$, and let $T
  architecture: a = geometer("high"); return a; answered 144, correct 177
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  architecture: c = coder("high"); v = verifier("high", c); return v; answered 2, correct 85

Both wrong: 8.

## Most expensive correct questions (possible waste)
- [Precalculus L5, cost 38846] Three unit circles are drawn so they are mutually tangent, as shown below.  A blue circle that is externally tangent to all three unit circles is drawn.  Finally, three red circles
  architecture: c = coder("high"); g = geometer("high"); v = verifier("max", c, g); return v
- [Intermediate Algebra L5, cost 29761] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  architecture: a = algebraist("high"); v = verifier("max", a); return v
- [Geometry L5, cost 29736] Given a point $P$ on a triangular piece of paper $ABC,\,$ consider the creases that are formed in the paper when $A, B,\,$ and $C\,$ are folded onto $P.\,$ Let us call $P$ a fold p
  architecture: a = coder("high"); v = verifier("max", a); return v
- [Geometry L5, cost 29686] The graphs of the equations
$y=k, \qquad y=\sqrt{3}x+2k, \qquad y=-\sqrt{3}x+2k,$
are drawn in the coordinate plane for $k=-10,-9,-8,\ldots,9,10.\,$ These 63 lines cut part of the 
  architecture: c = coder("high"); v = verifier("max", c); return v
- [Precalculus L5, cost 29621] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection
  architecture: a = geometer("high"); v = verifier("max", a); return v