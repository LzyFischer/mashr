"""Dataset-level RSI on the HR harness.

  P=~/miniconda3/envs/tinker/bin/python
  set -a; source ~/.config/hrsi/tinker.env; set +a
  $P -m mashr.rsi --rounds 5 --out results/rsi/gsm8k_r1

Splits (GSM8K): dev-A = train[:200] (performance reports), dev-B = train[200:400] (acceptance
gate), test = test[:300] (evaluated once at the end). The reference is the full team; it anchors the
accuracy constraint and the per-question comparison in the report.

One round:
  1. report: incumbent harness on dev-A, aggregated by difficulty bucket (# gold calculation steps)
     and by HR mode, plus examples of "saved wrong" (HR wrong, full team right) and expensive plans
  2. propose: the proposer (27B, thinking) rewrites the "Staffing rules" section, K times
  3. screen: the verifier (27B) drops candidates it judges harmful from the report
  4. gate: each surviving candidate runs on dev-B. Feasible = acc >= ref_acc - eps. Candidates are
     ordered by (feasible, -cost) if feasible else (infeasible, acc); the best replaces the
     incumbent only if it beats it under the same ordering.
Employee calls are cached, so a question whose plan did not change costs only the HR call.
"""
import argparse
import json
import os
import re
import statistics
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

from .hr import HARNESS_V0, plan_for
from .llm import LLM
from .mas import FULL_TEAM, Executor, extract

ROOT = os.path.join(os.path.dirname(__file__), "..")
BIG = "Qwen/Qwen3.8-27B"
RULES_HEAD = "## Staffing rules"
PROMPT_WEIGHT = 0.25   # cost = generated tokens + 0.25 * prompt tokens (HR + employees)


def load(split: str, lo: int, hi: int):
    rows = [json.loads(l) for l in open(os.path.join(ROOT, "data", "gsm8k", f"{split}.jsonl"))]
    return [{"id": f"{split}{i}", "question": r["question"],
             "gold": extract(r["answer"].split("####")[-1]),
             "steps": len(re.findall(r"<<", r["answer"]))}
            for i, r in enumerate(rows)][lo:hi]


def bucket(steps: int) -> str:
    return "1-2 steps" if steps <= 2 else "3-4 steps" if steps <= 4 else "5-6 steps" if steps <= 6 \
        else "7+ steps"


def cost(calls) -> float:
    return sum(c["gen_tokens"] + PROMPT_WEIGHT * c["prompt_tokens"] for c in calls)


def evaluate(llm, ex, items, harness=None, workers=128):
    """harness=None runs the full team (the reference)."""
    def one(it):
        if harness is None:
            plan, calls = FULL_TEAM, []
        else:
            plan, hr_call = plan_for(llm, it["question"], harness)
            calls = [hr_call]
        out = ex.run(it["question"], plan)
        calls = calls + out["calls"]
        return {**it, "plan": plan, "pred": out["answer"], "correct": out["answer"] == it["gold"],
                "calls": calls, "cost": cost(calls),
                "fallback": any(c.get("fallback") for c in calls)}
    with ThreadPoolExecutor(workers) as pool:
        return list(pool.map(one, items))


def summarize(rows):
    n = len(rows)
    return {"n": n, "acc": round(sum(r["correct"] for r in rows) / n, 4),
            "cost": round(sum(r["cost"] for r in rows) / n, 1),
            "modes": dict(Counter(r["plan"]["mode"] for r in rows)),
            "fallback": sum(r["fallback"] for r in rows)}


def plan_str(p) -> str:
    if p["mode"] == "self":
        return f"self (answered {p.get('answer')})"
    if p["mode"] == "single":
        return f"single {p.get('agent')} thinking={p.get('thinking', 'off')}"
    ag = ", ".join(f"{k}{v.get('rounds', '')}:{v.get('thinking', 'off')}"
                   for k, v in p["agents"].items())
    return f"team [{ag}] stop_if_consensus={p.get('stop_if_consensus', False)}"


def report(rows, ref) -> str:
    refd = {r["id"]: r for r in ref}
    lines = ["# Performance report (dev-A)", "",
             f"HR system: acc {summarize(rows)['acc']:.1%}, cost {summarize(rows)['cost']:.0f} "
             f"tokens/question. Full team: acc {summarize(ref)['acc']:.1%}, cost "
             f"{summarize(ref)['cost']:.0f}. Invalid HR outputs (fell back to full team): "
             f"{summarize(rows)['fallback']}.", "",
             "## By difficulty (number of calculation steps in the reference solution)",
             "| bucket | n | HR acc | team acc | HR cost | team cost | HR modes |", "|---|---|---|---|---|---|---|"]
    by = defaultdict(list)
    for r in rows:
        by[bucket(r["steps"])].append(r)
    for b in sorted(by):
        rs = by[b]
        rf = [refd[r["id"]] for r in rs]
        m = Counter(r["plan"]["mode"] for r in rs)
        lines.append(f"| {b} | {len(rs)} | {sum(r['correct'] for r in rs)/len(rs):.0%} | "
                     f"{sum(r['correct'] for r in rf)/len(rf):.0%} | "
                     f"{statistics.mean(r['cost'] for r in rs):.0f} | "
                     f"{statistics.mean(r['cost'] for r in rf):.0f} | "
                     f"{', '.join(f'{k} {v}' for k, v in m.most_common())} |")
    lines += ["", "## By HR decision", "| decision | n | acc | mean cost |", "|---|---|---|---|"]
    byp = defaultdict(list)
    for r in rows:
        p = r["plan"]
        key = p["mode"] if p["mode"] != "single" else f"single thinking={p.get('thinking', 'off')}"
        byp[key].append(r)
    for k, rs in sorted(byp.items()):
        lines.append(f"| {k} | {len(rs)} | {sum(r['correct'] for r in rs)/len(rs):.0%} | "
                     f"{statistics.mean(r['cost'] for r in rs):.0f} |")
    bad = [r for r in rows if not r["correct"] and refd[r["id"]]["correct"]]
    lines += ["", f"## Saved wrong: HR plan failed, full team succeeded ({len(bad)} questions)"]
    for r in bad[:10]:
        lines.append(f"- [{bucket(r['steps'])}] {r['question'][:300]}\n  plan: {plan_str(r['plan'])}; "
                     f"answered {r['pred']}, correct {r['gold']}")
    both = [r for r in rows if not r["correct"] and not refd[r["id"]]["correct"]]
    lines += ["", f"Both HR and full team wrong: {len(both)} questions (likely beyond the team)."]
    rich = sorted([r for r in rows if r["correct"]], key=lambda r: -r["cost"])[:6]
    lines += ["", "## Most expensive correctly-solved questions (possible waste)"]
    for r in rich:
        lines.append(f"- [{bucket(r['steps'])}, cost {r['cost']:.0f}] {r['question'][:200]}\n"
                     f"  plan: {plan_str(r['plan'])}")
    return "\n".join(lines)


def get_rules(h: str) -> str:
    return h.split(RULES_HEAD, 1)[1].strip()


def set_rules(h: str, rules: str) -> str:
    return h.split(RULES_HEAD, 1)[0] + RULES_HEAD + "\n" + rules.strip() + "\n"


PROPOSE = """You improve the instructions of an HR manager model (a 9B model, no reasoning) that,
for each math word problem, decides which agents work on it and how (or answers it itself).
Objective: minimize the team's average cost while keeping accuracy within {eps:.0%} of the full
team's accuracy on held-out questions. Accuracy comes first: a cheaper harness that loses accuracy
beyond that margin is rejected.

You may only rewrite the "Staffing rules" section. The HR reads only the problem text: rules must be
decidable from the problem text (e.g. number of quantities, operations, percentages, rates, units,
multi-part questions), never from information it does not have. Keep the rules short, concrete,
and few (at most 12 lines): the HR is a small model.

# Current HR harness
{harness}

# Performance report of the current harness
{report}

# Earlier attempts (dev-B = held-out gate set; full team on dev-B: acc {ref_acc:.1%}, cost {ref_cost:.0f})
{history}

Think about what the report shows, then output the complete new Staffing rules section between
<rules> and </rules>. {hint}"""

HINTS = ["", "Prefer a change that removes waste on the easy buckets.",
         "Prefer a change that fixes the 'saved wrong' failures."]

VERIFY = """An HR manager model decides per math problem which agents to use. Below is a performance
report of its current instructions and a proposed new set of staffing rules.

# Report
{report}

# Proposed staffing rules
{rules}

Is this proposal likely to lose substantial accuracy (for example, sending clearly hard problem types
to the cheapest option, contradicting itself, or relying on information the HR cannot see in the
problem text)? Answer with a JSON object only: {{"keep": true or false, "reason": "<one sentence>"}}"""


def big_call(llm, prompt, thinking, seed, max_tokens):
    return llm.chat(BIG, [{"role": "user", "content": prompt}], thinking=thinking,
                    max_tokens=max_tokens, seed=seed).text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--eps", type=float, default=0.02)
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "rsi", "gsm8k_r1"))
    ap.add_argument("--n-dev", type=int, default=200)
    ap.add_argument("--n-test", type=int, default=300)
    ap.add_argument("--skip-test", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    llm = LLM()
    ex = Executor(llm)
    n = a.n_dev
    dev_a, dev_b, test = load("train", 0, n), load("train", n, 2 * n), load("test", 0, a.n_test)

    def log(msg):
        print(msg, flush=True)
        with open(os.path.join(a.out, "log.txt"), "a") as f:
            f.write(msg + "\n")

    def dump(name, obj):
        with open(os.path.join(a.out, name), "w") as f:
            f.write(obj if isinstance(obj, str) else json.dumps(obj, indent=1))

    with ThreadPoolExecutor(2) as pool:
        ref_a, ref_b = pool.map(lambda xs: evaluate(llm, ex, xs), [dev_a, dev_b])
    sa, sb = summarize(ref_a), summarize(ref_b)
    floor = sb["acc"] - a.eps
    log(f"reference full team: dev-A {sa}  dev-B {sb}  -> accuracy floor on dev-B {floor:.3f}")

    def key(s):
        return (1, -s["cost"]) if s["acc"] >= floor else (0, s["acc"])

    harness = HARNESS_V0
    inc_b = summarize(evaluate(llm, ex, dev_b, harness))
    log(f"round 0 incumbent (v0) dev-B {inc_b}")
    history = [f"round 0 (v0, no rules): dev-B acc {inc_b['acc']:.1%}, cost {inc_b['cost']:.0f}"]
    trace = [{"round": 0, "accepted": True, "dev_b": inc_b, "rules": get_rules(harness)}]

    for t in range(1, a.rounds + 1):
        d = f"round_{t}"
        os.makedirs(os.path.join(a.out, d), exist_ok=True)
        rows_a = evaluate(llm, ex, dev_a, harness)
        rep = report(rows_a, ref_a)
        dump(f"{d}/harness.txt", harness)
        dump(f"{d}/report.md", rep)
        log(f"round {t}: incumbent dev-A {summarize(rows_a)}")

        def propose(i):
            txt = big_call(llm, PROPOSE.format(eps=a.eps, harness=harness, report=rep,
                                               history="\n".join(history), ref_acc=sb["acc"],
                                               ref_cost=sb["cost"], hint=HINTS[i % len(HINTS)]),
                           "high", seed=1000 * t + i, max_tokens=2048)
            m = re.search(r"<rules>(.*?)</rules>", txt, re.S)
            return m.group(1).strip() if m else None
        with ThreadPoolExecutor(a.k) as pool:
            cands = [c for c in pool.map(propose, range(a.k)) if c]

        def verify(c):
            v = big_call(llm, VERIFY.format(report=rep, rules=c), "low", seed=t, max_tokens=300)
            m = re.search(r"\{.*\}", v, re.S)
            try:
                j = json.loads(m.group(0))
                return bool(j.get("keep", True)), str(j.get("reason", ""))
            except Exception:
                return True, "unparseable verdict, kept"
        with ThreadPoolExecutor(a.k) as pool:
            verdicts = list(pool.map(verify, cands))
        kept = [c for c, (k, _) in zip(cands, verdicts) if k] or cands

        def gate(c):
            return summarize(evaluate(llm, ex, dev_b, set_rules(harness, c))) if c in kept else None
        with ThreadPoolExecutor(len(cands) or 1) as pool:   # candidates are gated concurrently
            gated = list(pool.map(gate, cands))
        results = []
        for i, c in enumerate(cands):
            entry = {"rules": c, "verifier_keep": verdicts[i][0], "verifier_reason": verdicts[i][1]}
            if gated[i] is not None:
                entry["dev_b"] = gated[i]
            results.append(entry)
            log(f"  cand {i}: verifier keep={verdicts[i][0]} ({verdicts[i][1][:80]})"
                + (f"  dev-B {entry['dev_b']}" if "dev_b" in entry else ""))
        dump(f"{d}/candidates.json", results)
        tested = [r for r in results if "dev_b" in r]
        best = max(tested, key=lambda r: key(r["dev_b"])) if tested else None
        accepted = best is not None and key(best["dev_b"]) > key(inc_b)
        for r in results:
            status = ("ACCEPTED" if r is best and accepted else
                      "rejected by verifier" if "dev_b" not in r else "rejected by gate")
            extra = (f": dev-B acc {r['dev_b']['acc']:.1%}, cost {r['dev_b']['cost']:.0f}"
                     if "dev_b" in r else "")
            history.append(f"round {t} [{status}]{extra}\n  rules: "
                           + r["rules"].replace("\n", "\n  "))
        if accepted:
            harness, inc_b = set_rules(harness, best["rules"]), best["dev_b"]
        trace.append({"round": t, "accepted": accepted, "dev_b": inc_b, "rules": get_rules(harness)})
        log(f"round {t}: {'accepted' if accepted else 'no change'}; incumbent dev-B {inc_b}")
        dump("trace.json", trace)

    dump("final_harness.txt", harness)
    if not a.skip_test:
        hs = {"full_team": None, "hr_v0": HARNESS_V0, "hr_final": harness}
        with ThreadPoolExecutor(3) as pool:
            res = dict(zip(hs, pool.map(lambda h: summarize(evaluate(llm, ex, test, h)),
                                        hs.values())))
        dump("test.json", res)
        log(f"TEST: {json.dumps(res)}")


if __name__ == "__main__":
    main()
