# Diagnostic report (dev-A)

Organization: acc 78.0%, cost 9200/question, of which the HR 1711 (HR prompt 3203 chars). 2 distinct architectures, 3.0 nodes per question. HR outputs: repaired 0, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| GSM-Hard | 150 | 78% | - | 9200 | 0 | coder.low,solver.off>verifier.low 147, coder.low 3 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.low,solver.off>verifier.low | 147 | 78% | 9287 |
| coder.low | 3 | 67% | 4966 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| coder.low | 150 | 75% | 95% | 3590 | - | - | - |
| solver.off | 147 | 73% | 0% | 656 | - | - | - |
| verifier.low (with inputs) | 147 | 78% | 85% | 3323 | 23 | 7 | 3 |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| coder.low (input) | 60 | 1 | 0 | 59 | 3414 |
| solver.off (input) | 60 | 0 | 2 | 58 | 327 |
| verifier.low (output) | 60 | 1 | 2 | 57 | 3204 |

## Organization wrong (33)
- [GSM-Hard] Marty has 100 centimeters of ribbon that he must cut into 8361211 equal parts. Each of the cut parts must be divided into 5 equal parts. How long will each final cut be?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 2.39199800124647, correct 2.392e-06
- [GSM-Hard] Dale is selling butterscotch candies to raise money for his club at school. He doesn't have the candies yet and is instead just taking orders. He started off with 7310392 total that he ordered and wanted to sell, but he ended up selling 150 butterscotch candies. Then he ordered 7
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 14620634, correct 7310342.0
- [GSM-Hard] 20% of 7871124 people think horse
  architecture: c = coder("low"); return c; answered 1574224.8, correct 2518759.68
- [GSM-Hard] An apple orchard sells apples in bags of 4228934. The orchard sold a total of 2000 apples one day. How much did an orchard earn for selling this at $5 per bag?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 5000, correct 0.0023646621
- [GSM-Hard] Audrey has to take two math tests to pass 6th grade. She must correctly answer 4103049% of the total questions to move on to the 7th grade. The first test has 4103049 questions and she gets 60% of them correct. The second test has 40 questions. How many questions does she need to
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 168349339374.21, correct 410332.8999999999
- [GSM-Hard] Billy is buying some candy with $10 his father gave him. The candy costs $4808993 a pound. After buying candy, he takes half his change and spends it on gumballs, which cost $.05 each. If he bought 40 gumballs, how many pounds of candy did he buy?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 6, correct 1.2477e-06
- [GSM-Hard] James buys 5072217 pairs of shoes a month.  He spends $5072217640 on shoes each year.  How much does he pay on average for each pair of shoes?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 83.33334384813058, correct 4.33735e-05
- [GSM-Hard] Ellen and her sister, Lani, went to the mall to buy presents for their mom. Ellen bought a pair of leggings for $4915315 and a photo frame for $5. Lani bought a pair of sunglasses at $30 and two bathrobes at $4915315 each. How much did they spend in all?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 14745980, correct 4915550.0
- [GSM-Hard] James buys a new wardrobe.  He buys 1662810 suits and 1662810 dress pants.  He also buys 3 dress shirts per suit.  The suits cost $750 each and the dress pants cost 1/5 that cost.  The dress shirts were $60 each.  How much did everything cost?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 1795834800, correct 249430800.0
- [GSM-Hard] Judy teaches 8387270 dance classes, every day, on the weekdays and 8 classes on Saturday.  If each class has 18387270 students and she charges $18387270.00 per student, how much money does she make in 1 week?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v; answered 14178334486374316507136, correct 9435680550.0

## Most expensive correct questions (possible waste)
- [GSM-Hard, cost 16220] Cody and Trevor had 7633966 sandwiches. Cody ate a third of the sandwiches, and Trevor ate a quarter of the sandwiches. How many sandwiches are left?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v
- [GSM-Hard, cost 14804] The ratio of popsicles that Betty and Sam have is 5:6. If the total number of popsicles they have together is 9381115, how many more popsicles does Sam have more than Betty?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v
- [GSM-Hard, cost 13490] A company pays each of its employees $2543121 in a month. The company has a policy of increasing the salaries of each of its employees by 10% of the initial salary every year for t
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v
- [GSM-Hard, cost 13225] 6139339 seniors need to receive awards.  Each senior receives a picture frame that costs $20.  Each picture frame needs to be etched with the logo for an additional 20% cost per fr
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v
- [GSM-Hard, cost 12077] Emil is 19 years old now. When he turns 7450634, he will be half the age of his dad but twice as old as his brother.  What is the sum of the ages of his dad and his brother now?
  architecture: c = coder("low"); s = solver("off"); v = verifier("low", c, s); return v