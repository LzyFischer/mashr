"""Run one configuration on GSM8K and write per-question rows + a summary line.

  P=~/miniconda3/envs/tinker/bin/python
  set -a; source ~/.config/hrsi/tinker.env; set +a
  $P -m mashr.run --config full_team --n 200
Configs: single_off, single_low, single_high, full_team, full_team_stop, hr_v0.
"""
import argparse
import json
import os
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from .hr import HARNESS_V0, plan_for
from .llm import LLM
from .mas import FULL_TEAM, Executor, extract

ROOT = os.path.join(os.path.dirname(__file__), "..")
FIXED = {
    "single_off": {"mode": "single", "agent": "solver_A", "thinking": "off"},
    "single_low": {"mode": "single", "agent": "solver_A", "thinking": "low"},
    "single_high": {"mode": "single", "agent": "solver_A", "thinking": "high"},
    "full_team": FULL_TEAM,
    "full_team_stop": {**FULL_TEAM, "stop_if_consensus": True},
}


def load(n: int, offset: int = 0):
    rows = [json.loads(l) for l in open(os.path.join(ROOT, "data", "gsm8k", "test.jsonl"))]
    return [{"id": i, "question": r["question"], "gold": extract(r["answer"].split("####")[-1])}
            for i, r in enumerate(rows)][offset:offset + n]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--offset", type=int, default=0)
    ap.add_argument("--workers", type=int, default=48)
    ap.add_argument("--harness", help="text file with an HR harness (default: v0)")
    ap.add_argument("--tag", default="")
    a = ap.parse_args()
    llm = LLM()
    ex = Executor(llm)
    harness = open(a.harness).read() if a.harness else HARNESS_V0

    def one(item):
        hr_call = None
        if a.config in FIXED:
            plan = FIXED[a.config]
        else:
            plan, hr_call = plan_for(llm, item["question"], harness)
        out = ex.run(item["question"], plan)
        calls = ([hr_call] if hr_call else []) + out["calls"]
        return {**item, "config": a.config, "plan": plan, "pred": out["answer"],
                "correct": out["answer"] == item["gold"], "rounds": out["rounds"],
                "early_stop": out.get("early_stop", False), "calls": calls,
                "gen_tokens": sum(c["gen_tokens"] for c in calls),
                "prompt_tokens": sum(c["prompt_tokens"] for c in calls)}

    items = load(a.n, a.offset)
    with ThreadPoolExecutor(a.workers) as pool:
        rows = list(pool.map(one, items))
    name = a.config + (f"_{a.tag}" if a.tag else "")
    os.makedirs(os.path.join(ROOT, "results", "mashr"), exist_ok=True)
    with open(os.path.join(ROOT, "results", "mashr", f"{name}.jsonl"), "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    n = len(rows)
    summary = {"config": name, "n": n, "acc": sum(r["correct"] for r in rows) / n,
               "gen_tokens": sum(r["gen_tokens"] for r in rows) / n,
               "prompt_tokens": sum(r["prompt_tokens"] for r in rows) / n,
               "calls": sum(len(r["calls"]) for r in rows) / n,
               "modes": dict(Counter(r["plan"]["mode"] for r in rows)),
               "hr_fallback": sum(any(c.get("fallback") for c in r["calls"]) for r in rows)}
    print(json.dumps(summary))
    with open(os.path.join(ROOT, "results", "mashr", "summary.jsonl"), "a") as f:
        f.write(json.dumps(summary) + "\n")


if __name__ == "__main__":
    main()
