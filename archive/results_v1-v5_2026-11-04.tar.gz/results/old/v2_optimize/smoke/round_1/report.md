# Diagnostic report (dev-A)

Pool: acc 100.0%, 11633 tokens/question (7696 generated). Full system: acc 91.7%, 23582 tokens. Orchestrator prompt: 7750 chars. Invalid orchestrator outputs: 0.

## By category
| category | n | acc | full acc | tokens | full tokens | plan shapes |
|---|---|---|---|---|---|---|
| Algebra L4 | 4 | 100% | 100% | 7953 | 16885 | 1 solver+review 2, 1 solver+review+decide 1, 1 solver 1 |
| Algebra L5 | 1 | 100% | 100% | 4903 | 20650 | 1 solver 1 |
| Counting & Probability L5 | 1 | 100% | 100% | 8022 | 21197 | 1 solver+review+decide 1 |
| Intermediate Algebra L4 | 1 | 100% | 100% | 9046 | 22788 | 1 solver+review+decide 1 |
| Intermediate Algebra L5 | 2 | 100% | 100% | 22175 | 33465 | 1 solver+review+decide 2 |
| Prealgebra L4 | 1 | 100% | 100% | 4160 | 12626 | 1 solver 1 |
| Prealgebra L5 | 1 | 100% | 0% | 14659 | 38357 | 1 solver+review+decide 1 |
| Precalculus L5 | 1 | 100% | 100% | 22643 | 32903 | 1 solver+review+decide 1 |

## Escalation tiers
| tier | planned | ran | changed answer | to correct | to wrong |
|---|---|---|---|---|---|
| review | 9 | 9 | 0 | 0 | 0 |
| decide | 7 | 5 | 0 | 0 | 0 |

## Agents: leave-one-out replay on 6 multi-agent questions
Remove the agent from that tier and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| agent@tier | uses | needed | harmful | no effect | mean tokens saved |
|---|---|---|---|---|---|
| judge@decide | 2 | 0 | 0 | 2 | 5167 |
| reviewer@review | 3 | 0 | 0 | 3 | 8335 |
| solver_algebra@decide | 1 | 0 | 0 | 1 | 1934 |
| solver_algebra@review | 1 | 0 | 0 | 1 | 3224 |
| solver_counting@review | 1 | 0 | 0 | 1 | 1815 |
| solver_polynomial@decide | 1 | 0 | 0 | 1 | 5178 |
| solver_polynomial@review | 1 | 0 | 0 | 1 | 8503 |

## Orchestrator usage
Agent assignments: reviewer 6, solver_polynomial 5, solver_geometry 5, solver_algebra 4, judge 3, solver_counting 3, solver_quick 2
Skills switched on: verify_substitution 18, check_answer_form 17, arithmetic_check 9, graph_diagram_reading 5, parse_exact_ask 4, area_perimeter_shapes 3, quadratic_vertex 3, algebraic_manipulation 2, minimal_polynomial 2, check_units 2, coordinate_geometry 2, radical_exponent_laws 1, symmetric_roots 1, counting_constraints 1, case_split 1, proportion_rate 1, matrix_roots_unity 1
Skills never switched on: none

## Pool wrong, full system right (0)

Both wrong: 0.

## Most expensive correct questions (possible waste)
- [Intermediate Algebra L5, 26238 tokens] During the car ride home, Michael looks back at his recent math exams. A problem on Michael's calculus mid-term gets him starting thinking about a particular quadratic,\[x^2-sx+p,\
  plan: solve=[solver_polynomial:high+symmetric_roots/minimal_polynomial/verify_substitution/check_answer_form] review if always=[reviewer:high+verify_substitution/arithmetic_check/check_answer_form] decide if always=[judge:high+check_answer_form/verify_substitution/arithmetic_check]
- [Precalculus L5, 22643 tokens] Let $\omega$ be a nonreal root of $x^3 = 1,$ and let
\[\mathbf{M} = \begin{pmatrix} -\omega^2 & - \omega \\ 1 & 0 \end{pmatrix}.\]Find the sum of the entries of $\mathbf{M} + \math
  plan: solve=[solver_polynomial:high+matrix_roots_unity/verify_substitution/check_answer_form] review if always=[reviewer:low+verify_substitution/arithmetic_check/check_answer_form] decide if always=[judge:high+check_answer_form/verify_substitution/arithmetic_check]
- [Intermediate Algebra L5, 18112 tokens] There is a unique polynomial $P(x)$ of degree $8$ with rational coefficients and leading coefficient $1,$ which has the number \[\sqrt{2} + \sqrt{3} + \sqrt{5}\]as a root. Compute 
  plan: solve=[solver_polynomial:high+minimal_polynomial/verify_substitution] review if always=[solver_polynomial:off+check_answer_form] decide if always=[solver_polynomial:off+check_answer_form]
- [Prealgebra L5, 14659 tokens] The area of the shaded region is 78 square inches. All angles are right angles and all measurements are given in inches. What is the perimeter of the non-shaded region?

[asy]size(
  plan: solve=[solver_geometry:high+graph_diagram_reading/coordinate_geometry/area_perimeter_shapes] review if always=[solver_quick:low+parse_exact_ask/check_answer_form] decide if conflict=[reviewer:high+verify_substitution/arithmetic_check/graph_diagram_reading/check_answer_form]
- [Algebra L4, 12927 tokens] Solve for $Q$ if $\sqrt{Q^3} = 16\sqrt[8]{16}$.
  plan: solve=[solver_algebra:low+radical_exponent_laws/algebraic_manipulation/verify_substitution] review if always=[reviewer:low+verify_substitution/arithmetic_check] decide if always=[judge:high+check_answer_form/verify_substitution/arithmetic_check]