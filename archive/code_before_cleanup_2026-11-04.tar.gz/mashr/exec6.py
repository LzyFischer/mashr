"""Fast loop v6: the HR writes the team and each node's residual harness (org6.py); the executor runs
it. A node with tools gets Python with those tools preloaded (engine.run_python)."""
from concurrent.futures import ThreadPoolExecutor

from .engine import ANSWER_FMT, CODE, SHOW_CHARS, cost, majority, run_python
from .llm import THINK_BUDGET
from .mas import MODEL, extract
from .org6 import fallback_plan, hr_prompt, parse_program
from .tools6 import TOOLS, tool_code

PY_RUNS = 2
RETRY = "Your answer could not be used:\n{problems}\n\nWrite it again: the code block, then the notes."


class Engine:
    def __init__(self, llm, model: str = MODEL, seed: int = 0, hr_thinking: str = "low",
                 answer_fmt: str = ANSWER_FMT, extract_fn=extract):
        self.llm, self.model, self.seed, self.hr_thinking = llm, model, seed, hr_thinking
        self.answer_fmt, self.extract = answer_fmt, extract_fn

    def orchestrate(self, pool: dict, question: str):
        msgs = [{"role": "system", "content": hr_prompt(pool)},
                {"role": "user", "content": f"Problem: {question}\n\nYour team:"}]
        calls, probs = [], []
        for attempt in range(2):
            r = self.llm.chat(self.model, msgs, thinking=self.hr_thinking, max_tokens=900,
                              seed=self.seed + attempt)
            calls.append({"agent": "HR", "node": None, "prompt_tokens": r.prompt_tokens,
                          "gen_tokens": r.gen_tokens})
            plan, probs = parse_program(pool, r.text)
            if plan is not None:
                return plan, calls, {"problems": probs[:4], "retried": attempt == 1,
                                     "fallback": False}
            msgs += [{"role": "assistant", "content": r.text},
                     {"role": "user", "content": RETRY.format(problems="\n".join(probs[:6]))}]
        return fallback_plan(pool), calls, {"problems": probs[:4], "retried": True, "fallback": True}

    def _node(self, pool, node, user):
        system = pool["agents"][node["agent"]]["role"]
        if node["skills"]:
            system += "\n\nSkills to apply:\n" + "\n".join(f"- {pool['skills'][k]}" for k in node["skills"])
        runs = PY_RUNS if node["tools"] else 0
        if runs:
            helpers = [t for t in node["tools"] if TOOLS[t]["code"].strip()]
            system += (f"\n\nYou can run Python (numpy and sympy available) up to {runs} times: write "
                       "one ```python``` code block that prints what you need, then stop and wait for "
                       "its output.")
            if helpers:
                system += " These functions are already defined:\n" + "\n".join(
                    f"- {TOOLS[t]['doc']}" for t in helpers)
        if node["note"]:
            user = user.replace(f"\n\n{self.answer_fmt}", "") if user.endswith(self.answer_fmt) else user
            user += f"\n\nNote from your manager: {node['note']}\n\n{self.answer_fmt}"
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        calls, shown, last_out = [], [], None
        pre = tool_code(node["tools"])
        for k in range(runs + 1):
            # with thinking off the reasoning is in the answer itself, so it gets more room
            r = self.llm.chat(self.model, msgs, thinking=node["thinking"],
                              max_tokens=4096 if node["thinking"] == "off" else 2048, seed=self.seed)
            calls.append({"agent": node["agent"], "node": node["id"], "thinking": node["thinking"],
                          "prompt_tokens": r.prompt_tokens, "gen_tokens": r.gen_tokens})
            shown.append(r.text)
            code = CODE.findall(r.text)
            if not code or "####" in r.text.split("```")[-1] or k == runs:
                break
            out, _ = run_python(pre + "\n" + code[-1])
            last_out = out
            shown.append(f"[Python output]\n{out}")
            more = ("You may run code again or give the final answer." if k + 1 < runs
                    else "No more code runs. Give the final answer now.")
            msgs += [{"role": "assistant", "content": r.text},
                     {"role": "user", "content": f"Output:\n{out}\n\n{more} {self.answer_fmt}"}]
        text = r.text
        ans = self.extract(text) if ("####" in text or "boxed" in text or last_out is None) \
            else self.extract(last_out)
        return {"id": node["id"], "agent": node["agent"], "text": "\n\n".join(shown), "answer": ans,
                "calls": calls,
                "cut": calls[0]["gen_tokens"] >= THINK_BUDGET[node["thinking"]] > 0}

    def run(self, pool: dict, question: str, plan: dict) -> dict:
        done, depth = {}, {}
        for n in plan["nodes"]:
            depth[n["id"]] = 1 + max((depth[i] for i in n["inputs"]), default=-1)
        for d in sorted(set(depth.values())):
            layer = [n for n in plan["nodes"] if depth[n["id"]] == d]

            def one(n):
                if not n["inputs"]:
                    user = f"Problem: {question}\n\n{self.answer_fmt}"
                else:
                    work = "\n\n".join(f"[{done[i]['agent']} ({i})]\n{done[i]['text'][-SHOW_CHARS:]}"
                                       for i in n["inputs"])
                    user = (f"Problem: {question}\n\nWork from your teammates:\n{work}\n\nGive your "
                            f"own solution and final answer.\n\n{self.answer_fmt}")
                return self._node(pool, n, user)
            if len(layer) == 1:
                outs = [one(layer[0])]
            else:
                with ThreadPoolExecutor(len(layer)) as ex:
                    outs = list(ex.map(one, layer))
            for o in outs:
                done[o["id"]] = o
        answer = done[plan["output"]]["answer"]
        if answer is None:
            answer = majority([o["answer"] for o in done.values()])
        calls = [c for n in plan["nodes"] for c in done[n["id"]]["calls"]]
        return {"answer": answer, "calls": calls,
                "nodes": [{k: v for k, v in done[n["id"]].items() if k not in ("text", "calls")}
                          | {"cost": round(cost(done[n["id"]]["calls"]), 1)} for n in plan["nodes"]]}
