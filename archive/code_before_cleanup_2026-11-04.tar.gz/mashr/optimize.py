"""Slow loop: dataset-level optimization of the agent pool (agents, skills, dispatch policy).

  P=~/miniconda3/envs/tinker/bin/python
  set -a; source ~/.config/hrsi/tinker.env; set +a
  $P -m mashr.optimize --dataset math --init design --out results/optimize/math_design

Round 0: the pool is the hand-written V0, or (--init design) written by the designer from a sample of
dev-A problems. Each round:
  1. run the incumbent on dev-A; leave-one-out replay of each agent in each tier on up to --loo-n
     multi-agent questions (unchanged prefixes are cached); build the diagnostic report
  2. the designer proposes K lists of edit operations; invalid results go back once with the errors
  3. gate on dev-B: feasible = acc >= full-system acc - eps; best by (feasible, -cost) else
     (infeasible, acc); replaces the incumbent only if strictly better under the same ordering
Cost = generated tokens + 0.2 * prompt tokens over all calls, including the orchestrator's.
"""
import argparse
import copy
import json
import os
import re
import statistics
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

from .cascade import PROMPT_WEIGHT, Cascade, cost
from .llm import LLM
from .orgrsi import load_items
from .pool import FULL, V0, apply_ops, check_plan, orchestrator_prompt, validate
from .rsi import BIG, ROOT

WORKERS = 128


def evaluate(cas, pool, items, fixed=None):
    def one(it):
        if fixed is not None:
            plan, pre = check_plan(pool, fixed)[0], []
        else:
            plan, call = cas.orchestrate(pool, it["question"])
            pre = [call]
        out = cas.run(pool, it["question"], plan)
        calls = pre + out["calls"]
        inv = next((c for c in pre if c.get("invalid")), None)
        return {**it, "plan": plan, "trace": out["trace"], "pred": out["answer"],
                "correct": out["answer"] == it["gold"], "calls": calls, "cost": cost(calls),
                "gen_tokens": sum(c["gen_tokens"] for c in calls),
                "prompt_tokens": sum(c["prompt_tokens"] for c in calls),
                "invalid": inv is not None, "problems": inv["problems"] if inv else None}
    with ThreadPoolExecutor(WORKERS) as pool_:
        return list(pool_.map(one, items))


def shape(plan) -> str:
    """Architecture shape, e.g. 'solve2>review?>decide' (? = runs only on disagreement)."""
    return ">".join(f"{st['type']}{len(st['agents'])}" + ("?" if st["if"] == "disagree" else "")
                    for st in plan["stages"])


def summarize(rows):
    n = len(rows)
    hard = [r for r in rows if r["hard"]]
    return {"n": n, "acc": round(sum(r["correct"] for r in rows) / n, 4),
            "cost": round(sum(r["cost"] for r in rows) / n, 1),
            "gen_tokens": round(sum(r["gen_tokens"] for r in rows) / n, 1),
            "prompt_tokens": round(sum(r["prompt_tokens"] for r in rows) / n, 1),
            "acc_hard": round(sum(r["correct"] for r in hard) / max(1, len(hard)), 4),
            "shapes": dict(Counter(shape(r["plan"]) for r in rows).most_common(6)),
            "invalid": sum(r["invalid"] for r in rows)}


def leave_one_out(cas, pool, rows, n):
    """Drop one agent from one stage that ran (an emptied stage is dropped) and replay."""
    jobs, seen = [], []
    for r in rows:
        stages = r["plan"]["stages"]
        ran = [(t["stage"], a) for t in r["trace"] if t["ran"] for a in stages[t["stage"]]["agents"]]
        if len(ran) < 2:
            continue
        if len(seen) >= n:
            break
        seen.append(r["id"])
        for i, a in ran:
            if i == 0 and len(stages[0]["agents"]) == 1:
                continue
            jobs.append((r, i, a))

    def one(job):
        r, i, a = job
        p = copy.deepcopy(r["plan"])
        del p["stages"][i]["agents"][a]
        p["stages"] = [st for st in p["stages"] if st["agents"]]
        p["stages"][0]["if"] = "always"
        out = cas.run(pool, r["question"], p)
        own = cost([c for c in r["calls"] if c["agent"] != "orchestrator"])
        st = r["plan"]["stages"][i]
        return {"bucket": r["bucket"], "where": f"{a}@{st['type']}{i + 1}", "was": r["correct"],
                "now": out["answer"] == r["gold"], "saved": own - cost(out["calls"])}
    with ThreadPoolExecutor(WORKERS) as pool_:
        return list(pool_.map(one, jobs)), len(seen)


def plan_str(p):
    return " > ".join(
        f"{st['type']}" + (" if disagree" if st["if"] == "disagree" else "") + "[" + ", ".join(
            f"{a}:{v['thinking']}" + (f"+{'/'.join(v['skills'])}" if v["skills"] else "")
            for a, v in st["agents"].items()) + "]" for st in p["stages"])


def pct(xs):
    return f"{sum(xs) / len(xs):.0%}" if xs else "-"


def report(rows, ref, loo, loo_n, pool) -> str:
    refd = {r["id"]: r for r in ref}
    s, sr = summarize(rows), summarize(ref)
    L = ["# Diagnostic report (dev-A)", "",
         f"Pool: acc {s['acc']:.1%}, cost {s['cost']:.0f}/question ({s['gen_tokens']:.0f} generated, "
         f"{s['prompt_tokens']:.0f} prompt tokens; cost = generated + {PROMPT_WEIGHT} x prompt). "
         f"Full system: acc {sr['acc']:.1%}, cost {sr['cost']:.0f}. Orchestrator "
         f"prompt: {len(orchestrator_prompt(pool))} chars. Invalid orchestrator outputs: "
         f"{s['invalid']}.", "",
         "## By category", "| category | n | acc | full acc | cost | full cost | architectures |",
         "|---|---|---|---|---|---|---|"]
    by = defaultdict(list)
    for r in rows:
        by[r["bucket"]].append(r)
    for b in sorted(by):
        rs, rf = by[b], [refd[r["id"]] for r in by[b]]
        L.append(f"| {b} | {len(rs)} | {pct([r['correct'] for r in rs])} | "
                 f"{pct([r['correct'] for r in rf])} | {statistics.mean(r['cost'] for r in rs):.0f}"
                 f" | {statistics.mean(r['cost'] for r in rf):.0f} | "
                 + ", ".join(f"{k} {v}" for k, v in Counter(shape(r['plan']) for r in rs).most_common(3))
                 + " |")
    L += ["", "## Later stages (by type and condition): how often they ran and changed the answer",
          "| stage | planned | ran | changed answer | to correct | to wrong |", "|---|---|---|---|---|---|"]
    g = defaultdict(lambda: [0, 0, 0, 0, 0])
    for r in rows:
        for t in r["trace"]:
            if t["stage"] == 0:
                continue
            st = r["plan"]["stages"][t["stage"]]
            k = f"{st['type']} if {st['if']}"
            g[k][0] += 1
            if t["ran"]:
                g[k][1] += 1
                if t["before"] is not None and t["majority"] != t["before"]:
                    g[k][2] += 1
                    g[k][3] += t["majority"] == r["gold"]
                    g[k][4] += t["before"] == r["gold"]
    for k, v in sorted(g.items()):
        L.append(f"| {k} | {v[0]} | {v[1]} | {v[2]} | {v[3]} | {v[4]} |")
    L += ["", f"## Agents: leave-one-out replay on {loo_n} multi-agent questions",
          "Remove the agent from that stage and re-run: 'needed' = right becomes wrong; "
          "'harmful' = wrong becomes right.",
          "| agent@stage | uses | needed | harmful | no effect | mean cost saved |",
          "|---|---|---|---|---|---|"]
    g = defaultdict(list)
    for x in loo:
        g[x["where"]].append(x)
    for k, xs in sorted(g.items()):
        need = sum(x["was"] and not x["now"] for x in xs)
        harm = sum(not x["was"] and x["now"] for x in xs)
        L.append(f"| {k} | {len(xs)} | {need} | {harm} | {len(xs) - need - harm} | "
                 f"{statistics.mean(x['saved'] for x in xs):.0f} |")
    used = Counter(a for r in rows for st in r["plan"]["stages"] for a in st["agents"])
    sk = Counter(x for r in rows for st in r["plan"]["stages"] for v in st["agents"].values()
                 for x in v["skills"])
    L += ["", "## Orchestrator usage",
          "Architectures: " + ", ".join(f"{k} {v}" for k, v in
                                         Counter(shape(r["plan"]) for r in rows).most_common(8)),
          "Agent assignments: " + ", ".join(f"{k} {v}" for k, v in used.most_common()),
          "Skills switched on: " + (", ".join(f"{k} {v}" for k, v in sk.most_common()) or "none"),
          "Skills never switched on: " + (", ".join(
              x for x in pool["skills"] if x not in sk) or "none")]
    inv = [r for r in rows if r["invalid"]]
    if inv:
        L.append("Invalid outputs, first problems: " + "; ".join(str(r["problems"]) for r in inv[:4]))
    bad = [r for r in rows if not r["correct"] and refd[r["id"]]["correct"]]
    L += ["", f"## Pool wrong, full system right ({len(bad)})"]
    for r in bad[:10]:
        L.append(f"- [{r['bucket']}] {r['question'][:280]}\n  plan: {plan_str(r['plan'])}; "
                 f"answered {r['pred']}, correct {r['gold']}")
    L.append(f"\nBoth wrong: {sum(not r['correct'] and not refd[r['id']]['correct'] for r in rows)}.")
    rich = sorted([r for r in rows if r["correct"]], key=lambda r: -r["cost"])[:5]
    L += ["", "## Most expensive correct questions (possible waste)"]
    for r in rich:
        L.append(f"- [{r['bucket']}, cost {r['cost']:.0f}] {r['question'][:180]}\n"
                 f"  plan: {plan_str(r['plan'])}")
    return "\n".join(L)


OPS_DOC = """Edit operations (a JSON list, applied in order):
{"op": "add_agent", "name": "<name>", "role": "<role description, <= 400 chars>", "skills": ["<id>"]}
{"op": "remove_agent", "name": "<agent>"}
{"op": "edit_role", "name": "<agent>", "role": "<new role description>"}
{"op": "set_skills", "name": "<agent>", "skills": ["<id>", ...]}
{"op": "add_skill", "id": "<new_id>", "text": "<general how-to, <= 500 chars>", "to": ["<agent>"]}
{"op": "edit_skill", "id": "<id>", "text": "<new text>"}
{"op": "remove_skill", "id": "<id>"}
{"op": "set_policy", "text": "<the orchestrator's complete dispatch policy, <= 2000 chars>"}
Limits: <= 8 agents, <= 30 skills, <= 5 skills per agent. The policy must not mention removed agents.
The orchestrator designs the architecture per question: 1-4 stages, each of type solve (later solve
stages are debate rounds), review or decide, with up to 4 agents, their thinking levels (off/low/high)
and skills, and a condition for later stages ("always", or "disagree" = only if the answers so far
are not unanimous). The policy can tell it which architectures to use for which problems."""

PROPOSE = """You design a pool of LLM agents (all the same 9B model) that solves math problems. Per problem,
an orchestrator (the same 9B model, no reasoning, sees only the problem text and its prompt) designs
the architecture: which stages run, who fills them, their thinking levels and skills.

Objective: minimize the average cost per problem (generated tokens + 0.2 x prompt tokens, including the
orchestrator's own prompt) while keeping accuracy within {eps:.0%} of the full system on held-out
problems. Accuracy comes first.

Base each change on evidence in the report: remove agents whose leave-one-out removal never hurts;
add a skill only for an error pattern that recurs across several problems (skills must be general
techniques, not solutions to specific problems); remove skills that are never switched on; keep the
policy short and decidable from the problem text; the orchestrator prompt is paid on every problem.

{ops_doc}

# Current pool (JSON)
{pool}

# Diagnostic report
{report}

# Earlier attempts (dev-B gate; full system on dev-B: acc {ref_acc:.1%}, cost {ref_cost:.0f})
{history}

Think about what the evidence shows, then output a JSON list of edit operations between <ops> and
</ops>. {hint}"""

HINTS = ["", "Prefer changes that remove waste: agents, stages, thinking or skills that do not change "
             "answers.",
         "Prefer changes that fix the 'pool wrong, full system right' failures."]

REPAIR = """Your output could not be used:
{errors}

Output the corrected complete JSON between <{tag}> and </{tag}>."""

DESIGN = """Design the initial pool of LLM agents (all the same 9B model) that will solve problems like the
samples below. Per problem, an orchestrator (the same 9B model, no reasoning) designs the
architecture: stages (solve / review / decide), who fills them, thinking levels and skills.
Objective: high accuracy at low cost (generated tokens + 0.2 x prompt tokens).

Write the agents (name, role, skill ids), a library of general skills this task needs, and the
orchestrator's dispatch policy.

{ops_doc}

# JSON format (an example pool; replace it with your own design)
{example}

# Sample problems
{samples}

Output the complete pool JSON between <pool> and </pool>."""


def ask_json(llm, prompt, tag, check, seed, max_tokens=4096):
    msgs = [{"role": "user", "content": prompt}]
    for attempt in range(2):
        txt = llm.chat(BIG, msgs, thinking="high", max_tokens=max_tokens, seed=seed + attempt).text
        m = re.search(rf"<{tag}>(.*?)</{tag}>", txt, re.S)
        try:
            obj = json.loads(m.group(1)) if m else None
            errs = [f"no <{tag}> block"] if obj is None else []
        except json.JSONDecodeError as e:
            obj, errs = None, [f"bad JSON: {e}"]
        if obj is not None:
            res, errs = check(obj)
            if not errs:
                return obj, res, attempt
        msgs += [{"role": "assistant", "content": txt},
                 {"role": "user", "content": REPAIR.format(errors="\n".join(errs[:15]), tag=tag)}]
    return None, None, 2


def ops_summary(ops):
    out = []
    for op in ops:
        if op.get("op") == "set_policy":
            out.append("set_policy:\n    " + str(op.get("text", "")).replace("\n", "\n    "))
        else:
            out.append(json.dumps(op)[:300])
    return "\n  ".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=["gsm8k", "math"], default="math")
    ap.add_argument("--init", choices=["hand", "design"], default="design")
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--eps", type=float, default=0.02)
    ap.add_argument("--n-dev-a", type=int, default=150)
    ap.add_argument("--n-dev-b", type=int, default=200)
    ap.add_argument("--n-test", type=int, default=156)
    ap.add_argument("--loo-n", type=int, default=60)
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "optimize", "math_design"))
    ap.add_argument("--skip-test", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    llm = LLM()
    cas = Cascade(llm)
    dev_a = load_items(a.dataset, "train", 0, a.n_dev_a)
    dev_b = load_items(a.dataset, "train", a.n_dev_a, a.n_dev_a + a.n_dev_b)
    test = load_items(a.dataset, "test", 0, a.n_test)

    def log(msg):
        print(msg, flush=True)
        with open(os.path.join(a.out, "log.txt"), "a") as f:
            f.write(msg + "\n")

    def dump(name, obj):
        path = os.path.join(a.out, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(obj if isinstance(obj, str) else json.dumps(obj, indent=1))

    with ThreadPoolExecutor(2) as ex:
        ref_a, ref_b = ex.map(lambda xs: evaluate(cas, V0, xs, FULL), [dev_a, dev_b])
    sa, sb = summarize(ref_a), summarize(ref_b)
    floor = sb["acc"] - a.eps
    log(f"full system: dev-A {sa}\n             dev-B {sb}\n             floor on dev-B {floor:.3f}")

    if a.init == "hand":
        pool = copy.deepcopy(V0)
    else:
        samples = "\n".join(f"- {it['question']}" for it in dev_a[:30])
        pool, _, tries = ask_json(llm, DESIGN.format(ops_doc=OPS_DOC, example=json.dumps(V0, indent=1),
                                                     samples=samples), "pool",
                                  lambda o: (None, validate(o)), seed=7, max_tokens=6000)
        if pool is None:
            raise SystemExit("initial design failed: no valid pool after repair")
        log(f"designed initial pool (repair attempts: {tries})")
    pool0 = copy.deepcopy(pool)
    dump("round_0/pool.json", pool)

    def key(s):
        return (1, -s["cost"]) if s["acc"] >= floor else (0, s["acc"])

    inc_b = summarize(evaluate(cas, pool, dev_b))
    log(f"round 0 incumbent dev-B {inc_b}")
    history = [f"round 0 (initial pool): dev-B acc {inc_b['acc']:.1%}, cost {inc_b['cost']:.0f}"]
    trace = [{"round": 0, "accepted": True, "dev_b": inc_b}]

    for t in range(1, a.rounds + 1):
        d = f"round_{t}"
        rows_a = evaluate(cas, pool, dev_a)
        loo, loo_n = leave_one_out(cas, pool, rows_a, a.loo_n)
        rep = report(rows_a, ref_a, loo, loo_n, pool)
        dump(f"{d}/pool.json", pool)
        dump(f"{d}/report.md", rep)
        log(f"round {t}: incumbent dev-A {summarize(rows_a)}; leave-one-out replays {len(loo)}")

        def propose(i):
            prompt = PROPOSE.format(eps=a.eps, ops_doc=OPS_DOC, pool=json.dumps(pool, indent=1),
                                    report=rep, history="\n".join(history), ref_acc=sb["acc"],
                                    ref_cost=sb["cost"], hint=HINTS[i % len(HINTS)])
            ops, new, tries = ask_json(llm, prompt, "ops", lambda o: apply_ops(pool, o),
                                       seed=1000 * t + 10 * i)
            return {"ops": ops, "pool": new, "repairs": tries}
        with ThreadPoolExecutor(a.k) as ex:
            cands = list(ex.map(propose, range(a.k)))
        valid = [c for c in cands if c["pool"] is not None]
        with ThreadPoolExecutor(len(valid) or 1) as ex:
            gated = list(ex.map(lambda c: summarize(evaluate(cas, c["pool"], dev_b)), valid))
        for c, g in zip(valid, gated):
            c["dev_b"] = g
        for i, c in enumerate(cands):
            log(f"  cand {i}: " + ("invalid after repair" if c["pool"] is None else
                                   f"{len(c['ops'])} ops, repairs {c['repairs']}, dev-B {c['dev_b']}"))
        best = max(valid, key=lambda c: key(c["dev_b"])) if valid else None
        accepted = best is not None and key(best["dev_b"]) > key(inc_b)
        for c in cands:
            if c["pool"] is None:
                history.append(f"round {t} [invalid]")
                continue
            status = "ACCEPTED" if c is best and accepted else "rejected by gate"
            history.append(f"round {t} [{status}]: dev-B acc {c['dev_b']['acc']:.1%}, "
                           f"cost {c['dev_b']['cost']:.0f}, invalid outputs "
                           f"{c['dev_b']['invalid']}\n  {ops_summary(c['ops'])}")
        dump(f"{d}/candidates.json", [{k: v for k, v in c.items() if k != "pool"} for c in cands])
        if accepted:
            pool, inc_b = best["pool"], best["dev_b"]
        trace.append({"round": t, "accepted": accepted, "dev_b": inc_b})
        log(f"round {t}: {'accepted' if accepted else 'no change'}; incumbent dev-B {inc_b}")
        dump("trace.json", trace)

    dump("final_pool.json", pool)
    if not a.skip_test:
        jobs = {"full_system": (V0, FULL), "pool_round0": (pool0, None), "pool_final": (pool, None)}
        with ThreadPoolExecutor(3) as ex:
            res = dict(zip(jobs, ex.map(lambda j: summarize(evaluate(cas, j[0], test, j[1])),
                                        jobs.values())))
        dump("test.json", res)
        log(f"TEST: {json.dumps(res)}")


if __name__ == "__main__":
    main()
