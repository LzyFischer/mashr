"""The agent pool: what the designer edits (slow loop) and what the orchestrator reads (fast loop).

  agents  name -> {"role": str, "skills": [skill ids]}   at most 8 agents, 5 skills each
  skills  id -> text                                       how-to knowledge held by agents
  policy  str                                              the orchestrator's dispatch rules

The orchestrator chooses the architecture per question: an ordered list of stages, each with a
type, the agents who fill it and a run condition (evaluated by a rule engine, no extra call):
  {"stages": [{"type": "solve", "agents": {agent: {"thinking": off|low|high, "skills": [ids]}},
               "if": "always"},
              {"type": "review", "agents": {...}, "if": "disagree"}, ...]}
  type: solve (independent if first; later solve stages are debate rounds that see earlier work),
        review (check the earlier work), decide (pick the final answer)
  if:   always | disagree (the answers produced so far are not unanimous, or one is missing)
Each stage sees the full outputs of every earlier stage that ran. The final answer is the majority
of the last stage that ran. At most 4 stages and 4 agents per stage; the first stage is a solve
stage that always runs.
"""
import copy
import json
import re

THINK = ("off", "low", "high")
NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,30}$")
LIMITS = {"agents": 8, "skills": 30, "skills_per_agent": 5, "skill_chars": 500,
          "policy_chars": 2000, "role_chars": 400}

V0 = {
    "agents": {
        "solver_A": {"role": "You are a math solver. Solve the problem directly and concisely.",
                     "skills": ["reread_question"]},
        "solver_B": {"role": "You are a careful math solver. Solve the problem step by step, then "
                             "double-check each arithmetic step before giving the answer.",
                     "skills": ["reread_question", "percent_base", "check_units"]},
        "solver_C": {"role": "You are a math solver who prefers algebra. Define variables, write "
                             "equations for the problem, and solve them.",
                     "skills": ["verify_by_substitution"]},
        "critic": {"role": "You are a reviewer. Check the given solutions for errors in reasoning or "
                           "arithmetic, say which one (if any) is correct, and give the answer you "
                           "believe is correct.", "skills": ["check_units", "verify_by_substitution"]},
        "judge": {"role": "You are the final decider. Read all solutions and reviews and decide the "
                          "single correct final answer. Briefly justify the choice.", "skills": []},
    },
    "skills": {
        "reread_question": "Before answering, re-read the question and make sure your final number "
                           "answers exactly what is asked (units, total vs. part, requested form).",
        "percent_base": "For percentages and fractions, first write down what quantity the percent "
                        "or fraction is taken of, then compute.",
        "check_units": "Convert all quantities to the same unit before combining them.",
        "verify_by_substitution": "After finding the answer, plug it back into the conditions of the "
                                  "problem and confirm every condition holds.",
    },
    "policy": "(no rules yet)",
}

STAGE_TYPES = ("solve", "review", "decide")
MAX_STAGES, MAX_PER_STAGE = 4, 4

# reference ("full system"): everyone, every stage, always
FULL = {"stages": [
    {"type": "solve", "agents": {a: {"thinking": "low"} for a in ("solver_A", "solver_B", "solver_C")},
     "if": "always"},
    {"type": "review", "agents": {"critic": {"thinking": "low"}}, "if": "always"},
    {"type": "decide", "agents": {"judge": {"thinking": "off"}}, "if": "always"}]}


def fallback_plan(pool: dict) -> dict:
    """Fixed, not editable: the first agent solves alone with thinking low."""
    first = next(iter(pool["agents"]))
    return {"stages": [{"type": "solve", "agents": {first: {"thinking": "low", "skills": []}},
                        "if": "always"}]}


def _agents(pool, raw, probs):
    """Normalize a stage's agents: accepts {agent: spec}, [agent, ...] or "agent"."""
    if isinstance(raw, str):
        raw = [raw]
    if isinstance(raw, list):
        raw = {a: {} for a in raw if isinstance(a, str)}
    if not isinstance(raw, dict):
        return {}
    out = {}
    for a, spec in raw.items():
        if a not in pool["agents"]:
            probs.append(f"{a!r} is not in the pool")
            continue
        if len(out) == MAX_PER_STAGE:
            probs.append(f"more than {MAX_PER_STAGE} agents in a stage")
            break
        spec = spec if isinstance(spec, dict) else {}
        th = spec.get("thinking", "off")
        sk = spec.get("skills") if isinstance(spec.get("skills"), list) else []
        out[a] = {"thinking": th if th in THINK else "off",
                  "skills": [x for x in sk if x in pool["agents"][a]["skills"]]}
    return out


def check_plan(pool: dict, p) -> tuple[dict | None, list[str]]:
    """Normalize an orchestrator plan (the per-question architecture). Returns (plan, problems)."""
    if not isinstance(p, dict) or not isinstance(p.get("stages"), list):
        return None, ["plan needs a 'stages' list"]
    probs: list = []
    stages = []
    for raw in p["stages"]:
        if not isinstance(raw, dict):
            continue
        typ = raw.get("type") if raw.get("type") in STAGE_TYPES else "solve"
        ag = _agents(pool, raw.get("agents"), probs)
        if not ag:
            continue
        if len(stages) == MAX_STAGES:
            probs.append(f"more than {MAX_STAGES} stages")
            break
        cond = "disagree" if raw.get("if") == "disagree" and stages else "always"
        stages.append({"type": typ, "agents": ag, "if": cond})
    if not stages:
        return None, probs + ["no stage with a valid agent"]
    if stages[0]["type"] != "solve":
        probs.append("first stage forced to solve")
        stages[0]["type"] = "solve"
    return {"stages": stages}, probs


def validate(pool: dict) -> list[str]:
    errs = []
    for k in ("agents", "skills", "policy"):
        if k not in pool:
            errs.append(f"missing key {k!r}")
    if errs:
        return errs
    if not pool["agents"]:
        errs.append("the pool has no agents")
    if len(pool["agents"]) > LIMITS["agents"]:
        errs.append(f"too many agents: {len(pool['agents'])} > {LIMITS['agents']}")
    if len(pool["skills"]) > LIMITS["skills"]:
        errs.append(f"too many skills: {len(pool['skills'])} > {LIMITS['skills']}")
    for sid, txt in pool["skills"].items():
        if not NAME.match(sid):
            errs.append(f"bad skill id {sid!r} (letters, digits, underscores)")
        if not isinstance(txt, str) or not txt.strip() or len(txt) > LIMITS["skill_chars"]:
            errs.append(f"skill {sid!r}: text must be 1..{LIMITS['skill_chars']} chars")
    for name, a in pool["agents"].items():
        if not NAME.match(name):
            errs.append(f"bad agent name {name!r}")
        if not isinstance(a, dict) or not str(a.get("role", "")).strip():
            errs.append(f"{name!r} needs a role")
            continue
        if len(a["role"]) > LIMITS["role_chars"]:
            errs.append(f"{name!r}: role longer than {LIMITS['role_chars']} chars")
        sk = a.get("skills", [])
        if len(sk) > LIMITS["skills_per_agent"]:
            errs.append(f"{name!r} holds {len(sk)} skills > {LIMITS['skills_per_agent']}")
        for s in sk:
            if s not in pool["skills"]:
                errs.append(f"{name!r} holds unknown skill {s!r}")
    if not isinstance(pool["policy"], str) or len(pool["policy"]) > LIMITS["policy_chars"]:
        errs.append(f"policy must be a string of at most {LIMITS['policy_chars']} chars")
    return errs


def apply_ops(pool: dict, ops) -> tuple[dict, list[str]]:
    """Apply designer edit operations; returns (new pool, errors incl. validation errors)."""
    o = copy.deepcopy(pool)
    errs = []
    if not isinstance(ops, list) or not ops:
        return o, ["ops must be a non-empty list"]
    for i, op in enumerate(ops):
        try:
            kind = op["op"]
            if kind == "add_agent":
                if op["name"] in o["agents"]:
                    raise ValueError(f"agent {op['name']!r} exists")
                o["agents"][op["name"]] = {"role": op["role"], "skills": list(op.get("skills", []))}
            elif kind == "remove_agent":
                del o["agents"][op["name"]]
            elif kind == "edit_role":
                o["agents"][op["name"]]["role"] = op["role"]
            elif kind == "set_skills":
                o["agents"][op["name"]]["skills"] = list(op["skills"])
            elif kind in ("add_skill", "edit_skill"):
                if (op["id"] in o["skills"]) != (kind == "edit_skill"):
                    raise ValueError(f"skill {op['id']!r} " +
                                     ("exists (use edit_skill)" if kind == "add_skill"
                                      else "does not exist"))
                o["skills"][op["id"]] = op["text"]
                for name in op.get("to", []):
                    if op["id"] not in o["agents"][name]["skills"]:
                        o["agents"][name]["skills"].append(op["id"])
            elif kind == "remove_skill":
                del o["skills"][op["id"]]
                for a in o["agents"].values():
                    a["skills"] = [s for s in a["skills"] if s != op["id"]]
            elif kind == "set_policy":
                o["policy"] = op["text"]
            else:
                raise ValueError(f"unknown op {kind!r}")
        except (KeyError, TypeError, ValueError) as e:
            errs.append(f"op {i} ({json.dumps(op)[:120]}): {type(e).__name__} {e}")
    # removed agents must not linger in the policy text
    for name in set(pool["agents"]) - set(o["agents"]):
        if re.search(rf"\b{re.escape(name)}\b", o["policy"]):
            errs.append(f"policy still mentions removed agent {name!r}")
    return o, errs + validate(o)


def orchestrator_prompt(pool: dict) -> str:
    lines = ["You are the orchestrator of a pool of agents that solve math problems. For each "
             "problem you design, before anyone works on it, the architecture that solves it: the "
             "stages, who works in each stage, how much each one thinks, which of their skills to "
             "switch on, and when each later stage runs. Spend as little as possible while keeping "
             "accuracy.", "",
             "## Architecture",
             "An ordered list of 1-4 stages. Stage types:",
             "- solve: the agents solve the problem. In the first stage they work independently; a "
             "later solve stage is a debate round in which they see the earlier work and revise.",
             "- review: the agents check the earlier work and give the answer they believe is right.",
             "- decide: the agents pick the single final answer from the earlier work.",
             "Each later stage has a condition: \"always\", or \"disagree\" = run only if the "
             "answers produced so far are not all the same (or one is missing). Every stage sees the "
             "full outputs of all earlier stages that ran. The final answer is the majority answer "
             "of the last stage that ran. A single solver is the cheapest architecture. With a single "
             "solver, \"disagree\" never fires (unless the answer is missing): to have one solver "
             "checked, use a review stage with \"always\".", "",
             "## Agents (thinking off ~200 generated tokens per call; low up to ~1000 extra; high "
             "up to ~4000 extra)"]
    for name, a in pool["agents"].items():
        lines.append(f"- {name}: {a['role'][:200]} [skills: {', '.join(a['skills']) or 'none'}]")
    used = {x for a in pool["agents"].values() for x in a["skills"]}
    if used:
        lines += ["", "## Skills (switch on only what the problem needs)"]
        lines += [f"- {x}: {pool['skills'][x][:120]}" for x in pool["skills"] if x in used]
    lines += ["", "## Output: exactly one JSON object, nothing else",
              '{"stages": [{"type": "solve", "agents": {"<agent>": {"thinking": "off|low|high", '
              '"skills": ["<id>"]}}, "if": "always"}, {"type": "review", "agents": {...}, '
              '"if": "disagree"}]}', "",
              "## Dispatch policy", pool["policy"]]
    return "\n".join(lines)
