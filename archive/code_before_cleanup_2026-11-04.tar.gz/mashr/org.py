"""The organization: what dataset-level RSI edits and what the per-question HR reads.

  staff        name -> {"job": str, "skills": [skill ids]}       the roster the HR may assign
  alumni       same shape: fired staff, invisible to the HR, can be rehired by RSI
  skills       id -> text                                          how-to knowledge, held by staff
  sops         id -> {"desc": str, "stages": [stage]}              escalation procedures
  handbook     str                                                 the HR's dispatch rules
  default_plan plan                                                used when the HR's output is invalid

A stage is {"id", "task": solve|review|decide, "when": [cond], "sees": [stage ids],
            "show": full|answer}. "when" is OR-ed; conditions are evaluated by the rule engine on
earlier stages, with no HR call:
  always | disagree:<s> | unsure:<s> | missing:<s> | long:<s>:<tokens>
"show" is how this stage's output is shown to later stages that "see" it.

A plan (HR output) is
  {"sop": id, "assign": {stage: [staff]}, "thinking": {staff: off|low|high},
   "skills": {staff: [ids]}, "guide": {staff: "<short note>"}}
or {"sop": "self", "answer": "<number>"}.
"""
import copy
import json
import re

TASKS = ("solve", "review", "decide")
THINK = ("off", "low", "high")
NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,30}$")
LIMITS = {"staff": 8, "sops": 8, "skills": 30, "skill_chars": 600, "handbook_chars": 3000,
          "guide_chars": 200}

V0 = {
    "staff": {
        "solver_A": {"job": "You are a math solver. Solve the problem directly and concisely.",
                     "skills": ["reread_question"]},
        "solver_B": {"job": "You are a careful math solver. Solve the problem step by step, then "
                            "double-check each arithmetic step before giving the answer.",
                     "skills": ["reread_question", "percent_base", "check_units"]},
        "solver_C": {"job": "You are a math solver who prefers algebra. Define variables, write "
                            "equations for the problem, and solve them.",
                     "skills": ["verify_by_substitution"]},
        "critic": {"job": "You are a critic. Check the given solutions for errors in reasoning or "
                          "arithmetic, say which one (if any) is correct, and give the answer you "
                          "believe is correct.", "skills": ["check_units", "verify_by_substitution"]},
        "judge": {"job": "You are the judge. Read the team's solutions and decide the single correct "
                         "final answer. Briefly justify the choice.", "skills": []},
    },
    "alumni": {},
    "skills": {
        "reread_question": "Before answering, re-read the last sentence of the problem and make sure "
                           "your final number answers exactly what is asked (units, total vs. part).",
        "percent_base": "For percentages and fractions, first write down what quantity the percent "
                        "or fraction is taken of, then compute.",
        "check_units": "Convert all quantities to the same unit (minutes/hours, cents/dollars, "
                       "days/weeks) before combining them.",
        "verify_by_substitution": "After finding the answer, plug it back into the conditions of the "
                                  "problem and confirm every condition holds.",
    },
    "sops": {
        "solo": {"desc": "one employee solves", "stages": [
            {"id": "draft", "task": "solve", "when": ["always"], "sees": [], "show": "full"}]},
        "draft_check": {"desc": "one employee solves; a reviewer checks only if the draft is unsure",
                        "stages": [
            {"id": "draft", "task": "solve", "when": ["always"], "sees": [], "show": "full"},
            {"id": "check", "task": "review", "when": ["unsure:draft"], "sees": ["draft"],
             "show": "full"}]},
        "vote": {"desc": "several employees solve independently; a decider is called only if they "
                         "disagree", "stages": [
            {"id": "vote", "task": "solve", "when": ["always"], "sees": [], "show": "full"},
            {"id": "decide", "task": "decide", "when": ["disagree:vote"], "sees": ["vote"],
             "show": "full"}]},
        "debate": {"desc": "independent solutions, then a review round, then a final decision",
                   "stages": [
            {"id": "r1", "task": "solve", "when": ["always"], "sees": [], "show": "full"},
            {"id": "r2", "task": "review", "when": ["always"], "sees": ["r1"], "show": "full"},
            {"id": "final", "task": "decide", "when": ["always"], "sees": ["r2"], "show": "full"}]},
    },
    "handbook": "(no rules yet)",
    "default_plan": {"sop": "vote", "assign": {"vote": ["solver_A", "solver_B", "solver_C"],
                                               "decide": ["judge"]},
                     "thinking": {}, "skills": {}, "guide": {}},
}

# the reference ("full team"): everyone, thinking low, every stage of the debate
FULL_TEAM = {"sop": "debate",
             "assign": {"r1": ["solver_A", "solver_B", "solver_C"],
                        "r2": ["solver_A", "solver_B", "solver_C", "critic"], "final": ["judge"]},
             "thinking": {"solver_A": "low", "solver_B": "low", "solver_C": "low", "critic": "low",
                          "judge": "off"}, "skills": {}, "guide": {}}


def parse_cond(c: str, earlier: list[str]) -> str | None:
    """Return an error message, or None if the condition is valid."""
    if c == "always":
        return None
    parts = c.split(":")
    if parts[0] in ("disagree", "unsure", "missing") and len(parts) == 2:
        return None if parts[1] in earlier else f"condition {c!r} refers to a later/unknown stage"
    if parts[0] == "long" and len(parts) == 3 and parts[2].isdigit():
        return None if parts[1] in earlier else f"condition {c!r} refers to a later/unknown stage"
    return f"bad condition {c!r}"


def check_plan(org: dict, p: dict) -> tuple[dict | None, list[str]]:
    """Normalize an HR plan against the org. Returns (plan or None, problems)."""
    probs = []
    if not isinstance(p, dict):
        return None, ["plan is not an object"]
    sop = p.get("sop")
    if sop == "self":
        if "answer" not in p:
            return None, ["self plan without answer"]
        return {"sop": "self", "answer": str(p["answer"])}, []
    if sop not in org["sops"]:
        return None, [f"unknown sop {sop!r}"]
    stages = org["sops"][sop]["stages"]
    assign_in = p.get("assign") if isinstance(p.get("assign"), dict) else {}
    ids = [st["id"] for st in stages]
    if assign_in and not set(assign_in) & set(ids):
        # small HRs mix up stage names across SOPs: map their stages onto this SOP's by order
        assign_in = dict(zip(ids, assign_in.values()))
        probs.append("stage names remapped by order")
    assign = {}
    for st in stages:
        who = assign_in.get(st["id"], [])
        who = [who] if isinstance(who, str) else who if isinstance(who, list) else []
        kept = []
        for w in who:
            if w in org["staff"] and w not in kept:
                kept.append(w)
            elif w not in org["staff"]:
                probs.append(f"{w!r} is not on the roster")
        assign[st["id"]] = kept
    if not assign[stages[0]["id"]]:
        return None, probs + [f"first stage {stages[0]['id']!r} has nobody assigned"]
    used = {w for ws in assign.values() for w in ws}
    th_in = p.get("thinking") if isinstance(p.get("thinking"), dict) else {}
    sk_in = p.get("skills") if isinstance(p.get("skills"), dict) else {}
    gd_in = p.get("guide") if isinstance(p.get("guide"), dict) else {}
    thinking = {w: (th_in.get(w) if th_in.get(w) in THINK else "off") for w in used}
    skills = {w: [s for s in (sk_in.get(w) or []) if s in org["staff"][w]["skills"]]
              for w in used if isinstance(sk_in.get(w) or [], list)}
    guide = {w: str(gd_in[w])[:LIMITS["guide_chars"]] for w in used if gd_in.get(w)}
    return {"sop": sop, "assign": assign, "thinking": thinking, "skills": skills,
            "guide": guide}, probs


def validate(org: dict) -> list[str]:
    errs = []
    for k in ("staff", "alumni", "skills", "sops", "handbook", "default_plan"):
        if k not in org:
            errs.append(f"missing key {k!r}")
    if errs:
        return errs
    if not org["staff"]:
        errs.append("roster is empty")
    for k, lim in (("staff", "staff"), ("sops", "sops"), ("skills", "skills")):
        if len(org[k]) > LIMITS[lim]:
            errs.append(f"too many {k}: {len(org[k])} > {LIMITS[lim]}")
    for sid, txt in org["skills"].items():
        if not NAME.match(sid):
            errs.append(f"bad skill id {sid!r} (letters, digits, underscores)")
        if not isinstance(txt, str) or not txt.strip() or len(txt) > LIMITS["skill_chars"]:
            errs.append(f"skill {sid!r} text must be 1..{LIMITS['skill_chars']} chars")
    for group in ("staff", "alumni"):
        for name, s in org[group].items():
            if not NAME.match(name):
                errs.append(f"bad staff name {name!r}")
            if not isinstance(s, dict) or not str(s.get("job", "")).strip():
                errs.append(f"{name!r} needs a job description")
                continue
            for sk in s.get("skills", []):
                if sk not in org["skills"]:
                    errs.append(f"{name!r} holds unknown skill {sk!r}")
    both = set(org["staff"]) & set(org["alumni"])
    if both:
        errs.append(f"in both staff and alumni: {sorted(both)}")
    if "self" in org["sops"]:
        errs.append("'self' is reserved")
    for sop_id, sop in org["sops"].items():
        if not NAME.match(sop_id):
            errs.append(f"bad sop id {sop_id!r}")
        stages = sop.get("stages") if isinstance(sop, dict) else None
        if not stages:
            errs.append(f"sop {sop_id!r} has no stages")
            continue
        earlier = []
        for i, st in enumerate(stages):
            sid = st.get("id")
            if not sid or sid in earlier:
                errs.append(f"sop {sop_id!r}: stage ids must be unique and non-empty")
            if st.get("task") not in TASKS:
                errs.append(f"sop {sop_id!r} stage {sid!r}: task must be one of {TASKS}")
            if st.get("show", "full") not in ("full", "answer"):
                errs.append(f"sop {sop_id!r} stage {sid!r}: show must be full or answer")
            when = st.get("when", ["always"])
            if not isinstance(when, list) or not when:
                errs.append(f"sop {sop_id!r} stage {sid!r}: when must be a non-empty list")
                when = []
            if i == 0 and when != ["always"]:
                errs.append(f"sop {sop_id!r}: first stage must have when ['always']")
            for c in when:
                e = parse_cond(str(c), earlier)
                if e:
                    errs.append(f"sop {sop_id!r} stage {sid!r}: {e}")
            for s in st.get("sees", []):
                if s not in earlier:
                    errs.append(f"sop {sop_id!r} stage {sid!r} sees unknown/later stage {s!r}")
            if i > 0 and not st.get("sees"):
                errs.append(f"sop {sop_id!r} stage {sid!r}: later stages must see an earlier stage")
            earlier.append(sid)
    if not isinstance(org["handbook"], str) or len(org["handbook"]) > LIMITS["handbook_chars"]:
        errs.append(f"handbook must be a string of at most {LIMITS['handbook_chars']} chars")
    else:
        for name in org["alumni"]:
            if re.search(rf"\b{re.escape(name)}\b", org["handbook"]):
                errs.append(f"handbook still mentions fired employee {name!r}")
    if not errs:
        plan, probs = check_plan(org, org["default_plan"])
        if plan is None or plan["sop"] == "self" or probs:
            errs.append(f"default_plan invalid: {probs or 'self or unparseable'}")
    return errs


def apply_ops(org: dict, ops: list) -> tuple[dict, list[str]]:
    """Apply RSI edit operations; returns (new org, errors). Errors include validation errors."""
    o = copy.deepcopy(org)
    errs = []
    if not isinstance(ops, list) or not ops:
        return o, ["ops must be a non-empty list"]
    for i, op in enumerate(ops):
        try:
            kind = op["op"]
            if kind == "hire":
                if op["name"] in o["staff"] or op["name"] in o["alumni"]:
                    raise ValueError(f"{op['name']!r} already exists (use rehire for alumni)")
                o["staff"][op["name"]] = {"job": op["job"], "skills": list(op.get("skills", []))}
            elif kind == "fire":
                o["alumni"][op["name"]] = o["staff"].pop(op["name"])
                for ws in o["default_plan"].get("assign", {}).values():
                    if op["name"] in ws:
                        ws.remove(op["name"])
            elif kind == "rehire":
                o["staff"][op["name"]] = o["alumni"].pop(op["name"])
            elif kind == "edit_job":
                o["staff"][op["name"]]["job"] = op["job"]
            elif kind == "set_skills":
                o["staff"][op["name"]]["skills"] = list(op["skills"])
            elif kind in ("add_skill", "edit_skill"):
                if kind == "add_skill" and op["id"] in o["skills"]:
                    raise ValueError(f"skill {op['id']!r} exists (use edit_skill)")
                if kind == "edit_skill" and op["id"] not in o["skills"]:
                    raise ValueError(f"skill {op['id']!r} does not exist")
                o["skills"][op["id"]] = op["text"]
                for name in op.get("to", []):
                    if op["id"] not in o["staff"][name]["skills"]:
                        o["staff"][name]["skills"].append(op["id"])
            elif kind == "remove_skill":
                del o["skills"][op["id"]]
                for s in list(o["staff"].values()) + list(o["alumni"].values()):
                    s["skills"] = [x for x in s.get("skills", []) if x != op["id"]]
            elif kind == "set_sop":
                o["sops"][op["id"]] = op["sop"]
            elif kind == "remove_sop":
                del o["sops"][op["id"]]
                if o["default_plan"].get("sop") == op["id"]:
                    raise ValueError("cannot remove the default plan's sop (set_default first)")
            elif kind == "set_handbook":
                o["handbook"] = op["text"]
            elif kind == "set_default":
                o["default_plan"] = op["plan"]
            else:
                raise ValueError(f"unknown op {kind!r}")
        except (KeyError, TypeError, ValueError) as e:
            errs.append(f"op {i} ({json.dumps(op)[:120]}): {type(e).__name__} {e}")
    return o, errs + validate(o)


def hr_prompt(org: dict) -> str:
    """The HR's handbook as it sees it: roster, skill ids, SOPs, rules, output format."""
    lines = ["You are the HR manager of a team that solves math problems. For each problem "
             "you decide, before anyone works on it, which procedure (SOP) to run, who fills each "
             "stage, how much each person thinks, which of their skills to switch on, and an "
             "optional one-line note per person. Every generated token costs money; keep the "
             "team's accuracy while spending as little as possible.", "",
             "## Roster (cost = generated tokens; thinking off ~150, low up to ~1000 extra, high up "
             "to ~4000 extra)"]
    for name, s in org["staff"].items():
        sk = ", ".join(s["skills"]) or "none"
        lines.append(f"- {name}: {s['job'][:160]} [skills: {sk}]")
    lines += ["", "## Skills (switch on only the ones the problem needs)"]
    for sid, txt in org["skills"].items():
        if any(sid in s["skills"] for s in org["staff"].values()):
            lines.append(f"- {sid}: {txt[:120]}")
    lines += ["", "## SOPs (later stages run only when their condition fires; unsure = someone "
              "reported low confidence or gave no answer)"]
    for sop_id, sop in org["sops"].items():
        st = " -> ".join(f"{s['id']}({s['task']}" + ("" if s.get("when", ["always"]) == ["always"]
                                                     else f" if {' or '.join(s['when'])}") + ")"
                         for s in sop["stages"])
        tmpl = ", ".join(f'"{s["id"]}": [...]' for s in sop["stages"])
        lines.append(f"- {sop_id}: {sop.get('desc', '')}. Stages: {st}. assign: {{{tmpl}}}")
    lines += ["- self: you answer the problem yourself, nobody else works on it.", "",
              "## Output: exactly one JSON object, nothing else",
              '{"sop": "<sop id>", "assign": {"<stage id>": ["<employee>", ...]}, '
              '"thinking": {"<employee>": "off|low|high"}, "skills": {"<employee>": ["<skill id>"]}, '
              '"guide": {"<employee>": "<at most 20 words>"}}',
              'or {"sop": "self", "answer": "<number>"}. Use the stage names of the SOP you chose; '
              'stages you leave empty are skipped.',
              "", "## Dispatch rules", org["handbook"]]
    return "\n".join(lines)
