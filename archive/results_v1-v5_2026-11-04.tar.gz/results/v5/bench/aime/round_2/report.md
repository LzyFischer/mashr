# Diagnostic report (dev-A)

Organization: acc 88.7%, cost 37739/question, of which the HR 1900 (HR prompt 4897 chars). 43 distinct architectures, 2.6 nodes per question. HR outputs: repaired 0, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| AIME 1983 | 2 | 100% | - | 35349 | 0 | coder.high,solver.high>verifier.max 1, coder.max,discrete.high>verifier.max 1 |
| AIME 1985 | 3 | 67% | - | 35691 | 0 | coder.max,geometry.max>verifier.max 1, solver.high>verifier.max 1, coder.high,discrete.high>verifier.max 1 |
| AIME 1986 | 4 | 75% | - | 27746 | 0 | coder.high,solver.high>verifier.max 1, coder.low>verifier.low 1, solver.max 1 |
| AIME 1987 | 3 | 100% | - | 22775 | 0 | discrete.max>verifier.max 1, solver.max 1, coder.high,geometry.high>verifier.max 1 |
| AIME 1988 | 1 | 100% | - | 50772 | 0 | coder.max,discrete.high>verifier.max 1 |
| AIME 1989 | 2 | 100% | - | 24240 | 0 | solver.max 1, coder.high,solver.high>verifier.max 1 |
| AIME 1991 | 1 | 100% | - | 59776 | 0 | coder.max,geometry.max>verifier.max 1 |
| AIME 1992 | 2 | 100% | - | 54003 | 0 | coder.max,solver.max>verifier.max 1, coder.max,discrete.max>verifier.max 1 |
| AIME 1993 | 4 | 100% | - | 38445 | 0 | coder.max,solver.max>verifier.max 1, coder.high,solver.high>verifier.max 1, solver.max 1 |
| AIME 1994 | 1 | 100% | - | 21082 | 0 | solver.max 1 |
| AIME 1995 | 2 | 100% | - | 22415 | 0 | solver.high>verifier.max 1, geometry.high>verifier.max 1 |
| AIME 1996 | 2 | 100% | - | 22571 | 0 | solver.high>verifier.max 1, coder.max,discrete.high>verifier.max 1 |
| AIME 1997 | 1 | 100% | - | 33752 | 0 | coder.max>verifier.max 1 |
| AIME 1999 | 6 | 100% | - | 32565 | 0 | coder.high,solver.high>verifier.max 1, solver.max 1, solver.high>verifier.max 1 |
| AIME 2000 | 3 | 100% | - | 46025 | 0 | coder.max,geometry.max>verifier.max 1, algebra.high,coder.max,solver.max>verifier.max 1, solver.max 1 |
| AIME 2001 | 6 | 100% | - | 38207 | 0 | coder.max,solver.max>verifier.max 2, coder.max,discrete.high>verifier.max 1, solver.high 1 |
| AIME 2002 | 3 | 100% | - | 29651 | 0 | discrete.high>verifier.max 1, coder.max,geometry.max>verifier.max 1, solver.max 1 |
| AIME 2003 | 5 | 80% | - | 39769 | 0 | coder.max,discrete.max>verifier.max 1, geometry.max>solver.high>verifier.max 1, geometry.high>verifier.max 1 |
| AIME 2004 | 8 | 100% | - | 43245 | 0 | coder.max,geometry.max>verifier.max 2, coder.max,solver.max>verifier.max 2, coder.max,solver.high>verifier.max 1 |
| AIME 2005 | 8 | 100% | - | 33855 | 0 | coder.max,solver.max>verifier.max 2, coder.max,solver.high>verifier.max 2, solver.high 1 |
| AIME 2006 | 9 | 89% | - | 40024 | 0 | coder.max,geometry.max,solver.max>verifier.max 2, discrete.high,solver.high>verifier.max 1, solver.max 1 |
| AIME 2007 | 5 | 100% | - | 42985 | 0 | coder.max>verifier.max 1, coder.high,solver.max>verifier.max 1, geometry.max>coder.max>verifier.max 1 |
| AIME 2008 | 5 | 80% | - | 35324 | 0 | solver.high 1, coder.max,geometry.max,solver.max>verifier.max 1, coder.max,geometry.max>verifier.max 1 |
| AIME 2009 | 3 | 100% | - | 26028 | 0 | coder.high,solver.high>verifier.max 1, algebra.high,coder.high>verifier.max 1, coder.max,solver.high>verifier.max 1 |
| AIME 2010 | 5 | 80% | - | 44732 | 0 | coder.max,geometry.max>verifier.max 2, coder.max,discrete.high>verifier.max 1, algebra.high,discrete.high,solver.max>verifier.max 1 |
| AIME 2011 | 6 | 83% | - | 33805 | 0 | coder.max,geometry.high>verifier.max 1, solver.max 1, geometry.max 1 |
| AIME 2012 | 3 | 100% | - | 38119 | 0 | coder.max,discrete.max>verifier.max 1, coder.max,discrete.high>verifier.max 1, coder.max,solver.high>verifier.max 1 |
| AIME 2013 | 3 | 100% | - | 55743 | 0 | coder.max,discrete.max>verifier.max 1, coder.max,geometry.max>verifier.max>judge.max 1, coder.max,solver.max>verifier.max 1 |
| AIME 2014 | 7 | 71% | - | 42279 | 0 | solver.max 3, algebra.max,coder.max>verifier.max 1, coder.max,discrete.max>verifier.max 1 |
| AIME 2015 | 8 | 88% | - | 26242 | 0 | coder.max,discrete.high>verifier.max 3, solver.high 2, solver.max 2 |
| AIME 2016 | 4 | 50% | - | 50825 | 0 | geometry.max,solver.high>verifier.max 1, coder.high,solver.high>verifier.max 1, coder.max,solver.max>verifier.max 1 |
| AIME 2017 | 6 | 100% | - | 44763 | 0 | coder.max,discrete.high>verifier.max 1, solver.max 1, coder.max,geometry.high,solver.max>verifier.max 1 |
| AIME 2018 | 6 | 50% | - | 45927 | 0 | geometry.high>verifier.max 1, coder.max,discrete.max>verifier.max 1, coder.max,solver.max>verifier.max 1 |
| AIME 2019 | 1 | 100% | - | 52593 | 0 | coder.max,solver.max>verifier.max 1 |
| AIME 2020 | 6 | 83% | - | 32187 | 0 | discrete.high>verifier.high 1, solver.high 1, coder.max,geometry.max>verifier.max 1 |
| AIME 2021 | 6 | 83% | - | 38979 | 0 | coder.high,solver.high>verifier.max 2, solver.max 1, solver.high>discrete.high>verifier.max 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| solver.max | 19 | 89% | 20539 |
| coder.max,solver.max>verifier.max | 16 | 100% | 54073 |
| coder.max,geometry.max>verifier.max | 13 | 92% | 55915 |
| coder.high,solver.high>verifier.max | 12 | 92% | 28153 |
| coder.max,discrete.high>verifier.max | 12 | 83% | 42952 |
| coder.max,solver.high>verifier.max | 9 | 100% | 33045 |
| coder.max,discrete.max>verifier.max | 8 | 75% | 55079 |
| solver.high | 6 | 67% | 9777 |
| solver.high>verifier.max | 6 | 100% | 18980 |
| geometry.high>verifier.max | 3 | 100% | 20982 |
| coder.max,geometry.max,solver.max>verifier.max | 3 | 100% | 75802 |
| coder.max>verifier.max | 3 | 67% | 44241 |
| discrete.high>verifier.max | 3 | 100% | 17011 |
| coder.high,discrete.high>verifier.max | 3 | 67% | 28445 |
| coder.max,geometry.high,solver.max>verifier.max | 2 | 100% | 60638 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| verifier.max (with inputs) | 120 | 90% | 18% | 11855 | 28 | 18 | 1 |
| coder.max | 73 | 81% | 79% | 19895 | - | - | - |
| solver.max | 45 | 89% | 89% | 19025 | - | - | - |
| solver.high | 42 | 86% | 100% | 7456 | - | - | - |
| geometry.max | 25 | 60% | 96% | 19592 | - | - | - |
| discrete.high | 22 | 73% | 100% | 8381 | - | - | - |
| coder.high | 19 | 89% | 100% | 9915 | - | - | - |
| discrete.max | 9 | 67% | 67% | 20044 | - | - | - |
| geometry.high | 8 | 50% | 100% | 7959 | - | - | - |
| algebra.high | 6 | 67% | 100% | 7733 | - | - | - |
| coder.low | 4 | 100% | 100% | 5433 | - | - | - |
| verifier.low (with inputs) | 3 | 100% | 100% | 4011 | - | - | - |
| coder.max (with inputs) | 2 | 100% | 0% | 8321 | - | - | - |
| solver.high (with inputs) | 2 | 0% | 100% | 8501 | 2 | - | 2 |
| algebra.max | 2 | 0% | 100% | 33493 | - | - | - |
| judge.max (with inputs) | 2 | 100% | 50% | 11868 | - | - | - |
| verifier.high (with inputs) | 1 | 100% | 100% | 7613 | - | - | - |
| discrete.high (with inputs) | 1 | 100% | 0% | 2561 | - | - | - |
| algebra.high (with inputs) | 1 | 100% | 0% | 2995 | - | - | - |
| solver.low | 1 | 100% | 100% | 4236 | - | - | - |
| coder.low (with inputs) | 1 | 100% | 100% | 2959 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.max (output) | 59 | 8 | 0 | 51 | 12263 |
| coder.max (input) | 36 | 2 | 2 | 32 | 17445 |
| solver.high (input) | 20 | 0 | 1 | 19 | 5145 |
| geometry.max (input) | 14 | 1 | 2 | 11 | 15565 |
| solver.max (input) | 13 | 1 | 0 | 12 | 15128 |
| coder.high (input) | 11 | 0 | 0 | 11 | 8266 |
| discrete.high (input) | 9 | 0 | 0 | 9 | 6535 |
| discrete.max (input) | 5 | 0 | 0 | 5 | 9061 |
| geometry.high (input) | 4 | 0 | 0 | 4 | 1397 |
| algebra.high (input) | 3 | 0 | 0 | 3 | 7512 |
| verifier.high (output) | 1 | 0 | 0 | 1 | 7613 |
| algebra.max (input) | 1 | 0 | 0 | 1 | 48420 |

HR output problems: minor: line 1: non-node argument ignored (23); minor: line 2: non-node argument ignored (2)

## Organization wrong (17)
- [AIME 2016] Squares $ABCD$ and $EFGH$ have a common center and $\overline{AB} || \overline{EF}$ . The area of $ABCD$ is 2016, and the area of $EFGH$ is a smaller positive integer. Square $IJKL$ is constructed so that each of its vertices lies on a side of $ABCD$ and each vertex of $EFGH$ lie
  architecture: a = geometry("max"); b = solver("high"); out = verifier("max", a, b); return out; answered 14, correct 840
- [AIME 2018] Find the number of functions $f$ from $\{0, 1, 2, 3, 4, 5, 6\}$ to the integers such that $f(0) = 0$ , $f(6) = 12$ , and \[|x - y|  \leq  |f(x) - f(y)|  \leq  3|x - y|\] for all $x$ and $y$ in $\{0, 1, 2, 3, 4, 5, 6\}$ .
  architecture: a = discrete("max"); b = coder("max"); out = verifier("max", a, b); return out; answered 173, correct 185
- [AIME 2014] A rectangle has sides of length $a$ and 36. A hinge is installed at each vertex of the rectangle, and at the midpoint of each side of length 36. The sides of length $a$ can be pressed toward each other keeping those two sides parallel so the rectangle becomes a convex hexagon as 
  architecture: a = solver("max"); return a; answered 64, correct 720
- [AIME 2020] Let $P(x)$ be a quadratic polynomial with complex coefficients whose $x^2$ coefficient is $1.$ Suppose the equation $P(P(x))=0$ has four distinct solutions, $x=3,4,a,b.$ Find the sum of all possible values of $(a+b)^2.$
  architecture: a = solver("high"); return a; answered 3.5, correct 85
- [AIME 2010] Let $N$ be the number of ways to write $2010$ in the form $2010 = a_3 \cdot 10^3 + a_2 \cdot 10^2 + a_1 \cdot 10 + a_0$ , where the $a_i$ 's are integers, and $0 \le a_i \le 99$ . An example of such a representation is $1\cdot 10^3 + 3\cdot 10^2 + 67\cdot 10^1 + 40\cdot 10^0$ . F
  architecture: a = discrete("high"); b = coder("max"); out = verifier("max", a, b); return out; answered 2, correct 202
- [AIME 2008] On a long straight stretch of one-way single-lane highway, cars all travel at the same speed and all obey the safety rule: the distance from the back of the car ahead to the front of the car behind is exactly one car length for each 15 kilometers per hour of speed or fraction the
  architecture: a = solver("high"); return a; answered 15, correct 375
- [AIME 2003] Let $A = (0,0)$ and $B = (b,2)$ be points on the coordinate plane. Let $ABCDEF$ be a convex equilateral hexagon such that $\angle FAB = 120^\circ,$ $\overline{AB}\parallel \overline{DE},$ $\overline{BC}\parallel \overline{EF,}$ $\overline{CD}\parallel \overline{FA},$ and the y-co
  architecture: a = geometry("max"); b = solver("high", a); out = verifier("max", b, a); return out; answered 2, correct 51
- [AIME 2016] Triangle $ABC$ is inscribed in circle $\omega$ . Points $P$ and $Q$ are on side $\overline{AB}$ with $AP<AQ$ . Rays $CP$ and $CQ$ meet $\omega$ again at $S$ and $T$ (other than $C$ ), respectively. If $AP=4,PQ=3,QB=6,BT=5,$ and $AS=7$ , then $ST=\frac{m}{n}$ , where $m$ and $n$ a
  architecture: a = solver("high"); b = coder("high"); out = verifier("max", a, b); return out; answered 42, correct 43
- [AIME 1985] As shown in the figure, $\triangle ABC$ is divided into six smaller triangles by lines drawn from the vertices through a common interior point. The areas of four of these triangles are as indicated. Find the area of $\triangle ABC$ . AIME 1985 Problem 6.png
  architecture: a = geometry("max"); b = coder("max"); out = verifier("max", a, b); return out; answered 78, correct 315
- [AIME 2011] Let $A_1 A_2 A_3 A_4 A_5 A_6 A_7 A_8$ be a regular octagon.  Let $M_1$ , $M_3$ , $M_5$ , and $M_7$ be the midpoints of sides $\overline{A_1 A_2}$ , $\overline{A_3 A_4}$ , $\overline{A_5 A_6}$ , and $\overline{A_7 A_8}$ , respectively.  For $i = 1, 3, 5, 7$ , ray $R_i$ is construc
  architecture: a = geometry("max"); return a; answered 0, correct 37

## Most expensive correct questions (possible waste)
- [AIME 2006, cost 91561] Given that $x, y,$ and $z$ are real numbers that satisfy: \begin{align*} x &= \sqrt{y^2-\frac{1}{16}}+\sqrt{z^2-\frac{1}{16}}, \\ y &= \sqrt{z^2-\frac{1}{25}}+\sqrt{x^2-\frac{1}{25
  architecture: a = solver("max"); b = coder("max"); c = geometry("max"); v = verifier("max", a, b, c); return v
- [AIME 2014, cost 88999] Real numbers $r$ and $s$ are roots of $p(x)=x^3+ax+b$ , and $r+4$ and $s-3$ are roots of $q(x)=x^3+ax+b+240$ . Find the sum of all possible values of $|b|$ .
  architecture: a = algebra("max"); b = coder("max"); v = verifier("max", a, b); return v
- [AIME 2013, cost 75821] Triangle $AB_0C_0$ has side lengths $AB_0 = 12$ , $B_0C_0 = 17$ , and $C_0A = 25$ . For each positive integer $n$ , points $B_n$ and $C_n$ are located on $\overline{AB_{n-1}}$ and 
  architecture: a = geometry("max"); b = coder("max"); c = verifier("max", a, b); out = judge("max", a, b, c); return out
- [AIME 2008, cost 70046] In triangle $ABC$ , $AB = AC = 100$ , and $BC = 56$ . Circle $P$ has radius $16$ and is tangent to $\overline{AC}$ and $\overline{BC}$ . Circle $Q$ is externally tangent to circle 
  architecture: geometry = geometry("max"); coder = coder("max"); solver = solver("max"); verifier = verifier("max", geometry, coder, solver); return verifier
- [AIME 2017, cost 69797] Find the number of integer values of $k$ in the closed interval $[-500,500]$ for which the equation $\log(kx)=2\log(x+2)$ has exactly one real solution.
  architecture: a = solver("max"); b = coder("max"); c = discrete("high"); v = verifier("max", a, b, c); out = judge("max", a, b, c, v); return out