# Diagnostic report (dev-A)

Organization: acc 82.0%, cost 9789/question (8960 generated, 4147 prompt tokens; cost = generated + 0.2 x prompt, including the orchestrator's). Full system: acc 91.3%, cost 17252. Orchestrator prompt 5333 chars, thinking low; 24 distinct architectures. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 4096 | 13285 | solver 7, solver>checker?>judge? 4, solver>checker? 2 |
| Algebra L5 | 18 | 100% | 100% | 6847 | 15585 | solver 7, solver>checker?L1>judge? 3, solver>checker?>judge? 2 |
| Counting & Probability L4 | 8 | 100% | 100% | 12214 | 15676 | solver+coder>checker?L1>judge? 4, solver+coder>checker?>judge? 1, solver>checker?>judge? 1 |
| Counting & Probability L5 | 9 | 56% | 89% | 12395 | 19103 | solver 2, solver+coder>checker?L1>judge? 2, solver>coder?>checker?L1>judge? 1 |
| Geometry L4 | 5 | 80% | 100% | 5477 | 15889 | solver 3, solver>checker? 1, solver>checker?>judge? 1 |
| Geometry L5 | 7 | 43% | 57% | 22056 | 22647 | solver+coder>checker?L1>judge? 5, solver>checker?L1 1, solver+coder>checker? 1 |
| Intermediate Algebra L4 | 14 | 93% | 100% | 8967 | 18210 | solver 3, solver+coder>checker?>judge? 3, solver>checker?>judge? 3 |
| Intermediate Algebra L5 | 17 | 47% | 71% | 14914 | 21465 | solver+coder>checker?L1>judge? 4, solver 2, solver+coder>checker?>judge? 2 |
| Number Theory L4 | 9 | 100% | 100% | 6636 | 17149 | solver>checker?L1>judge? 3, solver 3, solver>checker?>judge? 1 |
| Number Theory L5 | 16 | 88% | 88% | 10608 | 18165 | solver 5, solver+coder>checker?>judge? 2, solver+coder>checkerL1>judge 1 |
| Prealgebra L4 | 12 | 92% | 100% | 3490 | 10794 | solver 9, solver>checker? 2, solver>checker?L1 1 |
| Prealgebra L5 | 9 | 78% | 89% | 11367 | 17096 | solver+coder>checker?L1>judge? 2, solver>checker?L1>judge? 2, solver+coder>checker?L1>judge 1 |
| Precalculus L4 | 3 | 67% | 100% | 7121 | 20027 | solver 1, solver>coder?&checker&judge 1, solver>checker?L1 1 |
| Precalculus L5 | 6 | 67% | 83% | 18395 | 22960 | solver+coder>checker? 2, solver+coder>checker?L1>judge? 2, solver>checker?L1>judge? 1 |

## First stages (staffing): accuracy of their answer
| first stage | uses | answer correct | mean cost |
|---|---|---|---|
| solver:off+cot/reread/confidence | 40 | 98% | 926 |
| solver:low+cot/reread/confidence/substitution | 37 | 89% | 4122 |
| solver:low+cot/reread/confidence/case_analysis/substitution + coder:low+react/reread/confidence/case_analysis | 20 | 50% | 9222 |
| solver:low+cot/reread/confidence | 11 | 55% | 4653 |
| solver:low+cot/reread/confidence/case_analysis/substitution | 6 | 50% | 4602 |
| solver:low+cot/reread/confidence/substitution + coder:low+react/reread/confidence | 6 | 50% | 9769 |
| solver:low+cot/reread/confidence/substitution + coder:low+react/reread/confidence/case_analysis | 4 | 75% | 8854 |
| solver:low | 3 | 33% | 4876 |
| solver:low+cot/reread/confidence/case_analysis + coder:low+react/reread/confidence/case_analysis | 3 | 0% | 10360 |
| solver:off+cot/reread/confidence/substitution | 2 | 100% | 891 |
| solver:low+cot/reread/confidence/case_analysis + coder:low+react/reread/confidence | 2 | 100% | 9435 |
| solver:low+cot/confidence/reread | 2 | 100% | 2528 |
| solver:low+cot/reread/confidence + coder:low+react/reread/confidence | 1 | 0% | 10397 |
| solver:low+cot/reread/confidence/case_analysis/substitution + coder:low+react/reread/confidence | 1 | 0% | 9420 |
| solver:high+cot/reread/confidence/substitution + solver:high+cot/reread/confidence/substitution | 1 | 0% | 16474 |

## Later stages (function and condition): how often they ran and changed the answer
| stage | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| decide if shaky | 49 | 14 | 5 | 1 | 1 | 4840 |
| check if shaky (loop 1) | 41 | 14 | 11 | 8 | 0 | 8260 |
| check if shaky | 25 | 3 | 3 | 3 | 0 | 4768 |
| decide if always | 5 | 4 | 0 | 0 | 0 | 2815 |
| check if always (loop 1) | 5 | 5 | 1 | 1 | 0 | 4830 |
| decide if disagree or fail or unsure | 4 | 1 | 1 | 0 | 0 | 6318 |
| decide if disagree or fail or unsure or tool_error | 4 | 3 | 1 | 0 | 0 | 5723 |
| check if always | 4 | 3 | 0 | 0 | 0 | 2941 |
| decide if disagree or fail | 3 | 0 | 0 | 0 | 0 | 0 |
| check if disagree or fail or unsure or tool_error (loop 1) | 3 | 2 | 1 | 0 | 0 | 5720 |
| check if unsure | 3 | 0 | 0 | 0 | 0 | 0 |
| check if disagree or fail or unsure or tool_error | 3 | 2 | 2 | 0 | 0 | 5926 |
| check if disagree or fail or unsure | 3 | 0 | 0 | 0 | 0 | 0 |
| check if disagree or fail or unsure (loop 1) | 3 | 1 | 1 | 0 | 0 | 5943 |
| produce if shaky | 2 | 0 | 0 | 0 | 0 | 0 |

## Signals after the first stage (150 questions, 42 with a wrong answer at that point)
fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 29 | 90% | 62% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 0 | 0% | 0% |
| agreement < 1 | 29 | 90% | 62% |
| agreement < 0.67 | 29 | 90% | 62% |
| tokens > 1000 | 120 | 35% | 100% |
| tokens > 2000 | 109 | 39% | 100% |
| tokens > 4000 | 78 | 53% | 98% |
| [shaky] disagree or fail or unsure or tool_error | 29 | 90% | 62% |

## Leave-one-out replay on 55 questions with 2+ nodes that ran
Remove the employee from that stage (agent@function<stage>) or the whole stage, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| solver@produce1 | 48 | 9 | 1 | 38 | 11397 |
| coder@produce1 | 46 | 15 | 0 | 31 | 11278 |
| stage 2 check if shaky | 17 | 4 | 0 | 13 | 7273 |
| stage 3 decide if shaky | 14 | 1 | 1 | 12 | 4840 |
| stage 2 check | 8 | 1 | 0 | 7 | 4014 |
| stage 3 decide | 4 | 0 | 0 | 4 | 2815 |
| stage 2 check if disagree or fail or unsure or tool_error | 4 | 0 | 0 | 4 | 5959 |
| stage 3 decide if disagree or fail or unsure or tool_error | 3 | 0 | 0 | 3 | 5723 |
| stage 2 check if disagree | 1 | 0 | 0 | 1 | 14587 |
| stage 3 decide if fail or disagree | 1 | 0 | 0 | 1 | 5192 |
| stage 2 produce | 1 | 0 | 0 | 1 | 1438 |
| stage 3 decide if disagree or fail or unsure or tool_error or agreement < 0.9 | 1 | 0 | 0 | 1 | 3727 |
| stage 2 check if disagree or tool_error | 1 | 0 | 0 | 1 | 18249 |
| stage 3 decide if fail or disagree or unsure | 1 | 1 | 0 | 0 | 6260 |
| stage 2 check if disagree or fail or unsure or tool_error or agreement < 1 | 1 | 1 | 0 | 0 | 4349 |
| stage 2 produce if true | 1 | 0 | 0 | 1 | 3526 |
| stage 2 check if disagree or fail or unsure | 1 | 0 | 0 | 1 | 6340 |
| stage 3 decide if disagree or fail or unsure | 1 | 0 | 0 | 1 | 6318 |

## Orchestrator usage
Architectures: solver 43, solver+coder>checker?L1>judge? 22, solver>checker?>judge? 14, solver>checker?L1>judge? 13, solver>checker? 11, solver+coder>checker?>judge? 11, solver>checker?L1 9, solver+coder>checker? 4
Employees: solver 151, checker 104, judge 73, coder 53; never staffed: none
Thinking: low 336, off 42, high 3
Skills switched on: reread 371, confidence 228, cot 216, substitution 183, python_check 104, case_analysis 73, react 53; never: none
Conditions: always 165, shaky 117, disagree or fail or unsure or tool_error 11, disagree or fail or unsure 10, disagree or unsure or fail 6, disagree or fail 4, unsure 3, unsure or fail 2, fail 2, fail or disagree or unsure 2, disagree or tool_error 2, disagree 1, fail or disagree 1, disagree or agreement < 1 1, unsure or fail or disagree 1, disagree or fail or missing 1, disagree or fail or unsure or tool_error or agreement < 0.9 1, disagree or fail or unsure or tool_error or agreement < 1 1, true 1
Copies > 1: 2; debate rounds > 1: 0; check loops: 57
Orchestrator outputs: minor fixes 6 (skills an employee does not hold, quoted conditions, missing commas), structural repairs 0, asked again 19 (valid on the 2nd try: 16), fixed fallback 3 (acc 33%).
Most common problems: minor: judge does not hold ['confidence'] (2); minor: judge does not hold ['rereread'] (1); bad JSON: Expecting ',' delimiter: line 4 column 75 (char 215) (1); minor: judge does not hold ['ct'] (1); bad JSON: Expecting ',' delimiter: line 4 column 75 (char 201) (1); minor: a stage mixed functions; its parts run in order (1)

## Organization wrong, full system right (17)
- [Intermediate Algebra L5] During the car ride home, Michael looks back at his recent math exams. A problem on Michael's calculus mid-term gets him starting thinking about a particular quadratic,\[x^2-sx+p,\]with roots $r_1$ and $r_2$. He notices that\[r_1+r_2=r_1^2+r_2^2=r_1^3+r_2^3=\cdots=r_1^{2007}+r_2^
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution] > produce if shaky[coder:low+react/reread/confidence/case_analysis] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if shaky[judge:low+reread/cot]; answered 0, correct 2
- [Intermediate Algebra L5] Find the sum of all complex numbers $z$ that satisfy
\[z^3 + z^2 - |z|^2 + 2z = 0.\]
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution] > check if shaky (loop 1)[checker:low+python_check/reread/substitution] > decide if shaky[judge:low+reread/cot]; answered 0, correct -2
- [Counting & Probability L5] The number of increasing sequences of positive integers $a_1 \le a_2 \le a_3 \le \cdots \le a_{10} \le 2007$ such that $a_i-i$ is even for $1\le i \le 10$ can be expressed as ${m \choose n}$ for some positive integers $m > n$. Compute the remainder when $m$ is divided by 1000.
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution] > produce if disagree or fail or unsure or tool_error[coder:low+react/reread/confidence/case_analysis] > check if disagree or fail or unsure or tool_error (loop 1)[checker:low+python_check/reread/substitution] > decide if disagree or fail or unsure or tool_error[judge:low+reread/cot]; answered 3, correct 8
- [Prealgebra L5] Triangle $ABC$ is a right triangle. If the measure of angle $PAB$ is $x^\circ$ and the measure of angle $ACB$ is expressed in the form $(Mx+N)^\circ$ with $M=1$, what is the value of $M+N$?

[asy]
draw((-10,0)--(20,0),linewidth(1),Arrows);
draw((0,0)--(10,10/sqrt(3))--(10+10/3,0)
  plan: produce[solver:low+cot/reread/confidence]; answered 1, correct -89
- [Intermediate Algebra L5] A nonzero polynomial with rational coefficients has all of the numbers \[1+\sqrt{2}, \; 2+\sqrt{3}, \;3+\sqrt{4},\; \dots, \;1000+\sqrt{1001}\]as roots. What is the smallest possible degree of such a polynomial?
  plan: produce[solver:low]; answered 1001, correct 1970
- [Intermediate Algebra L5] Let $(a_1, b_1),$ $(a_2, b_2),$ $\dots,$ $(a_n, b_n)$ be the real solutions to
\begin{align*}
a + \frac{17a + 6b}{a^2 + b^2} &= 6, \\
b + \frac{6a - 17b}{a^2 + b^2} &= 0.
\end{align*}Find $a_1 + b_1 + a_2 + b_2 + \dots + a_n + b_n.$

Hint: Use complex numbers.
  plan: produce[solver:low+cot/reread/confidence] > produce if disagree or unsure or fail[coder:low+react/reread/confidence]; answered 2, correct 6
- [Prealgebra L5] In the diagram, $AB,$ $BC,$ $CD,$ $DE,$ $EF,$ $FG,$ $GH,$ and $HK$ all have length $4,$ and all angles are right angles, with the exception of the angles at $D$ and $F.$

[asy]
draw((0,0)--(0,4)--(4,4)--(4,8)--(6.8284,5.1716)--(9.6569,8)--(9.6569,4)--(13.6569,4)--(13.6569,0)--cyc
  plan: produce[solver:low+cot/reread/confidence] > check if shaky (loop 1)[checker:low+python_check/reread/substitution] > decide if shaky[judge:low+reread/cot]; answered 0, correct 8
- [Precalculus L4] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\frac{a + b \sqrt{c}}{d},$ where $a,$ $b,$ $c,$ $d$ are positive integers, in simplest form.  Find $a
  plan: produce[solver:low+cot/reread/confidence] > produce if shaky[coder:low+react/reread/confidence] & check[checker:low+python_check/reread/substitution] & decide[judge:low+reread/cot]; answered 2, correct 8
- [Number Theory L5] Suppose that $ABC_4+200_{10}=ABC_9$, where $A$, $B$, and $C$ are valid digits in base 4 and 9. What is the sum when you add all possible values of $A$, all possible values of $B$, and all possible values of $C$?
  plan: produce[solver:low+cot/reread/case_analysis/substitution/confidence, coder:low+react/reread/confidence/case_analysis]; answered 9, correct 10
- [Geometry L4] A line with slope of $-2$ intersects the positive $x$-axis at $A$ and the positive $y$-axis at $B$. A second line intersects the $x$-axis at $C(8,0)$ and the $y$-axis at $D$. The lines intersect at $E(4,4)$. What is the area of the shaded quadrilateral $OBEC$? [asy]
draw((0,-1)--
  plan: produce[solver:low+cot/reread/confidence/substitution]; answered 16, correct 40

Both wrong: 10.

## Most expensive correct questions (possible waste)
- [Precalculus L5, cost 35945] Let $a$ and $b$ be two 12th roots of unity, not necessarily distinct.  Find the number of different possible values of $(a + b)^{12}.$
  plan: produce[solver:low+cot/case_analysis/reread, coder:low+react/reread/confidence] > check if disagree or tool_error (loop 1)[checker:low+python_check/reread/substitution] > decide if fail or disagree or unsure[judge:low+cot/reread]
- [Intermediate Algebra L5, cost 35105] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution, coder:low+react/reread/confidence/case_analysis] > check (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if shaky[judge:low+reread/cot]
- [Counting & Probability L5, cost 34058] Let set $\mathcal{A}$ be a 90-element subset of $\{1,2,3,\ldots,100\},$ and let $S$ be the sum of the elements of $\mathcal{A}.$ Find the number of possible values of $S.$
  plan: produce[solverx2:low+cot/reread/confidence/case_analysis/substitution, coder:low+react/reread/confidence/case_analysis] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if shaky[judge:low+reread/cot]
- [Number Theory L5, cost 33296] Let $\tau (n)$ denote the number of positive integer divisors of $n$ (including $1$ and $n$). Find the sum of the six least positive integers $n$ that are solutions to $\tau (n) + 
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution, coderx2:low+react/reread/confidence/case_analysis] > check if disagree or fail or unsure or tool_error (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if disagree or fail or unsure or tool_error[judge:low+reread/cot]
- [Geometry L5, cost 32648] The grid below contains the $16$ points whose $x$- and $y$-coordinates are in the set $\{0,1,2,3\}$: [asy]
size(2.5cm);
for(int i=0; i<4; i+=1) { for(int j=0; j<4; j+=1) { dot((i,j
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution, coder:low+react/reread/confidence/case_analysis] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if shaky[judge:low+reread/cot]