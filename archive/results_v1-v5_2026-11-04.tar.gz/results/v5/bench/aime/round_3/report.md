# Diagnostic report (dev-A)

Organization: acc 96.0%, cost 41405/question, of which the HR 1923 (HR prompt 3998 chars). 16 distinct architectures, 2.9 nodes per question. HR outputs: repaired 1, written again 4, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| AIME 1983 | 2 | 100% | - | 28632 | 0 | coder.high,solver.high>verifier.max 2 |
| AIME 1985 | 3 | 67% | - | 45572 | 0 | coder.high,solver.high>verifier.max 2, coder.max,solver.max>verifier.max 1 |
| AIME 1986 | 4 | 100% | - | 38484 | 0 | coder.max,solver.max>verifier.max 2, coder.high,solver.high>verifier.max 1, coder.high>verifier.max 1 |
| AIME 1987 | 3 | 100% | - | 31068 | 0 | coder.max,solver.max>verifier.max 2, coder.high,solver.high>verifier.max 1 |
| AIME 1988 | 1 | 100% | - | 56051 | 0 | coder.max,solver.max>verifier.max 1 |
| AIME 1989 | 2 | 100% | - | 31619 | 0 | solver.high>verifier.max 1, coder.max,solver.high>verifier.max 1 |
| AIME 1991 | 1 | 100% | - | 27556 | 0 | coder.high,solver.high>verifier.max 1 |
| AIME 1992 | 2 | 100% | - | 48193 | 0 | coder.max,solver.max>verifier.max 1, solver.max>verifier.max 1 |
| AIME 1993 | 4 | 100% | - | 34707 | 0 | coder.max,solver.max>verifier.max 2, solver.high>coder.high>verifier.max 1, solver.high>verifier.max 1 |
| AIME 1994 | 1 | 100% | - | 18987 | 0 | solver.high>verifier.max 1 |
| AIME 1995 | 2 | 100% | - | 46127 | 0 | coder.max,solver.max>verifier.max 1, coder.high,solver.high>verifier.max 1 |
| AIME 1996 | 2 | 100% | - | 19641 | 0 | solver.high>verifier.max 1, coder.high,solver.high>verifier.max 1 |
| AIME 1997 | 1 | 100% | - | 25216 | 0 | coder.high,solver.high>verifier.max 1 |
| AIME 1999 | 6 | 100% | - | 28471 | 0 | coder.high,solver.high>verifier.max 2, coder.max>solver.high>verifier.max 1, coder.high>verifier.max 1 |
| AIME 2000 | 3 | 100% | - | 57241 | 0 | coder.max,solver.max>verifier.max 1, coder.max,solver.max>geometry.max>verifier.max 1, coder.high,solver.max>verifier.max 1 |
| AIME 2001 | 6 | 83% | - | 57376 | 0 | coder.max,solver.max>verifier.max 2, coder.max,geometry.max,solver.max>verifier.max 2, coder.max>solver.max>verifier.max 1 |
| AIME 2002 | 3 | 100% | - | 32071 | 0 | coder.max,solver.max>verifier.max 1, coder.high>solver.high>verifier.max 1, coder.high>verifier.max 1 |
| AIME 2003 | 5 | 100% | - | 47651 | 0 | coder.max,solver.max>verifier.max 2, solver.max 1, coder.max,geometry.max,solver.max>verifier.max 1 |
| AIME 2004 | 8 | 100% | - | 49136 | 0 | coder.max,solver.max>verifier.max 3, coder.max,geometry.max,solver.max>verifier.max 1, solver.max>verifier.max 1 |
| AIME 2005 | 8 | 100% | - | 39036 | 0 | coder.max,solver.max>verifier.max 3, coder.high,solver.high>verifier.max 2, solver.high>verifier.max 2 |
| AIME 2006 | 9 | 100% | - | 42097 | 0 | coder.high,solver.high>verifier.max 5, coder.max,geometry.max,solver.max>verifier.max 1, coder.max>solver.max>verifier.max 1 |
| AIME 2007 | 5 | 100% | - | 50367 | 0 | coder.max,geometry.max,solver.max>verifier.max 2, coder.high,solver.high>verifier.max 1, coder.high>verifier.max 1 |
| AIME 2008 | 5 | 100% | - | 39898 | 0 | coder.high>verifier.max 1, coder.max,geometry.max,solver.max>verifier.max 1, coder.max,solver.max>verifier.max 1 |
| AIME 2009 | 3 | 100% | - | 19108 | 0 | solver.high>verifier.max 2, solver.max 1 |
| AIME 2010 | 5 | 80% | - | 40435 | 0 | coder.max,solver.max>verifier.max 3, coder.high,solver.high>verifier.max 1, coder.high>verifier.max 1 |
| AIME 2011 | 6 | 100% | - | 42693 | 0 | coder.high,solver.high>verifier.max 4, coder.max,geometry.max,solver.max>verifier.max 1, coder.max,solver.max>verifier.max 1 |
| AIME 2012 | 3 | 100% | - | 30260 | 0 | coder.high,solver.high>verifier.max 2, coder.high>verifier.max 1 |
| AIME 2013 | 3 | 100% | - | 44745 | 0 | coder.high,solver.high>verifier.max 2, coder.max,geometry.max,solver.max>verifier.max 1 |
| AIME 2014 | 7 | 86% | - | 43748 | 0 | coder.high,solver.high>verifier.max 3, coder.max,solver.max>verifier.max 2, solver.max>verifier.max 1 |
| AIME 2015 | 8 | 100% | - | 30650 | 0 | coder.high,solver.high>verifier.max 3, coder.high 1, coder.high>verifier.max 1 |
| AIME 2016 | 4 | 75% | - | 68290 | 0 | coder.max,geometry.max,solver.max>verifier.max 2, coder.max,solver.max>verifier.max 2 |
| AIME 2017 | 6 | 100% | - | 51141 | 0 | coder.max,solver.max>verifier.max 3, coder.high,solver.high>verifier.max 2, coder.max,geometry.max,solver.max>verifier.max 1 |
| AIME 2018 | 6 | 100% | - | 42191 | 0 | coder.max,solver.max>verifier.max 2, solver.high>verifier.max 1, coder.high>solver.high>verifier.max 1 |
| AIME 2019 | 1 | 100% | - | 47193 | 0 | coder.max,solver.max>verifier.max 1 |
| AIME 2020 | 6 | 100% | - | 36382 | 0 | solver.high>verifier.max 2, coder.high,solver.high>verifier.max 2, coder.max,solver.max>verifier.max 2 |
| AIME 2021 | 6 | 83% | - | 44048 | 0 | coder.high,solver.high>verifier.max 3, coder.max>solver.max>verifier.max 1, coder.max,geometry.max,solver.max>verifier.max 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.high,solver.high>verifier.max | 46 | 98% | 28325 |
| coder.max,solver.max>verifier.max | 43 | 100% | 52679 |
| coder.max,geometry.max,solver.max>verifier.max | 16 | 75% | 83649 |
| solver.high>verifier.max | 15 | 100% | 20050 |
| coder.high>verifier.max | 8 | 88% | 22518 |
| solver.max>verifier.max | 4 | 100% | 40593 |
| coder.max>solver.max>verifier.max | 4 | 100% | 43892 |
| coder.high>solver.high>verifier.max | 3 | 100% | 29554 |
| coder.max,solver.high>verifier.max | 3 | 100% | 47231 |
| solver.max | 2 | 100% | 21059 |
| coder.high | 1 | 100% | 9122 |
| coder.max>solver.high>verifier.max | 1 | 100% | 33372 |
| coder.max,solver.max>geometry.max>verifier.max | 1 | 100% | 77856 |
| coder.high,solver.max>verifier.max | 1 | 100% | 31179 |
| solver.high>coder.high>verifier.max | 1 | 100% | 19178 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| verifier.max (with inputs) | 147 | 96% | 27% | 12680 | 28 | 23 | - |
| coder.max | 69 | 72% | 93% | 19679 | - | - | - |
| solver.max | 67 | 75% | 90% | 19162 | - | - | - |
| solver.high | 65 | 77% | 100% | 7421 | - | - | - |
| coder.high | 59 | 76% | 98% | 8014 | - | - | - |
| geometry.max | 16 | 50% | 100% | 22753 | - | - | - |
| solver.max (with inputs) | 4 | 100% | 0% | 10612 | - | - | - |
| solver.high (with inputs) | 4 | 100% | 100% | 7695 | - | - | - |
| geometry.max (with inputs) | 1 | 100% | 100% | 20218 | - | - | - |
| coder.high (with inputs) | 1 | 100% | 0% | 4025 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.max (output) | 60 | 12 | 0 | 48 | 12759 |
| coder.max (input) | 29 | 3 | 0 | 26 | 16626 |
| solver.max (input) | 29 | 4 | 0 | 25 | 17360 |
| solver.high (input) | 25 | 0 | 0 | 25 | 2269 |
| coder.high (input) | 24 | 0 | 1 | 23 | 3283 |
| geometry.max (input) | 8 | 1 | 0 | 7 | 18838 |

HR output problems: minor: line 1: non-node argument ignored (9); minor: line 2: non-node argument ignored (2); line 1: expected `x = employee("thinking", inputs...)` (1); line 2: expected `x = employee("thinking", inputs...)` (1)

## Organization wrong (6)
- [AIME 2010] Let $N$ be the number of ways to write $2010$ in the form $2010 = a_3 \cdot 10^3 + a_2 \cdot 10^2 + a_1 \cdot 10 + a_0$ , where the $a_i$ 's are integers, and $0 \le a_i \le 99$ . An example of such a representation is $1\cdot 10^3 + 3\cdot 10^2 + 67\cdot 10^1 + 40\cdot 10^0$ . F
  architecture: a = coder("high"); out = verifier("max", a); return out; answered 10, correct 202
- [AIME 2016] Triangle $ABC$ is inscribed in circle $\omega$ . Points $P$ and $Q$ are on side $\overline{AB}$ with $AP<AQ$ . Rays $CP$ and $CQ$ meet $\omega$ again at $S$ and $T$ (other than $C$ ), respectively. If $AP=4,PQ=3,QB=6,BT=5,$ and $AS=7$ , then $ST=\frac{m}{n}$ , where $m$ and $n$ a
  architecture: a = coder("max"); b = solver("max"); c = geometry("max"); out = verifier("max", a, b, c); return out; answered 986, correct 43
- [AIME 1985] As shown in the figure, $\triangle ABC$ is divided into six smaller triangles by lines drawn from the vertices through a common interior point. The areas of four of these triangles are as indicated. Find the area of $\triangle ABC$ . AIME 1985 Problem 6.png
  architecture: a = coder("high"); b = solver("high"); out = verifier("max", a, b); return out; answered 30, correct 315
- [AIME 2021] Let $A_1A_2A_3\ldots A_{12}$ be a dodecagon ( $12$ -gon). Three frogs initially sit at $A_4,A_8,$ and $A_{12}$ . At the end of each minute, simultaneously, each of the three frogs jumps to one of the two vertices adjacent to its current position, chosen randomly and independently
  architecture: a = coder("max"); b = solver("max"); c = geometry("max"); out = verifier("max", a, b, c); return out; answered 13, correct 19
- [AIME 2001] In quadrilateral $ABCD$ , $\angle{BAD}\cong\angle{ADC}$ and $\angle{ABD}\cong\angle{BCD}$ , $AB = 8$ , $BD = 10$ , and $BC = 6$ . The length $CD$ may be written in the form $\frac {m}{n}$ , where $m$ and $n$ are relatively prime positive integers. Find $m + n$ .
  architecture: a = coder("max"); b = solver("max"); c = geometry("max"); out = verifier("max", a, b, c); return out; answered 36, correct 69
- [AIME 2014] On square $ABCD$ , points $E,F,G$ , and $H$ lie on sides $\overline{AB},\overline{BC},\overline{CD},$ and $\overline{DA},$ respectively, so that $\overline{EG} \perp \overline{FH}$ and $EG=FH = 34$ . Segments $\overline{EG}$ and $\overline{FH}$ intersect at a point $P$ , and the 
  architecture: a = coder("max"); b = solver("max"); c = geometry("max"); out = verifier("max", a, b, c); return out; answered 1156, correct 850

## Most expensive correct questions (possible waste)
- [AIME 2004, cost 84753] Let $ABC$ be a triangle with sides 3, 4, and 5, and $DEFG$ be a 6-by-7 rectangle. A segment is drawn to divide triangle $ABC$ into a triangle $U_1$ and a trapezoid $V_1$ and anothe
  architecture: a = coder("max"); b = solver("max"); c = geometry("max"); out = verifier("max", a, b, c); return out
- [AIME 2003, cost 83671] Let $A = (0,0)$ and $B = (b,2)$ be points on the coordinate plane. Let $ABCDEF$ be a convex equilateral hexagon such that $\angle FAB = 120^\circ,$ $\overline{AB}\parallel \overlin
  architecture: a = solver("max"); b = coder("max"); c = geometry("max"); out = verifier("max", a, b, c); return out
- [AIME 2017, cost 81755] The area of the smallest equilateral triangle with one vertex on each of the sides of the right triangle with side lengths $2\sqrt3$ , $5$ , and $\sqrt{37}$ , as shown, is $\tfrac{
  architecture: a = coder("max"); b = solver("max"); c = geometry("max"); out = verifier("max", a, b, c); return out
- [AIME 2013, cost 79388] Triangle $AB_0C_0$ has side lengths $AB_0 = 12$ , $B_0C_0 = 17$ , and $C_0A = 25$ . For each positive integer $n$ , points $B_n$ and $C_n$ are located on $\overline{AB_{n-1}}$ and 
  architecture: a = coder("max"); b = solver("max"); c = geometry("max"); d = verifier("max", a, b, c); return d
- [AIME 2011, cost 78928] Let $A_1 A_2 A_3 A_4 A_5 A_6 A_7 A_8$ be a regular octagon.  Let $M_1$ , $M_3$ , $M_5$ , and $M_7$ be the midpoints of sides $\overline{A_1 A_2}$ , $\overline{A_3 A_4}$ , $\overlin
  architecture: a = coder("max"); b = solver("max"); c = geometry("max"); out = verifier("max", a, b, c); return out