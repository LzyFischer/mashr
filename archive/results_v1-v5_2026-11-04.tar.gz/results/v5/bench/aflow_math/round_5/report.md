# Diagnostic report (dev-A)

Organization: acc 96.7%, cost 20044/question, of which the HR 1856 (HR prompt 4676 chars). 18 distinct architectures, 2.3 nodes per question. HR outputs: repaired 0, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Counting & Probability L5 | 40 | 95% | - | 24243 | 0 | coder.high>verifier.high 13, coder.low>verifier.low 6, coder.high>verifier.max 5 |
| Number Theory L5 | 42 | 98% | - | 17965 | 0 | coder.high>verifier.high 25, coder.low>verifier.low 8, coder.high>verifier.max 6 |
| Prealgebra L5 | 44 | 95% | - | 15238 | 0 | coder.low>verifier.low 26, coder.high>verifier.high 6, reader.high>coder.high>verifier.max 5 |
| Precalculus L5 | 24 | 100% | - | 25494 | 0 | coder.high>verifier.high 7, coder.high>solver.high>verifier.max 6, reader.high>coder.max>verifier.max 2 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.high>verifier.high | 51 | 96% | 16563 |
| coder.low>verifier.low | 41 | 100% | 9490 |
| coder.high>verifier.max | 14 | 100% | 23374 |
| reader.high>coder.high>verifier.max | 10 | 100% | 24414 |
| coder.high>solver.high>verifier.max | 7 | 100% | 33182 |
| reader.high>coder.max>verifier.max | 7 | 86% | 35589 |
| reader.high>coder.high,solver.high>verifier.max | 5 | 80% | 38206 |
| coder.max>verifier.max | 4 | 100% | 30543 |
| reader.high>coder.max,solver.high>verifier.max | 2 | 100% | 39977 |
| reader.high>coder.max>solver.high>verifier.max | 1 | 100% | 74725 |
| reader.high>coder.max,coder.max>verifier.max | 1 | 100% | 68107 |
| coder.low>verifier.high | 1 | 100% | 14897 |
| coder.high>reader.low>verifier.max | 1 | 100% | 30284 |
| reader.high>coder.high>solver.high>verifier.max | 1 | 100% | 28027 |
| reader.high>coder.max,solver.max>verifier.max | 1 | 100% | 29104 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| coder.high | 74 | 82% | 97% | 8314 | - | - | - |
| verifier.max (with inputs) | 55 | 96% | 9% | 10897 | 22 | 20 | 3 |
| verifier.high (with inputs) | 54 | 94% | 89% | 6695 | 8 | 6 | 3 |
| coder.low | 42 | 93% | 98% | 3961 | - | - | - |
| verifier.low (with inputs) | 41 | 100% | 100% | 3754 | 3 | 3 | 1 |
| reader.high | 29 | 52% | 100% | 7839 | - | - | - |
| coder.high (with inputs) | 18 | 83% | 94% | 8264 | 8 | 5 | 1 |
| solver.high (with inputs) | 16 | 75% | 100% | 8576 | 10 | 6 | 1 |
| coder.max (with inputs) | 13 | 77% | 46% | 16625 | 9 | 6 | 1 |
| coder.max | 4 | 100% | 100% | 18686 | - | - | - |
| reader.low (with inputs) | 1 | 100% | 100% | 4287 | - | - | - |
| solver.max (with inputs) | 1 | 100% | 0% | 12022 | - | - | - |
| solver.high | 1 | 100% | 100% | 7551 | - | - | - |
| reader.low | 1 | 100% | 100% | 3787 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| coder.high (input) | 40 | 2 | 1 | 37 | 6089 |
| verifier.max (output) | 26 | 10 | 1 | 15 | 11231 |
| verifier.high (output) | 22 | 2 | 0 | 20 | 6859 |
| reader.high (input) | 13 | 4 | 2 | 7 | 3449 |
| coder.low (input) | 13 | 1 | 0 | 12 | 3531 |
| verifier.low (output) | 12 | 0 | 0 | 12 | 3751 |
| coder.max (input) | 8 | 1 | 1 | 6 | 13170 |
| solver.high (input) | 6 | 0 | 0 | 6 | 10339 |
| reader.low (input) | 1 | 0 | 0 | 1 | 4235 |

HR output problems: minor: line 1: non-node argument ignored (9)

## Organization wrong (5)
- [Prealgebra L5] A square and a regular heptagon  are coplanar and share a common side $\overline{AD}$, as shown. What is the degree measure of exterior angle $BAC$?  Express your answer as a common fraction.

[asy]
for(int i=0; i <=7; ++i) {
draw(dir(360*i/7+90)--dir(360*(i+1)/7+90));
}
pair A =
  architecture: r = reader("high"); c = coder("high", r); s = solver("high", r); v = verifier("max", r, c, s); return v; answered 1530/7, correct \frac{990}{7}^\circ
- [Prealgebra L5] Two points are drawn on each side of a square with an area of 81 square units, dividing the side into 3 congruent parts.  Quarter-circle arcs connect the points on adjacent sides to create the figure shown.  What is the length of the boundary of the bolded figure?  Express your a
  architecture: r = reader("high"); c = coder("max", r); v = verifier("max", r, c); return v; answered 12 + 6\pi, correct 30.8
- [Counting & Probability L5] In an office at various times during the day, the boss gives the secretary a letter to type, each time putting the letter on top of the pile in the secretary's in-box. When there is time, the secretary takes the top letter off the pile and types it. There are nine letters to be t
  architecture: r = reader("high"); c = coder("high", r); v = verifier("high", r, c); return v; answered So Case 3, correct 704
- [Number Theory L5] Find the largest three-digit integer that is divisible by each of its distinct, non-zero digits.
  architecture: c = coder("high"); v = verifier("high", c); return v; answered 999, correct 936
- [Counting & Probability L5] How many positive integers less than 10,000 have at most two different digits?
  architecture: c = coder("high"); v = verifier("high", c); return v; answered Total = $126 \times 24 = 3024, correct 927

## Most expensive correct questions (possible waste)
- [Counting & Probability L5, cost 74725] Matt will arrange four identical, dotless dominoes (shaded 1 by 2 rectangles) on the 5 by 4 grid below so that a path is formed from the upper left-hand corner $A$ to the lower rig
  architecture: r = reader("high"); c = coder("max", r); s = solver("high", r, c); out = verifier("max", r, c, s); return out
- [Counting & Probability L5, cost 68107] Let $N$ be the number of positive integers that are less than or equal to $2003$ and whose base-$2$ representation has more $1$'s than $0$'s. Find the remainder when $N$ is divided
  architecture: r = reader("high"); c1 = coder("max", r); c2 = coder("max", r); out = verifier("max", r, c1, c2); return out
- [Number Theory L5, cost 53727] Find the largest integer $n$ satisfying the following conditions:
(i) $n^2$ can be expressed as the difference of two consecutive cubes;
(ii) $2n + 79$ is a perfect square.
  architecture: r = reader("high"); c = coder("max", r); v = verifier("max", r, c); return v
- [Counting & Probability L5, cost 46698] Point $P$ is selected at random from the interior of the pentagon with vertices $A=(0,2)$, $B= (4,0)$, $C = (2\pi +1, 0)$, $D=(2\pi
+1,4)$, and $E=(0,4)$. What is the probability t
  architecture: r = reader("high"); c = coder("max", r); out = verifier("max", r, c); return out
- [Prealgebra L5, cost 43755] Each of the boxes in the figure below is a square. How many different squares can be traced using the lines in the figure?

[asy]
unitsize(0.2inch);
draw((0,1)--(1,1)--(1,4)--(0,4)
  architecture: r = reader("high"); c = coder("max", r); v = verifier("max", r, c); return v