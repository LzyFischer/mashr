# Diagnostic report (dev-A)

Organization: acc 91.3%, cost 36702/question, of which the HR 1843 (HR prompt 3170 chars). 14 distinct architectures, 2.9 nodes per question. HR outputs: repaired 0, written again 1, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| AIME 1983 | 2 | 100% | - | 20404 | 0 | coder.high,solver.high>verifier.max 1, coder.high,solver.high>verifier.high 1 |
| AIME 1985 | 3 | 67% | - | 29639 | 0 | coder.high,solver.high>verifier.max 3 |
| AIME 1986 | 4 | 100% | - | 41544 | 0 | coder.max,solver.max>verifier.max 2, coder.high,solver.high>verifier.max 1, coder.low,solver.low>verifier.low 1 |
| AIME 1987 | 3 | 100% | - | 28604 | 0 | coder.high,solver.high>verifier.max 2, coder.max,solver.max>verifier.max 1 |
| AIME 1988 | 1 | 100% | - | 55470 | 0 | coder.max,solver.max>verifier.max 1 |
| AIME 1989 | 2 | 100% | - | 33483 | 0 | coder.high,solver.high>verifier.max 2 |
| AIME 1991 | 1 | 100% | - | 28773 | 0 | coder.high,solver.high>verifier.max 1 |
| AIME 1992 | 2 | 50% | - | 56274 | 0 | coder.max,solver.max>verifier.max 2 |
| AIME 1993 | 4 | 100% | - | 42405 | 0 | coder.max,solver.max>verifier.max 3, coder.high,solver.high>verifier.max 1 |
| AIME 1994 | 1 | 100% | - | 25825 | 0 | coder.high,solver.high>verifier.high 1 |
| AIME 1995 | 2 | 100% | - | 26172 | 0 | coder.high,solver.high>verifier.max 2 |
| AIME 1996 | 2 | 100% | - | 23771 | 0 | coder.high,solver.high>verifier.high 1, coder.high,solver.high>verifier.max 1 |
| AIME 1997 | 1 | 100% | - | 18490 | 0 | coder.high,solver.high>verifier.max 1 |
| AIME 1999 | 6 | 100% | - | 29731 | 0 | coder.high,solver.high>verifier.max 4, coder.max,solver.max>verifier.max 1, coder.max>solver.max>verifier.max 1 |
| AIME 2000 | 3 | 67% | - | 35651 | 0 | coder.max,solver.max>verifier.max 1, solver.max 1, solver.high>coder.high>verifier.max 1 |
| AIME 2001 | 6 | 100% | - | 45227 | 0 | coder.max,solver.max>verifier.max 5, solver.high 1 |
| AIME 2002 | 3 | 100% | - | 25804 | 0 | coder.high,solver.high>verifier.max 1, solver.max 1, coder.high,solver.max>verifier.max 1 |
| AIME 2003 | 5 | 80% | - | 40554 | 0 | coder.max,solver.max>verifier.max 2, coder.high,solver.high>verifier.max 2, coder.high,solver.max>verifier.max 1 |
| AIME 2004 | 8 | 75% | - | 38980 | 0 | coder.high,solver.high>verifier.max 3, coder.max,solver.max>verifier.max 3, coder.max,solver.high>verifier.max 1 |
| AIME 2005 | 8 | 100% | - | 27041 | 0 | coder.high,solver.high>verifier.max 6, coder.max,solver.max>verifier.max 1, coder.high,solver.high>verifier.high 1 |
| AIME 2006 | 9 | 100% | - | 37831 | 0 | coder.max,solver.max>verifier.max 3, coder.low,solver.high>verifier.max 1, coder.max,solver.high>verifier.max 1 |
| AIME 2007 | 5 | 100% | - | 29485 | 0 | coder.high,solver.high>verifier.max 4, coder.high,solver.max>verifier.max 1 |
| AIME 2008 | 5 | 100% | - | 41310 | 0 | coder.max,solver.max>verifier.max 3, coder.max>solver.max>verifier.max 1, coder.high,solver.high>verifier.high 1 |
| AIME 2009 | 3 | 100% | - | 28751 | 0 | coder.high,solver.high>verifier.high 2, coder.max,solver.max>verifier.max 1 |
| AIME 2010 | 5 | 80% | - | 35415 | 0 | coder.high,solver.high>verifier.max 2, coder.high,solver.high>verifier.high 1, coder.max,solver.max>verifier.max 1 |
| AIME 2011 | 6 | 83% | - | 32636 | 0 | coder.high,solver.high>verifier.high 2, coder.max,solver.max>verifier.max 2, solver.low 1 |
| AIME 2012 | 3 | 100% | - | 30725 | 0 | coder.high,solver.high>verifier.max 3 |
| AIME 2013 | 3 | 100% | - | 49620 | 0 | coder.max,solver.max>verifier.max 2, coder.high,solver.max>verifier.max 1 |
| AIME 2014 | 7 | 86% | - | 36324 | 0 | coder.high,solver.high>verifier.max 2, solver.max 2, coder.max,solver.max>verifier.max 2 |
| AIME 2015 | 8 | 88% | - | 39109 | 0 | coder.max,solver.max>verifier.max 5, coder.high,solver.high>verifier.max 3 |
| AIME 2016 | 4 | 75% | - | 55101 | 0 | coder.max,solver.max>verifier.max 3, coder.high,solver.max>verifier.max 1 |
| AIME 2017 | 6 | 83% | - | 37943 | 0 | coder.high,solver.high>verifier.max 2, coder.max,solver.max>verifier.max 2, solver.max 1 |
| AIME 2018 | 6 | 83% | - | 44841 | 0 | coder.max,solver.max>verifier.max 3, coder.high,solver.high>verifier.max 2, coder.max>verifier.max 1 |
| AIME 2019 | 1 | 100% | - | 43974 | 0 | coder.max,solver.max>verifier.max 1 |
| AIME 2020 | 6 | 100% | - | 38017 | 0 | coder.max,solver.max>verifier.max 3, coder.high,solver.high>verifier.max 2, coder.high,solver.high>verifier.high 1 |
| AIME 2021 | 6 | 100% | - | 38323 | 0 | coder.high,solver.high>verifier.max 3, coder.max,solver.max>verifier.max 2, coder.high,solver.max>verifier.max 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.high,solver.high>verifier.max | 56 | 96% | 26139 |
| coder.max,solver.max>verifier.max | 55 | 87% | 52312 |
| coder.high,solver.high>verifier.high | 13 | 100% | 22175 |
| coder.high,solver.max>verifier.max | 8 | 88% | 43453 |
| solver.max | 5 | 60% | 21817 |
| coder.max>solver.max>verifier.max | 4 | 100% | 51123 |
| coder.max,solver.high>verifier.max | 2 | 100% | 34842 |
| coder.max>verifier.max | 1 | 100% | 29512 |
| coder.low,solver.high>verifier.max | 1 | 100% | 22433 |
| solver.low | 1 | 0% | 6984 |
| solver.high>coder.high>verifier.max | 1 | 100% | 22330 |
| coder.low,solver.low>verifier.low | 1 | 100% | 15776 |
| coder.low>solver.high>verifier.max | 1 | 100% | 38448 |
| solver.high | 1 | 100% | 9611 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| verifier.max (with inputs) | 129 | 92% | 18% | 10478 | 30 | 21 | 2 |
| coder.high | 77 | 77% | 99% | 8167 | - | - | - |
| solver.high | 74 | 80% | 100% | 7406 | - | - | - |
| solver.max | 68 | 78% | 93% | 19120 | - | - | - |
| coder.max | 62 | 76% | 94% | 19680 | - | - | - |
| verifier.high (with inputs) | 13 | 100% | 62% | 5168 | 1 | 1 | - |
| solver.max (with inputs) | 4 | 100% | 50% | 16540 | 2 | 2 | - |
| coder.low | 3 | 100% | 100% | 6830 | - | - | - |
| solver.low | 2 | 50% | 100% | 4581 | - | - | - |
| coder.high (with inputs) | 1 | 100% | 100% | 5633 | - | - | - |
| verifier.low (with inputs) | 1 | 100% | 100% | 3339 | - | - | - |
| solver.high (with inputs) | 1 | 100% | 100% | 7969 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.max (output) | 55 | 13 | 1 | 41 | 10829 |
| solver.high (input) | 32 | 0 | 1 | 31 | 7091 |
| coder.high (input) | 32 | 0 | 2 | 30 | 7551 |
| solver.max (input) | 27 | 1 | 1 | 25 | 16480 |
| coder.max (input) | 27 | 1 | 1 | 25 | 14648 |
| verifier.high (output) | 5 | 0 | 0 | 5 | 4933 |
| coder.low (input) | 1 | 0 | 0 | 1 | 3080 |

HR output problems: minor: line 1: non-node argument ignored (21); minor: line 2: non-node argument ignored (10)

## Organization wrong (13)
- [AIME 2017] Let $z_1 = 18 + 83i$ , $z_2 = 18 + 39i,$ and $z_3 = 78 + 99i,$ where $i = \sqrt{-1}$ . Let $z$ be the unique complex number with the properties that $\frac{z_3 - z_1}{z_2 - z_1} \cdot \frac{z - z_2}{z - z_3}$ is a real number and the imaginary part of $z$ is the greatest possible
  architecture: a = solver("max"); return a; answered 2, correct 56
- [AIME 1992] Consider the region $A^{}_{}$ in the complex plane that consists of all points $z^{}_{}$ such that both $\frac{z^{}_{}}{40}$ and $\frac{40^{}_{}}{\overline{z}}$ have real and imaginary parts between $0^{}_{}$ and $1^{}_{}$ , inclusive. What is the integer that is nearest the area
  architecture: a = solver("max"); b = coder("max"); v = verifier("max", a, b); return v; answered 571.6814692828617, correct 572
- [AIME 2010] Let $N$ be the number of ways to write $2010$ in the form $2010 = a_3 \cdot 10^3 + a_2 \cdot 10^2 + a_1 \cdot 10 + a_0$ , where the $a_i$ 's are integers, and $0 \le a_i \le 99$ . An example of such a representation is $1\cdot 10^3 + 3\cdot 10^2 + 67\cdot 10^1 + 40\cdot 10^0$ . F
  architecture: a = coder("high"); b = solver("high"); v = verifier("max", a, b); return v; answered 9999, correct 202
- [AIME 2003] Let $A = (0,0)$ and $B = (b,2)$ be points on the coordinate plane. Let $ABCDEF$ be a convex equilateral hexagon such that $\angle FAB = 120^\circ,$ $\overline{AB}\parallel \overline{DE},$ $\overline{BC}\parallel \overline{EF,}$ $\overline{CD}\parallel \overline{FA},$ and the y-co
  architecture: a = solver("max"); b = coder("high"); v = verifier("max", a, b); return v; answered -5.77, correct 51
- [AIME 2000] In triangle $ABC,$ it is given that angles $B$ and $C$ are congruent. Points $P$ and $Q$ lie on $\overline{AC}$ and $\overline{AB},$ respectively, so that $AP = PQ = QB = BC.$ Angle $ACB$ is $r$ times as large as angle $APQ,$ where $r$ is a positive real number. Find $\lfloor 100
  architecture: a = solver("max"); return a; answered 46, correct 571
- [AIME 2016] Triangle $ABC$ is inscribed in circle $\omega$ . Points $P$ and $Q$ are on side $\overline{AB}$ with $AP<AQ$ . Rays $CP$ and $CQ$ meet $\omega$ again at $S$ and $T$ (other than $C$ ), respectively. If $AP=4,PQ=3,QB=6,BT=5,$ and $AS=7$ , then $ST=\frac{m}{n}$ , where $m$ and $n$ a
  architecture: a = solver("max"); b = coder("max"); v = verifier("max", a, b); return v; answered 1, correct 43
- [AIME 1985] As shown in the figure, $\triangle ABC$ is divided into six smaller triangles by lines drawn from the vertices through a common interior point. The areas of four of these triangles are as indicated. Find the area of $\triangle ABC$ . AIME 1985 Problem 6.png
  architecture: a = solver("high"); b = coder("high"); v = verifier("max", a, b); return v; answered 100, correct 315
- [AIME 2004] Let $ABCDE$ be a convex pentagon with $AB || CE, BC || AD, AC || DE, \angle ABC=120^\circ, AB=3, BC=5,$ and $DE = 15.$ Given that the ratio between the area of triangle $ABC$ and the area of triangle $EBD$ is $m/n,$ where $m$ and $n$ are relatively prime positive integers, find $
  architecture: a = solver("max"); b = coder("max"); v = verifier("max", a, b); return v; answered 2, correct 484
- [AIME 2011] In triangle $ABC$ , $AB = 125$ , $AC = 117$ , and $BC = 120$ .  The angle bisector of angle $A$ intersects $\overline{BC}$ at point $L$ , and the angle bisector of angle $B$ intersects $\overline{AC}$ at point $K$ .  Let $M$ and $N$ be the feet of the perpendiculars from $C$ to $
  architecture: a = solver("low"); return a; answered 0, correct 56
- [AIME 2004] A unicorn is tethered by a 20-foot silver rope to the base of a magician's cylindrical tower whose radius is 8 feet. The rope is attached to the tower at ground level and to the unicorn at a height of 4 feet. The unicorn has pulled the rope taut, the end of the rope is 4 feet fro
  architecture: a = solver("max"); b = coder("max"); v = verifier("max", a, b); return v; answered 1, correct 813

## Most expensive correct questions (possible waste)
- [AIME 2018, cost 67185] Find the number of functions $f$ from $\{0, 1, 2, 3, 4, 5, 6\}$ to the integers such that $f(0) = 0$ , $f(6) = 12$ , and \[|x - y|  \leq  |f(x) - f(y)|  \leq  3|x - y|\] for all $x
  architecture: a = solver("max"); b = coder("max"); v = verifier("max", a, b); return v
- [AIME 2000, cost 62288] In the middle of a vast prairie, a firetruck is stationed at the intersection of two perpendicular straight highways. The truck travels at $50$ miles per hour along the highways an
  architecture: a = coder("max"); b = solver("max"); v = verifier("max", a, b); return v
- [AIME 1992, cost 62253] In a game of Chomp , two players alternately take bites from a 5-by-7 grid of unit squares. To take a bite, a player chooses one of the remaining squares, then removes ("eats") all
  architecture: a = coder("max"); b = solver("max"); v = verifier("max", a, b); return v
- [AIME 2001, cost 62154] In quadrilateral $ABCD$ , $\angle{BAD}\cong\angle{ADC}$ and $\angle{ABD}\cong\angle{BCD}$ , $AB = 8$ , $BD = 10$ , and $BC = 6$ . The length $CD$ may be written in the form $\frac 
  architecture: a = solver("max"); b = coder("max"); v = verifier("max", a, b); return v
- [AIME 2016, cost 62088] Centered at each lattice point in the coordinate plane are a circle radius $\frac{1}{10}$ and a square with sides of length $\frac{1}{5}$ whose sides are parallel to the coordinate
  architecture: a = solver("max"); b = coder("max"); v = verifier("max", a, b); return v