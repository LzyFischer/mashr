#!/bin/bash
# v6: employees + HR on local vLLM (GPU 3, port 8001), designer (27B) on Tinker.
# usage: results/rsi6/run.sh <dataset> <out-name> [extra rsi6 args...]
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
export MASHR_LOCAL_MODELS=Qwen/Qwen3.5-9B MASHR_LOCAL=http://localhost:8001/v1
ds=$1; name=$2; shift 2
~/miniconda3/envs/tinker/bin/python -m mashr.rsi6 --dataset "$ds" --init design --out "results/rsi6/$name" "$@" \
  > "results/rsi6/$name.out" 2>&1
