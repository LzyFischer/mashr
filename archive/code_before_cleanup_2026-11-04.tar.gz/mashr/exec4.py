"""Fast loop v4: the orchestrator (HR) staffs each question; the executor runs the topology
(org4.py). Python runs through engine.run_python (no network, resource limits)."""
import json
import re
from concurrent.futures import ThreadPoolExecutor

from .blocks import compile_conditions, eval_cond, parse_cond
from .engine import ANSWER_FMT, CODE, SHOW_CHARS, VERDICT, VERDICT_FMT, cost, majority, \
    run_python, signals
from .mas import MODEL, extract
from .org4 import check_plan, fallback_plan, orchestrator_prompt, tool_budget

RETRY = ("Your output could not be used:\n{problems}\n\nOutput the corrected staffing plan: exactly "
         "one JSON object, nothing else.")


def loads_lenient(text):
    """(object, note): strict JSON, else with missing commas between values inserted; (None, error)
    if neither parses."""
    try:
        return json.loads(text), None
    except json.JSONDecodeError as e:
        err = str(e)
    # stage options written inside the nodes list: ["a:low:cot", "loop": 1] -> ["a:low:cot"], "loop": 1
    fixed = re.sub(r'("\s*),\s*"(if|loop|rounds|sees)"\s*:', r'\1], "\2":', text)
    fixed = re.sub(r'("(?:if|loop|rounds|sees)"\s*:\s*(?:"[^"]*"|\d+))\s*\]', r"\1", fixed)
    fixed = re.sub(r'([}\]"]|\d|true|false|null)(\s*\n\s*)(?=[{\["])', r"\1,\2", fixed)
    fixed = re.sub(r'([}\]])(\s*)(?=[{\["])', r"\1,\2", fixed)
    try:
        return json.loads(fixed), "JSON syntax repaired"
    except json.JSONDecodeError:
        pass
    try:                                    # a complete object followed by stray brackets
        obj, _ = json.JSONDecoder().raw_decode(text)
        return obj, "trailing characters ignored"
    except json.JSONDecodeError:
        return None, err


class Engine:
    def __init__(self, llm, model: str = MODEL, seed: int = 0):
        self.llm, self.model, self.seed = llm, model, seed

    # ------------------------------------------------------------ the orchestrator

    def orchestrate(self, pool: dict, question: str):
        """Returns (plan, calls, info). info: repaired problems, retried, fallback."""
        msgs = [{"role": "system", "content": orchestrator_prompt(pool)},
                {"role": "user", "content": f"Problem: {question}\n\nYour staffing plan (JSON):"}]
        calls, probs = [], []
        for attempt in range(2):
            r = self.llm.chat(self.model, msgs, thinking=pool["orchestrator"].get("thinking", "off"),
                              max_tokens=900, seed=self.seed + attempt)
            calls.append({"agent": "orchestrator", "stage": None, "prompt_tokens": r.prompt_tokens,
                          "gen_tokens": r.gen_tokens})
            plan, probs = None, ["no JSON object"]
            m = re.search(r"\{.*\}", r.text, re.S)
            if m:
                obj, err = loads_lenient(m.group(0))
                if obj is None:
                    probs = [f"bad JSON: {err}"]
                else:
                    plan, probs = check_plan(pool, obj)
                    if err:
                        probs = [f"minor: {err}"] + probs
            if plan is not None:
                return plan, calls, {"problems": probs[:4], "retried": attempt == 1,
                                     "fallback": False}
            msgs += [{"role": "assistant", "content": r.text},
                     {"role": "user", "content": RETRY.format(problems="\n".join(probs[:6]))}]
        return fallback_plan(pool), calls, {"problems": probs[:4], "retried": True, "fallback": True}

    # ------------------------------------------------------------ one node turn (with tool loop)

    def _call(self, pool, stage, node, user, seed_off=0):
        a = pool["agents"][node["agent"]]
        system = a["role"]
        if node["skills"]:
            system += "\n\nSkills to apply:\n" + "\n".join(f"- {pool['skills'][x]['text']}"
                                                           for x in node["skills"])
        tool = tool_budget(pool, node["skills"])
        if tool:
            system += (f"\n\nYou can run Python (numpy and sympy available) up to {tool} time(s): "
                       "write one ```python``` code block that prints what you need, then stop and "
                       "wait for its output.")
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        calls, shown, last_out, tool_error = [], [], None, False
        for k in range(tool + 1):
            r = self.llm.chat(self.model, msgs, thinking=node["thinking"], max_tokens=2048,
                              seed=self.seed + seed_off)
            calls.append({"agent": node["agent"], "stage": stage, "thinking": node["thinking"],
                          "prompt_tokens": r.prompt_tokens, "gen_tokens": r.gen_tokens})
            shown.append(r.text)
            code = CODE.findall(r.text)
            if not code or "####" in r.text.split("```")[-1] or k == tool:
                break
            out, ok = run_python(code[-1])
            tool_error |= not ok
            last_out = out
            shown.append(f"[Python output]\n{out}")
            more = ("You may run code again or give the final answer." if k + 1 < tool
                    else "No more code runs. Give the final answer now.")
            msgs += [{"role": "assistant", "content": r.text},
                     {"role": "user", "content": f"Output:\n{out}\n\n{more} {ANSWER_FMT}"}]
        text = r.text
        ans = extract(text) if ("####" in text or "boxed" in text or last_out is None) \
            else extract(last_out)
        v = VERDICT.findall(text)
        return {"agent": node["agent"], "node": node, "stage": stage, "text": "\n\n".join(shown),
                "answer": ans, "verdict": v[-1].upper() if v else None,
                "unsure": bool(re.search(r"Confidence:\s*\**\s*low", text, re.I)),
                "tool_error": tool_error, "calls": calls}

    @staticmethod
    def _shown(outs):
        return "\n\n".join(f"[{o['agent']}, stage {o['stage'] + 1}]\n{o['text'][-SHOW_CHARS:]}"
                           for o in outs)

    @staticmethod
    def _par(fn, jobs):
        if len(jobs) == 1:
            return [fn(jobs[0])]
        with ThreadPoolExecutor(len(jobs)) as ex:
            return list(ex.map(fn, jobs))

    # ------------------------------------------------------------ stage functions

    def _produce(self, pool, i, st, s, q):
        if s["sees"] == "none" or not st["history"]:
            user = f"Problem: {q}\n\n{ANSWER_FMT}"
        else:
            user = (f"Problem: {q}\n\nEarlier work:\n{self._shown(st['history'])}\n\nConsider the "
                    f"earlier work and give your own solution. {ANSWER_FMT}")
        jobs = [(n, k) for n in s["nodes"] for k in range(n["copies"])]
        rnd = self._par(lambda j: self._call(pool, i, j[0], user, seed_off=j[1]), jobs)
        outs = list(rnd)
        for _ in range(s["rounds"] - 1):
            ans = [o["answer"] for o in rnd]
            if None not in ans and len(set(ans)) == 1:
                break
            user = (f"Problem: {q}\n\nAnswers from the last round:\n{self._shown(rnd)}\n\nConsider "
                    f"them and give your revised solution. {ANSWER_FMT}")
            rnd = self._par(lambda j: self._call(pool, i, j[0], user, seed_off=j[1]), jobs)
            outs += rnd
        return outs, rnd, {}

    def _check(self, pool, i, st, s, q):
        outs, drafts, history, current = [], [], list(st["history"]), st["current"]
        for it in range(s["loop"] + 1):
            user = (f"Problem: {q}\n\nEarlier work:\n{self._shown(history)}\n\nThe current answer is "
                    f"{current}. Check whether it is correct. {VERDICT_FMT} {ANSWER_FMT}")
            checks = self._par(lambda n: self._call(pool, i, n, user), s["nodes"])
            for o in checks:
                if o["answer"] is None and o["verdict"] == "PASS":
                    o["answer"] = current
            outs += checks
            v = [o["verdict"] for o in checks]
            fail = v.count("FAIL") > v.count("PASS")
            if not fail or it == s["loop"]:
                break
            # the author of the current answer revises from the critiques
            authors = [h for h in history if h["answer"] == current and h["node"]["agent"] in
                       pool["agents"] and pool["agents"][h["node"]["agent"]]["function"] == "produce"]
            prev = authors[-1] if authors else next(
                (h for h in reversed(history) if pool["agents"][h["agent"]]["function"] == "produce"),
                None)
            if prev is None:
                break
            crit = "\n\n".join(f"[{o['agent']}]\n{o['text'][-SHOW_CHARS:]}" for o in checks)
            d = self._call(pool, i, prev["node"],
                           f"Problem: {q}\n\nYour earlier solution:\n{prev['text'][-SHOW_CHARS:]}\n\n"
                           f"Critique:\n{crit}\n\nRevise your solution. {ANSWER_FMT}",
                           seed_off=it + 1)
            outs.append(d)
            drafts.append(d)
            history += checks + [d]
            if d["answer"] is not None:
                current = d["answer"]
        return outs, drafts[-1:] + checks, {"fail": fail}

    def _decide(self, pool, i, st, s, q):
        user = (f"Problem: {q}\n\nEarlier work:\n{self._shown(st['history'])}\n\nDecide the single "
                f"correct final answer. {ANSWER_FMT}")
        outs = self._par(lambda n: self._call(pool, i, n, user), s["nodes"])
        return outs, outs, {}

    # ------------------------------------------------------------ the flow

    def run(self, pool: dict, question: str, plan: dict) -> dict:
        conds = compile_conditions(pool)[0]
        st = {"seen": [], "current": None, "history": [], "last": {}, "steps": 0}
        calls, trace, probe = [], [], None
        ran = set()
        for i, s in enumerate(plan["stages"]):
            sig = signals(st)
            if i == 1:
                probe = {"signals": sig, "current": st["current"]}
            skip = (s["with"] not in ran) if "with" in s else \
                (i > 0 and not eval_cond(parse_cond(s["if"], conds), sig))
            if skip:
                trace.append({"stage": i, "ran": False, "signals": sig})
                continue
            fn = {"produce": self._produce, "check": self._check, "decide": self._decide}[s["function"]]
            outs, counted, extra = fn(pool, i, st, s, question)
            stage_calls = [c for o in outs for c in o["calls"]]
            calls += stage_calls
            ans = [o["answer"] for o in counted]
            before = st["current"]
            m = majority(ans)
            st["current"] = m if m is not None else before
            st["seen"] += ans
            st["history"] += outs
            st["steps"] += 1
            ran.add(i)
            st["last"] = {"unsure": any(o["unsure"] for o in outs),
                          "tool_error": any(o["tool_error"] for o in outs),
                          "tokens": max((c["gen_tokens"] for c in stage_calls), default=0), **extra}
            trace.append({"stage": i, "ran": True, "answers": ans, "before": before,
                          "current": st["current"], "signals": sig,
                          "cost": round(cost(stage_calls), 1)})
        if probe is None:
            probe = {"signals": signals(st), "current": st["current"]}
        final = st["current"] if pool["final"] == "last" else (majority(st["seen"]) or st["current"])
        return {"answer": final, "calls": calls, "trace": trace, "probe": probe}
