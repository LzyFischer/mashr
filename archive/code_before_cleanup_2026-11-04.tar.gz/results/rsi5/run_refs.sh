#!/bin/bash
# reference systems on test: HR-designed full teams (round-0 and final org), CoT-SC x5, LLM-Debate 3x2
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
PYTHONPATH=. ~/miniconda3/envs/tinker/bin/python results/rsi5/references.py results/rsi5/references --think high \
  > results/rsi5/references.out 2>&1
