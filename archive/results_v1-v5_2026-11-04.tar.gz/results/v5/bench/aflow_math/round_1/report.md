# Diagnostic report (dev-A)

Organization: acc 92.0%, cost 17107/question, of which the HR 1872 (HR prompt 4385 chars). 38 distinct architectures, 2.0 nodes per question. HR outputs: repaired 0, written again 1, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Counting & Probability L5 | 40 | 90% | - | 20232 | 0 | solver.high>verifier.high 8, coder.high>verifier.high 8, reader.low>solver.high>verifier.high 2 |
| Number Theory L5 | 42 | 98% | - | 18372 | 0 | coder.high>verifier.high 9, solver.high>verifier.high 6, coder.low>verifier.low 6 |
| Prealgebra L5 | 44 | 95% | - | 11533 | 0 | solver.low>verifier.low 12, solver.low 9, coder.high>verifier.high 4 |
| Precalculus L5 | 24 | 79% | - | 19904 | 0 | solver.high>verifier.high 6, coder.high,solver.high>verifier.high 5, coder.high>verifier.high 3 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.high>verifier.high | 24 | 96% | 16155 |
| solver.high>verifier.high | 23 | 87% | 16273 |
| solver.low>verifier.low | 14 | 93% | 8836 |
| solver.low | 12 | 83% | 5691 |
| coder.high,solver.high>verifier.high | 10 | 100% | 24640 |
| coder.low>verifier.low | 10 | 100% | 10391 |
| solver.high | 6 | 100% | 9228 |
| reader.low>solver.high | 6 | 67% | 14633 |
| solver.max | 4 | 100% | 20759 |
| coder.high>verifier.low | 3 | 100% | 15716 |
| reader.low>solver.high>verifier.high | 3 | 100% | 24712 |
| reader.low>solver.low>verifier.low | 2 | 100% | 12696 |
| coder.high | 2 | 100% | 10432 |
| expert.high>verifier.high | 2 | 100% | 16783 |
| solver.high>verifier.low | 2 | 100% | 17750 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| verifier.high (with inputs) | 69 | 94% | 93% | 7455 | 11 | 7 | 2 |
| solver.high | 44 | 84% | 100% | 7569 | - | - | - |
| coder.high | 43 | 88% | 98% | 7285 | - | - | - |
| verifier.low (with inputs) | 31 | 97% | 100% | 3980 | 2 | 1 | - |
| solver.low | 26 | 88% | 100% | 3761 | - | - | - |
| reader.low | 22 | 32% | 100% | 4807 | - | - | - |
| solver.high (with inputs) | 16 | 56% | 100% | 8136 | 14 | 7 | 2 |
| coder.low | 12 | 92% | 92% | 4744 | - | - | - |
| verifier.max (with inputs) | 11 | 82% | 45% | 16218 | 6 | 4 | - |
| solver.max | 5 | 100% | 100% | 18852 | - | - | - |
| coder.high (with inputs) | 4 | 50% | 100% | 8686 | 3 | 1 | - |
| solver.low (with inputs) | 4 | 100% | 100% | 4190 | 1 | 1 | - |
| expert.high | 4 | 75% | 100% | 9064 | - | - | - |
| coder.max | 3 | 100% | 100% | 22774 | - | - | - |
| expert.max | 3 | 67% | 100% | 20165 | - | - | - |
| coder.xhigh | 2 | 100% | 100% | 15767 | - | - | - |
| solver.max (with inputs) | 2 | 100% | 100% | 24879 | 2 | 2 | - |
| expert.high (with inputs) | 1 | 0% | 100% | 8569 | 1 | - | - |
| solver.xhigh | 1 | 0% | 100% | 12332 | - | - | - |
| expert.xhigh | 1 | 100% | 100% | 10971 | - | - | - |
| reader.high | 1 | 0% | 100% | 8257 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| verifier.high (output) | 28 | 4 | 1 | 23 | 8087 |
| solver.high (input) | 22 | 3 | 1 | 18 | 8219 |
| coder.high (input) | 21 | 4 | 0 | 17 | 7655 |
| verifier.low (output) | 17 | 1 | 0 | 16 | 4486 |
| reader.low (input) | 15 | 4 | 1 | 10 | 3949 |
| solver.low (input) | 9 | 0 | 0 | 9 | 3457 |
| verifier.max (output) | 7 | 2 | 0 | 5 | 16313 |
| solver.high (output) | 4 | 1 | 1 | 2 | 7958 |
| expert.high (input) | 3 | 0 | 0 | 3 | 9712 |
| coder.low (input) | 3 | 0 | 0 | 3 | 435 |
| coder.xhigh (input) | 2 | 1 | 0 | 1 | 19784 |
| solver.low (output) | 2 | 1 | 0 | 1 | 4314 |
| coder.max (input) | 2 | 0 | 0 | 2 | 21599 |
| solver.max (output) | 2 | 2 | 0 | 0 | 24879 |
| expert.xhigh (input) | 1 | 0 | 0 | 1 | 10612 |

HR output problems: minor: line 1: non-node argument ignored (2)

## Organization wrong (12)
- [Counting & Probability L5] Matt will arrange four identical, dotless dominoes (shaded 1 by 2 rectangles) on the 5 by 4 grid below so that a path is formed from the upper left-hand corner $A$ to the lower righthand corner $B$. In a path, consecutive dominoes must touch at their sides and not just their corn
  architecture: a = reader("low"); b1 = solver("high", a); b2 = coder("high", a); b3 = expert("high", a); v = verifier("max", b1, b2, b3); return v; answered 16, correct 35
- [Prealgebra L5] A square and a regular heptagon  are coplanar and share a common side $\overline{AD}$, as shown. What is the degree measure of exterior angle $BAC$?  Express your answer as a common fraction.

[asy]
for(int i=0; i <=7; ++i) {
draw(dir(360*i/7+90)--dir(360*(i+1)/7+90));
}
pair A =
  architecture: r = reader("low"); s = solver("high"); out = verifier("max", r, s); return out; answered So the angle is $141, correct \frac{990}{7}^\circ
- [Precalculus L5] In the diagram below, triangle $ABC$ has been reflected over its median $\overline{AM}$ to produce triangle $AB'C'$.  If $AE = 6$, $EC =12$, and $BD = 10$, then find $AB$.

[asy]
size(250);
pair A,B,C,D,M,BB,CC,EE;
B = (0,0);
D = (10,0);
M = (15,0);
C=2*M;
A = D + (scale(1.2)*rot
  architecture: r = reader("low"); s = solver("high", r); return s; answered So $DC = DM + MC = m - 10 + m = 2m - 10, correct 8\sqrt{3}
- [Number Theory L5] Let $g(n)$ be the product of the proper positive integer divisors of $n$. (Recall that a proper divisor of $n$ is a divisor other than $n$.) For how many values of $n$ does $n$ not divide $g(n)$, given that $2 \le n \le 50$?
  architecture: a = solver("low"); return a; answered g(49) = 1 \cdot, correct 19
- [Counting & Probability L5] Every card in a deck has a picture of one shape - circle, square, or triangle, which is painted in one of the three colors - red, blue, or green. Furthermore, each color is applied in one of three shades - light, medium, or dark. The deck has 27 cards, with every shape-color-shad
  architecture: a = solver("low"); b = verifier("low", a); return b; answered 2. Shape Diff, Color, correct 117
- [Precalculus L5] In triangle $ABC$, $3 \sin A + 4 \cos B = 6$ and $4 \sin B + 3 \cos A = 1$. Find all possible values of $\angle C,$ in degrees.  Enter all the possible values, separated by commas.
  architecture: a = solver("xhigh"); return a; answered Therefore,, correct 30^\circ
- [Precalculus L5] How many solutions of the equation $\tan x = \tan (\tan x)$ are on the interval $0 \le x \le \tan^{-1} 942$?  (Here $\tan^{-1}$ means the inverse tangent function, sometimes written $\arctan$.)

Note: You can assume the result that $\tan \theta > \theta$ for $0 < \theta < \frac{\
  architecture: r = reader("low"); s = solver("high", r); return s; answered At $x=0$, $\tan 0 = 0, correct 300
- [Precalculus L5] Find all angles $x$, $0^\circ \le x < 180^\circ,$ such that
\[\sin 6x + \cos 4x = 0.\]Enter all the solutions, separated by commas.
  architecture: s = solver("high"); v = verifier("high", s); return v; answered 27^\circ, 63^\circ, 99^\circ, 135^\circ, 171^\circ`, correct 27^\circ, 63^\circ, 99^\circ, 135^\circ, 171^\circ
- [Counting & Probability L5] In an office at various times during the day, the boss gives the secretary a letter to type, each time putting the letter on top of the pile in the secretary's in-box. When there is time, the secretary takes the top letter off the pile and types it. There are nine letters to be t
  architecture: a = coder("high"); r = verifier("high", a); return r; answered My formula was $2^{n-2} + 2^{n-2}$. Here $n=3$,, correct 704
- [Counting & Probability L5] How many positive integers less than 10,000 have at most two different digits?
  architecture: s = solver("high"); v = verifier("high", s); return v; answered - $2000, 2002, 2020, 2022,, correct 927

## Most expensive correct questions (possible waste)
- [Number Theory L5, cost 51429] What is the largest positive integer that is not the sum of a positive integral multiple of $42$ and a positive composite integer?
  architecture: a = expert("max"); b = solver("high", a); out = verifier("max", a, b); return out
- [Number Theory L5, cost 50934] Find the largest integer $n$ satisfying the following conditions:
(i) $n^2$ can be expressed as the difference of two consecutive cubes;
(ii) $2n + 79$ is a perfect square.
  architecture: a = solver("high"); b = coder("high"); v = verifier("max", a, b); return v
- [Precalculus L5, cost 46492] Let $S$ be the set of all points $(x,y,z)$ such that $x^2 + y^2 + z^2 \le 25$ and $z \ge 0.$  Compute the side length of the largest cube contained in $S.$
  architecture: a = coder("max"); r = reader("low"); v = verifier("max", a, r); return v
- [Counting & Probability L5, cost 40198] A $7\times 1$ board is completely covered by $m\times 1$ tiles without overlap; each tile may cover any number of consecutive squares, and each tile lies completely on the board. E
  architecture: a = solver("max"); b = coder("high"); v = verifier("max", a, b); return v
- [Counting & Probability L5, cost 37115] Let $N$ be the number of positive integers that are less than or equal to $2003$ and whose base-$2$ representation has more $1$'s than $0$'s. Find the remainder when $N$ is divided
  architecture: a = coder("xhigh"); b = verifier("high", a); return b