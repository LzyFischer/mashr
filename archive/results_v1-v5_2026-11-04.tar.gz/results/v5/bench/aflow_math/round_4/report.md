# Diagnostic report (dev-A)

Organization: acc 96.7%, cost 21485/question, of which the HR 1922 (HR prompt 4487 chars). 26 distinct architectures, 2.6 nodes per question. HR outputs: repaired 0, written again 2, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Counting & Probability L5 | 40 | 95% | - | 25714 | 0 | coder.high>verifier.high 9, reader.high>coder.high,solver.high>verifier.max 6, coder.high,solver.high>verifier.max 5 |
| Number Theory L5 | 42 | 98% | - | 21193 | 0 | coder.high>verifier.high 14, coder.low>verifier.low 8, coder.high>solver.high>verifier.max 4 |
| Prealgebra L5 | 44 | 95% | - | 15310 | 0 | coder.low>verifier.low 24, coder.high>verifier.high 6, reader.high>coder.high>verifier.max 4 |
| Precalculus L5 | 24 | 100% | - | 26270 | 0 | reader.high>coder.high,solver.high>verifier.max 7, coder.high>verifier.high 5, reader.high>coder.high>solver.high>verifier.max 2 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.low>verifier.low | 37 | 100% | 9238 |
| coder.high>verifier.high | 34 | 94% | 15686 |
| reader.high>coder.high,solver.high>verifier.max | 16 | 88% | 36303 |
| coder.high,solver.high>verifier.max | 12 | 100% | 29759 |
| coder.high>solver.high>verifier.max | 9 | 100% | 27773 |
| coder.high>verifier.max | 7 | 100% | 21404 |
| reader.high>coder.high>verifier.max | 5 | 100% | 26446 |
| coder.low>verifier.high | 4 | 100% | 12021 |
| coder.max>solver.high>verifier.max | 3 | 100% | 39537 |
| reader.high>coder.high>solver.high>verifier.max | 3 | 100% | 38645 |
| reader.low>coder.high,solver.high>verifier.max | 3 | 100% | 28924 |
| reader.high>coder.max,solver.max>verifier.max | 2 | 100% | 41406 |
| solver.high>verifier.high | 2 | 100% | 16728 |
| reader.high>verifier.max | 1 | 100% | 23174 |
| coder.low>solver.low>verifier.high | 1 | 100% | 16578 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| verifier.max (with inputs) | 68 | 96% | 9% | 10066 | 13 | 11 | 2 |
| coder.high | 62 | 89% | 92% | 7553 | - | - | - |
| verifier.high (with inputs) | 44 | 95% | 95% | 7054 | 6 | 4 | 3 |
| coder.low | 43 | 98% | 98% | 3608 | - | - | - |
| verifier.low (with inputs) | 38 | 100% | 97% | 3802 | 2 | 2 | 1 |
| solver.high (with inputs) | 36 | 83% | 100% | 8420 | 13 | 7 | - |
| reader.high | 34 | 65% | 97% | 7828 | - | - | - |
| coder.high (with inputs) | 33 | 85% | 82% | 7132 | 13 | 8 | 2 |
| solver.high | 15 | 87% | 100% | 8517 | - | - | - |
| coder.max (with inputs) | 6 | 100% | 17% | 14453 | 2 | 2 | - |
| reader.low | 5 | 60% | 100% | 4694 | - | - | - |
| solver.max (with inputs) | 5 | 80% | 20% | 12265 | 2 | 1 | - |
| coder.max | 3 | 100% | 100% | 19747 | - | - | - |
| solver.low (with inputs) | 1 | 100% | 100% | 4795 | - | - | - |
| coder.low (with inputs) | 1 | 100% | 100% | 3765 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| coder.high (input) | 38 | 3 | 3 | 32 | 5022 |
| verifier.max (output) | 30 | 6 | 0 | 24 | 10914 |
| solver.high (input) | 22 | 0 | 1 | 21 | 6428 |
| reader.high (input) | 18 | 2 | 0 | 16 | 4718 |
| coder.low (input) | 17 | 1 | 0 | 16 | 3802 |
| verifier.high (output) | 16 | 1 | 0 | 15 | 7250 |
| verifier.low (output) | 14 | 0 | 0 | 14 | 3888 |
| coder.max (input) | 4 | 0 | 0 | 4 | 14299 |
| reader.low (input) | 3 | 0 | 0 | 3 | 3058 |
| solver.max (input) | 1 | 0 | 0 | 1 | 7618 |
| solver.low (input) | 1 | 0 | 0 | 1 | 4981 |

HR output problems: minor: line 1: non-node argument ignored (11); minor: line 3: non-node argument ignored (2); minor: line 2: non-node argument ignored (1)

## Organization wrong (5)
- [Counting & Probability L5] Matt will arrange four identical, dotless dominoes (shaded 1 by 2 rectangles) on the 5 by 4 grid below so that a path is formed from the upper left-hand corner $A$ to the lower righthand corner $B$. In a path, consecutive dominoes must touch at their sides and not just their corn
  architecture: r = reader("high"); c = coder("high", r); s = solver("high", r); out = verifier("max", r, c, s); return out; answered 19, correct 35
- [Prealgebra L5] A square and a regular heptagon  are coplanar and share a common side $\overline{AD}$, as shown. What is the degree measure of exterior angle $BAC$?  Express your answer as a common fraction.

[asy]
for(int i=0; i <=7; ++i) {
draw(dir(360*i/7+90)--dir(360*(i+1)/7+90));
}
pair A =
  architecture: r = reader("high"); c = coder("high", r); s = solver("high", r); out = verifier("max", r, c, s); return out; answered 1530/7, correct \frac{990}{7}^\circ
- [Number Theory L5] Let $a_n$ be the number obtained by writing the integers 1 to $n$ from left to right. Therefore, $a_4 = 1234$ and \[a_{12} = 123456789101112.\]For $1 \le k \le 100$, how many $a_k$ are divisible by 9?
  architecture: c = coder("high"); v = verifier("high", c); return v; answered 27", correct 22
- [Counting & Probability L5] In an office at various times during the day, the boss gives the secretary a letter to type, each time putting the letter on top of the pile in the secretary's in-box. When there is time, the secretary takes the top letter off the pile and types it. There are nine letters to be t
  architecture: r = reader("high"); c = coder("high", r); s = solver("max", r, c); v = verifier("max", r, c, s); return v; answered 128, correct 704
- [Prealgebra L5] Two sides of a right triangle have the lengths 4 and 5. What is the product of the possible lengths of the third side? Express the product as a decimal rounded to the nearest tenth.
  architecture: c = coder("high"); v = verifier("high", c); return v; answered 3\sqrt{41}, correct 19.2

## Most expensive correct questions (possible waste)
- [Counting & Probability L5, cost 52463] Three numbers, $a_1\,$, $a_2\,$, $a_3\,$, are drawn randomly and without replacement from the set $\{1, 2, 3, \dots, 1000\}\,$. Three other numbers, $b_1\,$, $b_2\,$, $b_3\,$, are 
  architecture: a = reader("high"); c = coder("max", a); s = solver("high", a, c); out = verifier("max", a, c, s); return out
- [Prealgebra L5, cost 46662] Each of the boxes in the figure below is a square. How many different squares can be traced using the lines in the figure?

[asy]
unitsize(0.2inch);
draw((0,1)--(1,1)--(1,4)--(0,4)
  architecture: r = reader("high"); c = coder("high", r); s = solver("high", r, c); out = verifier("max", r, c, s); return out
- [Number Theory L5, cost 45842] Find the largest integer $n$ satisfying the following conditions:
(i) $n^2$ can be expressed as the difference of two consecutive cubes;
(ii) $2n + 79$ is a perfect square.
  architecture: r = reader("high"); c = coder("max", r); s = solver("max", r, c); out = verifier("max", r, c, s); return out
- [Precalculus L5, cost 45662] In triangle $ABC$, $3 \sin A + 4 \cos B = 6$ and $4 \sin B + 3 \cos A = 1$. Find all possible values of $\angle C,$ in degrees.  Enter all the possible values, separated by commas.
  architecture: r = reader("high"); c = coder("high", r); s = solver("high", r); v = verifier("max", r, c, s); return v
- [Counting & Probability L5, cost 44811] Let $N$ be the number of positive integers that are less than or equal to $2003$ and whose base-$2$ representation has more $1$'s than $0$'s. Find the remainder when $N$ is divided
  architecture: c = coder("high"); s = solver("high"); v = verifier("max", c, s); return v