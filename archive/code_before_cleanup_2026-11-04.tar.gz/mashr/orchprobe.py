"""Probe the v4 orchestrator alone (no solving): how often its staffing plans need repair, a second try
or the fallback, and what goes wrong. Cheap: one or two calls per question.

  $P -m mashr.orchprobe results/rsi4/smoke/round_0/pool.json --n 350 [--seed 0] [--show 5]
"""
import argparse
import json
import re
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from .exec4 import Engine
from .llm import LLM
from .org4 import shape
from .orgrsi import load_items


def kind(p: str) -> str:
    """Problem class, with names and numbers stripped."""
    p = re.sub(r"'[^']*'|\[[^\]]*\]|\"[^\"]*\"", "<x>", p)
    return re.sub(r"\d+", "<n>", p)[:90]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pool")
    ap.add_argument("--dataset", default="math")
    ap.add_argument("--n", type=int, default=350)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--show", type=int, default=0, help="print this many raw problem examples")
    a = ap.parse_args()
    pool = json.load(open(a.pool))
    eng = Engine(LLM(), seed=a.seed)
    items = load_items(a.dataset, "train", 0, a.n)
    with ThreadPoolExecutor(64) as ex:
        res = list(ex.map(lambda it: eng.orchestrate(pool, it["question"]), items))
    n = len(res)
    minor = [i for i, (_, _, x) in enumerate(res)
             if any(p.startswith("minor:") for p in x["problems"])]
    rep = [i for i, (_, _, x) in enumerate(res) if not x["retried"]
           and any(not p.startswith("minor:") for p in x["problems"])]
    retr = [i for i, (_, _, x) in enumerate(res) if x["retried"]]
    fb = [i for i, (_, _, x) in enumerate(res) if x["fallback"]]
    cost = sum(c["gen_tokens"] + 0.2 * c["prompt_tokens"] for _, cs, _ in res for c in cs) / n
    clean = sum(not x["problems"] and not x["retried"] for _, _, x in res)
    print(f"n {n}: clean {clean} ({clean / n:.0%}), minor fixes {len(minor)}, structural repairs "
          f"{len(rep)}, asked again {len(retr)} (fallback {len(fb)}); orchestrator cost "
          f"{cost:.0f}/question; usable without a second call {(n - len(retr)) / n:.0%}")
    print("problem classes:")
    for k, v in Counter(kind(p) for _, _, x in res for p in x["problems"]).most_common(12):
        print(f"  {v:4d}  {k}")
    print("architectures:", Counter(shape(p) for p, _, _ in res).most_common(10))
    print("skills on:", Counter(s for p, _, _ in res for st in p["stages"] for nd in st["nodes"]
                                for s in nd["skills"]).most_common())
    for i in (rep + retr)[:a.show]:
        print("---", res[i][2]["problems"])


if __name__ == "__main__":
    main()
