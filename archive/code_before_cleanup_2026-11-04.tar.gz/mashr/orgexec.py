"""Per-question fast loop: the HR's single call, and the SOP executor with rule-engine escalation."""
import json
import re
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from .mas import MODEL, extract
from .org import check_plan, hr_prompt

ANSWER_FMT = ("End your response with exactly two lines:\nConfidence: high or low\n#### <number>")
TASK_TEXT = {
    "solve": "Consider the team's messages and give your own solution.",
    "review": "Check these solutions for errors in reasoning or arithmetic and give the answer you "
              "believe is correct.",
    "decide": "Decide the single correct final answer.",
}


def confidence(text: str) -> str:
    m = re.findall(r"Confidence:\s*\**\s*(high|low)", text, re.I)
    return m[-1].lower() if m else "unknown"


def majority(answers):
    answers = [a for a in answers if a is not None]
    return Counter(answers).most_common(1)[0][0] if answers else None


def fires(cond: str, done: dict) -> bool:
    if cond == "always":
        return True
    parts = cond.split(":")
    st = done.get(parts[1])
    if st is None:                     # referenced stage did not run
        return False
    outs = st["outputs"]
    answers = [o["answer"] for o in outs]
    if parts[0] == "disagree":
        return len(outs) >= 2 and (None in answers or len(set(answers)) > 1)
    if parts[0] == "missing":
        return None in answers
    if parts[0] == "unsure":
        return None in answers or any(o["confidence"] != "high" for o in outs)
    if parts[0] == "long":
        return any(o["gen_tokens"] > int(parts[2]) for o in outs)
    return False


class OrgExecutor:
    def __init__(self, llm, model: str = MODEL, seed: int = 0):
        self.llm, self.model, self.seed = llm, model, seed

    def hr(self, org: dict, question: str):
        r = self.llm.chat(self.model, [{"role": "system", "content": hr_prompt(org)},
                                       {"role": "user", "content": f"Problem: {question}\n\n"
                                                                   "Your JSON decision:"}],
                          thinking="off", max_tokens=500, seed=self.seed)
        plan, probs = None, ["no JSON object"]
        m = re.search(r"\{.*\}", r.text, re.S)
        if m:
            try:
                plan, probs = check_plan(org, json.loads(m.group(0)))
            except json.JSONDecodeError as e:
                probs = [f"bad JSON: {e}"]
        call = {"role": "hr", "stage": None, "thinking": "off", "prompt_tokens": r.prompt_tokens,
                "gen_tokens": r.gen_tokens, "cached": r.cached, "fallback": plan is None,
                "problems": probs[:3]}
        if plan is None:
            plan, _ = check_plan(org, org["default_plan"])
        return plan, call

    def _employee(self, org, plan, name, stage, user):
        s = org["staff"][name]
        sys = s["job"]
        on = plan["skills"].get(name, [])
        if on:
            sys += "\n\nSkills to apply:\n" + "\n".join(f"- {org['skills'][k]}" for k in on)
        if plan["guide"].get(name):
            user = f"Note from your manager: {plan['guide'][name]}\n\n{user}"
        th = plan["thinking"].get(name, "off")
        r = self.llm.chat(self.model, [{"role": "system", "content": sys},
                                       {"role": "user", "content": user}],
                          thinking=th, max_tokens=2048, seed=self.seed)
        return {"name": name, "text": r.text, "answer": extract(r.text),
                "confidence": confidence(r.text), "gen_tokens": r.gen_tokens,
                "call": {"role": name, "stage": stage, "thinking": th,
                         "prompt_tokens": r.prompt_tokens, "gen_tokens": r.gen_tokens,
                         "cached": r.cached}}

    def run(self, org: dict, question: str, plan: dict) -> dict:
        if plan["sop"] == "self":
            return {"answer": extract(plan["answer"]), "calls": [], "trace": []}
        done, calls, trace = {}, [], []
        last = None
        for st in org["sops"][plan["sop"]]["stages"]:
            who = plan["assign"].get(st["id"], [])
            fired = any(fires(c, done) for c in st.get("when", ["always"]))
            if not who or not fired:
                trace.append({"stage": st["id"], "ran": False, "fired": fired, "members": who})
                continue
            if not st.get("sees"):
                user = f"Problem: {question}\n\n{ANSWER_FMT}"
            else:
                shown = []
                for sid in st["sees"]:
                    if sid not in done:
                        continue
                    for o in done[sid]["outputs"]:
                        body = o["text"] if done[sid]["show"] == "full" else \
                            f"Final answer: {o['answer']}"
                        shown.append(f"[{o['name']}, stage {sid}]\n{body}")
                user = (f"Problem: {question}\n\nTeam messages:\n" + "\n\n".join(shown)
                        + f"\n\n{TASK_TEXT[st['task']]} {ANSWER_FMT}")
            with ThreadPoolExecutor(len(who)) as pool:
                outs = list(pool.map(lambda n: self._employee(org, plan, n, st["id"], user), who))
            calls += [o["call"] for o in outs]
            done[st["id"]] = {"outputs": outs, "show": st.get("show", "full")}
            prev = majority([o["answer"] for o in done[last]["outputs"]]) if last else None
            cur = majority([o["answer"] for o in outs])
            trace.append({"stage": st["id"], "ran": True, "fired": True, "members": who,
                          "answers": [o["answer"] for o in outs], "majority": cur,
                          "prev_majority": prev})
            last = st["id"]
        return {"answer": majority([o["answer"] for o in done[last]["outputs"]]),
                "calls": calls, "trace": trace}
