"""The HR: one call per question, reads its harness H and the question, emits a plan (see mas.py).

H is plain text and is what dataset-level RSI edits. v0 has an empty staffing-rules section.
"""
import json
import re

from .mas import FULL_TEAM, MODEL

HARNESS_V0 = """You are the HR manager of a team that solves grade-school math word problems. For each
problem you decide, before anyone works on it, who works on it and how. Every token the team
generates costs money; your goal is to keep the team's accuracy while spending as little as possible.

## Staff (all the same model; cost = generated tokens)
- solver_A: solves directly and concisely.
- solver_B: solves step by step and double-checks arithmetic.
- solver_C: sets up variables and equations.
- critic: reviews other agents' solutions and gives its own answer (only useful from round 2).
- judge: reads the last round and picks the final answer (otherwise answers are majority-voted).
Thinking levels per agent: "off" (~150 tokens per call), "low" (up to ~1000 extra reasoning tokens),
"high" (up to ~4000 extra reasoning tokens).

## Options (output exactly one JSON object, nothing else)
1. Answer it yourself if it is trivial:
   {"mode": "self", "answer": "<number>"}
2. Give it to one employee:
   {"mode": "single", "agent": "solver_B", "thinking": "low"}
3. Assemble a team. Agents not listed are not used. "message": "full" passes the whole solution to
   the next round, "conclusion" passes only the final answer. stop_if_consensus ends after round 1
   if all round-1 answers agree.
   {"mode": "team", "agents": {"solver_A": {"rounds": [1], "thinking": "off", "message": "conclusion"},
    "solver_B": {"rounds": [1, 2], "thinking": "low", "message": "full"},
    "critic": {"rounds": [2], "thinking": "off", "message": "full"}, "judge": {"thinking": "off"}},
    "stop_if_consensus": true}

## Staffing rules
(none yet)
"""


def parse_plan(text: str) -> dict | None:
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return None
    try:
        p = json.loads(m.group(0))
    except json.JSONDecodeError:
        return None
    if p.get("mode") == "self" and "answer" in p:
        return p
    if p.get("mode") == "single" and p.get("thinking", "off") in ("off", "low", "high"):
        return p
    # rules often name team templates ("hard", "easy_team"); the HR then writes that name as the
    # mode. Any plan with an agents dict is a team plan.
    if isinstance(p.get("agents"), dict) and p["agents"]:
        return {**p, "mode": "team", "template": p.get("mode")}
    return None


def plan_for(llm, question: str, harness: str = HARNESS_V0, model: str = MODEL, seed: int = 0):
    r = llm.chat(model, [{"role": "system", "content": harness},
                         {"role": "user", "content": f"Problem: {question}\n\nYour JSON decision:"}],
                 thinking="off", max_tokens=400, seed=seed)
    plan = parse_plan(r.text)
    call = {"role": "hr", "thinking": "off", "prompt_tokens": r.prompt_tokens,
            "gen_tokens": r.gen_tokens, "cached": r.cached, "fallback": plan is None}
    return (plan or FULL_TEAM), call
