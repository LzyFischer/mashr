# Performance report (dev-A)

Organization: acc 92.7%, cost 8742/question. Full team: acc 91.3%, cost 27271. Invalid HR outputs (default plan used): 2.

## By category
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 4570 | 19590 | vote 10, solo 3, check 2, hard 1, self 1 |
| Algebra L5 | 18 | 100% | 100% | 5890 | 23083 | vote 11, hard 4, check 2, solo 1 |
| Counting & Probability L4 | 8 | 100% | 100% | 6402 | 22644 | vote 8 |
| Counting & Probability L5 | 9 | 89% | 89% | 9714 | 32029 | vote 9 |
| Geometry L4 | 5 | 100% | 100% | 6750 | 24771 | solo 2, hard 2, vote 1 |
| Geometry L5 | 7 | 57% | 57% | 18644 | 39998 | hard 6, vote 1 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 8115 | 28859 | vote 8, hard 4, check 2 |
| Intermediate Algebra L5 | 17 | 76% | 71% | 15878 | 36267 | vote 10, hard 6, check 1 |
| Number Theory L4 | 9 | 100% | 100% | 6521 | 26425 | vote 9 |
| Number Theory L5 | 16 | 94% | 88% | 9028 | 29063 | vote 13, solo 2, check 1 |
| Prealgebra L4 | 12 | 100% | 100% | 3266 | 15420 | vote 5, check 4, solo 3 |
| Prealgebra L5 | 9 | 100% | 100% | 7734 | 26009 | vote 4, hard 3, solo 2 |
| Precalculus L4 | 3 | 100% | 67% | 11857 | 31364 | hard 2, vote 1 |
| Precalculus L5 | 6 | 67% | 83% | 15603 | 38717 | vote 3, hard 3 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| check.check | 12 | 1 | 0 | 0 | 0 |
| check.draft | 12 | 12 | 0 | 0 | 0 |
| hard.r1 | 31 | 31 | 0 | 0 | 0 |
| hard.r2 | 31 | 31 | 10 | 5 | 0 |
| hard.r3 | 31 | 6 | 5 | 1 | 0 |
| solo.draft | 13 | 13 | 0 | 0 | 0 |
| vote.r1 | 93 | 93 | 0 | 0 | 0 |
| vote.r2 | 93 | 14 | 11 | 6 | 0 |
| vote.r3 | 93 | 7 | 7 | 2 | 1 |

## Employees: leave-one-out replay on 60 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| critic | 31 | 8 | 0 | 23 | 8349 |
| judge | 8 | 1 | 1 | 6 | 6340 |
| solver_B | 43 | 2 | 2 | 39 | 4145 |
| solver_C | 44 | 2 | 0 | 42 | 4476 |
Needed / uses by difficulty: critic@Algebra L4: 0/1; critic@Algebra L5: 0/3; critic@Counting & Probability L5: 0/1; critic@Geometry L4: 1/2; critic@Geometry L5: 1/4; critic@Intermediate Algebra L4: 1/3; critic@Intermediate Algebra L5: 1/7; critic@Number Theory L5: 1/2; critic@Prealgebra L5: 2/3; critic@Precalculus L4: 0/1; critic@Precalculus L5: 1/4; judge@Counting & Probability L5: 0/1; judge@Geometry L5: 0/2; judge@Intermediate Algebra L5: 0/2; judge@Number Theory L5: 1/2; judge@Precalculus L5: 0/1; solver_B@Algebra L4: 0/4; solver_B@Algebra L5: 0/2; solver_B@Counting & Probability L4: 0/3; solver_B@Counting & Probability L5: 0/4; solver_B@Geometry L5: 0/1; solver_B@Intermediate Algebra L4: 0/5; solver_B@Intermediate Algebra L5: 1/7; solver_B@Number Theory L4: 0/4; solver_B@Number Theory L5: 1/4; solver_B@Prealgebra L4: 0/1; solver_B@Prealgebra L5: 0/3; solver_B@Precalculus L4: 0/2; solver_B@Precalculus L5: 0/3; solver_C@Algebra L4: 0/4; solver_C@Algebra L5: 0/2; solver_C@Counting & Probability L4: 0/3; solver_C@Counting & Probability L5: 0/4; solver_C@Geometry L5: 0/1; solver_C@Intermediate Algebra L4: 0/5; solver_C@Intermediate Algebra L5: 0/7; solver_C@Number Theory L4: 0/4; solver_C@Number Theory L5: 1/4; solver_C@Prealgebra L4: 0/1; solver_C@Prealgebra L5: 0/3; solver_C@Precalculus L4: 1/3; solver_C@Precalculus L5: 0/3

## HR usage
Employees assigned (questions): solver_B 146, critic 136, judge 123, solver_C 70
Skills switched on (times): reread_question 462, final_form 460, verify_by_substitution 128, percent_base 64, diagram_coordinates 33, check_units 30, common_roots_diff 13, subtract_from 8, near_power_count 7, geometric_sequence 6, complex_equilateral 6, perm_repeats_zero 5, roots_unity_count 5, coordinate_3d 5, mean_removed 3, intercepts_linear 3, power_pair_recursion 2, coordinate_max_area 1
Guide notes written: 120
Invalid HR outputs, first problems: ["bad JSON: Expecting ':' delimiter: line 1 column 434 (char 433)"]; ["bad JSON: Expecting ':' delimiter: line 1 column 506 (char 505)"]

## Saved wrong: org failed, full team succeeded (4)
- [Number Theory L5] A relatively prime date is a date for which the number of the month and the number of the day are relatively prime. For example, June 17 is a relatively prime date because the greatest common factor of 6 and 17 is 1. How many relatively prime dates are in the month with the fewes
  plan: vote r1=[solver_B:low+reread_question/percent_base/final_form] r2=[critic:high+reread_question/verify_by_substitution/final_form] r3=[judge:low+reread_question/final_form] guide: judge: "Select the final count and ensure it matches the question's request."; critic: "Verify counts for Feb and check if leap year affects the result significantly."; solver_B: "Calculate GCD for all dates in the shortest month (Feb). Count pairs with GCD=1."; answered 14, correct 10
- [Precalculus L5] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection = perspective(6,3,2);

triple A, B, C, D, E, F, G, H;

A = (1,1,0);
B = (1,-1,0);
C = (-1,-1,0);
D 
  plan: hard r1=[solver_B:low+reread_question/coordinate_3d/final_form, solver_C:low+reread_question/coordinate_3d/final_form] r2=[critic:high+reread_question/coordinate_3d/final_form] r3=[judge:low+reread_question/final_form] guide: judge: "Confirm final answer format and selection."; critic: "Verify intersection logic and area calculation steps."; solver_C: "Define vertices. Calculate intersection points. Use geometric formula for maximal cross-section area."; solver_B: "Parametrize plane intersection with prism edges. Maximize area using distance from centroid."; answered 5, correct 225
- [Intermediate Algebra L5] Let
\[x^8 + 98x^4 + 1 = p(x) q(x),\]where $p(x)$ and $q(x)$ are monic, non-constant polynomials with integer coefficients.  Find $p(1) + q(1).$
  plan: vote r1=[solver_B:low+reread_question/final_form/common_roots_diff] r2=[critic:high+reread_question/verify_by_substitution/final_form] r3=[judge:low+reread_question/final_form] guide: judge: "Confirm the single correct integer sum."; critic: "Verify factorization and sum of values at x=1."; solver_B: "Factor x^8+98x^4+1 using substitution and difference of squares."; answered -1, correct 20
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: hard r1=[solver_B:low+reread_question/diagram_coordinates/final_form, solver_C:low+reread_question/diagram_coordinates/final_form] r2=[critic:high+reread_question/diagram_coordinates/final_form] r3=[judge:low+reread_question/final_form] guide: judge: "Confirm max area value and units."; critic: "Verify derivative or symmetry argument for maximum, check boundary conditions."; solver_C: "Define angle theta, derive coordinates of intersections, maximize area formula."; solver_B: "Model lines as rotating, find intersection points, calculate area as function of angle, maximize."; answered 2, correct 85

Both wrong: 7.

## Most expensive correctly-solved questions (possible waste)
- [Intermediate Algebra L5, cost 26745] Find the number of integers $n$ such that \[1+\left\lfloor\dfrac{100n}{101}\right\rfloor=\left\lceil\dfrac{99n}{100}\right\rceil.\]
  plan: vote r1=[solver_B:low+reread_question/final_form/percent_base, solver_C:low+reread_question/final_form/verify_by_substitution] r2=[critic:high+reread_question/final_form/verify_by_substitution] r3=[judge:low+reread_question/final_form] guide: judge: "Select final count and verify form."; critic: "Verify logic, arithmetic, and count of integers."; solver_C: "Define bounds for floor and ceil, solve for n."; solver_B: "Solve inequality by expanding floor/ceil definitions."
- [Geometry L5, cost 26674] Square $ABCD$ has center $O,\ AB=900,\ E$ and $F$ are on $AB$ with $AE<BF$ and $E$ between $A$ and $F, m\angle EOF =45^\circ,$ and $EF=400.$ Given that $BF=p+q\sqrt{r},$ where $p,q
  plan: hard r1=[solver_B:low+reread_question/diagram_coordinates/final_form, solver_C:low+reread_question/diagram_coordinates/final_form] r2=[critic:high+reread_question/verify_by_substitution/final_form] r3=[judge:low+reread_question/final_form] guide: judge: "Select correct BF value and sum p+q+r."; critic: "Check arithmetic and that BF = p+q√r form is met."; solver_C: "Define variables for AE, BF. Use tan(45) relation between slopes."; solver_B: "Set coordinates for A, B, E, F, O. Use angle condition to find BF."
- [Number Theory L5, cost 26552] Let $\tau (n)$ denote the number of positive integer divisors of $n$ (including $1$ and $n$). Find the sum of the six least positive integers $n$ that are solutions to $\tau (n) + 
  plan: vote r1=[solver_B:low+reread_question/percent_base/final_form, solver_C:low+reread_question/verify_by_substitution/final_form] r2=[critic:high+reread_question/verify_by_substitution/final_form] r3=[judge:low+reread_question/final_form] guide: judge: "Select best verified answer, format as sum."; critic: "Check arithmetic, ensure n and n+1 satisfy tau sum."; solver_C: "Define n, solve diophantine, verify sum conditions."; solver_B: "List divisors, find pairs summing to 7, check least integers."
- [Number Theory L5, cost 19776] Let $N$ be the number of ways to write $2010$ in the form $2010 = a_3 \cdot 10^3 + a_2 \cdot 10^2 + a_1 \cdot 10 + a_0$, where the $a_i$'s are integers, and $0 \le a_i \le 99$. An 
  plan: vote r1=[solver_B:low+reread_question/percent_base/final_form, solver_C:low+reread_question/verify_by_substitution/final_form] r2=[critic:high+reread_question/check_units/final_form] r3=[judge:low+reread_question/final_form]
- [Intermediate Algebra L5, cost 19144] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  plan: vote r1=[solver_B:low+reread_question/power_pair_recursion/final_form, solver_C:low+reread_question/power_pair_recursion/final_form] r2=[critic:high+reread_question/verify_by_substitution/final_form] r3=[judge:low+reread_question/final_form] guide: judge: "Select final answer matching exact form."; critic: "Verify conditions hold for derived values."; solver_C: "Define recurrence relation for f(2^k + m)."; solver_B: "Use recursion with powers of 2 to reduce f(2002)."