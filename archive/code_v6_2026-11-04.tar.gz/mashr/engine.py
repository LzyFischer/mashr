"""Fast loop: the HR writes the team and each node's residual harness (org.py); the executor runs it.
A node with tools gets Python with those tools preloaded.

Model-written Python runs in a separate interpreter without network (unshare -rn when available),
with memory, CPU-time and file-size limits, in a temporary directory.
"""
import os
import re
import shutil
import subprocess
import tempfile
import threading
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from .llm import THINK_BUDGET
from .org import fallback_plan, hr_prompt, parse_program
from .tools import TOOLS, tool_code

MODEL = "Qwen/Qwen3.5-9B"
ANSWER_FMT = "End your response with a final line of the form '#### <number>'."
PROMPT_WEIGHT = 0.2   # cost = generated tokens + 0.2 * prompt tokens (all calls, incl. the HR's)
SHOW_CHARS = 4000
PY_RUNS = 2
RETRY = "Your answer could not be used:\n{problems}\n\nWrite it again: the code block, then the notes."

PY = os.environ.get("MASHR_PY", "/usr/bin/python3")   # needs numpy/sympy; the tinker env has none
CODE = re.compile(r"```(?:python|py)\s*\n(.*?)```", re.S)
_ISOLATE = (["unshare", "-rn"] if shutil.which("unshare") and subprocess.run(
    ["unshare", "-rn", "true"], capture_output=True).returncode == 0 else [])
_py_cache: dict = {}
_py_lock = threading.Lock()


def run_python(code: str, timeout: int = 10) -> tuple[str, bool]:
    """Run code; returns (stdout tail plus error, ok). Results are memoized per code string."""
    with _py_lock:
        if code in _py_cache:
            return _py_cache[code]
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "main.py")
        with open(path, "w") as f:
            f.write(code)
        cmd = ["prlimit", "--as=2000000000", f"--cpu={timeout}", "--fsize=10000000", "--",
               *_ISOLATE, PY, "-I", path]
        try:
            r = subprocess.run(cmd, cwd=d, capture_output=True, text=True, timeout=timeout + 5,
                               env={"PATH": "/usr/bin:/bin", "HOME": d})
            out, err, ok = r.stdout, r.stderr, r.returncode == 0
        except subprocess.TimeoutExpired:
            out, err, ok = "", "timed out", False
    text = out[-1500:].strip()
    if not ok:
        text += "\n[error] " + err.strip()[-800:]
    res = (text.strip() or "(no output)", ok)
    with _py_lock:
        _py_cache[code] = res
    return res


def majority(answers):
    """Most common non-missing answer; ties go to the earliest."""
    xs = [a for a in answers if a is not None]
    if not xs:
        return None
    c = Counter(xs)
    top = max(c.values())
    return next(a for a in xs if c[a] == top)


def cost(calls) -> float:
    return sum(c["gen_tokens"] + PROMPT_WEIGHT * c["prompt_tokens"] for c in calls)


def extract(text: str) -> str | None:
    m = re.findall(r"####\s*\$?\s*(-?[\d,]*\.?\d+)", text)
    if not m:
        m = re.findall(r"\\boxed\{\s*\$?(-?[\d,]*\.?\d+)", text) or re.findall(r"-?[\d,]*\.?\d+", text)
    if not m:
        return None
    s = m[-1].replace(",", "")
    try:
        f = float(s)
        return str(int(f)) if f == int(f) else str(f)
    except ValueError:
        return None


class Engine:
    def __init__(self, llm, model: str = MODEL, seed: int = 0, hr_thinking: str = "low",
                 answer_fmt: str = ANSWER_FMT, extract_fn=extract):
        self.llm, self.model, self.seed, self.hr_thinking = llm, model, seed, hr_thinking
        self.answer_fmt, self.extract = answer_fmt, extract_fn

    def orchestrate(self, pool: dict, question: str):
        msgs = [{"role": "system", "content": hr_prompt(pool)},
                {"role": "user", "content": f"Problem: {question}\n\nYour team:"}]
        calls, probs = [], []
        for attempt in range(2):
            r = self.llm.chat(self.model, msgs, thinking=self.hr_thinking, max_tokens=900,
                              seed=self.seed + attempt)
            calls.append({"agent": "HR", "node": None, "prompt_tokens": r.prompt_tokens,
                          "gen_tokens": r.gen_tokens})
            plan, probs = parse_program(pool, r.text)
            if plan is not None:
                return plan, calls, {"problems": probs[:4], "retried": attempt == 1,
                                     "fallback": False}
            msgs += [{"role": "assistant", "content": r.text},
                     {"role": "user", "content": RETRY.format(problems="\n".join(probs[:6]))}]
        return fallback_plan(pool), calls, {"problems": probs[:4], "retried": True, "fallback": True}

    def _node(self, pool, node, user):
        system = pool["agents"][node["agent"]]["role"]
        if node["skills"]:
            system += "\n\nSkills to apply:\n" + "\n".join(f"- {pool['skills'][k]}" for k in node["skills"])
        runs = PY_RUNS if node["tools"] else 0
        if runs:
            helpers = [t for t in node["tools"] if TOOLS[t]["code"].strip()]
            system += (f"\n\nYou can run Python (numpy and sympy available) up to {runs} times: write "
                       "one ```python``` code block that prints what you need, then stop and wait for "
                       "its output.")
            if helpers:
                system += " These functions are already defined:\n" + "\n".join(
                    f"- {TOOLS[t]['doc']}" for t in helpers)
        if node["note"]:
            user = user.replace(f"\n\n{self.answer_fmt}", "") if user.endswith(self.answer_fmt) else user
            user += f"\n\nNote from your manager: {node['note']}\n\n{self.answer_fmt}"
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        calls, shown, last_out = [], [], None
        pre = tool_code(node["tools"])
        for k in range(runs + 1):
            # with thinking off the reasoning is in the answer itself, so it gets more room
            r = self.llm.chat(self.model, msgs, thinking=node["thinking"],
                              max_tokens=4096 if node["thinking"] == "off" else 2048, seed=self.seed)
            calls.append({"agent": node["agent"], "node": node["id"], "thinking": node["thinking"],
                          "prompt_tokens": r.prompt_tokens, "gen_tokens": r.gen_tokens})
            shown.append(r.text)
            code = CODE.findall(r.text)
            if not code or "####" in r.text.split("```")[-1] or k == runs:
                break
            out, _ = run_python(pre + "\n" + code[-1])
            last_out = out
            shown.append(f"[Python output]\n{out}")
            more = ("You may run code again or give the final answer." if k + 1 < runs
                    else "No more code runs. Give the final answer now.")
            msgs += [{"role": "assistant", "content": r.text},
                     {"role": "user", "content": f"Output:\n{out}\n\n{more} {self.answer_fmt}"}]
        text = r.text
        ans = self.extract(text) if ("####" in text or "boxed" in text or last_out is None) \
            else self.extract(last_out)
        return {"id": node["id"], "agent": node["agent"], "text": "\n\n".join(shown), "answer": ans,
                "calls": calls,
                "cut": calls[0]["gen_tokens"] >= THINK_BUDGET[node["thinking"]] > 0}

    def run(self, pool: dict, question: str, plan: dict) -> dict:
        done, depth = {}, {}
        for n in plan["nodes"]:
            depth[n["id"]] = 1 + max((depth[i] for i in n["inputs"]), default=-1)
        for d in sorted(set(depth.values())):
            layer = [n for n in plan["nodes"] if depth[n["id"]] == d]

            def one(n):
                if not n["inputs"]:
                    user = f"Problem: {question}\n\n{self.answer_fmt}"
                else:
                    work = "\n\n".join(f"[{done[i]['agent']} ({i})]\n{done[i]['text'][-SHOW_CHARS:]}"
                                       for i in n["inputs"])
                    user = (f"Problem: {question}\n\nWork from your teammates:\n{work}\n\nGive your "
                            f"own solution and final answer.\n\n{self.answer_fmt}")
                return self._node(pool, n, user)
            if len(layer) == 1:
                outs = [one(layer[0])]
            else:
                with ThreadPoolExecutor(len(layer)) as ex:
                    outs = list(ex.map(one, layer))
            for o in outs:
                done[o["id"]] = o
        answer = done[plan["output"]]["answer"]
        if answer is None:
            answer = majority([o["answer"] for o in done.values()])
        calls = [c for n in plan["nodes"] for c in done[n["id"]]["calls"]]
        return {"answer": answer, "calls": calls,
                "nodes": [{k: v for k, v in done[n["id"]].items() if k not in ("text", "calls")}
                          | {"cost": round(cost(done[n["id"]]["calls"]), 1)} for n in plan["nodes"]]}
