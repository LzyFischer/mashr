"""The organization v3: agents and skills plus an editable rule layer (building blocks, run
conditions, recipes, the orchestrator's mode and the final-answer rule). The designer edits all of it.

The block library follows operator-library / supernet designs for agentic workflows: MaAS (Zhang et
al., ICML 2025: I/O, CoT, Debate, Reflexion, ReAct, Evaluator-optimizer, Exit), AFlow (Zhang et al.,
ICLR 2025: Generate, Review/Revise, ScEnsemble, Programmer), MASS (Zhou et al., 2025: prompts and
topology optimized together), Self-Consistency, Program-of-Thought, multi-agent debate (Du et al.).
Here the library itself is editable: a block is a primitive kind (implemented in engine.py) plus the
designer's own instruction and parameters, and the conditions that gate later steps are expressions
over free runtime signals that the designer can rewrite.

  agents        name -> {"role": str, "skills": [ids]}
  skills        id -> how-to text
  blocks        id -> {"kind": <kind>, "instruction": str, ...params}
  conditions    name -> expression, e.g. "disagree or fail or agree < 0.67"
  recipes       name -> plan: a named architecture the orchestrator can pick by name
  orchestrator  {"mode": "llm" | "fixed", "recipe": <used in fixed mode>, "fallback": <recipe used
                 when the orchestrator's output is invalid>, "thinking": "off" | "low"}
  final         "last" (current answer after the last step that ran) | "vote" (majority of all answers)
  policy        the orchestrator's dispatch rules

A plan is {"recipe": name} or {"steps": [{"block": id, "agents": {agent: {"thinking": off|low|high,
"skills": [ids]}}, "if": <condition name or expression>}, ...]}. The first step always runs and must
produce answers (solve, debate or refine).

Block kinds:
  solve   each agent answers n times, independently (sees "none") or after reading the earlier work
          (sees "earlier"); tool k lets it run Python up to k times. Covers I/O, CoT,
          self-consistency, program-of-thought (tool 1 with a "write a program" instruction), ReAct.
  debate  `rounds` rounds; from round 2 every agent reads all agents' last outputs and revises; stops
          early once all agree.
  review  agents check the earlier work against the current answer, end with VERDICT PASS/FAIL and
          the answer they believe; tool lets them check by code.
  refine  evaluator-optimizer / Reflexion: the first agent drafts (or takes the latest output that
          gave the current answer), the second agent (or the first) critiques it with `critique`
          and a PASS/FAIL verdict; on FAIL the first agent revises; at most `iters` critiques.
  decide  agents pick the final answer from the earlier work.
  exit    stops the flow when its condition holds.
  Every block has `show`: how its outputs appear to later steps ("full" text or only the "answer").

Runtime signals (free; computed from the state before each later step):
  disagree    the answers so far are not unanimous, or one is missing
  missing     there is no current answer
  unsure      an output of the last step said 'Confidence: low' (blocks with confidence: true)
  fail        a check in the last step said FAIL (review: majority; refine: its last critique)
  tool_error  a Python run in the last step failed or timed out
  agree       share of the answers so far that equal the current answer (0..1)
  answers     number of answers so far
  tokens      most generated tokens of one call in the last step
  steps       number of steps run so far
"""
import copy
import json
import re

THINK = ("off", "low", "high", "xhigh", "max")
NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,30}$")
LIMITS = {"agents": 8, "skills": 30, "skills_per_agent": 5, "skill_chars": 500, "role_chars": 400,
          "policy_chars": 2000, "blocks": 12, "instruction_chars": 600, "conditions": 10,
          "condition_chars": 200, "recipes": 8, "steps": 5, "agents_per_step": 4, "calls": 30}

KINDS = {
    "solve": {"n": 1, "tool": 0, "sees": "none", "show": "full", "confidence": False},
    "debate": {"rounds": 2, "tool": 0, "sees": "none", "show": "full", "confidence": False},
    "review": {"tool": 0, "show": "full", "confidence": False},
    "refine": {"iters": 2, "tool": 0, "show": "full",
               "critique": "Check the draft for errors in reasoning, in arithmetic and in what "
                           "exactly the question asks."},
    "decide": {"show": "full"},
    "exit": {},
}
PRODUCING = ("solve", "debate", "refine")
RANGES = {"n": (1, 5), "tool": (0, 3), "rounds": (2, 3), "iters": (1, 3)}
CHOICES = {"sees": ("none", "earlier"), "show": ("full", "answer"), "confidence": (True, False)}

BOOL_SIGNALS = ("disagree", "missing", "unsure", "fail", "tool_error")
NUM_SIGNALS = ("agree", "answers", "tokens", "steps")
CMP = ("<", "<=", ">", ">=", "==", "!=")
TOKEN = re.compile(r"\s*(<=|>=|==|!=|<|>|\(|\)|[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)")


# ---------------------------------------------------------------- conditions

def parse_cond(expr: str, named: dict | None = None):
    """Parse a condition into a nested tuple (raises ValueError). `named` maps condition names to
    already-parsed conditions, which are inlined."""
    named = named or {}
    if not isinstance(expr, str) or not expr.strip():
        raise ValueError("empty condition")
    expr, toks, pos = expr.strip(), [], 0
    while pos < len(expr):
        m = TOKEN.match(expr, pos)
        if not m:
            raise ValueError(f"cannot parse {expr[pos:pos + 20]!r}")
        toks.append(m.group(1))
        pos = m.end()
    i = 0

    def peek():
        return toks[i] if i < len(toks) else None

    def take():
        nonlocal i
        if i >= len(toks):
            raise ValueError(f"unexpected end of {expr!r}")
        i += 1
        return toks[i - 1]

    def or_():
        n = and_()
        while peek() == "or":
            take()
            n = ("or", n, and_())
        return n

    def and_():
        n = not_()
        while peek() == "and":
            take()
            n = ("and", n, not_())
        return n

    def not_():
        if peek() == "not":
            take()
            return ("not", not_())
        return atom()

    def atom():
        t = take()
        if t == "(":
            n = or_()
            if take() != ")":
                raise ValueError(f"missing ')' in {expr!r}")
            return n
        if t in ("always", "never", "true", "false"):
            return ("const", t in ("always", "true"))
        if t in BOOL_SIGNALS:
            return ("sig", t)
        if t in NUM_SIGNALS or t == "agreement":       # agreement: v4's name for agree
            t = "agree" if t == "agreement" else t
            op, v = take(), take()
            if op not in CMP or not re.fullmatch(r"\d+(?:\.\d+)?", v):
                raise ValueError(f"{t} needs a comparison with a number, e.g. '{t} < 0.7'")
            return ("cmp", t, op, float(v))
        if t in named:
            return named[t]
        raise ValueError(f"unknown name {t!r} in {expr!r}")

    n = or_()
    if i != len(toks):
        raise ValueError(f"unexpected {toks[i]!r} in {expr!r}")
    return n


def eval_cond(n, sig: dict) -> bool:
    op = n[0]
    if op == "const":
        return n[1]
    if op == "sig":
        return bool(sig[n[1]])
    if op == "cmp":
        a, b = sig[n[1]], n[3]
        return {"<": a < b, "<=": a <= b, ">": a > b, ">=": a >= b, "==": a == b, "!=": a != b}[n[2]]
    if op == "not":
        return not eval_cond(n[1], sig)
    if op == "and":
        return eval_cond(n[1], sig) and eval_cond(n[2], sig)
    return eval_cond(n[1], sig) or eval_cond(n[2], sig)


def compile_conditions(pool: dict) -> tuple[dict, list[str]]:
    """Named conditions may use signals and conditions defined before them."""
    out, errs = {}, []
    for name, expr in pool.get("conditions", {}).items():
        if not NAME.match(name) or name in BOOL_SIGNALS + NUM_SIGNALS + ("always", "never", "and",
                                                                          "or", "not", "true",
                                                                          "false", "agreement"):
            errs.append(f"bad condition name {name!r}")
            continue
        if not isinstance(expr, str) or len(expr) > LIMITS["condition_chars"]:
            errs.append(f"condition {name!r} must be a string of at most "
                        f"{LIMITS['condition_chars']} chars")
            continue
        try:
            out[name] = parse_cond(expr, out)
        except ValueError as e:
            errs.append(f"condition {name!r}: {e}")
    return out, errs


# ---------------------------------------------------------------- blocks and plans

def block(pool: dict, bid: str) -> dict:
    """The block with its kind's defaults filled in."""
    b = pool["blocks"][bid]
    return {**KINDS[b["kind"]], **b}


def check_block(bid, b) -> list[str]:
    if not NAME.match(bid):
        return [f"bad block id {bid!r}"]
    if not isinstance(b, dict) or b.get("kind") not in KINDS:
        return [f"block {bid!r}: kind must be one of {', '.join(KINDS)}"]
    errs = []
    allowed = set(KINDS[b["kind"]]) | {"kind", "instruction"}
    for k, v in b.items():
        if k not in allowed:
            errs.append(f"block {bid!r}: unknown field {k!r} for kind {b['kind']} "
                        f"(allowed: {', '.join(sorted(allowed))})")
        elif k in RANGES and (not isinstance(v, int) or isinstance(v, bool)
                              or not RANGES[k][0] <= v <= RANGES[k][1]):
            errs.append(f"block {bid!r}: {k} must be an integer in {RANGES[k][0]}..{RANGES[k][1]}")
        elif k in CHOICES and v not in CHOICES[k]:
            errs.append(f"block {bid!r}: {k} must be one of {CHOICES[k]}")
        elif k in ("instruction", "critique") and (not isinstance(v, str)
                                                  or len(v) > LIMITS["instruction_chars"]):
            errs.append(f"block {bid!r}: {k} must be a string of at most "
                        f"{LIMITS['instruction_chars']} chars")
    if b["kind"] != "exit" and not str(b.get("instruction", "")).strip():
        errs.append(f"block {bid!r} needs an instruction")
    return errs


def step_calls(b: dict, n_agents: int) -> int:
    """Upper bound on model calls of one step."""
    t = 1 + b.get("tool", 0)
    return {"solve": n_agents * b.get("n", 1) * t, "debate": n_agents * b.get("rounds", 2) * t,
            "review": n_agents * t, "refine": t * (1 + b.get("iters", 2)) + b.get("iters", 2),
            "decide": n_agents, "exit": 0}[b["kind"]]


def _agents(pool, raw, probs):
    """Normalize a step's agents: accepts {agent: spec}, [agent, ...] or "agent"."""
    if isinstance(raw, str):
        raw = [raw]
    if isinstance(raw, list):
        raw = {a: {} for a in raw if isinstance(a, str)}
    if not isinstance(raw, dict):
        return {}
    out = {}
    for a, spec in raw.items():
        if a not in pool["agents"]:
            probs.append(f"{a!r} is not in the pool")
            continue
        if len(out) == LIMITS["agents_per_step"]:
            probs.append(f"more than {LIMITS['agents_per_step']} agents in a step")
            break
        spec = spec if isinstance(spec, dict) else {}
        th = spec.get("thinking", "off")
        sk = spec.get("skills") if isinstance(spec.get("skills"), list) else []
        out[a] = {"thinking": th if th in THINK else "off",
                  "skills": [x for x in sk if x in pool["agents"][a]["skills"]]}
    return out


def check_plan(pool: dict, p, conds: dict | None = None) -> tuple[dict | None, list[str]]:
    """Normalize a plan. Returns (plan, problems); plan is None when nothing usable remains."""
    if conds is None:
        conds = compile_conditions(pool)[0]
    if isinstance(p, dict) and "recipe" in p and "steps" not in p:
        name = p["recipe"]
        if name not in pool.get("recipes", {}):
            return None, [f"unknown recipe {name!r}"]
        plan, probs = check_plan(pool, pool["recipes"][name], conds)
        if plan is not None:
            plan["recipe"] = name
        return plan, probs
    if not isinstance(p, dict) or not isinstance(p.get("steps"), list):
        return None, ["plan needs 'recipe' or a 'steps' list"]
    probs, steps, calls = [], [], 0
    for raw in p["steps"]:
        if not isinstance(raw, dict) or raw.get("block") not in pool["blocks"]:
            probs.append(f"unknown block {raw.get('block') if isinstance(raw, dict) else raw!r}")
            continue
        b = block(pool, raw["block"])
        if not steps and b["kind"] not in PRODUCING:
            probs.append(f"first step must be a solve, debate or refine block, not "
                         f"{raw['block']!r} ({b['kind']})")
            continue
        ag = {} if b["kind"] == "exit" else _agents(pool, raw.get("agents"), probs)
        if b["kind"] != "exit" and not ag:
            probs.append(f"step {raw['block']!r} has no valid agent")
            continue
        cond = raw.get("if", "always")
        if not steps:
            cond = "always"
        else:
            try:
                parse_cond(str(cond), conds)
            except ValueError as e:
                probs.append(f"step {raw['block']!r}: {e}; using 'always'")
                cond = "always"
        if len(steps) == LIMITS["steps"]:
            probs.append(f"more than {LIMITS['steps']} steps")
            break
        c = step_calls(b, len(ag))
        if calls + c > LIMITS["calls"]:
            probs.append(f"more than {LIMITS['calls']} calls in the plan")
            break
        calls += c
        steps.append({"block": raw["block"], "agents": ag, "if": str(cond)})
    if not steps:
        return None, probs + ["no usable step"]
    return {"steps": steps}, probs


def fallback_plan(pool: dict) -> dict:
    fb = pool["orchestrator"].get("fallback")
    if fb in pool.get("recipes", {}):
        plan = check_plan(pool, {"recipe": fb})[0]
        if plan is not None:
            return plan
    bid = next(b for b in pool["blocks"] if pool["blocks"][b]["kind"] in PRODUCING)
    first = next(iter(pool["agents"]))
    return {"steps": [{"block": bid, "agents": {first: {"thinking": "low", "skills": []}},
                       "if": "always"}]}


def plan_str(p) -> str:
    return " > ".join(
        st["block"] + ("" if st["if"] == "always" else f" if {st['if']}") + "[" + ", ".join(
            f"{a}:{v['thinking']}" + (f"+{'/'.join(v['skills'])}" if v["skills"] else "")
            for a, v in st["agents"].items()) + "]" for st in p["steps"])


def shape(p) -> str:
    """e.g. 'cot*3>verify?' (*n = agents in the step, ? = conditional step)."""
    return ">".join(st["block"] + (f"*{len(st['agents'])}" if len(st["agents"]) > 1 else "")
                    + ("" if st["if"] == "always" else "?")
                    for st in p["steps"])


# ---------------------------------------------------------------- the pool

def validate(pool: dict) -> list[str]:
    keys = ("agents", "skills", "blocks", "conditions", "recipes", "orchestrator", "final", "policy")
    errs = [f"missing key {k!r}" for k in keys if k not in pool]
    if errs:
        return errs
    if not pool["agents"]:
        errs.append("the pool has no agents")
    for k in ("agents", "skills", "blocks", "conditions", "recipes"):
        if len(pool[k]) > LIMITS[k]:
            errs.append(f"too many {k}: {len(pool[k])} > {LIMITS[k]}")
    for sid, txt in pool["skills"].items():
        if not NAME.match(sid):
            errs.append(f"bad skill id {sid!r} (letters, digits, underscores)")
        if not isinstance(txt, str) or not txt.strip() or len(txt) > LIMITS["skill_chars"]:
            errs.append(f"skill {sid!r}: text must be 1..{LIMITS['skill_chars']} chars")
    for name, a in pool["agents"].items():
        if not NAME.match(name):
            errs.append(f"bad agent name {name!r}")
        if not isinstance(a, dict) or not str(a.get("role", "")).strip():
            errs.append(f"{name!r} needs a role")
            continue
        if len(a["role"]) > LIMITS["role_chars"]:
            errs.append(f"{name!r}: role longer than {LIMITS['role_chars']} chars")
        sk = a.get("skills", [])
        if len(sk) > LIMITS["skills_per_agent"]:
            errs.append(f"{name!r} holds {len(sk)} skills > {LIMITS['skills_per_agent']}")
        errs += [f"{name!r} holds unknown skill {s!r}" for s in sk if s not in pool["skills"]]
    for bid, b in pool["blocks"].items():
        errs += check_block(bid, b)
    if errs:
        return errs
    if not any(b["kind"] in PRODUCING for b in pool["blocks"].values()):
        errs.append("no solve, debate or refine block")
    conds, cerrs = compile_conditions(pool)
    errs += cerrs
    for name, plan in pool["recipes"].items():
        if not NAME.match(name):
            errs.append(f"bad recipe name {name!r}")
        _, probs = check_plan(pool, plan if isinstance(plan, dict) and "steps" in plan
                              else {"steps": None}, conds)
        errs += [f"recipe {name!r}: {x}" for x in probs]
    o = pool["orchestrator"]
    if not isinstance(o, dict) or o.get("mode") not in ("llm", "fixed"):
        errs.append("orchestrator.mode must be 'llm' or 'fixed'")
    else:
        if o["mode"] == "fixed" and o.get("recipe") not in pool["recipes"]:
            errs.append("fixed mode needs orchestrator.recipe naming an existing recipe")
        if o.get("fallback") is not None and o["fallback"] not in pool["recipes"]:
            errs.append(f"orchestrator.fallback {o['fallback']!r} is not a recipe")
        if o.get("thinking", "off") not in ("off", "low"):
            errs.append("orchestrator.thinking must be 'off' or 'low'")
    if pool["final"] not in ("last", "vote"):
        errs.append("final must be 'last' or 'vote'")
    if not isinstance(pool["policy"], str) or len(pool["policy"]) > LIMITS["policy_chars"]:
        errs.append(f"policy must be a string of at most {LIMITS['policy_chars']} chars")
    return errs


def apply_ops(pool: dict, ops) -> tuple[dict, list[str]]:
    """Apply designer edit operations; returns (new pool, errors incl. validation errors)."""
    o = copy.deepcopy(pool)
    errs = []
    if not isinstance(ops, list) or not ops:
        return o, ["ops must be a non-empty list"]
    for i, op in enumerate(ops):
        try:
            kind = op["op"]
            if kind == "add_agent":
                if op["name"] in o["agents"]:
                    raise ValueError(f"agent {op['name']!r} exists")
                o["agents"][op["name"]] = {"role": op["role"], "skills": list(op.get("skills", []))}
            elif kind == "remove_agent":
                del o["agents"][op["name"]]
            elif kind == "edit_role":
                o["agents"][op["name"]]["role"] = op["role"]
            elif kind == "set_skills":
                o["agents"][op["name"]]["skills"] = list(op["skills"])
            elif kind in ("add_skill", "edit_skill"):
                if (op["id"] in o["skills"]) != (kind == "edit_skill"):
                    raise ValueError(f"skill {op['id']!r} " + ("exists (use edit_skill)"
                                                               if kind == "add_skill"
                                                               else "does not exist"))
                o["skills"][op["id"]] = op["text"]
                for name in op.get("to", []):
                    if op["id"] not in o["agents"][name]["skills"]:
                        o["agents"][name]["skills"].append(op["id"])
            elif kind == "remove_skill":
                del o["skills"][op["id"]]
                for a in o["agents"].values():
                    a["skills"] = [s for s in a["skills"] if s != op["id"]]
            elif kind in ("add_block", "edit_block"):
                if (op["id"] in o["blocks"]) != (kind == "edit_block"):
                    raise ValueError(f"block {op['id']!r} " + ("exists (use edit_block)"
                                                               if kind == "add_block"
                                                               else "does not exist"))
                if not isinstance(op["block"], dict):
                    raise TypeError("block must be an object")
                o["blocks"][op["id"]] = dict(op["block"])
            elif kind == "remove_block":
                del o["blocks"][op["id"]]
            elif kind == "set_condition":
                o["conditions"][op["name"]] = op["expr"]
            elif kind == "remove_condition":
                del o["conditions"][op["name"]]
            elif kind == "set_recipe":
                o["recipes"][op["name"]] = op["plan"]
            elif kind == "remove_recipe":
                del o["recipes"][op["name"]]
            elif kind == "set_orchestrator":
                o["orchestrator"].update({k: op[k] for k in ("mode", "recipe", "fallback", "thinking")
                                          if k in op})
            elif kind == "set_final":
                o["final"] = op["rule"]
            elif kind == "set_policy":
                o["policy"] = op["text"]
            else:
                raise ValueError(f"unknown op {kind!r}")
        except (KeyError, TypeError, ValueError) as e:
            errs.append(f"op {i} ({json.dumps(op)[:120]}): {type(e).__name__} {e}")
    for what in ("agents", "blocks", "recipes"):
        for name in set(pool[what]) - set(o[what]):
            if re.search(rf"\b{re.escape(name)}\b", o["policy"]):
                errs.append(f"policy still mentions removed {what[:-1]} {name!r}")
    return o, errs + validate(o)


def orchestrator_prompt(pool: dict) -> str:
    final = ("the current answer after the last step that ran" if pool["final"] == "last"
             else "the majority of all answers produced")
    L = ["You are the orchestrator of a pool of agents that solve math problems. For each problem, "
         "before anyone works on it, you choose its workflow: a named recipe, or your own steps "
         "(which building block, who fills it, how much each one thinks, which of their skills to "
         "switch on, and when each later step runs). Spend as little as possible while keeping "
         "accuracy.", "", "## Building blocks"]
    for bid, b in pool["blocks"].items():
        b = {**KINDS[b["kind"]], **b}
        extra = [f"{k}={b[k]}" for k in ("n", "rounds", "iters", "tool")
                 if k in b and b[k] != KINDS[b["kind"]][k]]
        L.append(f"- {bid} ({b['kind']}{', ' + ', '.join(extra) if extra else ''}): "
                 f"{b.get('instruction', 'stop here')[:160]}")
    L += ["Kinds: solve = each agent answers (n times); debate = agents revise after reading each "
          "other; review = agents check the earlier work and give PASS/FAIL; refine = the first "
          "agent drafts, the second (or the same) critiques, the first revises; decide = agents pick "
          "the final answer; exit = stop. tool = the agent may run Python.", "",
          "## Run conditions",
          "The first step always runs. A later step runs only if its \"if\" holds: \"always\", a "
          "named condition, or an expression over the signals disagree (answers so far differ or "
          "one is missing), missing, unsure, fail (a check said FAIL), tool_error, agree (share of "
          "answers equal to the current one, 0-1), answers, tokens, steps; with and/or/not."]
    L += [f"- {k}: {v}" for k, v in pool["conditions"].items()]
    if pool["recipes"]:
        L += ["", "## Recipes"] + [f"- {k}: {plan_str(check_plan(pool, v)[0])}"
                                   for k, v in pool["recipes"].items()]
    L += ["", "## Agents (thinking off ~200 generated tokens per call; low up to ~1000 extra; high "
              "up to ~4000 extra)"]
    for name, a in pool["agents"].items():
        L.append(f"- {name}: {a['role'][:200]} [skills: {', '.join(a['skills']) or 'none'}]")
    used = {x for a in pool["agents"].values() for x in a["skills"]}
    if used:
        L += ["", "## Skills (switch on only what the problem needs)"]
        L += [f"- {x}: {pool['skills'][x][:120]}" for x in pool["skills"] if x in used]
    L += ["", "## Output: exactly one JSON object, nothing else"]
    if pool["recipes"]:
        L.append('{"recipe": "<name>"}   or')
    L += ['{"steps": [{"block": "<id>", "agents": {"<agent>": {"thinking": "off|low|high", '
          '"skills": ["<id>"]}}, "if": "always"}, {"block": "<id>", "agents": {...}, '
          '"if": "<condition>"}]}',
          f"1-{LIMITS['steps']} steps, at most {LIMITS['agents_per_step']} agents per step. The "
          f"final answer is {final}.", "", "## Dispatch policy", pool["policy"]]
    return "\n".join(L)


# ---------------------------------------------------------------- the hand-written start

_V0_ROLES = {
    "solver_A": "You are a math solver. Solve the problem directly and concisely.",
    "solver_B": "You are a careful math solver. Solve the problem step by step, then double-check "
                "each arithmetic step before giving the answer.",
    "solver_C": "You are a math solver who prefers algebra. Define variables, write equations for "
                "the problem, and solve them.",
}
HAND = {
    "agents": {
        **{k: {"role": v, "skills": []} for k, v in _V0_ROLES.items()},
        "coder": {"role": "You are a math solver who computes and checks with short, correct Python "
                          "programs and reasons carefully about their output.",
                  "skills": ["verify_by_substitution"]},
        "critic": {"role": "You are a reviewer. Check the given solutions for errors in reasoning or "
                           "arithmetic and give the answer you believe is correct.",
                   "skills": ["reread_question"]},
        "judge": {"role": "You are the final decider. Read all solutions and reviews and decide the "
                          "single correct final answer. Briefly justify the choice.", "skills": []},
    },
    "skills": {
        "reread_question": "Before answering, re-read the question and make sure your final number "
                           "answers exactly what is asked (units, total vs. part, requested form).",
        "verify_by_substitution": "After finding the answer, plug it back into the conditions of the "
                                  "problem and confirm every condition holds.",
    },
    "blocks": {
        "io": {"kind": "solve", "instruction": "Give the answer directly with minimal working."},
        "cot": {"kind": "solve", "instruction": "Solve the problem step by step."},
        "sc3": {"kind": "solve", "n": 3, "instruction": "Solve the problem step by step."},
        "pot": {"kind": "solve", "tool": 1,
                "instruction": "Write one Python program that computes the answer and prints it."},
        "react": {"kind": "solve", "tool": 3,
                  "instruction": "Reason step by step. Run Python whenever a computation or a case "
                                 "check is error-prone, and use its output."},
        "debate": {"kind": "debate", "rounds": 2, "instruction": "Solve the problem step by step."},
        "review": {"kind": "review", "instruction": "Check the earlier solutions for errors in "
                                                    "reasoning, arithmetic and in what the question "
                                                    "asks."},
        "verify": {"kind": "review", "tool": 1,
                   "instruction": "Write a Python check of the current answer against every "
                                  "condition of the problem (substitute it, brute-force small "
                                  "cases, or recompute independently), run it, and judge from its "
                                  "output."},
        "refine": {"kind": "refine", "iters": 2, "instruction": "Solve the problem step by step."},
        "decide": {"kind": "decide", "instruction": "Decide the single correct final answer from the "
                                                    "earlier work."},
        "stop": {"kind": "exit"},
    },
    "conditions": {"shaky": "disagree or fail"},
    "recipes": {
        "fast": {"steps": [{"block": "cot", "agents": {"solver_A": {"thinking": "off"}}}]},
        "checked": {"steps": [
            {"block": "cot", "agents": {"solver_B": {"thinking": "low"}}},
            {"block": "verify", "agents": {"coder": {"thinking": "low"}}, "if": "always"},
            {"block": "decide", "agents": {"judge": {"thinking": "low"}}, "if": "shaky"}]},
        "team": {"steps": [
            {"block": "cot", "agents": {a: {"thinking": "low"} for a in _V0_ROLES}},
            {"block": "review", "agents": {"critic": {"thinking": "low"}}, "if": "disagree"},
            {"block": "decide", "agents": {"judge": {"thinking": "off"}}, "if": "disagree"}]},
    },
    "orchestrator": {"mode": "llm", "recipe": None, "fallback": "checked", "thinking": "off"},
    "final": "last",
    "policy": "Use fast for routine one- or two-step problems, checked for standard problems, and "
              "team for hard ones (extrema, counting with restrictions, geometry with diagrams, many "
              "conditions).",
}

# fixed single-architecture baselines on HAND (orchestrator mode fixed, no orchestrator call)
BASELINES = {
    "single_off": {"steps": [{"block": "cot", "agents": {"solver_B": {"thinking": "off"}}}]},
    "single_low": {"steps": [{"block": "cot", "agents": {"solver_B": {"thinking": "low"}}}]},
    "single_high": {"steps": [{"block": "cot", "agents": {"solver_B": {"thinking": "high"}}}]},
    "sc3_low": {"steps": [{"block": "sc3", "agents": {"solver_B": {"thinking": "low"}}}]},
    "pot_low": {"steps": [{"block": "pot", "agents": {"coder": {"thinking": "low"}}}]},
}
