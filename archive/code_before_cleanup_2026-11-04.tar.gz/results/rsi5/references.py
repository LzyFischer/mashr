"""Reference systems for the v5 report, all on the test set:

  full team (per organization): the HR designs ONE architecture, without seeing any problem, that uses
      every employee at least once; it is then used for every problem (no per-question staffing).
  CoT-SC (Wang et al., 2023): one generic chain-of-thought agent sampled 5 times, majority vote.
  LLM-Debate (Du et al., 2023): 3 generic agents, 2 rounds; in round 2 each agent reads the others'
      round-1 answers and updates its own; majority vote of round 2.
The literature baselines use their own generic agents and prompts (no Python, no employees).

  PYTHONPATH=. $P results/rsi5/references.py results/rsi5/references [--think high]
"""
import argparse
import json
import os
import re
from concurrent.futures import ThreadPoolExecutor

from mashr.engine import ANSWER_FMT, cost, majority
from mashr.exec5 import Engine
from mashr.llm import LLM
from mashr.mas import MODEL, extract
from mashr.org5 import hr_prompt, parse_program, program_str, shape
from mashr.orgrsi import load_items
from mashr.rsi5 import evaluate, summarize

FULL_TASK = ("Design ONE architecture that will be used, unchanged, for every problem of this benchmark "
             "(competition math, MATH Level 4-5; you will not see the individual problems). Every "
             "employee listed above must appear in it at least once. Accuracy is what matters.\n\n"
             "Your architecture:")
COT = "Let's think step by step."
DEBATE_UPDATE = ("These are the solutions to the problem from other agents: {others}\n\nUsing the "
                 "reasoning from other agents as additional advice, can you give an updated answer? "
                 "Examine your solution and that of other agents step by step.")


FIXED_TASK = ("Design ONE architecture that will be used, unchanged, for every problem of this benchmark "
              "(competition math, MATH Level 4-5; you will not see the individual problems). Accuracy "
              "is what matters.\n\nYour architecture:")


def design_full_team(llm, pool, hr_thinking, tries=4, require_all=True):
    """The HR's one-off architecture (all employees unless require_all is False); returns
    (plan, raw text, attempts)."""
    msgs = [{"role": "system", "content": hr_prompt(pool)},
            {"role": "user", "content": FULL_TASK if require_all else FIXED_TASK}]
    for k in range(tries):
        r = llm.chat(MODEL, msgs, thinking=hr_thinking, max_tokens=900, seed=100 + k)
        plan, probs = parse_program(pool, r.text)
        missing = sorted(set(pool["agents"]) - {n["agent"] for n in plan["nodes"]}) \
            if plan and require_all else []
        if plan is not None and not missing and not [p for p in probs if not p.startswith("minor")]:
            return plan, r.text, k + 1
        err = probs + ([f"missing employees: {missing}"] if missing else [])
        msgs += [{"role": "assistant", "content": r.text},
                 {"role": "user", "content": "Not usable: " + "; ".join(err) + ". Write it again: "
                                             "only the code" + (", every employee at least once."
                                                                if require_all else ".")}]
    raise SystemExit(f"no valid full-team architecture after {tries} tries: {err}")


def call(llm, msgs, think, seed):
    r = llm.chat(MODEL, msgs, thinking=think, max_tokens=2048, seed=seed)
    return r.text, {"prompt_tokens": r.prompt_tokens, "gen_tokens": r.gen_tokens}


def cot_sc(llm, it, think, k=5):
    user = f"{it['question']}\n\n{COT} {ANSWER_FMT}"
    outs = [call(llm, [{"role": "user", "content": user}], think, seed=s) for s in range(k)]
    ans = majority([extract(t) for t, _ in outs])
    return ans, [c for _, c in outs]


def debate(llm, it, think, agents=3, rounds=2):
    q = f"{it['question']}\n\n{COT} {ANSWER_FMT}"
    hist = [[{"role": "user", "content": q}] for _ in range(agents)]
    calls, last = [], []
    for r in range(rounds):
        if r > 0:
            for i in range(agents):
                others = "\n\n".join(f"One agent solution: ```{last[j]}```" for j in range(agents)
                                     if j != i)
                hist[i] += [{"role": "assistant", "content": last[i]},
                            {"role": "user", "content": DEBATE_UPDATE.format(others=others)
                             + f" {ANSWER_FMT}"}]
        with ThreadPoolExecutor(agents) as ex:
            res = list(ex.map(lambda i: call(llm, hist[i], think, seed=i), range(agents)))
        last = [t for t, _ in res]
        calls += [c for _, c in res]
    return majority([extract(t) for t in last]), calls


def run_lit(llm, items, fn, think):
    def one(it):
        ans, calls = fn(llm, it, think)
        return {**it, "correct": ans == it["gold"], "cost": cost(calls)}
    with ThreadPoolExecutor(64) as ex:
        rows = list(ex.map(one, items))
    hard = [r for r in rows if r["hard"]]
    return {"n": len(rows), "acc": round(sum(r["correct"] for r in rows) / len(rows), 4),
            "acc_hard": round(sum(r["correct"] for r in hard) / len(hard), 4),
            "cost": round(sum(r["cost"] for r in rows) / len(rows), 1)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--think", default="high")
    ap.add_argument("--hr-thinking", default="low")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    llm = LLM()
    eng = Engine(llm, hr_thinking=a.hr_thinking)
    test = load_items("math", "test", 0, 156)
    res = {}
    for name, path in (("full_team_round0", "results/rsi5/math_acc/round_0/pool.json"),
                       ("full_team_final", "results/rsi5/math_acc/final_pool.json")):
        pool = json.load(open(path))
        plan, raw, tries = design_full_team(llm, pool, a.hr_thinking)
        print(f"{name}: {program_str(plan)}  (HR attempts {tries})", flush=True)
        json.dump({"plan": plan, "program": program_str(plan), "shape": shape(plan), "raw": raw,
                   "attempts": tries}, open(os.path.join(a.out, f"{name}_design.json"), "w"), indent=1)
        res[name] = summarize(evaluate(eng, pool, test, plan))
        print(name, res[name], flush=True)
    for name, fn in ((f"cot_sc5_{a.think}", cot_sc), (f"llm_debate_3x2_{a.think}", debate)):
        res[name] = run_lit(llm, test, fn, a.think)
        print(name, res[name], flush=True)
    json.dump(res, open(os.path.join(a.out, "test.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
