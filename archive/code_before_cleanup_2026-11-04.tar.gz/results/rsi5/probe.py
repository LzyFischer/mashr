"""HR-only probe for v5: how often the architecture code is usable, and what the HR writes."""
import json, sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from mashr.exec5 import Engine
from mashr.llm import LLM
from mashr.org5 import HAND, shape
from mashr.orgrsi import load_items

pool = json.load(open(sys.argv[1])) if len(sys.argv) > 1 else HAND
eng = Engine(LLM())
items = load_items("math", "train", 0, 350)
res = list(ThreadPoolExecutor(64).map(lambda it: eng.orchestrate(pool, it["question"]), items))
n = len(res)
clean = sum(not x["problems"] and not x["retried"] for _, _, x in res)
hr = sum(c["gen_tokens"] + 0.2 * c["prompt_tokens"] for _, cs, _ in res for c in cs) / n
print(f"n {n}: clean {clean / n:.0%}, problems but usable {sum(bool(x['problems']) and not x['retried'] for _, _, x in res)}, "
      f"written again {sum(x['retried'] for _, _, x in res)}, fallback {sum(x['fallback'] for _, _, x in res)}; HR cost {hr:.0f}/question")
print("problems:", Counter(p for _, _, x in res for p in x["problems"]).most_common(6))
print("architectures:", Counter(shape(p) for p, _, _ in res).most_common(12))
hard = {it["id"]: it["hard"] for it in items}
for lv in (False, True):
    ps = [p for (p, _, _), it in zip(res, items) if it["hard"] == lv]
    print("L5" if lv else "L4", "nodes/q", round(sum(len(p["nodes"]) for p in ps) / len(ps), 2),
          "thinking:", Counter(nd["thinking"] for p in ps for nd in p["nodes"]).most_common())
