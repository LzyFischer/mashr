#!/bin/bash
# v4 full run on MATH L4-5 integer answers: 27B founds the organization, 5 rounds of RSI, test + baselines
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
~/miniconda3/envs/tinker/bin/python -m mashr.rsi4 --dataset math --init design --rounds 5 --k 3 \
  --n-dev-a 150 --n-dev-b 200 --n-test 156 --loo-n 60 --out results/rsi4/math_design \
  > results/rsi4/math_design.out 2>&1
