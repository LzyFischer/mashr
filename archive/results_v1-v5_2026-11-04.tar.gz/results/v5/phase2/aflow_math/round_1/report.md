# Diagnostic report (dev-A)

Organization: acc 98.0%, cost 19349/question, of which the HR 1893 (HR prompt 4865 chars). 19 distinct architectures, 2.4 nodes per question. HR outputs: repaired 0, written again 1, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Counting & Probability L5 | 40 | 98% | - | 22724 | 0 | coder.high>verifier.high 11, coder.low>verifier.low 9, reader.high>coder.high>verifier.max 6 |
| Number Theory L5 | 42 | 98% | - | 17846 | 0 | coder.high>verifier.high 15, coder.low>verifier.low 14, coder.high>verifier.max 7 |
| Prealgebra L5 | 44 | 98% | - | 15017 | 0 | coder.low>verifier.low 22, coder.high>verifier.high 8, reader.high>coder.high>verifier.max 8 |
| Precalculus L5 | 24 | 100% | - | 24296 | 0 | coder.high>verifier.high 7, coder.high>verifier.max 5, reader.high>coder.high>verifier.max 3 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.low>verifier.low | 46 | 96% | 9868 |
| coder.high>verifier.high | 41 | 100% | 17112 |
| reader.high>coder.high>verifier.max | 17 | 100% | 27869 |
| coder.high>verifier.max | 14 | 100% | 20386 |
| coder.max>verifier.max | 6 | 83% | 33184 |
| reader.high>coder.high,solver.high>verifier.max | 4 | 100% | 36184 |
| reader.high>coder.max>verifier.max | 4 | 100% | 25450 |
| coder.high>solver.high>verifier.max | 4 | 100% | 30465 |
| reader.low>coder.high>verifier.high | 3 | 100% | 22673 |
| reader.high>coder.high>solver.high>verifier.max | 2 | 100% | 37116 |
| reader.high>coder.low>verifier.low | 1 | 100% | 32366 |
| reader.low>coder.max>verifier.max | 1 | 100% | 26681 |
| reader.low>coder.low>verifier.low | 1 | 100% | 14438 |
| coder.low>verifier.high | 1 | 100% | 12074 |
| reader.high>coder.high,coder.high>verifier.max | 1 | 100% | 41466 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| coder.high | 59 | 88% | 98% | 8471 | - | - | - |
| verifier.max (with inputs) | 56 | 98% | 5% | 10069 | 15 | 14 | 1 |
| verifier.low (with inputs) | 48 | 96% | 100% | 4104 | 7 | 6 | 3 |
| coder.low | 47 | 91% | 98% | 4188 | - | - | - |
| verifier.high (with inputs) | 46 | 100% | 93% | 6950 | 4 | 4 | 1 |
| reader.high | 31 | 65% | 97% | 8099 | - | - | - |
| coder.high (with inputs) | 30 | 87% | 80% | 8335 | 10 | 7 | 2 |
| solver.high (with inputs) | 13 | 62% | 100% | 7997 | 7 | 2 | 1 |
| coder.max (with inputs) | 7 | 100% | 0% | 10978 | 1 | 1 | - |
| reader.low | 6 | 100% | 100% | 5375 | - | - | - |
| coder.max | 6 | 83% | 50% | 16345 | - | - | - |
| coder.low (with inputs) | 2 | 50% | 100% | 4594 | 1 | - | - |
| reader.max | 1 | 100% | 100% | 19858 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| coder.high (input) | 35 | 3 | 0 | 32 | 5623 |
| verifier.max (output) | 25 | 3 | 0 | 22 | 9427 |
| coder.low (input) | 19 | 5 | 0 | 14 | 4347 |
| verifier.low (output) | 19 | 1 | 0 | 18 | 4676 |
| reader.high (input) | 16 | 2 | 0 | 14 | 3934 |
| verifier.high (output) | 16 | 2 | 0 | 14 | 6498 |
| coder.max (input) | 6 | 0 | 0 | 6 | 9308 |
| solver.high (input) | 4 | 0 | 0 | 4 | 5227 |
| reader.low (input) | 3 | 0 | 0 | 3 | -1308 |

HR output problems: minor: line 1: non-node argument ignored (1)

## Organization wrong (3)
- [Number Theory L5] For how many positive integers $n$ does $\frac{1}{n}$ yield a terminating decimal with a non-zero hundredths digit?
  architecture: c = coder("low"); v = verifier("low", c); return v; answered - $n, correct 11
- [Prealgebra L5] An equilateral triangle has sides of length 2 units. A second equilateral triangle is formed having sides that are $150\%$ of the length of the sides of the first triangle. A third equilateral triangle is formed having sides that are $150\%$ of the length of the sides of the seco
  architecture: c = coder("low"); v = verifier("low", c); return v; answered 237.5, correct 237.5\%
- [Counting & Probability L5] In an office at various times during the day, the boss gives the secretary a letter to type, each time putting the letter on top of the pile in the secretary's in-box. When there is time, the secretary takes the top letter off the pile and types it. There are nine letters to be t
  architecture: c = coder("max"); out = verifier("max", c); return out; answered 256, correct 704

## Most expensive correct questions (possible waste)
- [Counting & Probability L5, cost 53120] Point $P$ is selected at random from the interior of the pentagon with vertices $A=(0,2)$, $B= (4,0)$, $C = (2\pi +1, 0)$, $D=(2\pi
+1,4)$, and $E=(0,4)$. What is the probability t
  architecture: r = reader("max"); c = coder("max", r); s = solver("high", r, c); v = verifier("max", r, c, s); return v
- [Number Theory L5, cost 49758] What is the largest positive integer that is not the sum of a positive integral multiple of $42$ and a positive composite integer?
  architecture: r = reader("high"); c = coder("max", r); s = solver("high", r, c); v = verifier("max", r, c, s); return v
- [Counting & Probability L5, cost 44437] A standard six-sided fair die is rolled four times. The probability that the product of all four numbers rolled is a perfect square is $\tfrac{m}{n}$, where $m$ and $n$ are relativ
  architecture: r = reader("high"); c = coder("high", r); s = solver("high", r); v = verifier("max", r, c, s); return v
- [Prealgebra L5, cost 41827] A square and a regular heptagon  are coplanar and share a common side $\overline{AD}$, as shown. What is the degree measure of exterior angle $BAC$?  Express your answer as a commo
  architecture: r = reader("high"); c = coder("high", r); s = solver("high", r); v = verifier("max", r, c, s); return v
- [Precalculus L5, cost 41466] Let
\[\mathbf{M} = \begin{pmatrix} a & b & c \\ b & c & a \\ c & a & b \end{pmatrix}\]be a matrix with complex entries such that $\mathbf{M}^2 = \mathbf{I}.$  If $abc = 1,$ then fi
  architecture: r = reader("high"); c1 = coder("high", r); c2 = coder("high", r); v = verifier("max", r, c1, c2); return v