# Diagnostic report (dev-A)

Organization: acc 86.7%, cost 12604/question (11606 generated, 4986 prompt tokens; cost = generated + 0.2 x prompt, including the orchestrator's). Full system: acc 91.3%, cost 17252. Orchestrator (HR): 2328/question of that cost (18%), prompt 6474 chars, thinking low; 34 distinct architectures. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 8307 | 13285 | solver 6, solver>checker>judge 4, solver>checker? 2 |
| Algebra L5 | 18 | 94% | 100% | 7761 | 15585 | solver 4, solver>checker>judge 2, solver>judge? 2 |
| Counting & Probability L4 | 8 | 88% | 100% | 8580 | 15676 | solver>checker?L1>judge? 2, solver>checker 1, solver>judge 1 |
| Counting & Probability L5 | 9 | 78% | 89% | 16406 | 19103 | solver+coder>checkerL1>judge? 2, solver 2, solver>checker>judge 2 |
| Geometry L4 | 5 | 100% | 100% | 11465 | 15889 | solver 3, solver+coder>checkerL1>judge? 1, solver+coder>checker?>judge? 1 |
| Geometry L5 | 7 | 57% | 57% | 27729 | 22647 | solver 1, solver+coder&checker+checker&judge>judge? 1, solver+coder>checker?L1>judge? 1 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 12261 | 18210 | solver>checker>judge 2, solver>checkerL1>judge 2, solver 2 |
| Intermediate Algebra L5 | 17 | 71% | 71% | 21203 | 21465 | solver+coder>checker?L1>judge? 4, solver+coder>checkerL1>judge? 3, solver+coder>checker>judge 2 |
| Number Theory L4 | 9 | 100% | 100% | 8557 | 17149 | solver 2, solver>checker?L1>judge? 1, solver>checkerL1>judge 1 |
| Number Theory L5 | 16 | 75% | 88% | 11510 | 18165 | solver>checker? 3, solver>checker>judge 3, solver+coder>checker?L1>judge? 2 |
| Prealgebra L4 | 12 | 100% | 100% | 4604 | 10794 | solver 6, solver>checker? 2, solver>checker?L1>judge? 1 |
| Prealgebra L5 | 9 | 78% | 89% | 10530 | 17096 | solver 4, solver+coder>checker?L1>judge? 1, solver>checker?>judge? 1 |
| Precalculus L4 | 3 | 100% | 100% | 14074 | 20027 | solver>judge 1, solver&checker&judge 1, solver>checker>judge 1 |
| Precalculus L5 | 6 | 67% | 83% | 26063 | 22960 | solver+coder>checker?L1>judge 2, solver>checker+checker?>judge? 1, solver+coder>checkerL1>judge? 1 |

## First stages (staffing): accuracy of their answer
| first stage | uses | answer correct | mean cost |
|---|---|---|---|
| solver:low+cot/reread/confidence/substitution | 45 | 91% | 3832 |
| solver:low+cot/reread/confidence | 15 | 87% | 3947 |
| solver:low+cot/reread/confidence/substitution/case_analysis | 14 | 86% | 4007 |
| solver:low+cot/reread/confidence/case_analysis | 6 | 83% | 4626 |
| solver:low+cot/reread/confidence/substitution + coder:low+react/reread/confidence/substitution | 4 | 25% | 10384 |
| solver:low+cot/reread/confidence/substitution/case_analysis + coder:high+react/reread/confidence/case_analysis/substitution | 4 | 50% | 14186 |
| solver:high+cot/reread/confidence/substitution + coder:high+react/reread/confidence/substitution | 4 | 75% | 14380 |
| solver:off+cot/reread/confidence/substitution | 4 | 100% | 853 |
| solver:low+cot/confidence/substitution | 4 | 75% | 3990 |
| solver:low+cot/reread/substitution/case_analysis | 3 | 100% | 3931 |
| solver:low+cot/reread/confidence + coder:high+react/reread/confidence | 2 | 0% | 13432 |
| solver:low+cot/reread/confidence/substitution/case_analysis + coder:low+react/reread/confidence/substitution | 2 | 100% | 8704 |
| solver:low+cot/reread/substitution | 2 | 100% | 3982 |
| solver:low+cot/reread/confidence/substitution + coder:high+react/reread/confidence/substitution | 2 | 50% | 12613 |
| solver:low+cot/confidence | 2 | 50% | 4517 |

## Later stages (function and condition): how often they ran and changed the answer
| stage | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| decide if always | 46 | 45 | 2 | 1 | 0 | 3475 |
| decide if shaky | 44 | 15 | 3 | 0 | 1 | 5353 |
| check if always | 42 | 42 | 7 | 6 | 1 | 3120 |
| check if shaky | 25 | 5 | 4 | 3 | 1 | 4967 |
| check if always (loop 1) | 19 | 19 | 4 | 4 | 0 | 6128 |
| check if shaky (loop 1) | 18 | 7 | 5 | 2 | 0 | 6972 |
| produce if shaky | 1 | 0 | 0 | 0 | 0 | 0 |
| produce if always | 1 | 1 | 0 | 0 | 0 | 3000 |

## Signals after the first stage (150 questions, 33 with a wrong answer at that point)
fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 22 | 82% | 55% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 0 | 0% | 0% |
| agreement < 1 | 22 | 82% | 55% |
| agreement < 0.67 | 22 | 82% | 55% |
| tokens > 1000 | 146 | 23% | 100% |
| tokens > 2000 | 141 | 23% | 100% |
| tokens > 4000 | 88 | 38% | 100% |
| [shaky] disagree or fail or unsure or tool_error | 22 | 82% | 55% |

## Leave-one-out replay on 60 questions with 2+ nodes that ran
Remove the employee from that stage (agent@function<stage>) or the whole stage, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| stage 2 check | 38 | 2 | 0 | 36 | 3524 |
| solver@produce1 | 27 | 6 | 1 | 20 | 10067 |
| coder@produce1 | 27 | 3 | 0 | 24 | 11016 |
| stage 3 decide | 27 | 1 | 0 | 26 | 3609 |
| stage 2 check if shaky | 9 | 1 | 0 | 8 | 7531 |
| stage 3 decide if shaky | 8 | 0 | 0 | 8 | 5271 |
| stage 2 decide | 7 | 0 | 0 | 7 | 2589 |
| checker@check2 | 2 | 0 | 0 | 2 | 2430 |
| stage 2 produce | 1 | 0 | 0 | 1 | 3000 |
| stage 4 decide if shaky | 1 | 0 | 0 | 1 | 4984 |

## Orchestrator usage
Architectures: solver 32, solver>checker>judge 18, solver>checker? 11, solver>checker 9, solver+coder>checkerL1>judge? 8, solver+coder>checker?L1>judge? 8, solver>judge 8, solver>checker?>judge? 7
Employees: solver 151, checker 106, judge 90, coder 41; never staffed: none
Thinking: low 334, high 48, off 6
Skills switched on: reread 363, substitution 245, cot 238, confidence 174, alternative 140, python_check 106, case_analysis 98, react 41, diagram 9; never: none
Conditions: always 258, shaky 88
Copies > 1: 0; debate rounds > 1: 0; check loops: 37
Orchestrator outputs: minor fixes 24 (skills an employee does not hold, quoted conditions, missing commas), structural repairs 0, asked again 8 (valid on the 2nd try: 7), fixed fallback 1 (acc 0%).
Most common problems: minor: JSON syntax repaired (15); minor: a stage mixed functions; its parts run in order (9); bad JSON: Expecting ',' delimiter: line 1 column 231 (char 230) (1)

## Organization wrong, full system right (9)
- [Counting & Probability L5] The number of increasing sequences of positive integers $a_1 \le a_2 \le a_3 \le \cdots \le a_{10} \le 2007$ such that $a_i-i$ is even for $1\le i \le 10$ can be expressed as ${m \choose n}$ for some positive integers $m > n$. Compute the remainder when $m$ is divided by 1000.
  plan: produce[solver:low+cot/reread/confidence] > decide if shaky[judge:low+reread/cot/alternative]; answered 1, correct 8
- [Prealgebra L5] Triangle $ABC$ is a right triangle. If the measure of angle $PAB$ is $x^\circ$ and the measure of angle $ACB$ is expressed in the form $(Mx+N)^\circ$ with $M=1$, what is the value of $M+N$?

[asy]
draw((-10,0)--(20,0),linewidth(1),Arrows);
draw((0,0)--(10,10/sqrt(3))--(10+10/3,0)
  plan: produce[solver:low+cot/reread/confidence/substitution]; answered 1, correct -89
- [Counting & Probability L4] Define a $\it{good\ word}$ as a sequence of letters that consists only of the letters $A$, $B$, and $C$ --- some of these letters may not appear in the sequence --- and in which $A$ is never immediately followed by $B$, $B$ is never immediately followed by $C$, and $C$ is never i
  plan: produce[solver:low+cot/reread/confidence/case_analysis] > check if shaky (loop 1)[checker:low+python_check/reread/substitution] > decide if shaky[judge:low+reread/cot/alternative]; answered 3, correct 192
- [Prealgebra L5] In the diagram, $AB,$ $BC,$ $CD,$ $DE,$ $EF,$ $FG,$ $GH,$ and $HK$ all have length $4,$ and all angles are right angles, with the exception of the angles at $D$ and $F.$

[asy]
draw((0,0)--(0,4)--(4,4)--(4,8)--(6.8284,5.1716)--(9.6569,8)--(9.6569,4)--(13.6569,4)--(13.6569,0)--cyc
  plan: produce[solver:low+cot/confidence/substitution]; answered 90, correct 8
- [Number Theory L5] Suppose that $ABC_4+200_{10}=ABC_9$, where $A$, $B$, and $C$ are valid digits in base 4 and 9. What is the sum when you add all possible values of $A$, all possible values of $B$, and all possible values of $C$?
  plan: produce[solver:low+cot/reread/confidence/substitution/case_analysis] > check if shaky[checker:low+python_check/reread/substitution/case_analysis/alternative]; answered 40, correct 10
- [Number Theory L5] What is the ones digit of $1^{2009} + 2^{2009} + 3^{2009} + \cdots + 2009^{2009}?$
  plan: produce[solver:low+cot/reread/confidence/substitution/case_analysis] > check if shaky[checker:low+python_check/reread/substitution] > decide if shaky[judge:low+reread/cot/alternative]; answered 0, correct 5
- [Algebra L5] How many zeros are in the expansion of $999,\!999,\!999,\!998^2$?
  plan: produce[solver:low+cot/reread/confidence/substitution] > check if shaky[checker:off+python_check/reread/substitution]; answered 12, correct 11
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: produce[solver:high+cot/reread/confidence/substitution/diagram, coder:high+react/reread/confidence/case_analysis/substitution] > check[checker:low+python_check/reread/substitution/case_analysis/alternative] > decide[judge:low+reread/cot/alternative]; answered 2, correct 85
- [Precalculus L5] Find the number of ordered quadruples $(a,b,c,d)$ of real numbers such that
\[\begin{pmatrix} a & b \\ c & d \end{pmatrix}^2 = \begin{pmatrix} c & a \\ d & b \end{pmatrix}.\]
  plan: produce[solver:low+cot/reread/confidence/substitution, coder:low+react/reread/confidence/substitution] > check if shaky[checker:low+python_check/reread/substitution/case_analysis/alternative] > decide if shaky[judge:low+reread/cot/alternative]; answered 2, correct 4

Both wrong: 11.

## Most expensive correct questions (possible waste)
- [Precalculus L5, cost 43044] Three unit circles are drawn so they are mutually tangent, as shown below.  A blue circle that is externally tangent to all three unit circles is drawn.  Finally, three red circles
  plan: produce[solver:high+cot/reread/confidence/substitution, coder:high+react/reread/confidence/substitution] > check (loop 1)[checker:low+python_check/reread/substitution/case_analysis/alternative] > decide if shaky[judge:low+reread/cot/alternative]
- [Geometry L5, cost 42672] Square $ABCD$ has center $O,\ AB=900,\ E$ and $F$ are on $AB$ with $AE<BF$ and $E$ between $A$ and $F, m\angle EOF =45^\circ,$ and $EF=400.$ Given that $BF=p+q\sqrt{r},$ where $p,q
  plan: produce[solver:high+cot/reread/confidence/substitution/case_analysis/diagram, coder:high+react/reread/confidence/case_analysis/substitution/diagram] > check (loop 1)[checker:low+python_check/reread/substitution/case_analysis/alternative/diagram] > decide if shaky[judge:low+reread/cot/alternative]
- [Counting & Probability L5, cost 36909] My three-digit code is 023. Reckha can't choose a code that is the same as mine in two or more of the three digit-positions, nor that is the same as mine except for switching the p
  plan: produce[solver:low+cot/reread/confidence/substitution/case_analysis, coder:high+react/reread/confidence/case_analysis/substitution] > check (loop 1)[checker:low+python_check/reread/substitution/case_analysis/alternative] > decide[judge:low+reread/cot/alternative]
- [Intermediate Algebra L5, cost 36621] Let $(a_1, b_1),$ $(a_2, b_2),$ $\dots,$ $(a_n, b_n)$ be the real solutions to
\begin{align*}
a + \frac{17a + 6b}{a^2 + b^2} &= 6, \\
b + \frac{6a - 17b}{a^2 + b^2} &= 0.
\end{alig
  plan: produce[solver:low+cot/reread/confidence, coder:high+react/reread/confidence] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/alternative] > decide if shaky[judge:low+reread/cot/alternative]
- [Counting & Probability L5, cost 34141] In how many different ways can 3 men and 4 women be placed into two groups of two people and one group of three people if there must be at least one man and one woman in each group
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution, coder:high+react/reread/confidence/case_analysis/substitution] > check (loop 1)[checker:low+python_check/reread/substitution/case_analysis/alternative] > decide if shaky[judge:low+reread/cot/alternative]