# Performance report (dev-A)

Organization: acc 92.0%, cost 8636/question. Full team: acc 91.3%, cost 27271. Invalid HR outputs (default plan used): 6.

## By category
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 3572 | 19590 | single 12, team 5 |
| Algebra L5 | 18 | 100% | 100% | 6401 | 23083 | team 12, single 6 |
| Counting & Probability L4 | 8 | 100% | 100% | 5113 | 22644 | single 4, team 4 |
| Counting & Probability L5 | 9 | 89% | 89% | 12973 | 32029 | team 8, single 1 |
| Geometry L4 | 5 | 100% | 100% | 6717 | 24771 | team 3, single 2 |
| Geometry L5 | 7 | 43% | 57% | 17480 | 39998 | team 6, single 1 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 10023 | 28859 | team 10, single 4 |
| Intermediate Algebra L5 | 17 | 76% | 71% | 14697 | 36267 | team 17 |
| Number Theory L4 | 9 | 100% | 100% | 5633 | 26425 | team 5, single 4 |
| Number Theory L5 | 16 | 88% | 88% | 7970 | 29063 | team 9, single 7 |
| Prealgebra L4 | 12 | 100% | 100% | 2914 | 15420 | single 9, team 3 |
| Prealgebra L5 | 9 | 100% | 100% | 8997 | 26009 | team 5, single 4 |
| Precalculus L4 | 3 | 100% | 67% | 11608 | 31364 | team 3 |
| Precalculus L5 | 6 | 83% | 83% | 14438 | 38717 | team 6 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| single.check | 54 | 2 | 1 | 0 | 0 |
| single.decide | 54 | 1 | 1 | 1 | 0 |
| single.draft | 54 | 54 | 0 | 0 | 0 |
| team.decide | 96 | 11 | 10 | 2 | 1 |
| team.review | 96 | 32 | 18 | 9 | 0 |
| team.solve | 96 | 96 | 0 | 0 | 0 |

## Employees: leave-one-out replay on 60 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| algebra | 56 | 2 | 1 | 53 | 4418 |
| careful | 36 | 1 | 1 | 34 | 4801 |
| counter | 29 | 1 | 2 | 26 | 4483 |
| critic | 20 | 6 | 0 | 14 | 7393 |
| judge | 6 | 1 | 0 | 5 | 6796 |
Needed / uses by difficulty: algebra@Algebra L4: 0/3; algebra@Algebra L5: 0/7; algebra@Counting & Probability L4: 0/1; algebra@Counting & Probability L5: 0/5; algebra@Geometry L4: 0/3; algebra@Geometry L5: 0/3; algebra@Intermediate Algebra L4: 0/7; algebra@Intermediate Algebra L5: 1/10; algebra@Number Theory L4: 0/2; algebra@Number Theory L5: 0/6; algebra@Prealgebra L4: 0/1; algebra@Prealgebra L5: 0/3; algebra@Precalculus L4: 0/3; algebra@Precalculus L5: 1/2; careful@Algebra L4: 0/3; careful@Algebra L5: 0/5; careful@Counting & Probability L5: 0/1; careful@Geometry L4: 0/3; careful@Geometry L5: 0/2; careful@Intermediate Algebra L4: 0/6; careful@Intermediate Algebra L5: 0/5; careful@Number Theory L4: 0/1; careful@Number Theory L5: 0/1; careful@Prealgebra L4: 0/2; careful@Prealgebra L5: 0/3; careful@Precalculus L4: 0/2; careful@Precalculus L5: 1/2; counter@Algebra L5: 0/2; counter@Counting & Probability L4: 0/1; counter@Counting & Probability L5: 0/5; counter@Geometry L5: 0/1; counter@Intermediate Algebra L4: 0/1; counter@Intermediate Algebra L5: 1/6; counter@Number Theory L4: 0/3; counter@Number Theory L5: 0/6; counter@Prealgebra L4: 0/1; counter@Prealgebra L5: 0/2; counter@Precalculus L4: 0/1; critic@Counting & Probability L5: 1/2; critic@Geometry L4: 0/1; critic@Geometry L5: 0/3; critic@Intermediate Algebra L4: 0/2; critic@Intermediate Algebra L5: 1/5; critic@Number Theory L5: 0/2; critic@Prealgebra L5: 2/2; critic@Precalculus L4: 1/1; critic@Precalculus L5: 1/2; judge@Counting & Probability L5: 0/1; judge@Geometry L5: 0/2; judge@Intermediate Algebra L4: 0/1; judge@Intermediate Algebra L5: 0/1; judge@Prealgebra L5: 1/1

## HR usage
Employees assigned (questions): judge 134, critic 129, algebra 95, careful 75, counter 51, fast 32
Skills switched on (times): final_format 454, sanity_check 357, verify_by_substitution 205, algebraic_substitution 91, solve_linear 38, check_units 25, diagram_extract 17, combinatorics_cases 16, coordinate_lines 15, number_factors 15, polynomial_roots 14, geometry_area 14, counting_digits 14, fraction_percent 13, exponent_rules 11, complex_roots 11, parabola_vertex 10, modular_answer_count 7, permutations_restrictions 5, inverse_function 5, inclusion_exclusion 5, complete_square 4, near_power_zeros 3, matrix_power 2, gcd_coprime 2, divisibility 1, functional_equation 1, sequence_sum 1, surd_power_rounding 1
Guide notes written: 109
Invalid HR outputs, first problems: ["bad JSON: Expecting ',' delimiter: line 1 column 384 (char 383)"]; ["bad JSON: Expecting ',' delimiter: line 43 column 4 (char 792)"]; ["bad JSON: Expecting ',' delimiter: line 1 column 343 (char 342)"]; ["bad JSON: Expecting ',' delimiter: line 1 column 344 (char 343)"]

## Saved wrong: org failed, full team succeeded (2)
- [Geometry L5] The grid below contains the $16$ points whose $x$- and $y$-coordinates are in the set $\{0,1,2,3\}$: [asy]
size(2.5cm);
for(int i=0; i<4; i+=1) { for(int j=0; j<4; j+=1) { dot((i,j)); }; };
[/asy] A square with all four of its vertices among these $16$ points has area $A$. What i
  plan: team solve=[algebra:low+verify_by_substitution/final_format, counter:low+combinatorics_cases/sanity_check/final_format] review=[critic:low+verify_by_substitution/sanity_check/final_format] decide=[judge:high+sanity_check/final_format] guide: counter: "List all unique side lengths squared from integer pairs."; algebra: "Ensure vertices are integer coordinates in [0,3]x[0,3]."; answered 2, correct 21
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: team solve=[algebra:low+parabola_vertex/final_format, careful:low+diagram_extract/coordinate_lines/sanity_check/final_format/verify_by_substitution] review=[critic:low+sanity_check/coordinate_lines/final_format] decide=[judge:high+sanity_check/final_format]; answered 2, correct 85

Both wrong: 10.

## Most expensive correctly-solved questions (possible waste)
- [Intermediate Algebra L5, cost 25067] Let
\[x^8 + 98x^4 + 1 = p(x) q(x),\]where $p(x)$ and $q(x)$ are monic, non-constant polynomials with integer coefficients.  Find $p(1) + q(1).$
  plan: team solve=[algebra:low+algebraic_substitution/polynomial_roots/verify_by_substitution/final_format, careful:low+algebraic_substitution/verify_by_substitution/sanity_check/final_format] review=[critic:low+verify_by_substitution/sanity_check/polynomial_roots/final_format] decide=[judge:high+sanity_check/final_format] guide: careful: "Check integer constraints and monic requirement. Verify sum of roots."; critic: "Verify factorization and integer coefficients explicitly."; algebra: "Factor x^8+98x^4+1 by completing square to (x^4-ax^2+1)(x^4+bx^2+1) then solve for a,b."; judge: "Confirm p(1)+q(1) calculation."
- [Intermediate Algebra L4, cost 24198] Find the largest constant $m,$ so that for any positive real numbers $a,$ $b,$ $c,$ and $d,$
\[\sqrt{\frac{a}{b + c + d}} + \sqrt{\frac{b}{a + c + d}} + \sqrt{\frac{c}{a + b + d}} 
  plan: team solve=[algebra:low+algebraic_substitution/final_format, careful:low+sanity_check/final_format/verify_by_substitution] review=[critic:low+verify_by_substitution/sanity_check/final_format] decide=[judge:high+sanity_check/final_format] guide: careful: "Verify limit cases where one variable approaches 0."; critic: "Ensure logic holds for all positive reals."; algebra: "Check symmetry; likely minimum at equal variables."; judge: "Select the largest proven lower bound."
- [Precalculus L5, cost 22405] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection
  plan: team solve=[algebra:low+verify_by_substitution/final_format, careful:low+diagram_extract/geometry_area/sanity_check/verify_by_substitution/final_format, counter:low+sanity_check/final_format] review=[critic:low+verify_by_substitution/sanity_check/geometry_area/coordinate_lines/final_format] decide=[judge:high+sanity_check/final_format] guide: algebra: "Max area of square cross-section cut by plane."; judge: "Select max area."; critic: "Re-calculate area formula."; counter: "Verify calculations."; careful: "Check intercepts and geometry setup."
- [Precalculus L5, cost 17642] Three unit circles are drawn so they are mutually tangent, as shown below.  A blue circle that is externally tangent to all three unit circles is drawn.  Finally, three red circles
  plan: team solve=[algebra:low+algebraic_substitution/exponent_rules/verify_by_substitution/final_format, careful:low+diagram_extract/geometry_area/algebraic_substitution/verify_by_substitution/sanity_check/final_format] review=[critic:low+verify_by_substitution/sanity_check/final_format] decide=[judge:high+sanity_check/final_format] guide: careful: "Extract coordinates and radii from diagram first."; critic: "Check curvature signs and final fraction simplification."; algebra: "Apply Descartes' Circle Theorem for curvatures."; judge: "Verify integer sum against constraints."
- [Precalculus L4, cost 17172] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\
  plan: team solve=[algebra:low+complex_roots/final_format, careful:low+geometry_area/sanity_check/final_format/verify_by_substitution] review=[critic:low+complex_roots/geometry_area/sanity_check/final_format] decide=[judge:high] guide: careful: "Verify vertex order and area formula for regular polygon subset."; critic: "Check arithmetic in sum of roots and final fraction simplification."; algebra: "Roots are 8th roots of unity excluding 1. Area via shoelace or imaginary parts."