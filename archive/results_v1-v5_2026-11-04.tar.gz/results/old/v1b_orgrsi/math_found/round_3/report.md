# Performance report (dev-A)

Organization: acc 90.7%, cost 8866/question. Full team: acc 91.3%, cost 27271. Invalid HR outputs (default plan used): 4.

## By category
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 82% | 100% | 5138 | 19590 | single 8, team 7, self 2 |
| Algebra L5 | 18 | 94% | 100% | 7111 | 23083 | team 10, single 7, self 1 |
| Counting & Probability L4 | 8 | 100% | 100% | 6263 | 22644 | single 5, team 3 |
| Counting & Probability L5 | 9 | 100% | 89% | 12743 | 32029 | team 9 |
| Geometry L4 | 5 | 100% | 100% | 7034 | 24771 | single 3, team 2 |
| Geometry L5 | 7 | 57% | 57% | 21060 | 39998 | team 7 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 8833 | 28859 | team 9, single 3, self 2 |
| Intermediate Algebra L5 | 17 | 88% | 71% | 14908 | 36267 | team 16, single 1 |
| Number Theory L4 | 9 | 100% | 100% | 6007 | 26425 | single 5, team 4 |
| Number Theory L5 | 16 | 81% | 88% | 6714 | 29063 | single 9, team 6, self 1 |
| Prealgebra L4 | 12 | 100% | 100% | 2490 | 15420 | single 10, team 2 |
| Prealgebra L5 | 9 | 89% | 100% | 7682 | 26009 | team 5, single 4 |
| Precalculus L4 | 3 | 100% | 67% | 11387 | 31364 | team 3 |
| Precalculus L5 | 6 | 83% | 83% | 15904 | 38717 | team 6 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| single.check | 55 | 0 | 0 | 0 | 0 |
| single.decide | 55 | 0 | 0 | 0 | 0 |
| single.draft | 55 | 55 | 0 | 0 | 0 |
| team.decide | 89 | 9 | 8 | 5 | 0 |
| team.review | 89 | 34 | 25 | 17 | 1 |
| team.solve | 89 | 89 | 0 | 0 | 0 |

## Employees: leave-one-out replay on 60 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| algebra | 54 | 2 | 0 | 52 | 4430 |
| careful | 35 | 0 | 0 | 35 | 4522 |
| counter | 34 | 2 | 3 | 29 | 4911 |
| critic | 24 | 15 | 1 | 8 | 7181 |
| judge | 6 | 3 | 0 | 3 | 8095 |
Needed / uses by difficulty: algebra@Algebra L4: 0/5; algebra@Algebra L5: 0/6; algebra@Counting & Probability L4: 0/1; algebra@Counting & Probability L5: 1/3; algebra@Geometry L4: 0/2; algebra@Geometry L5: 0/3; algebra@Intermediate Algebra L4: 0/7; algebra@Intermediate Algebra L5: 1/10; algebra@Number Theory L4: 0/2; algebra@Number Theory L5: 0/4; algebra@Prealgebra L4: 0/2; algebra@Prealgebra L5: 0/2; algebra@Precalculus L4: 0/3; algebra@Precalculus L5: 0/4; careful@Algebra L4: 0/5; careful@Algebra L5: 0/4; careful@Counting & Probability L4: 0/2; careful@Counting & Probability L5: 0/2; careful@Geometry L4: 0/2; careful@Geometry L5: 0/3; careful@Intermediate Algebra L4: 0/5; careful@Intermediate Algebra L5: 0/3; careful@Number Theory L4: 0/1; careful@Prealgebra L4: 0/2; careful@Prealgebra L5: 0/3; careful@Precalculus L4: 0/1; careful@Precalculus L5: 0/2; counter@Algebra L5: 0/2; counter@Counting & Probability L4: 0/3; counter@Counting & Probability L5: 0/5; counter@Geometry L5: 0/3; counter@Intermediate Algebra L4: 0/2; counter@Intermediate Algebra L5: 2/8; counter@Number Theory L4: 0/1; counter@Number Theory L5: 0/4; counter@Prealgebra L5: 0/1; counter@Precalculus L4: 0/2; counter@Precalculus L5: 0/3; critic@Algebra L5: 1/1; critic@Counting & Probability L5: 2/2; critic@Geometry L4: 1/1; critic@Geometry L5: 1/3; critic@Intermediate Algebra L4: 2/2; critic@Intermediate Algebra L5: 3/7; critic@Number Theory L4: 1/2; critic@Number Theory L5: 0/1; critic@Prealgebra L5: 0/1; critic@Precalculus L4: 1/1; critic@Precalculus L5: 3/3; judge@Counting & Probability L5: 1/1; judge@Geometry L5: 0/2; judge@Intermediate Algebra L5: 2/2; judge@Number Theory L5: 0/1

## HR usage
Employees assigned (questions): judge 100, critic 98, algebra 92, careful 68, counter 52, fast 40
Skills switched on (times): reread_question 407, final_format 406, confidence_calibration 403, sanity_check 307, verify_by_substitution 203, algebraic_substitution 99, check_units 45, solve_linear 43, geometry_area 27, coordinate_lines 23, diagram_extract 20, fraction_percent 20, combinatorics_cases 20, exponent_rules 18, number_factors 16, counting_digits 16, polynomial_roots 15, complex_roots 13, inverse_function 7, complete_square 7, inclusion_exclusion 7, parabola_vertex 6, surd_power_rounding 5, divisibility 5, sequence_sum 4, permutations_restrictions 3, near_power_zeros 3, matrix_power 3, functional_equation 3, gcd_coprime 2
Guide notes written: 101
Invalid HR outputs, first problems: ['bad JSON: Invalid control character at: line 1 column 785 (char 784)']; ["bad JSON: Expecting ',' delimiter: line 1 column 466 (char 465)"]; ["unknown sop 'counter'"]; ['bad JSON: Invalid control character at: line 1 column 770 (char 769)']

## Saved wrong: org failed, full team succeeded (6)
- [Prealgebra L5] The area of the shaded region is 78 square inches. All angles are right angles and all measurements are given in inches. What is the perimeter of the non-shaded region?

[asy]size(101);
filldraw(((0,0)--(0,8)--(10,8)--(10,-2)--(6,-2)--(6,0)--cycle^^(2.5,3)--(2.5,5)--(7.5,5)--(7.5
  plan: team solve=[careful:low+reread_question/diagram_extract/sanity_check/final_format, counter:low+reread_question/sanity_check/final_format] review=[critic:low+reread_question/verify_by_substitution/sanity_check/geometry_area/final_format] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: counter: "Calculate bounding box area and subtract shaded region area to find non-shaded area if needed for verification."; judge: "Select the perimeter value that matches the geometric derivation of the outer boundary."; careful: "Extract coordinates from Asymptote to define polygon vertices precisely."; critic: "Verify that the sum of shaded and non-shaded areas equals the total bounding box area derived from coordinates."; answered 30, correct 14
- [Algebra L4] The parabola with equation $y=ax^2+bx+c$ is graphed below:

[asy]
xaxis(-3,7);

yaxis(-5,32);

real g(real x)

{

return 4(x-2)^2-4;
}

draw(graph(g,-1,5));
dot((2,-4));
label("Vertex: $(2,-4)$", (2,-4), SE);
dot((4,12));
label("$(4,12)$", (4,12), E);
[/asy]

The zeros of the qua
  plan: self (answered 6); answered 6, correct 2
- [Algebra L4] Define the function $f(x) = 2x - 5$. For what value of $x$ is $f(x)$ equal to $f^{-1}(x)$?
  plan: self (answered 5/2); answered 2, correct 5
- [Number Theory L5] On a true-false test of 100 items, every question that is a multiple of 4 is true, and all others are false. If a student marks every item that is a multiple of 3 false and all others true, how many of the 100 items will be correctly answered?
  plan: self (answered 66); answered 66, correct 42
- [Algebra L4] Homewood Middle School has 1200 students, and 730 of these students attend a summer picnic. If two-thirds of the girls in the school and one-half of the boys in the school attend the picnic, how many girls attend the picnic?  (Assume that each student in the school is either a bo
  plan: single draft=[fast:off+reread_question/check_units/solve_linear/fraction_percent/sanity_check/final_format/confidence_calibration]; answered 780, correct 520
- [Algebra L5] How many zeros are in the expansion of $999,\!999,\!999,\!998^2$?
  plan: self (answered 2); answered 2, correct 11

Both wrong: 8.

## Most expensive correctly-solved questions (possible waste)
- [Counting & Probability L5, cost 26188] A bored student walks down a hall that contains a row of closed lockers, numbered $1$ to $1024$. He opens the locker numbered 1, and then alternates between skipping and opening ea
  plan: team solve=[counter:low+reread_question/sanity_check/final_format/confidence_calibration/sequence_sum/divisibility, algebra:low+reread_question/algebraic_substitution/exponent_rules/final_format/confidence_calibration/verify_by_substitution] review=[critic:low+reread_question/verify_by_substitution/sanity_check/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: algebra: "Model state changes with binary flips; 1024=2^10."; critic: "Verify simulation for small N matches formula."; counter: "Track open/closed states across passes; last one open is key."; judge: "Confirm unique maximum index."
- [Intermediate Algebra L5, cost 25760] Let
\[x^8 + 98x^4 + 1 = p(x) q(x),\]where $p(x)$ and $q(x)$ are monic, non-constant polynomials with integer coefficients.  Find $p(1) + q(1).$
  plan: team solve=[algebra:low+reread_question/algebraic_substitution/verify_by_substitution/final_format/confidence_calibration/complete_square/polynomial_roots, careful:low+reread_question/check_units/solve_linear/fraction_percent/verify_by_substitution/sanity_check/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: careful: "Verify integer coefficients and monic constraint for the factors found."; critic: "Check if p(1)+q(1) matches the sum of roots logic or direct eval."; algebra: "Factor x^8+98x^4+1 via completing square to find integer roots of p,q."; judge: "Confirm single valid pair and sum."
- [Intermediate Algebra L5, cost 25330] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes th
  plan: team solve=[careful:low+reread_question/check_units/coordinate_lines/diagram_extract/algebraic_substitution/sanity_check/final_format/confidence_calibration, algebra:low+reread_question/algebraic_substitution/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/coordinate_lines/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: algebra: "Maximize area function A(theta) = 1/2 * base * height or use determinant."; critic: "Check if max occurs at boundary (lines parallel) or critical point."; careful: "Model lines as functions of angle theta; find intersection points."; judge: "Select largest valid area found by solvers."
- [Intermediate Algebra L5, cost 25034] Consider the set of 30 parabolas defined as follows: all parabolas have as focus the point $(0,0)$ and the directrix lines have the form $y=ax+b$ with $a$ and $b$ integers such tha
  plan: team solve=[counter:low+reread_question/combinatorics_cases/sanity_check/final_format/confidence_calibration, algebra:low+reread_question/algebraic_substitution/verify_by_substitution/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/geometry_area/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: algebra: "Derive intersection condition for two parabolas with same focus."; critic: "Verify intersection count logic and arithmetic."; counter: "Count pairs of (a,b) directly; exclude no-intersection cases."; judge: "Select final count based on consensus."
- [Precalculus L5, cost 24379] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection
  plan: team solve=[careful:low+reread_question/diagram_extract/coordinate_lines/geometry_area/sanity_check/final_format/confidence_calibration, algebra:high+reread_question/algebraic_substitution/exponent_rules/verify_by_substitution/final_format/confidence_calibration, counter:low+reread_question/sanity_check/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/geometry_area/coordinate_lines/final_format/confidence_calibration] decide=[judge:high+reread_question/sanity_check/final_format/confidence_calibration] guide: algebra: "Parametrize plane intersection, compute area via cross product or projection."; judge: "Select the maximum valid area found."; critic: "Verify projection factor and vertex calculations."; counter: "Check bounds of intersection polygon vertices."; careful: "Extract vertices, find intersection polygon, maximize area."