"""Benchmarks for in-distribution RSI: each has its own dev-A / dev-B (for RSI) and test split, an
answer format and a grader. Splits are built by scripts/prepare_bench.py into data/bench/.

  math        our original MATH L4-5 integer subset (load_math)
  aflow_math  test = AFlow's MATH Level 5 test split (486); dev = MATH Level 5 problems of the same four
              types from the prm800k train file, excluding the AFlow test problems
  gsmhard     GSM-Hard v2 (1319), random split: dev-A 150, dev-B 200, test the remaining 969
  aime        test = AIME 2022-2025 (120); dev = AIME 1983-2021 (860)
"""
import json
import os
import random
import re

from .engine import ANSWER_FMT, extract

ROOT = os.path.join(os.path.dirname(__file__), "..")
SYM_FMT = ("End your response with a final line of the form '#### <final answer>', giving the final "
           "answer in simplest exact form (LaTeX is fine).")


def extract_sym(text):
    if text is None:
        return None
    if "####" in text:
        tail = text.rsplit("####", 1)[1].strip()
        a = tail.splitlines()[0] if tail else ""
    else:
        m = re.findall(r"\\boxed\{(.*)\}", text)
        a = m[-1] if m else (text.strip().splitlines()[-1] if text.strip() else "")
    a = a.strip().rstrip(".").strip().strip("$").rstrip(".").strip()
    return a or None


def grade_exact(pred, gold):
    return pred is not None and pred == gold


def grade_num(pred, gold):
    try:
        p, g = float(pred), float(gold)
    except (TypeError, ValueError):
        return False
    return abs(p - g) <= 1e-4 * max(1.0, abs(g))


def grade_sym(pred, gold):
    from math_verify import parse, verify
    if pred is None:
        return False
    if pred.replace(" ", "") == str(gold).replace(" ", ""):
        return True
    try:
        return bool(verify(parse(f"${gold}$", parsing_timeout=None),
                           parse(f"${pred}$", parsing_timeout=None), timeout_seconds=None))
    except Exception:
        return False


SPEC = {  # name -> answer format, extractor, grader
    "math": (ANSWER_FMT, extract, grade_exact),
    "aime": (ANSWER_FMT, extract, grade_num),
    "gsmhard": (ANSWER_FMT, extract, grade_num),
    "aflow_math": (SYM_FMT, extract_sym, grade_sym),
}


def load_math(split, lo, hi):
    """MATH level 4-5 problems with integer answers (split: train | test), shuffled with seed 0; items
    carry a report bucket and a 'hard' flag (level 5)."""
    rows = [json.loads(l) for l in open(os.path.join(ROOT, "data", "math", f"{split}.jsonl"))]
    rows = [r for r in rows if r["level"] in (4, 5)
            and re.fullmatch(r"-?\d+", r["answer"].replace(",", "").strip())]
    random.Random(0).shuffle(rows)
    return [{"id": r["unique_id"], "question": r["problem"], "gold": extract(r["answer"]),
             "bucket": f"{r['subject']} L{r['level']}", "hard": r["level"] == 5}
            for r in rows][lo:hi]


def load(name, split, n=None):
    """split: dev_a | dev_b | test; returns items with id, question, gold, bucket, hard."""
    if name == "math":
        lo, hi = {"dev_a": (0, 150), "dev_b": (150, 350)}.get(split, (0, 156))
        return load_math("test" if split == "test" else "train", lo, hi)[:n]
    rows = [json.loads(l) for l in open(os.path.join(ROOT, "data", "bench", f"{name}_{split}.jsonl"))]
    return rows[:n]
