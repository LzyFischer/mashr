"""Figures for the MAS-HR progress report (v5). Reads the run directories; writes PNGs next to this file.

  ~/miniconda3/envs/mem/bin/python results/figures/make_figs.py
"""
import json
import os
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
OUT = os.path.dirname(os.path.abspath(__file__))
R = lambda *p: os.path.join(ROOT, "results", *p)

# reference palette, light mode (3 slots validated all-pairs; aqua < 3:1 -> every mark is labeled)
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3de"
MASHR, FULL, FIXED, BASE = "#2a78d6", "#eb6834", "#1baf7a", "#9a9993"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 11, "axes.edgecolor": GRID, "axes.linewidth": 1,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "text.color": INK,
    "axes.facecolor": SURFACE, "figure.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "axes.titleweight": "bold", "axes.titlesize": 13, "axes.titlelocation": "left"})


def load(path):
    return json.load(open(R(path)))


def save(fig, name):
    fig.savefig(os.path.join(OUT, name), dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("wrote", name)


def subtitle(ax, text):
    ax.text(0.0, 1.015, text, transform=ax.transAxes, va="bottom", color=INK2, fontsize=9.5)


v5 = load("rsi5/math_acc/test.json")
refs = {**load("rsi5/references/test.json"), **load("rsi5/references/test_fixed.json")}
K = lambda s: s["cost"] / 1000                      # cost in thousand tokens per question
A = lambda s: 100 * s["acc"]


# 1. accuracy vs cost on test ------------------------------------------------------------------
def fig_frontier():
    fig, ax = plt.subplots(figsize=(9, 6))
    # (system, label, color, label offset (dx, dy), alignment)
    pts = [
        (v5["single_low"], "Single solver (low)", BASE, (9, -4), "left"),
        (v5["single_high"], "Single solver (high)", BASE, (0, -18), "center"),
        (v5["single_max"], "Single solver (max, 16k)", BASE, (9, -4), "left"),
        (refs["cot_sc5_high"], "CoT-SC ×5 (high)", BASE, (9, -4), "left"),
        (refs["llm_debate_3x2_high"], "LLM-Debate 3×2 (high)", BASE, (9, -4), "left"),
        (refs["hr_fixed_final"], "Fixed arch. (after RSI)", FIXED, (9, -14), "left"),
        (refs["hr_fixed_round0"], "Fixed arch. (no RSI)", FIXED, (9, -4), "left"),
        (refs["full_team_final"], "Full team (after RSI)", FULL, (-9, 6), "right"),
        (refs["full_team_round0"], "Full team (no RSI)", FULL, (0, -20), "center"),
    ]
    for s, lab, col, off, ha in pts:
        big = col != BASE
        ax.scatter(K(s), A(s), s=110 if big else 70, color=col, edgecolor=SURFACE, linewidth=2,
                   zorder=4 if big else 3)
        ax.annotate(f"{lab}  {A(s):.1f}%" if big else lab, (K(s), A(s)), xytext=off,
                    textcoords="offset points", ha=ha, color=INK if big else INK2, fontsize=10)
    x0, y0 = K(v5["org_round0"]), A(v5["org_round0"])
    x1, y1 = K(v5["org_final"]), A(v5["org_final"])
    ax.annotate("", (x1, y1), (x0, y0), arrowprops=dict(arrowstyle="-|>", color=MASHR, lw=2,
                                                        shrinkA=7, shrinkB=7))
    ax.scatter([x0], [y0], s=80, facecolor=SURFACE, edgecolor=MASHR, linewidth=2, zorder=4)
    ax.scatter([x1], [y1], s=130, color=MASHR, edgecolor=SURFACE, linewidth=2, zorder=5)
    ax.annotate(f"MAS-HR before RSI  {y0:.1f}%", (x0, y0), xytext=(10, -4),
                textcoords="offset points", color=INK2, fontsize=10)
    ax.annotate(f"MAS-HR  {y1:.1f}%", (x1, y1), xytext=(-10, 6), textcoords="offset points",
                ha="right", color=INK, fontsize=11, fontweight="bold")
    ax.set_xlabel("Cost per question (thousand tokens: generated + 0.2 × prompt)")
    ax.set_ylabel("Test accuracy (%)")
    ax.set_xlim(0, 52)
    ax.set_ylim(83, 101.5)
    ax.set_title("MATH L4–5 test (156 questions): accuracy vs. cost", pad=24)
    subtitle(ax, "Same 9B model everywhere. Full team / fixed architectures are designed once by the "
                 "HR (no RSI = initial organization). Upper left is better.")
    save(fig, "fig1_accuracy_vs_cost.png")


# 2. RSI trajectory on dev-B ---------------------------------------------------------------------
def fig_trajectory():
    t5 = load("rsi5/math_acc/trace.json")
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(8.6, 6.4), sharex=True,
                                 gridspec_kw={"hspace": 0.18})
    r = [x["round"] for x in t5]
    acc = [100 * x["dev_b"]["acc"] for x in t5]
    cost = [x["dev_b"]["cost"] / 1000 for x in t5]
    for ax, ys, fmt in ((a1, acc, "{:.1f}%"), (a2, cost, "{:.1f}k")):
        ax.plot(r, ys, color=MASHR, lw=2, marker="o", ms=8, mec=SURFACE, mew=2)
        ax.annotate(fmt.format(ys[-1]), (r[-1], ys[-1]), xytext=(9, -4),
                    textcoords="offset points", color=INK, fontsize=10.5, fontweight="bold")
    notes = {1: ("+ verifier on most problems", 12), 2: ("easy problems back to one node "
                                                         "(−24% cost)", -22),
             3: ("verifier thinking → max", 12)}
    for k, (txt, dy) in notes.items():
        a1.annotate(txt, (k, acc[k]), xytext=(0, dy), textcoords="offset points", ha="center",
                    color=MASHR, fontsize=9.5)
    a1.set_ylabel("dev-B accuracy (%)")
    a2.set_ylabel("Cost per question (k tokens)")
    a2.set_xlabel("RSI round (accepted organization)")
    a1.set_title("Organization learning across RSI rounds (dev-B, 200 questions)")
    a1.set_ylim(92, 98)
    a2.set_ylim(0, 17)
    a2.set_xticks(range(6))
    a2.set_xlim(-0.2, 5.7)
    save(fig, "fig2_rsi_trajectory.png")


# 3. thinking budget ----------------------------------------------------------------------------
def fig_budget():
    b = load("rsi4/analysis/budget.json")
    levels = [("low", 1), ("high", 4), ("xhigh", 8), ("max", 16)]
    xs = [k for _, k in levels]
    acc = [100 * b[lv]["acc"] for lv, _ in levels]
    cut = [100 * b[lv]["cut"] / b[lv]["n"] for lv, _ in levels]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4.4), gridspec_kw={"wspace": 0.28})
    a1.plot(xs, acc, color=MASHR, lw=2, marker="o", ms=8, mec=SURFACE, mew=2)
    for x, y in zip(xs, acc):
        a1.annotate(f"{y:.1f}%", (x, y), xytext=(0, 9), textcoords="offset points", ha="center",
                    fontsize=10)
    a1.set_title("Single solver, Level 5 (dev-A, 82 q.)")
    a1.set_ylabel("Accuracy (%)")
    a1.set_xscale("log", base=2)
    a1.set_xticks(xs, [f"{k}k" for k in xs])
    a1.set_ylim(55, 97)
    a1.set_xlabel("Thinking budget (tokens)")
    a2.bar(range(4), cut, color=MASHR, width=0.55, edgecolor=SURFACE, linewidth=2)
    for i, y in enumerate(cut):
        a2.annotate(f"{y:.0f}%", (i, y), xytext=(0, 4), textcoords="offset points", ha="center",
                    fontsize=10)
    a2.set_title("Reasoning cut at the budget")
    a2.set_ylabel("Share of questions (%)")
    a2.set_xticks(range(4), [f"{k}k" for k in xs])
    a2.set_ylim(0, 112)
    a2.set_xlabel("Thinking budget (tokens)")
    a2.grid(axis="x", visible=False)
    fig.text(0.125, -0.04, "Questions whose reasoning finished within the budget were answered "
             "correctly at every level (100%).", color=INK2, fontsize=9.5)
    save(fig, "fig3_thinking_budget.png")


# 4. headline bars ------------------------------------------------------------------------------
def fig_headline():
    rows = [("Full team (after RSI)", refs["full_team_final"], FULL),
            ("Full team (no RSI)", refs["full_team_round0"], FULL),
            ("LLM-Debate 3×2 (high)", refs["llm_debate_3x2_high"], BASE),
            ("HR's fixed architecture (after RSI)", refs["hr_fixed_final"], FIXED),
            ("HR's fixed architecture (no RSI)", refs["hr_fixed_round0"], FIXED),
            ("MAS-HR (per-question staffing)", v5["org_final"], MASHR),
            ("Single solver (max)", v5["single_max"], BASE)]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10.5, 5.0), sharey=True,
                                 gridspec_kw={"wspace": 0.08})
    ys = range(len(rows))[::-1]
    for y, (lab, s, col) in zip(ys, rows):
        a1.barh(y, A(s), color=col, height=0.6, edgecolor=SURFACE, linewidth=2)
        a1.annotate(f"{A(s):.1f}%", (A(s), y), xytext=(4, 0), textcoords="offset points",
                    va="center", fontsize=10.5)
        a2.barh(y, K(s), color=col, height=0.6, edgecolor=SURFACE, linewidth=2)
        a2.annotate(f"{K(s):.1f}k", (K(s), y), xytext=(4, 0), textcoords="offset points",
                    va="center", fontsize=10.5)
    a1.set_yticks(list(ys), [r[0] for r in rows])
    a1.set_xlim(90, 101.5)
    a1.set_title("Test accuracy (%)")
    a2.set_xlim(0, 50)
    a2.set_title("Cost per question (k tokens)")
    for ax in (a1, a2):
        ax.grid(axis="y", visible=False)
    a1.text(0, 1.1, "MATH L4–5 test, 156 questions; one question = 0.64 points",
            transform=a1.transAxes, color=INK2, fontsize=9.5)
    save(fig, "fig4_headline.png")


# 5. what the HR writes -------------------------------------------------------------------------
def fig_architectures():
    rep = open(R("rsi5/math_acc/round_5/report.md")).read()
    sec = rep.split("## Architectures the HR wrote")[1].split("##")[0]
    rows = [(m[0], int(m[1]), int(m[2]), float(m[3])) for m in
            re.findall(r"\| (\S+) \| (\d+) \| (\d+)% \| ([\d.]+) \|", sec)][:9]
    fig, ax = plt.subplots(figsize=(9, 4.8))
    ys = range(len(rows))[::-1]
    for y, (arch, n, acc, c) in zip(ys, rows):
        col = MASHR if ">" in arch else "#86b6ef"
        ax.barh(y, n, color=col, height=0.62, edgecolor=SURFACE, linewidth=2)
        ax.annotate(f"{acc}% correct · cost {c / 1000:.1f}k", (n, y), xytext=(5, 0),
                    textcoords="offset points", va="center", fontsize=9.5, color=INK2)
    nice = lambda a: a.replace(">", " → ").replace(",", " + ")
    ax.set_yticks(list(ys), [nice(r[0]) for r in rows])
    ax.set_xlabel("Questions (dev-A, 150)")
    ax.set_xlim(0, max(r[1] for r in rows) * 1.75)
    ax.grid(axis="y", visible=False)
    ax.set_title("Architectures the HR writes (final organization)", pad=24)
    subtitle(ax, "employee.thinking;  light = one node,  dark = solve → verify")
    save(fig, "fig5_hr_architectures.png")


# 6. without RSI vs after RSI, same three uses of the organization ------------------------------
def fig_rsi_effect():
    rows = [("MAS-HR (per-question staffing)", v5["org_round0"], v5["org_final"]),
            ("HR's best fixed architecture", refs["hr_fixed_round0"], refs["hr_fixed_final"]),
            ("Full team (all employees)", refs["full_team_round0"], refs["full_team_final"])]
    before, after = "#86b6ef", MASHR
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10.5, 3.9), sharey=True,
                                 gridspec_kw={"wspace": 0.08})
    h = 0.36
    for i, (lab, s0, s1) in enumerate(rows[::-1]):
        for ax, f, fmt in ((a1, A, "{:.1f}%"), (a2, K, "{:.1f}k")):
            for dy, s, col in ((h / 2, s0, before), (-h / 2, s1, after)):
                ax.barh(i + dy, f(s), height=h, color=col, edgecolor=SURFACE, linewidth=2)
                ax.annotate(fmt.format(f(s)), (f(s), i + dy), xytext=(4, 0),
                            textcoords="offset points", va="center", fontsize=10)
    a1.set_yticks(range(len(rows)), [r[0] for r in rows[::-1]])
    a1.set_xlim(88, 101.8)
    a1.set_title("Test accuracy (%)")
    a2.set_xlim(0, 52)
    a2.set_title("Cost per question (k tokens)")
    for ax in (a1, a2):
        ax.grid(axis="y", visible=False)
    a1.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=before),
                       plt.Rectangle((0, 0), 1, 1, color=after)],
              labels=["Without RSI (initial organization)", "After RSI (final organization)"],
              loc="upper left", bbox_to_anchor=(0, 1.24), ncol=2, fontsize=10)
    save(fig, "fig6_without_vs_after_rsi.png")


# 7. transfer to new datasets (no RSI on them) ----------------------------------------------------
def fig_transfer():
    sets = [("aime", "AIME 2022–25\n(120)"), ("aflow_math", "MATH Level 5\n(AFlow test, 486)"),
            ("gsmhard", "GSM-Hard\n(1319)")]
    systems = [("mashr_final", "MAS-HR (after RSI on MATH)", MASHR),
               ("mashr_round0", "MAS-HR (no RSI)", "#86b6ef"),
               ("single_max", "Single solver (max)", BASE)]
    res = {d: load(f"transfer/{d}.json") for d, _ in sets}
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.3), gridspec_kw={"wspace": 0.22})
    w = 0.26
    for j, (key, lab, col) in enumerate(systems):
        xs = [i + (j - 1) * w for i in range(len(sets))]
        acc = [100 * res[d][key]["all"]["acc"] for d, _ in sets]
        cst = [res[d][key]["all"]["cost"] / 1000 for d, _ in sets]
        a1.bar(xs, acc, width=w, color=col, edgecolor=SURFACE, linewidth=2, label=lab)
        a2.bar(xs, cst, width=w, color=col, edgecolor=SURFACE, linewidth=2)
        for x, y in zip(xs, acc):
            a1.annotate(f"{y:.0f}", (x, y), xytext=(0, 3), textcoords="offset points",
                        ha="center", fontsize=9)
        for x, y in zip(xs, cst):
            a2.annotate(f"{y:.0f}k", (x, y), xytext=(0, 3), textcoords="offset points",
                        ha="center", fontsize=9)
    for ax in (a1, a2):
        ax.set_xticks(range(len(sets)), [lab for _, lab in sets])
        ax.grid(axis="x", visible=False)
    a1.set_ylim(50, 102)
    a1.set_title("Accuracy (%)")
    a2.set_ylim(0, 37)
    a2.set_title("Cost per question (k tokens)")
    a1.legend(loc="upper left", bbox_to_anchor=(0, 1.2), ncol=3, fontsize=10)
    fig.text(0.125, -0.1, "Organizations learned on MATH (integer L4–5) and used unchanged. "
             "GSM-Hard has 303 non-integer gold answers (known label noise).\n"
             "MATH Level 5 without the 24 problems in our RSI dev sets: 91.8 / 86.8 / 95.0.",
             color=INK2, fontsize=9)
    save(fig, "fig7_transfer.png")


# 8. in-distribution RSI on each benchmark (RSI, HR and test on the same dataset) --------------------
def fig_in_distribution():
    sets = [("math", "MATH L4–5\n(int., 156)"), ("aflow_math", "MATH L5\n(AFlow, 486)"),
            ("gsmhard", "GSM-Hard\n(969)"), ("aime", "AIME 2022–25\n(120)")]
    res = {"math": {"org_final": v5["org_final"], "org_round0": v5["org_round0"],
                    "single_max": v5["single_max"]}}
    res.update({d: load(f"bench/{d}/test.json") for d, _ in sets[1:]})
    systems = [("org_final", "MAS-HR (after RSI on this benchmark)", MASHR),
               ("org_round0", "MAS-HR (no RSI)", "#86b6ef"),
               ("single_max", "Single solver (max)", BASE)]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.3), gridspec_kw={"wspace": 0.2})
    w = 0.26
    for j, (key, lab, col) in enumerate(systems):
        xs = [i + (j - 1) * w for i in range(len(sets))]
        acc = [100 * res[d][key]["acc"] for d, _ in sets]
        cst = [res[d][key]["cost"] / 1000 for d, _ in sets]
        a1.bar(xs, acc, width=w, color=col, edgecolor=SURFACE, linewidth=2, label=lab)
        a2.bar(xs, cst, width=w, color=col, edgecolor=SURFACE, linewidth=2)
        for x, y in zip(xs, acc):
            a1.annotate(f"{y:.0f}", (x, y), xytext=(0, 3), textcoords="offset points",
                        ha="center", fontsize=9)
        for x, y in zip(xs, cst):
            a2.annotate(f"{y:.0f}k", (x, y), xytext=(0, 3), textcoords="offset points",
                        ha="center", fontsize=9)
    for ax in (a1, a2):
        ax.set_xticks(range(len(sets)), [lab for _, lab in sets], fontsize=9.5)
        ax.grid(axis="x", visible=False)
    a1.set_ylim(50, 103)
    a1.set_title("Test accuracy (%)")
    a2.set_ylim(0, 55)
    a2.set_title("Cost per question (k tokens)")
    a1.legend(loc="upper left", bbox_to_anchor=(0, 1.2), ncol=3, fontsize=10)
    fig.text(0.125, -0.1, "RSI, HR and test on the same benchmark (dev-A/dev-B for RSI, disjoint test). "
             "AIME dev = AIME 1983–2021; GSM-Hard dev = 350 of its 1319 problems;\nAFlow MATH dev = "
             "MATH Level 5 train problems of the same four types. One seed per benchmark.",
             color=INK2, fontsize=9)
    save(fig, "fig8_in_distribution.png")


# 9. iterative RSI: phase 1 (accuracy) then phase 2 (cost), per benchmark --------------------------
def fig_phase2():
    sets = [("math", "MATH L4–5\n(int., 156)"), ("aflow_math", "MATH L5\n(AFlow, 486)"),
            ("gsmhard", "GSM-Hard\n(969)"), ("aime", "AIME 2022–25\n(120)")]
    res = {d: load(f"phase2/{d}/test.json") for d, _ in sets}
    systems = [("org_round0", "After phase 1 (accuracy)", "#86b6ef"),
               ("org_final", "After phase 2 (cost)", MASHR),
               ("single_max", "Single solver (max)", BASE)]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.3), gridspec_kw={"wspace": 0.2})
    w = 0.26
    for j, (key, lab, col) in enumerate(systems):
        xs = [i + (j - 1) * w for i in range(len(sets))]
        acc = [100 * res[d][key]["acc"] for d, _ in sets]
        cst = [res[d][key]["cost"] / 1000 for d, _ in sets]
        a1.bar(xs, acc, width=w, color=col, edgecolor=SURFACE, linewidth=2, label=lab)
        a2.bar(xs, cst, width=w, color=col, edgecolor=SURFACE, linewidth=2)
        for x, y in zip(xs, acc):
            a1.annotate(f"{y:.0f}", (x, y), xytext=(0, 3), textcoords="offset points",
                        ha="center", fontsize=9)
        for x, y in zip(xs, cst):
            a2.annotate(f"{y:.0f}k", (x, y), xytext=(0, 3), textcoords="offset points",
                        ha="center", fontsize=9)
    for ax in (a1, a2):
        ax.set_xticks(range(len(sets)), [lab for _, lab in sets], fontsize=9.5)
        ax.grid(axis="x", visible=False)
    a1.set_ylim(50, 103)
    a1.set_title("Test accuracy (%)")
    a2.set_ylim(0, 55)
    a2.set_title("Cost per question (k tokens)")
    a1.legend(loc="upper left", bbox_to_anchor=(0, 1.2), ncol=3, fontsize=10)
    fig.text(0.125, -0.1, "Phase 2 starts from the phase-1 organization; a change is accepted only if "
             "dev-B accuracy stays within 0.5 points of the best so far.\nMATH L4–5: no change "
             "accepted (both bars are the same organization). One seed per benchmark.",
             color=INK2, fontsize=9)
    save(fig, "fig9_iterative_rsi.png")


BENCH = [("math", "MATH L4–5 (integer, 156)"), ("aflow_math", "MATH Level 5 (AFlow test, 486)"),
         ("gsmhard", "GSM-Hard (969)"), ("aime", "AIME 2022–25 (120)")]
PHASE1 = {"math": "rsi5/math_acc", "aflow_math": "bench/aflow_math", "gsmhard": "bench/gsmhard",
          "aime": "bench/aime"}


# 10. per benchmark: accuracy vs cost path (no RSI -> phase 1 -> phase 2) with single-solver points ---
def fig_paths():
    fig, axes = plt.subplots(2, 2, figsize=(11, 8.4), gridspec_kw={"hspace": 0.42, "wspace": 0.22})
    for ax, (d, title) in zip(axes.flat, BENCH):
        p1, p2 = load(f"{PHASE1[d]}/test.json"), load(f"phase2/{d}/test.json")
        for k, lab in (("single_low", "single low"), ("single_high", "single high"),
                       ("single_max", "single max")):
            left = k == "single_max" and d in ("aflow_math", "aime")   # keep clear of MAS-HR points
            ax.scatter(K(p1[k]), A(p1[k]), s=60, color=BASE, edgecolor=SURFACE, linewidth=2, zorder=3)
            ax.annotate(lab, (K(p1[k]), A(p1[k])), xytext=(-7 if left else 7, -4),
                        textcoords="offset points", ha="right" if left else "left",
                        color=INK2, fontsize=9)
        path = [(p1["org_round0"], "no RSI"), (p2["org_round0"], "phase 1"),
                (p2["org_final"], "phase 2")]
        for (s0, _), (s1, _) in zip(path, path[1:]):
            if (K(s0), A(s0)) != (K(s1), A(s1)):
                ax.annotate("", (K(s1), A(s1)), (K(s0), A(s0)),
                            arrowprops=dict(arrowstyle="-|>", color=MASHR, lw=1.8, shrinkA=7,
                                            shrinkB=7))
        styles = [dict(facecolor=SURFACE, edgecolor=MASHR, linewidth=2),
                  dict(color="#86b6ef", edgecolor=SURFACE, linewidth=2),
                  dict(color=MASHR, edgecolor=SURFACE, linewidth=2)]
        for (s, lab), st, dy in zip(path, styles, (-14, 6, 6)):
            ax.scatter(K(s), A(s), s=95, zorder=4, **st)
        x2, y2 = K(path[2][0]), A(path[2][0])
        ax.annotate(f"phase 2  {y2:.1f}%", (x2, y2), xytext=(-8, 7), textcoords="offset points",
                    ha="right", fontsize=9.5, fontweight="bold")
        x0, y0 = K(path[0][0]), A(path[0][0])
        ax.annotate(f"no RSI  {y0:.1f}%", (x0, y0), xytext=(8, -12), textcoords="offset points",
                    fontsize=9, color=INK2)
        x1, y1 = K(path[1][0]), A(path[1][0])
        if (x1, y1) != (x2, y2):
            ax.annotate(f"phase 1  {y1:.1f}%", (x1, y1), xytext=(8, 4), textcoords="offset points",
                        fontsize=9, color=INK2)
        ax.set_title(title, fontsize=11.5)
        ax.set_xlim(0, max(K(s) for s, _ in path) * 1.5)
        lo = min(A(p1["single_low"]), y0) - 3
        ax.set_ylim(lo, 101)
        ax.set_xlabel("Cost per question (k tokens)", fontsize=9.5)
        ax.set_ylabel("Test accuracy (%)", fontsize=9.5)
    fig.text(0.125, 0.035, "Hollow = MAS-HR before RSI; light = after phase 1 (accuracy); dark = after "
             "phase 2 (cost); gray = single solver. MATH L4–5: phase 2 accepted no change.",
             color=INK2, fontsize=9)
    save(fig, "fig10_rsi_paths.png")


# 11. dev-B trajectory across both phases ------------------------------------------------------------
def fig_trajectories():
    fig, axes = plt.subplots(2, 4, figsize=(14, 5.8), sharex=True,
                             gridspec_kw={"hspace": 0.12, "wspace": 0.32})
    for j, (d, title) in enumerate(BENCH):
        t1, t2 = load(f"{PHASE1[d]}/trace.json"), load(f"phase2/{d}/trace.json")
        r1 = [x["round"] for x in t1]
        r2 = [len(t1) - 1 + x["round"] for x in t2]
        for row, f in ((0, lambda x: 100 * x["dev_b"]["acc"]), (1, lambda x: x["dev_b"]["cost"] / 1000)):
            ax = axes[row, j]
            ax.plot(r1, [f(x) for x in t1], color="#86b6ef", lw=2, marker="o", ms=5,
                    label="phase 1 (accuracy)")
            ax.plot(r2, [f(x) for x in t2], color=MASHR, lw=2, marker="o", ms=5,
                    label="phase 2 (cost)")
            ax.axvline(len(t1) - 1, color=GRID, lw=1.5, ls=(0, (3, 3)))
            if row == 0:
                ax.set_title({"math": "MATH L4–5", "aflow_math": "MATH Level 5",
                              "gsmhard": "GSM-Hard", "aime": "AIME (dev: 1983–2021)"}[d], fontsize=11)
        axes[1, j].set_xlabel("RSI round")
        axes[1, j].set_ylim(0, None)
    axes[0, 0].set_ylabel("dev-B accuracy (%)")
    axes[1, 0].set_ylabel("Cost (k tokens)")
    axes[0, 0].legend(loc="upper left", bbox_to_anchor=(0, 1.42), ncol=2, fontsize=10)
    fig.text(0.125, -0.02, "Rounds 0–5: phase 1 from the 27B's initial design; rounds 5–10: phase 2 from "
             "the phase-1 organization (round 5 re-evaluated). dev-B = 200 questions.",
             color=INK2, fontsize=9)
    save(fig, "fig11_rsi_trajectories.png")


if __name__ == "__main__":
    fig_paths()
    fig_trajectories()
    fig_phase2()
    fig_in_distribution()
    fig_transfer()
    fig_rsi_effect()
    fig_frontier()
    fig_trajectory()
    fig_budget()
    fig_headline()
    fig_architectures()
