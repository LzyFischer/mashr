# Performance report (dev-A)

Organization: acc 91.7%, cost 3825/question. Full team: acc 100.0%, cost 13034. Invalid HR outputs (default plan used): 0.

## By difficulty (calculation steps in the reference solution)
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| 1-2 steps | 4 | 100% | 100% | 2548 | 12770 | fast_solo 3, triple_vote 1 |
| 3-4 steps | 5 | 80% | 100% | 2987 | 12959 | fast_solo 3, draft_check 1, dual_review_decide 1 |
| 5-6 steps | 2 | 100% | 100% | 7898 | 12930 | dual_review_decide 2 |
| 7+ steps | 1 | 100% | 100% | 4980 | 14675 | dual_check 1 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| draft_check.check | 1 | 1 | 0 | 0 | 0 |
| draft_check.solve | 1 | 1 | 0 | 0 | 0 |
| dual_check.decide | 1 | 1 | 0 | 0 | 0 |
| dual_check.solve | 1 | 1 | 0 | 0 | 0 |
| dual_review_decide.decide | 3 | 0 | 0 | 0 | 0 |
| dual_review_decide.review | 3 | 3 | 1 | 1 | 0 |
| dual_review_decide.solve | 3 | 3 | 0 | 0 | 0 |
| fast_solo.solve | 6 | 6 | 0 | 0 | 0 |
| triple_vote.decide | 1 | 1 | 0 | 0 | 0 |
| triple_vote.solve | 1 | 1 | 0 | 0 | 0 |

## Employees: leave-one-out replay on 6 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| judge | 2 | 0 | 0 | 2 | 1144 |
| reviewer | 4 | 1 | 0 | 3 | 2040 |
| solver_algebra | 4 | 0 | 0 | 4 | 2061 |
| solver_quick | 2 | 0 | 0 | 2 | 1446 |
| solver_structured | 5 | 0 | 0 | 5 | 2151 |
Needed / uses by difficulty: judge@1-2 steps: 0/1; judge@7+ steps: 0/1; reviewer@3-4 steps: 0/2; reviewer@5-6 steps: 1/2; solver_algebra@1-2 steps: 0/1; solver_algebra@3-4 steps: 0/1; solver_algebra@5-6 steps: 0/2; solver_quick@1-2 steps: 0/1; solver_quick@7+ steps: 0/1; solver_structured@1-2 steps: 0/1; solver_structured@3-4 steps: 0/1; solver_structured@5-6 steps: 0/2; solver_structured@7+ steps: 0/1

## HR usage
Employees assigned (questions): solver_quick 8, solver_structured 6, judge 5, reviewer 4, solver_algebra 4
Skills switched on (times): reread_last_sentence 27, check_final_answer 27, extract_numbers 22, identify_operations 19, arithmetic_check 10, verify_by_substitution 8, percent_fraction_base 7, total_vs_part 7, convert_units 4, unknown_backward 4, confidence_rule 2, rate_time 2, geometric_sequence 2, budget_change 1, sequence_order 1
Guide notes written: 7

## Saved wrong: org failed, full team succeeded (1)
- [3-4 steps] James writes a 3-page letter to 2 different friends twice a week.  How many pages does he write a year?
  plan: fast_solo solve=[solver_quick:off+reread_last_sentence/extract_numbers/identify_operations/check_final_answer]; answered 312, correct 624

Both wrong: 0.

## Most expensive correctly-solved questions (possible waste)
- [5-6 steps, cost 9374] Mark has a garden with flowers. He planted plants of three different colors in it. Ten of them are yellow, and there are 80% more of those in purple. There are only 25% as many gre
  plan: dual_review_decide solve=[solver_structured:low+reread_last_sentence/extract_numbers/identify_operations/percent_fraction_base/total_vs_part/arithmetic_check/check_final_answer, solver_algebra:high+reread_last_sentence/extract_numbers/identify_operations/percent_fraction_base/unknown_backward/verify_by_substitution/check_final_answer] review=[reviewer:low+reread_last_sentence/extract_numbers/identify_operations/percent_fraction_base/total_vs_part/arithmetic_check/verify_by_substitution/check_final_answer] decide=[judge:low+reread_last_sentence/check_final_answer] guide: solver_structured: "Step-by-step calculation: Yellow=10, Purple=18, Green=28. Total=56."; solver_algebra: "Define Y=10, P=1.8Y, G=0.25(Y+P). Sum variables."; judge: "Select answer supported by correct derivation and verification."; reviewer: "Verify percent bases and addition steps. Check for misinterpretation."
- [3-4 steps, cost 7730] Ken created a care package to send to his brother, who was away at boarding school.  Ken placed a box on a scale, and then he poured into the box enough jelly beans to bring the we
  plan: dual_review_decide solve=[solver_structured:low+reread_last_sentence/extract_numbers/identify_operations/total_vs_part/arithmetic_check/check_final_answer, solver_algebra:high+reread_last_sentence/extract_numbers/identify_operations/unknown_backward/verify_by_substitution/check_final_answer] review=[reviewer:low+reread_last_sentence/extract_numbers/identify_operations/total_vs_part/arithmetic_check/verify_by_substitution/check_final_answer] decide=[judge:low+reread_last_sentence/check_final_answer] guide: solver_structured: "Track sequential weight changes step-by-step."; solver_algebra: "Model weight changes algebraically and verify."; judge: "Select the correct final weight."; reviewer: "Check arithmetic and logic of both solutions."
- [1-2 steps, cost 7593] A deep-sea monster rises from the waters once every hundred years to feast on a ship and sate its hunger. Over three hundred years, it has consumed 847 people. Ships have been buil
  plan: triple_vote solve=[solver_quick:low+reread_last_sentence/extract_numbers/check_final_answer, solver_structured:low+reread_last_sentence/extract_numbers/identify_operations/arithmetic_check/check_final_answer, solver_algebra:high+reread_last_sentence/extract_numbers/geometric_sequence/unknown_backward/verify_by_substitution/check_final_answer] decide=[judge:low+reread_last_sentence/check_final_answer] guide: solver_structured: "Step-by-step setup of geometric series."; solver_algebra: "Define variables and solve quadratic equation."; judge: "Verify all three answers match."; solver_quick: "Estimate using geometric sum formula quickly."
- [5-6 steps, cost 6422] Tobias is buying a new pair of shoes that costs $95. He has been saving up his money each month for the past three months. He gets a $5 allowance a month. He also mows lawns and sh
  plan: dual_review_decide solve=[solver_structured:low+reread_last_sentence/extract_numbers/identify_operations/convert_units/percent_fraction_base/total_vs_part/arithmetic_check/rate_time/budget_change/check_final_answer, solver_algebra:high+reread_last_sentence/extract_numbers/identify_operations/percent_fraction_base/sequence_order/unknown_backward/geometric_sequence/verify_by_substitution/check_final_answer] review=[reviewer:low+reread_last_sentence/extract_numbers/identify_operations/convert_units/percent_fraction_base/total_vs_part/arithmetic_check/verify_by_substitution/check_final_answer] decide=[judge:low+reread_last_sentence/check_final_answer] guide: solver_structured: "Calculate savings from allowance, lawn mowing, and unknown shoveling to match total spent."; solver_algebra: "Set up equation: Total Cost = (Allowance + Mowing) + Shoveling + Change."; judge: "Select the integer answer supported by both solvers."; reviewer: "Verify arithmetic and ensure shoveling count is an integer."
- [7+ steps, cost 4980] Tina makes $18.00 an hour.  If she works more than 8 hours per shift, she is eligible for overtime, which is paid by your hourly wage + 1/2 your hourly wage.  If she works 10 hours
  plan: dual_check solve=[solver_quick:low+reread_last_sentence/extract_numbers/check_final_answer, solver_structured:low+reread_last_sentence/extract_numbers/identify_operations/convert_units/rate_time/arithmetic_check/check_final_answer] decide=[judge:low+reread_last_sentence/check_final_answer] guide: solver_structured: "Compute daily total, then multiply by 5 days."; judge: "Verify calculations match the problem conditions."; solver_quick: "Calculate base 8h + overtime 2h at 1.5x rate."