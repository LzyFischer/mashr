"""Dataset-level RSI over the whole organization (roster, skills, SOPs, HR handbook).

  P=~/miniconda3/envs/tinker/bin/python
  set -a; source ~/.config/hrsi/tinker.env; set +a
  $P -m mashr.orgrsi --rounds 5 --init hand  --out results/orgrsi/gsm8k_hand
  $P -m mashr.orgrsi --rounds 5 --init found --out results/orgrsi/gsm8k_found

Round 0 ("founding"): the org is the hand-written V0, or (--init found) written by the big model
from a sample of dev-A problems. Each round:
  1. run the incumbent org on dev-A; leave-one-out replay of each employee on up to --loo-n
     questions (cached calls make the unchanged prefix free); build the performance report
  2. the big model proposes K edit-op lists (hire, fire, rehire, edit_job, set_skills, add_skill,
     edit_skill, remove_skill, set_sop, remove_sop, set_handbook, set_default); invalid results go
     back to it once with the validation errors
  3. gate on dev-B: feasible = acc >= full-team acc - eps; best by (feasible, -cost) else
     (infeasible, acc); replaces the incumbent only if strictly better under the same ordering.
"""
import argparse
import copy
import json
import os
import re
import statistics
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

from .llm import LLM
from .org import FULL_TEAM, V0, apply_ops, check_plan, validate
from .mas import extract
from .orgexec import OrgExecutor
from .rsi import BIG, ROOT, bucket, cost, load


def load_items(dataset: str, split: str, lo: int, hi: int):
    """Items carry a report bucket and a 'hard' flag (GSM8K: 5+ steps; MATH: level 5)."""
    if dataset == "gsm8k":
        return [{**it, "bucket": bucket(it["steps"]), "hard": it["steps"] >= 5}
                for it in load(split, lo, hi)]
    import random
    rows = [json.loads(l) for l in open(os.path.join(ROOT, "data", "math", f"{split}.jsonl"))]
    rows = [r for r in rows if r["level"] in (4, 5)
            and re.fullmatch(r"-?\d+", r["answer"].replace(",", "").strip())]
    random.Random(0).shuffle(rows)
    return [{"id": r["unique_id"], "question": r["problem"], "gold": extract(r["answer"]),
             "bucket": f"{r['subject']} L{r['level']}", "hard": r["level"] == 5}
            for r in rows][lo:hi]

WORKERS = 128


def evaluate(ex, org, items, fixed=None):
    def one(it):
        if fixed is not None:
            plan, pre = check_plan(org, fixed)[0], []
        else:
            plan, hr_call = ex.hr(org, it["question"])
            pre = [hr_call]
        out = ex.run(org, it["question"], plan)
        calls = pre + out["calls"]
        return {**it, "plan": plan, "trace": out["trace"], "pred": out["answer"],
                "correct": out["answer"] == it["gold"], "calls": calls, "cost": cost(calls),
                "fallback": any(c.get("fallback") for c in calls),
                "hr_problems": next((c.get("problems") for c in calls if c.get("fallback")), None)}
    with ThreadPoolExecutor(WORKERS) as pool:
        return list(pool.map(one, items))


def summarize(rows):
    n = len(rows)
    hard = [r for r in rows if r["hard"]]
    return {"n": n, "acc": round(sum(r["correct"] for r in rows) / n, 4),
            "cost": round(sum(r["cost"] for r in rows) / n, 1),
            "acc_hard": round(sum(r["correct"] for r in hard) / max(1, len(hard)), 4),
            "sops": dict(Counter(r["plan"]["sop"] for r in rows)),
            "fallback": sum(r["fallback"] for r in rows)}


def attribution(ex, org, rows, n):
    """Leave-one-out: drop one employee from one stage of the executed plan and replay."""
    jobs = []
    for r in rows:
        ran = [(t["stage"], m) for t in r["trace"] if t["ran"] for m in t["members"]]
        if len(ran) < 2:
            continue
        first = r["trace"][0]
        for stage, m in ran:
            if stage == first["stage"] and len(first["members"]) == 1:
                continue      # removing the only first-stage worker leaves nothing to run
            jobs.append((r, stage, m))
    sel_ids = []
    for r, _, _ in jobs:
        if r["id"] not in sel_ids:
            sel_ids.append(r["id"])
    sel_ids = set(sel_ids[:n])
    jobs = [j for j in jobs if j[0]["id"] in sel_ids]

    def one(job):
        r, stage, m = job
        p = copy.deepcopy(r["plan"])
        p["assign"][stage] = [x for x in p["assign"][stage] if x != m]
        out = ex.run(org, r["question"], p)
        return {"id": r["id"], "bucket": r["bucket"], "sop": r["plan"]["sop"],
                "stage": stage, "name": m, "was": r["correct"],
                "now": out["answer"] == r["gold"], "saved": r["cost"] - cost(out["calls"]) -
                sum(c["gen_tokens"] + 0.25 * c["prompt_tokens"] for c in r["calls"]
                    if c["role"] == "hr")}
    with ThreadPoolExecutor(WORKERS) as pool:
        return list(pool.map(one, jobs)), len(sel_ids)


def plan_str(p):
    if p["sop"] == "self":
        return f"self (answered {p.get('answer')})"
    parts = []
    for st, ws in p["assign"].items():
        if ws:
            parts.append(f"{st}=[" + ", ".join(
                f"{w}:{p['thinking'].get(w, 'off')}" + (f"+{'/'.join(p['skills'][w])}"
                                                        if p["skills"].get(w) else "")
                for w in ws) + "]")
    g = "; ".join(f"{w}: \"{t}\"" for w, t in p["guide"].items())
    return f"{p['sop']} " + " ".join(parts) + (f" guide: {g}" if g else "")


def pct(xs):
    return f"{sum(xs) / len(xs):.0%}" if xs else "-"


def report(rows, ref, loo, loo_n) -> str:
    refd = {r["id"]: r for r in ref}
    s, sr = summarize(rows), summarize(ref)
    L = ["# Performance report (dev-A)", "",
         f"Organization: acc {s['acc']:.1%}, cost {s['cost']:.0f}/question. Full team: acc "
         f"{sr['acc']:.1%}, cost {sr['cost']:.0f}. Invalid HR outputs (default plan used): "
         f"{s['fallback']}.", "",
         "## By category",
         "| bucket | n | acc | team acc | cost | team cost | SOPs chosen |", "|---|---|---|---|---|---|---|"]
    by = defaultdict(list)
    for r in rows:
        by[r["bucket"]].append(r)
    for b in sorted(by):
        rs, rf = by[b], [refd[r["id"]] for r in by[b]]
        L.append(f"| {b} | {len(rs)} | {pct([r['correct'] for r in rs])} | "
                 f"{pct([r['correct'] for r in rf])} | {statistics.mean(r['cost'] for r in rs):.0f} | "
                 f"{statistics.mean(r['cost'] for r in rf):.0f} | "
                 + ", ".join(f"{k} {v}" for k, v in Counter(r['plan']['sop'] for r in rs).most_common())
                 + " |")
    L += ["", "## SOP stages (how often a stage ran, and whether it changed the running answer)",
          "| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |",
          "|---|---|---|---|---|---|"]
    st = defaultdict(lambda: [0, 0, 0, 0, 0])
    for r in rows:
        for t in r["trace"]:
            k = f"{r['plan']['sop']}.{t['stage']}"
            st[k][0] += 1
            if t["ran"]:
                st[k][1] += 1
                if t.get("prev_majority") is not None and t["majority"] != t["prev_majority"]:
                    st[k][2] += 1
                    st[k][3] += t["majority"] == r["gold"]
                    st[k][4] += t["prev_majority"] == r["gold"]
    for k, v in sorted(st.items()):
        L.append(f"| {k} | {v[0]} | {v[1]} | {v[2]} | {v[3]} | {v[4]} |")
    L += ["", f"## Employees: leave-one-out replay on {loo_n} multi-person questions",
          "Removing the employee from that stage and re-running: 'needed' = answer was right and "
          "becomes wrong; 'harmful' = answer was wrong and becomes right.",
          "| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |",
          "|---|---|---|---|---|---|"]
    emp = defaultdict(list)
    for x in loo:
        emp[x["name"]].append(x)
    for name, xs in sorted(emp.items()):
        need = sum(x["was"] and not x["now"] for x in xs)
        harm = sum(not x["was"] and x["now"] for x in xs)
        L.append(f"| {name} | {len(xs)} | {need} | {harm} | {len(xs) - need - harm} | "
                 f"{statistics.mean(x['saved'] for x in xs):.0f} |")
    nb = defaultdict(lambda: [0, 0])
    for x in loo:
        nb[(x["name"], x["bucket"])][0] += 1
        nb[(x["name"], x["bucket"])][1] += x["was"] and not x["now"]
    L.append("Needed / uses by difficulty: " + "; ".join(
        f"{n}@{b}: {v[1]}/{v[0]}" for (n, b), v in sorted(nb.items())))
    used = Counter(w for r in rows if r["plan"]["sop"] != "self" for ws in r["plan"]["assign"].values()
                   for w in set(ws))
    sk = Counter(k for r in rows if r["plan"]["sop"] != "self" for ks in r["plan"]["skills"].values()
                 for k in ks)
    L += ["", "## HR usage", "Employees assigned (questions): " +
          ", ".join(f"{k} {v}" for k, v in used.most_common()),
          "Skills switched on (times): " + (", ".join(f"{k} {v}" for k, v in sk.most_common())
                                            or "none"),
          "Guide notes written: " + str(sum(bool(r["plan"].get("guide")) for r in rows))]
    fb = [r for r in rows if r["fallback"]]
    if fb:
        L.append("Invalid HR outputs, first problems: " + "; ".join(
            str(r["hr_problems"]) for r in fb[:4]))
    bad = [r for r in rows if not r["correct"] and refd[r["id"]]["correct"]]
    L += ["", f"## Saved wrong: org failed, full team succeeded ({len(bad)})"]
    for r in bad[:10]:
        L.append(f"- [{r['bucket']}] {r['question'][:280]}\n  plan: {plan_str(r['plan'])}; "
                 f"answered {r['pred']}, correct {r['gold']}")
    L.append(f"\nBoth wrong: {sum(not r['correct'] and not refd[r['id']]['correct'] for r in rows)}.")
    rich = sorted([r for r in rows if r["correct"] and not r["fallback"]], key=lambda r: -r["cost"])[:5]
    L += ["", "## Most expensive correctly-solved questions (possible waste)"]
    for r in rich:
        L.append(f"- [{r['bucket']}, cost {r['cost']:.0f}] {r['question'][:180]}\n"
                 f"  plan: {plan_str(r['plan'])}")
    return "\n".join(L)


OPS_DOC = """Edit operations (a JSON list, applied in order):
{"op": "hire", "name": "unit_checker", "job": "<job description>", "skills": ["<skill id>"]}
{"op": "fire", "name": "<employee>"}            removes them from the roster (kept as alumni)
{"op": "rehire", "name": "<alumnus>"}
{"op": "edit_job", "name": "<employee>", "job": "<new job description>"}
{"op": "set_skills", "name": "<employee>", "skills": ["<skill id>", ...]}
{"op": "add_skill", "id": "<new_id>", "text": "<concrete how-to, <= 600 chars>", "to": ["<employee>"]}
{"op": "edit_skill", "id": "<id>", "text": "<new text>"}
{"op": "remove_skill", "id": "<id>"}
{"op": "set_sop", "id": "<sop id>", "sop": {"desc": "...", "stages": [{"id": "...", "task": "solve|review|decide", "when": ["always"], "sees": [], "show": "full|answer"}, ...]}}   adds or replaces
{"op": "remove_sop", "id": "<sop id>"}
{"op": "set_handbook", "text": "<the HR's complete dispatch rules>"}
{"op": "set_default", "plan": {"sop": "...", "assign": {...}, "thinking": {...}, "skills": {}, "guide": {}}}
Stage conditions ("when", OR-ed, evaluated on earlier stages by a rule engine, free):
always | disagree:<stage> (2+ members gave different answers) | unsure:<stage> (someone reported
low confidence or gave no answer) | missing:<stage> | long:<stage>:<tokens>. The first stage must be
["always"]; later stages must "see" at least one earlier stage. Limits: <= 8 staff, <= 8 SOPs,
<= 30 skills. The handbook must not mention fired employees. Employees end every answer with a
"Confidence: high|low" line."""

PROPOSE = """You run the organization design of a team of LLM agents (all the same 9B model) that solves
math problems. Per problem, an HR manager (the same 9B model, no reasoning, reads only the
problem text and its handbook) picks an SOP, assigns employees to its stages, sets their thinking
level, switches on some of their skills and may write each a short note.

Objective: minimize the average cost per problem while keeping accuracy within {eps:.0%} of the full
team's accuracy on held-out problems. Accuracy comes first.

You may change anything: hire and fire employees, give them skills (concrete how-to knowledge that
lives with the employee, so the HR handbook stays short), design SOPs that escalate only when a
runtime signal fires, and rewrite the HR's dispatch rules. Base each change on evidence in the
report (e.g. fire an employee whose leave-one-out removal never hurts; add a skill for a recurring
error; add an escalation stage where cheap plans fail). The HR is a small model: keep the handbook
short and decidable from the problem text alone.

{ops_doc}

# Current organization (JSON)
{org}

# Performance report
{report}

# Earlier attempts (dev-B gate; full team on dev-B: acc {ref_acc:.1%}, cost {ref_cost:.0f})
{history}

Think about what the evidence shows, then output a JSON list of edit operations between <ops> and
</ops>. {hint}"""

HINTS = ["", "Prefer changes that remove waste: staff, stages or thinking that the evidence shows "
             "do not change answers.",
         "Prefer changes that fix the 'saved wrong' failures, e.g. with skills or escalation stages."]

REPAIR = """Your output could not be used:
{errors}

Output the corrected complete JSON between <{tag}> and </{tag}>."""

FOUND = """Design the initial organization of a team of LLM agents (all the same 9B model) that will solve
problems like the samples below. Per problem, an HR manager (the same 9B model, no reasoning, reads
only the problem text and its handbook) picks an SOP, assigns employees to its stages, sets their
thinking level (off / low / high), switches on some of their skills and may write a short note.
Objective: high accuracy at low cost (cost = generated tokens).

Write: the roster (each employee's job description and skill ids), a library of concrete skills this
task needs, a few SOPs that escalate only when runtime signals fire, the HR's dispatch rules, and a
default plan used when the HR's output is invalid. Fired staff go in "alumni" (start empty).

{ops_doc}

# JSON format (this is an example organization, replace it with your own design)
{example}

# Sample problems
{samples}

Output the complete organization JSON between <org> and </org>."""


def big(llm, messages, thinking, seed, max_tokens):
    return llm.chat(BIG, messages, thinking=thinking, max_tokens=max_tokens, seed=seed).text


def ask_json(llm, prompt, tag, check, seed, max_tokens=4096):
    """Ask the big model for <tag>JSON</tag>; on failure send errors back once."""
    msgs = [{"role": "user", "content": prompt}]
    for attempt in range(2):
        txt = big(llm, msgs, "high", seed + attempt, max_tokens)
        m = re.search(rf"<{tag}>(.*?)</{tag}>", txt, re.S)
        try:
            obj = json.loads(m.group(1)) if m else None
            errs = ["no <%s> block" % tag] if obj is None else []
        except json.JSONDecodeError as e:
            obj, errs = None, [f"bad JSON: {e}"]
        if obj is not None:
            res, errs = check(obj)
            if not errs:
                return obj, res, attempt
        msgs += [{"role": "assistant", "content": txt},
                 {"role": "user", "content": REPAIR.format(errors="\n".join(errs[:15]), tag=tag)}]
    return None, None, 2


def ops_summary(ops):
    out = []
    for op in ops:
        k = op.get("op")
        if k in ("fire", "rehire"):
            out.append(f"{k} {op.get('name')}")
        elif k == "set_handbook":
            out.append("set_handbook:\n    " + str(op.get("text", "")).replace("\n", "\n    "))
        else:
            out.append(json.dumps(op)[:300])
    return "\n  ".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--eps", type=float, default=0.02)
    ap.add_argument("--init", choices=["hand", "found"], default="hand")
    ap.add_argument("--dataset", choices=["gsm8k", "math"], default="gsm8k")
    ap.add_argument("--n-dev-a", type=int, default=200)
    ap.add_argument("--n-dev-b", type=int, default=300)
    ap.add_argument("--n-test", type=int, default=300)
    ap.add_argument("--loo-n", type=int, default=80)
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "orgrsi", "gsm8k_hand"))
    ap.add_argument("--skip-test", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    llm = LLM()
    ex = OrgExecutor(llm)
    dev_a = load_items(a.dataset, "train", 0, a.n_dev_a)
    dev_b = load_items(a.dataset, "train", a.n_dev_a, a.n_dev_a + a.n_dev_b)
    test = load_items(a.dataset, "test", 0, a.n_test)

    def log(msg):
        print(msg, flush=True)
        with open(os.path.join(a.out, "log.txt"), "a") as f:
            f.write(msg + "\n")

    def dump(name, obj):
        os.makedirs(os.path.dirname(os.path.join(a.out, name)), exist_ok=True)
        with open(os.path.join(a.out, name), "w") as f:
            f.write(obj if isinstance(obj, str) else json.dumps(obj, indent=1))

    with ThreadPoolExecutor(2) as pool:
        ref_a, ref_b = pool.map(lambda xs: evaluate(ex, V0, xs, FULL_TEAM), [dev_a, dev_b])
    sa, sb = summarize(ref_a), summarize(ref_b)
    floor = sb["acc"] - a.eps
    log(f"full team: dev-A {sa}\n           dev-B {sb}\n           floor on dev-B {floor:.3f}")

    if a.init == "hand":
        org = copy.deepcopy(V0)
    else:
        samples = "\n".join(f"- {it['question']}" for it in dev_a[:30])
        org, _, tries = ask_json(llm, FOUND.format(ops_doc=OPS_DOC, example=json.dumps(V0, indent=1),
                                                   samples=samples), "org",
                                 lambda o: (None, validate(o)), seed=7, max_tokens=6000)
        if org is None:
            raise SystemExit("founding failed: the big model did not produce a valid organization")
        log(f"founded organization (repair attempts: {tries})")
    org0 = copy.deepcopy(org)
    dump("round_0/org.json", org)

    def key(s):
        return (1, -s["cost"]) if s["acc"] >= floor else (0, s["acc"])

    inc_b = summarize(evaluate(ex, org, dev_b))
    log(f"round 0 incumbent dev-B {inc_b}")
    history = [f"round 0 (initial organization): dev-B acc {inc_b['acc']:.1%}, cost "
               f"{inc_b['cost']:.0f}"]
    trace = [{"round": 0, "accepted": True, "dev_b": inc_b}]

    for t in range(1, a.rounds + 1):
        d = f"round_{t}"
        rows_a = evaluate(ex, org, dev_a)
        loo, loo_n = attribution(ex, org, rows_a, a.loo_n)
        rep = report(rows_a, ref_a, loo, loo_n)
        dump(f"{d}/org.json", org)
        dump(f"{d}/report.md", rep)
        log(f"round {t}: incumbent dev-A {summarize(rows_a)}; leave-one-out replays {len(loo)}")

        def propose(i):
            prompt = PROPOSE.format(eps=a.eps, ops_doc=OPS_DOC, org=json.dumps(org, indent=1),
                                    report=rep, history="\n".join(history), ref_acc=sb["acc"],
                                    ref_cost=sb["cost"], hint=HINTS[i % len(HINTS)])
            ops, new, tries = ask_json(llm, prompt, "ops", lambda o: apply_ops(org, o),
                                       seed=1000 * t + 10 * i)
            return {"ops": ops, "org": new, "repairs": tries}
        with ThreadPoolExecutor(a.k) as pool:
            cands = list(pool.map(propose, range(a.k)))
        valid = [c for c in cands if c["org"] is not None]
        with ThreadPoolExecutor(len(valid) or 1) as pool:
            gated = list(pool.map(lambda c: summarize(evaluate(ex, c["org"], dev_b)), valid))
        for c, g in zip(valid, gated):
            c["dev_b"] = g
        for i, c in enumerate(cands):
            log(f"  cand {i}: " + (f"invalid after repair" if c["org"] is None else
                                   f"{len(c['ops'])} ops, repairs {c['repairs']}, dev-B {c['dev_b']}"))
        best = max(valid, key=lambda c: key(c["dev_b"])) if valid else None
        accepted = best is not None and key(best["dev_b"]) > key(inc_b)
        for c in cands:
            if c["org"] is None:
                history.append(f"round {t} [invalid]")
                continue
            status = "ACCEPTED" if c is best and accepted else "rejected by gate"
            history.append(f"round {t} [{status}]: dev-B acc {c['dev_b']['acc']:.1%}, cost "
                           f"{c['dev_b']['cost']:.0f}, invalid HR outputs {c['dev_b']['fallback']}\n"
                           f"  {ops_summary(c['ops'])}")
        dump(f"{d}/candidates.json", [{k: v for k, v in c.items() if k != "org"} for c in cands])
        if accepted:
            org, inc_b = best["org"], best["dev_b"]
        trace.append({"round": t, "accepted": accepted, "dev_b": inc_b})
        log(f"round {t}: {'accepted' if accepted else 'no change'}; incumbent dev-B {inc_b}")
        dump("trace.json", trace)

    dump("final_org.json", org)
    if not a.skip_test:
        jobs = {"full_team": (V0, FULL_TEAM), "org_round0": (org0, None), "org_final": (org, None)}
        with ThreadPoolExecutor(3) as pool:
            res = dict(zip(jobs, pool.map(lambda j: summarize(evaluate(ex, j[0], test, j[1])),
                                          jobs.values())))
        dump("test.json", res)
        log(f"TEST: {json.dumps(res)}")


if __name__ == "__main__":
    main()
