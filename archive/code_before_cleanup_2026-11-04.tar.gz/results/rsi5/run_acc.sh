#!/bin/bash
# v5 (minimal: employees + HR handbook; HR writes the architecture as code), accuracy-first objective
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
~/miniconda3/envs/tinker/bin/python -m mashr.rsi5 --dataset math --init design --objective acc \
  --rounds 5 --k 3 --n-dev-a 150 --n-dev-b 200 --n-test 156 --loo-n 60 --out results/rsi5/math_acc \
  > results/rsi5/math_acc.out 2>&1
