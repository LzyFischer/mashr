# Performance report (dev-A)

HR system: acc 96.0%, cost 4431 tokens/question. Full team: acc 97.5%, cost 13799. Invalid HR outputs (fell back to full team): 3.

## By difficulty (number of calculation steps in the reference solution)
| bucket | n | HR acc | team acc | HR cost | team cost | HR modes |
|---|---|---|---|---|---|---|
| 1-2 steps | 64 | 95% | 98% | 2935 | 12034 | single 43, team 19, self 2 |
| 3-4 steps | 89 | 96% | 98% | 4275 | 13702 | team 51, single 37, self 1 |
| 5-6 steps | 41 | 98% | 95% | 6597 | 16046 | team 30, single 11 |
| 7+ steps | 6 | 100% | 100% | 7912 | 18708 | team 5, single 1 |

## By HR decision
| decision | n | acc | mean cost |
|---|---|---|---|
| self | 3 | 33% | 234 |
| single thinking=low | 87 | 97% | 1892 |
| single thinking=off | 5 | 100% | 621 |
| team | 105 | 97% | 6836 |

## Saved wrong: HR plan failed, full team succeeded (4 questions)
- [3-4 steps] Rachel and Sara want to attend a beauty and modeling contest. They both want to buy new pairs of shoes and dresses. Sara buys a pair of shoes which costs $50 and a dress which costs $200. How much should Rachel budget if she wants to spend twice as much as what Sara spent on the pair of shoes and dr
  plan: self (answered 400); answered 400, correct 500
- [1-2 steps] Ellie has found an old bicycle in a field and thinks it just needs some oil to work well again.  She needs 10ml of oil to fix each wheel and will need another 5ml of oil to fix the rest of the bike. How much oil does she need in total to fix the bike?
  plan: self (answered 15); answered 15, correct 25
- [1-2 steps] Dan owns an ice cream shop and every sixth customer gets a free ice cream cone. Cones cost $2 each. If he sold $100 worth of cones, how many free ones did he give away?
  plan: single solver_B thinking=low; answered 6, correct 10
- [3-4 steps] A cleaning company produces two sanitizer sprays. One spray kills 50% of germs, and another spray kills 25% of germs. However, 5% of the germs they kill are the same ones. What percentage of germs would be left after using both sanitizer sprays together?
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:off, critic[2]:low, judge[2]:off] stop_if_consensus=False; answered 28.57, correct 30

Both HR and full team wrong: 4 questions (likely beyond the team).

## Most expensive correctly-solved questions (possible waste)
- [5-6 steps, cost 20141] Gail has two fish tanks. The first tank is twice the size of the second tank. There are 48 gallons of water in the first tank. She follows the rule of one gallon of water per inch of fish. If she keep
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 19760] Daniel has a collection of 346 video games. 80 of them, Daniel bought for $12 each. Of the rest, 50% were bought for $7. All others had a price of $3 each. How much did Daniel spend on all the games i
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [3-4 steps, cost 14969] Ariella has $200 more in her son's saving account than Daniella has in her son's savings account. Ariella's account earns her simple interest at the rate of 10% per annum. If Daniella has $400, how mu
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 13352] Madeline has 5 boxes with 24 crayons in each. She noticed that 5/8 of the crayons in the 2 boxes were not yet used. In the 2 other boxes, only 2/3 of the crayons were used while the last box was not e
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:off, critic[2]:low, judge:off] stop_if_consensus=False
- [3-4 steps, cost 11186] Conner has a dune buggy that he rides in the desert.  On flat sand, it can ride at a speed of 60 miles per hour.  When traveling on downhill slopes, it can race at 12 miles per hour faster than it can
  plan: team [solver_A[1]:off, solver_B[1, 2]:high, solver_C[1]:off, critic[2]:low, judge[2]:off] stop_if_consensus=False
- [7+ steps, cost 10910] In a section of the forest, there are 100 weasels and 50 rabbits. Three foxes invade this region and hunt the rodents. Each fox catches an average of 4 weasels and 2 rabbits per week. How many rabbits
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:off, critic[2]:low, judge:off] stop_if_consensus=False