# Diagnostic report (dev-A)

Organization: acc 75.0%, cost 4642/question (4279 generated, 1811 prompt tokens; cost = generated + 0.2 x prompt, including the orchestrator's). Full system: acc 83.3%, cost 17182. Orchestrator prompt 4696 chars, thinking off; 4 distinct architectures. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 4 | 100% | 100% | 3705 | 13214 | solver 3, solver>checker?L1>judge? 1 |
| Algebra L5 | 1 | 100% | 100% | 4119 | 16885 | solver 1 |
| Counting & Probability L5 | 1 | 100% | 100% | 4429 | 16333 | solver 1 |
| Intermediate Algebra L4 | 1 | 100% | 100% | 4768 | 17150 | solver>checker?L1>judge? 1 |
| Intermediate Algebra L5 | 2 | 50% | 50% | 6314 | 23837 | solver>checker?L1>judge 1, solver>checker?L1>judge? 1 |
| Prealgebra L4 | 1 | 100% | 100% | 3137 | 11068 | solver 1 |
| Prealgebra L5 | 1 | 0% | 0% | 5698 | 23481 | solver>checker?L1>judge? 1 |
| Precalculus L5 | 1 | 0% | 100% | 6101 | 20738 | solver>checker?>judge? 1 |

## First stages (staffing): accuracy of their answer
| first stage | uses | answer correct | mean cost |
|---|---|---|---|
| solver:low+cot/reread/verify | 10 | 70% | 3984 |
| solver:low+cot/cases/reread/verify | 1 | 100% | 5187 |
| solver:low+cot/cases/reread/confidence | 1 | 100% | 4101 |

## Later stages (function and condition): how often they ran and changed the answer
| stage | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| check if shaky (loop 1) | 5 | 0 | 0 | 0 | 0 | 0 |
| decide if disagree | 3 | 0 | 0 | 0 | 0 | 0 |
| decide if always | 1 | 1 | 0 | 0 | 0 | 1352 |
| decide if disagree or fail or missing or tool_error or unsure | 1 | 0 | 0 | 0 | 0 | 0 |
| check if shaky | 1 | 0 | 0 | 0 | 0 | 0 |
| decide if shaky | 1 | 0 | 0 | 0 | 0 | 0 |

## Signals after the first stage (12 questions, 3 with a wrong answer at that point)
fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 0 | 0% | 0% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 0 | 0% | 0% |
| agree < 1 | 0 | 0% | 0% |
| agree < 0.67 | 0 | 0% | 0% |
| tokens > 1000 | 12 | 25% | 100% |
| tokens > 2000 | 12 | 25% | 100% |
| tokens > 4000 | 6 | 50% | 100% |
| [shaky] fail or disagree or missing or tool_error or unsure | 0 | 0% | 0% |
| [hard] fail or disagree or missing or tool_error or unsure or tokens > 2000 | 12 | 25% | 100% |

## Leave-one-out replay on 1 questions with 2+ nodes that ran
Remove the employee from that stage (agent@function<stage>) or the whole stage, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| stage 3 decide | 1 | 0 | 0 | 1 | 1352 |

## Orchestrator usage
Architectures: solver 6, solver>checker?L1>judge? 4, solver>checker?L1>judge 1, solver>checker?>judge? 1
Employees: solver 12, checker 6, judge 6; never staffed: coder
Thinking: low 20, off 4
Skills switched on: reread 18, verify 17, cot 12, python_check 6, cases 2, confidence 1; never: pot, react
Conditions: always 13, shaky 7, disagree 3, disagree or fail or missing or tool_error or unsure 1
Copies > 1: 0; debate rounds > 1: 0; check loops: 5
Invalid outputs: repaired 1, asked again 1 (valid on the 2nd try: 1), fixed fallback 0 (acc -).
Most common problems: unexpected end of 'agree'; using 'always' (1)

## Organization wrong, full system right (1)
- [Precalculus L5] Let $\omega$ be a nonreal root of $x^3 = 1,$ and let
\[\mathbf{M} = \begin{pmatrix} -\omega^2 & - \omega \\ 1 & 0 \end{pmatrix}.\]Find the sum of the entries of $\mathbf{M} + \mathbf{M}^2 + \mathbf{M}^3 + \dots + \mathbf{M}^{2009}.$
  plan: produce[solver:low+cot/reread/verify] > check if shaky[checker:low+python_check/reread/verify] > decide if shaky[judge:off]; answered 2, correct 4018

Both wrong: 2.

## Most expensive correct questions (possible waste)
- [Intermediate Algebra L5, cost 7007] During the car ride home, Michael looks back at his recent math exams. A problem on Michael's calculus mid-term gets him starting thinking about a particular quadratic,\[x^2-sx+p,\
  plan: produce[solver:low+cot/cases/reread/verify] > check if shaky (loop 1)[checker:low+python_check/reread/verify] > decide (sees none)[judge:off]
- [Intermediate Algebra L4, cost 4768] If $x + \frac{1}{x} = 5,$ then compute the value of
\[(x - 2)^2 + \frac{25}{(x - 2)^2}.\]
  plan: produce[solver:low+cot/reread/verify] > check if shaky (loop 1)[checker:low+python_check/reread/verify] > decide if disagree[judge:off]
- [Counting & Probability L5, cost 4429] My school's Physics Club has 22 members.  It needs to select 3 officers: chairman, vice-chairman, and sergeant-at-arms.  Each person can hold at most one office.  Two of the member
  plan: produce[solver:low+cot/cases/reread/confidence]
- [Algebra L4, cost 4321] A line with slope equal to $1$ and a line with slope equal to $2$ intersect at the point $P(1,6),$ as shown. [asy]
unitsize(0.5 cm);
draw((0,-1)--(0,10),EndArrow);
draw((-10,0)--(5
  plan: produce[solver:low+cot/reread/verify] > check if shaky (loop 1)[checker:low+python_check/reread/verify] > decide if disagree[judge:low]
- [Algebra L4, cost 4163] Solve for $Q$ if $\sqrt{Q^3} = 16\sqrt[8]{16}$.
  plan: produce[solver:low+cot/reread/verify]