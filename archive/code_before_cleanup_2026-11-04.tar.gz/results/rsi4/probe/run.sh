#!/bin/bash
# orchestrator-only probe of the v4 prompt on 350 train questions, for two organizations
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
P=~/miniconda3/envs/tinker/bin/python
$P -m mashr.orchprobe results/rsi4/smoke/round_0/pool.json --n 350 > results/rsi4/probe/designed_v4.txt 2>&1
$P -c "import json;from mashr.org4 import HAND;json.dump(HAND,open('results/rsi4/probe/hand.json','w'),indent=1)"
$P -m mashr.orchprobe results/rsi4/probe/hand.json --n 350 > results/rsi4/probe/hand_v4.txt 2>&1
echo DONE > results/rsi4/probe/done
