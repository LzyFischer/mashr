# Performance report (dev-A)

HR system: acc 95.5%, cost 5727 tokens/question. Full team: acc 97.5%, cost 13799. Invalid HR outputs (fell back to full team): 0.

## By difficulty (number of calculation steps in the reference solution)
| bucket | n | HR acc | team acc | HR cost | team cost | HR modes |
|---|---|---|---|---|---|---|
| 1-2 steps | 64 | 95% | 98% | 3801 | 12034 | single 34, team 29, self 1 |
| 3-4 steps | 89 | 96% | 98% | 5567 | 13702 | team 57, single 31, self 1 |
| 5-6 steps | 41 | 95% | 95% | 8287 | 16046 | team 36, single 5 |
| 7+ steps | 6 | 100% | 100% | 11152 | 18708 | team 6 |

## By HR decision
| decision | n | acc | mean cost |
|---|---|---|---|
| self | 2 | 0% | 209 |
| single thinking=low | 67 | 99% | 1742 |
| single thinking=off | 3 | 100% | 535 |
| team | 128 | 95% | 8021 |

## Saved wrong: HR plan failed, full team succeeded (5 questions)
- [3-4 steps] James writes a 3-page letter to 2 different friends twice a week.  How many pages does he write a year?
  plan: self (answered 3120); answered 3120, correct 624
- [1-2 steps] Four classmates were comparing their ages based on their birth month. They found out that Jolyn is 2 months older than Therese while Therese is 5 months older than Aivo. Then, Leon is 2 months older than Aivo. How much older in months is Jolyn than Leon?
  plan: self (answered 3); answered 3, correct 5
- [1-2 steps] Dan owns an ice cream shop and every sixth customer gets a free ice cream cone. Cones cost $2 each. If he sold $100 worth of cones, how many free ones did he give away?
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, critic[2]:off, judge:off] stop_if_consensus=False; answered 9, correct 10
- [3-4 steps] A cleaning company produces two sanitizer sprays. One spray kills 50% of germs, and another spray kills 25% of germs. However, 5% of the germs they kill are the same ones. What percentage of germs would be left after using both sanitizer sprays together?
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:off, critic[2]:low, judge:off] stop_if_consensus=False; answered 28.57, correct 30
- [5-6 steps] Madeline has 5 boxes with 24 crayons in each. She noticed that 5/8 of the crayons in the 2 boxes were not yet used. In the 2 other boxes, only 2/3 of the crayons were used while the last box was not entirely used. How many unused crayons did Madeline have?
  plan: team [solver_A[1]:off, solver_B[1]:low, solver_C[1]:low, critic[2]:low, judge:off] stop_if_consensus=False; answered 4, correct 70

Both HR and full team wrong: 4 questions (likely beyond the team).

## Most expensive correctly-solved questions (possible waste)
- [7+ steps, cost 12954] In a section of the forest, there are 100 weasels and 50 rabbits. Three foxes invade this region and hunt the rodents. Each fox catches an average of 4 weasels and 2 rabbits per week. How many rabbits
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 12737] Daniel has a collection of 346 video games. 80 of them, Daniel bought for $12 each. Of the rest, 50% were bought for $7. All others had a price of $3 each. How much did Daniel spend on all the games i
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 12712] Rosie runs 6 miles per hour. She runs for 1 hour on Monday, 30 minutes on Tuesday, 1 hour on Wednesday, and 20 minutes on Thursday. If she wants to run 20 miles for the week, how many minutes should s
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 12664] James creates a media empire.  He creates a movie for $2000.  Each DVD cost $6 to make.  He sells it for 2.5 times that much.  He sells 500 movies a day for 5 days a week.  How much profit does he mak
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 12514] Gail has two fish tanks. The first tank is twice the size of the second tank. There are 48 gallons of water in the first tank. She follows the rule of one gallon of water per inch of fish. If she keep
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [7+ steps, cost 12496] Alice has 20 quarters. She wants to exchange them for nickels and so she goes to the bank. After getting back from the bank, she discovers that 20% of the nickels are iron nickels worth $3 each. What 
  plan: team [solver_A[1]:off, solver_B[1, 2]:low, solver_C[1]:low, critic[2]:low, judge:off] stop_if_consensus=False