"""Employees and the plan executor.

A plan (the HR's structured output) is one of
  {"mode": "self",   "answer": "..."}                                  HR answers itself
  {"mode": "single", "agent": "solver_B", "thinking": "low"}           one employee answers
  {"mode": "team",   "agents": {name: {"rounds": [1, 2], "thinking": "off", "message": "full"},
                                "judge": {"thinking": "off"}},
   "stop_if_consensus": true}
In a team, round-1 solvers work independently; in round r > 1 every scheduled agent sees the
messages of the agents active in round r-1 ("full" = their written solution, "conclusion" = only
their answer). The judge, if present, reads the last round and gives the final answer; otherwise
the last round's answers are majority-voted.
"""
import re
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

MODEL = "Qwen/Qwen3.5-9B"
ANSWER_FMT = "End your response with a final line of the form '#### <number>'."

ROLES = {
    "solver_A": "You are a math solver. Solve the problem directly and concisely.",
    "solver_B": "You are a careful math solver. Solve the problem step by step, then double-check "
                "each arithmetic step before giving the answer.",
    "solver_C": "You are a math solver who prefers algebra. Define variables, write equations for "
                "the problem, and solve them.",
    "critic": "You are a critic. Check the given solutions for errors in reasoning or arithmetic, "
              "say which one (if any) is correct, and give the answer you believe is correct.",
    "judge": "You are the judge. Read the team's solutions and decide the single correct final "
             "answer. Briefly justify the choice.",
}
SOLVERS = ["solver_A", "solver_B", "solver_C"]
FULL_TEAM = {"mode": "team", "stop_if_consensus": False, "agents": {
    **{s: {"rounds": [1, 2], "thinking": "low", "message": "full"} for s in SOLVERS},
    "critic": {"rounds": [2], "thinking": "low", "message": "full"},
    "judge": {"thinking": "off"}}}


def extract(text: str) -> str | None:
    m = re.findall(r"####\s*\$?\s*(-?[\d,]*\.?\d+)", text)
    if not m:
        m = re.findall(r"\\boxed\{\s*\$?(-?[\d,]*\.?\d+)", text) or re.findall(r"-?[\d,]*\.?\d+", text)
    if not m:
        return None
    s = m[-1].replace(",", "")
    try:
        f = float(s)
        return str(int(f)) if f == int(f) else str(f)
    except ValueError:
        return None


def majority(answers: list) -> str | None:
    answers = [a for a in answers if a is not None]
    return Counter(answers).most_common(1)[0][0] if answers else None


class Executor:
    def __init__(self, llm, model: str = MODEL, seed: int = 0):
        self.llm, self.model, self.seed = llm, model, seed

    def _call(self, role, user, thinking, log):
        r = self.llm.chat(self.model, [{"role": "system", "content": ROLES[role]},
                                       {"role": "user", "content": user}],
                          thinking=thinking, max_tokens=1024, seed=self.seed)
        log.append({"role": role, "thinking": thinking, "prompt_tokens": r.prompt_tokens,
                    "gen_tokens": r.gen_tokens, "cached": r.cached, "answer": extract(r.text)})
        return r.text

    def run(self, question: str, plan: dict) -> dict:
        log: list = []
        mode = plan["mode"]
        if mode == "self":
            return {"answer": extract(str(plan.get("answer", ""))), "calls": log, "rounds": 0}
        if mode == "single":
            agent = plan.get("agent", "solver_A")
            agent = agent if agent in SOLVERS else "solver_A"
            text = self._call(agent, f"Problem: {question}\n\n{ANSWER_FMT}",
                              plan.get("thinking", "off"), log)
            return {"answer": extract(text), "calls": log, "rounds": 1}

        agents = {k: v for k, v in plan["agents"].items() if k in ROLES and k != "judge"}
        last = max([r for v in agents.values() for r in v.get("rounds", [])] or [0])
        prev: dict = {}       # agent -> (message text, answer) from the previous round
        rounds_run = 0
        for r in range(1, last + 1):
            active = [a for a, v in agents.items() if r in v.get("rounds", [])]
            if not active:
                continue
            rounds_run = r

            def work(a):
                spec = agents[a]
                if not prev:
                    user = f"Problem: {question}\n\n{ANSWER_FMT}"
                else:
                    shown = "\n\n".join(
                        f"[{b}]\n" + (t if agents[b].get("message", "full") == "full"
                                      else f"Final answer: {ans}")
                        for b, (t, ans) in prev.items() if b != a)
                    task = ("Review these solutions." if a == "critic" else
                            "Consider the other solutions and give your updated solution.")
                    user = f"Problem: {question}\n\nTeam messages:\n{shown}\n\n{task} {ANSWER_FMT}"
                text = self._call(a, user, spec.get("thinking", "off"), log)
                return text, extract(text)
            # agents within a round are independent: call them concurrently
            with ThreadPoolExecutor(len(active)) as pool:
                cur = dict(zip(active, pool.map(work, active)))
            prev = cur
            ans = [v[1] for v in cur.values()]
            if (r == 1 and plan.get("stop_if_consensus") and len(ans) >= 2
                    and None not in ans and len(set(ans)) == 1):
                return {"answer": ans[0], "calls": log, "rounds": r, "early_stop": True}
        if "judge" in plan["agents"] and prev:
            shown = "\n\n".join(f"[{b}]\n{t}" for b, (t, _) in prev.items())
            text = self._call("judge", f"Problem: {question}\n\nTeam solutions:\n{shown}\n\n{ANSWER_FMT}",
                              plan["agents"]["judge"].get("thinking", "off"), log)
            final = extract(text)
        else:
            final = majority([v[1] for v in prev.values()])
        return {"answer": final, "calls": log, "rounds": rounds_run}
