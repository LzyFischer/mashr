"""Slow loop v3: the designer edits the whole organization, rule layer included (blocks.py).

  P=~/miniconda3/envs/tinker/bin/python
  set -a; source ~/.config/hrsi/tinker.env; set +a
  $P -m mashr.search --dataset math --init design --out results/search/math_design

Same protocol as optimize.py: dev-A run + leave-one-out (drop one agent from a step, or one whole
later step) -> diagnostic report -> K proposals of edit operations -> dev-B gate (feasible = acc >=
full-system acc - eps; cheapest feasible wins; must beat the incumbent). The report adds what the
rule layer needs: per-block effect, and how well each runtime signal (and each named condition)
predicts that the answer after the first step is wrong. The full-system reference is the same as
optimize.py's (cascade.py, V0, FULL), so its calls are shared through the cache.
"""
import argparse
import copy
import json
import os
import statistics
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

from .blocks import BASELINES, BOOL_SIGNALS, HAND, KINDS, LIMITS, apply_ops, check_plan, \
    compile_conditions, eval_cond, orchestrator_prompt, plan_str, shape, validate
from .cascade import Cascade
from .engine import PROMPT_WEIGHT, Engine, cost
from .llm import LLM
from .optimize import HINTS, ask_json, ops_summary, pct
from .optimize import evaluate as evaluate_ref
from .optimize import summarize as summarize_ref
from .orgrsi import load_items
from .pool import FULL, V0
from .rsi import ROOT

WORKERS = 128


def evaluate(eng, pool, items, plan=None):
    def one(it):
        if plan is not None:
            p, call = plan, None
        else:
            p, call = eng.orchestrate(pool, it["question"])
        out = eng.run(pool, it["question"], p)
        calls = ([call] if call else []) + out["calls"]
        return {**it, "plan": p, "trace": out["trace"], "probe": out["probe"], "pred": out["answer"],
                "correct": out["answer"] == it["gold"], "calls": calls, "cost": cost(calls),
                "gen_tokens": sum(c["gen_tokens"] for c in calls),
                "prompt_tokens": sum(c["prompt_tokens"] for c in calls),
                "invalid": bool(call and call["invalid"]),
                "problems": call["problems"] if call and call["invalid"] else None}
    with ThreadPoolExecutor(WORKERS) as ex:
        return list(ex.map(one, items))


def summarize(rows):
    n = len(rows)
    hard = [r for r in rows if r["hard"]]
    return {"n": n, "acc": round(sum(r["correct"] for r in rows) / n, 4),
            "cost": round(sum(r["cost"] for r in rows) / n, 1),
            "gen_tokens": round(sum(r["gen_tokens"] for r in rows) / n, 1),
            "prompt_tokens": round(sum(r["prompt_tokens"] for r in rows) / n, 1),
            "acc_hard": round(sum(r["correct"] for r in hard) / max(1, len(hard)), 4),
            "shapes": dict(Counter(shape(r["plan"]) for r in rows).most_common(6)),
            "invalid": sum(r.get("invalid", False) for r in rows)}


def leave_one_out(eng, pool, rows, n):
    """Drop one agent from a step that ran (if others remain in it), or one whole later step."""
    jobs, seen = [], []
    for r in rows:
        steps = r["plan"]["steps"]
        ran = [t["step"] for t in r["trace"] if t["ran"] and not t.get("exit")]
        if sum(len(steps[i]["agents"]) for i in ran) < 2:
            continue
        if len(seen) >= n:
            break
        seen.append(r["id"])
        for i in ran:
            if len(steps[i]["agents"]) > 1:
                jobs += [(r, i, a) for a in steps[i]["agents"]]
            if i > 0:
                jobs.append((r, i, None))

    def one(job):
        r, i, a = job
        p = copy.deepcopy(r["plan"])
        st = p["steps"][i]
        if a is None:
            del p["steps"][i]
        else:
            del st["agents"][a]
        out = eng.run(pool, r["question"], p)
        own = cost([c for c in r["calls"] if c["agent"] != "orchestrator"])
        return {"where": (f"{a}@{st['block']}{i + 1}" if a else
                          f"step {st['block']}{i + 1}" + ("" if st["if"] == "always"
                                                          else f" if {st['if']}")),
                "was": r["correct"], "now": out["answer"] == r["gold"],
                "saved": own - cost(out["calls"])}
    with ThreadPoolExecutor(WORKERS) as ex:
        return list(ex.map(one, jobs)), len(seen)


PROBES = [(s, f"{s}") for s in BOOL_SIGNALS] + [
    ("agree < 1", ("agree", 1.0)), ("agree < 0.67", ("agree", 0.67)),
    ("tokens > 1000", ("tokens", 1000)), ("tokens > 2000", ("tokens", 2000)),
    ("tokens > 4000", ("tokens", 4000))]


def report(rows, ref, loo, loo_n, pool) -> str:
    refd = {r["id"]: r for r in ref}
    s, sr = summarize(rows), summarize_ref(ref)
    o = pool["orchestrator"]
    L = ["# Diagnostic report (dev-A)", "",
         f"Pool: acc {s['acc']:.1%}, cost {s['cost']:.0f}/question ({s['gen_tokens']:.0f} generated, "
         f"{s['prompt_tokens']:.0f} prompt tokens; cost = generated + {PROMPT_WEIGHT} x prompt). "
         f"Full system: acc {sr['acc']:.1%}, cost {sr['cost']:.0f}. Orchestrator: mode {o['mode']}"
         + (f", prompt {len(orchestrator_prompt(pool))} chars, invalid outputs {s['invalid']}"
            if o["mode"] == "llm" else f", recipe {o['recipe']}") + f". Final rule: {pool['final']}.",
         "", "## By category", "| category | n | acc | full acc | cost | full cost | architectures |",
         "|---|---|---|---|---|---|---|"]
    by = defaultdict(list)
    for r in rows:
        by[r["bucket"]].append(r)
    for b in sorted(by):
        rs, rf = by[b], [refd[r["id"]] for r in by[b]]
        L.append(f"| {b} | {len(rs)} | {pct([r['correct'] for r in rs])} | "
                 f"{pct([r['correct'] for r in rf])} | {statistics.mean(r['cost'] for r in rs):.0f}"
                 f" | {statistics.mean(r['cost'] for r in rf):.0f} | "
                 + ", ".join(f"{k} {v}" for k, v in Counter(shape(r['plan']) for r in rs).most_common(3))
                 + " |")
    first = defaultdict(lambda: [0, 0, []])
    later = defaultdict(lambda: [0, 0, 0, 0, 0, []])
    for r in rows:
        for t in r["trace"]:
            st = r["plan"]["steps"][t["step"]]
            if t["step"] == 0:
                f = first[st["block"]]
                f[0] += 1
                f[1] += t["current"] == r["gold"]
                f[2].append(t["cost"])
                continue
            g = later[f"{st['block']} if {st['if']}"]
            g[0] += 1
            if t["ran"]:
                g[1] += 1
                g[5].append(t.get("cost", 0))
                if t["before"] is not None and t["current"] != t["before"]:
                    g[2] += 1
                    g[3] += t["current"] == r["gold"]
                    g[4] += t["before"] == r["gold"]
    L += ["", "## First steps (by block): accuracy of their answer",
          "| block | uses | answer correct | mean cost |", "|---|---|---|---|"]
    for k, v in sorted(first.items()):
        L.append(f"| {k} | {v[0]} | {v[1] / v[0]:.0%} | {statistics.mean(v[2]):.0f} |")
    L += ["", "## Later steps (block and condition): how often they ran and changed the answer",
          "| step | planned | ran | changed answer | to correct | to wrong | mean cost when ran |",
          "|---|---|---|---|---|---|---|"]
    for k, v in sorted(later.items()):
        L.append(f"| {k} | {v[0]} | {v[1]} | {v[2]} | {v[3]} | {v[4]} | "
                 f"{statistics.mean(v[5]) if v[5] else 0:.0f} |")
    # signal quality: state after the first step, every question
    wrong = [r["probe"]["current"] != r["gold"] for r in rows]
    conds = compile_conditions(pool)[0]
    tests = [(name, (lambda sig, s=sp: sig[s] if isinstance(s, str) else
                     (sig[s[0]] < s[1] if s[0] == "agree" else sig[s[0]] > s[1])))
             for name, sp in PROBES]
    tests += [(f"[{k}] {pool['conditions'][k]}", (lambda sig, c=c: eval_cond(c, sig)))
              for k, c in conds.items()]
    L += ["", f"## Signals after the first step ({len(rows)} questions, "
              f"{sum(wrong)} with a wrong answer at that point)",
          "Would this signal/condition catch the wrong first answers? fires = how often it holds; "
          "precision = share of firings where the answer was wrong; recall = share of wrong answers "
          "it fires on.", "| signal / condition | fires | precision | recall |", "|---|---|---|---|"]
    for name, fn in tests:
        fire = [fn(r["probe"]["signals"]) for r in rows]
        tp = sum(f and w for f, w in zip(fire, wrong))
        L.append(f"| {name} | {sum(fire)} | {tp / sum(fire) if sum(fire) else 0:.0%} | "
                 f"{tp / sum(wrong) if sum(wrong) else 0:.0%} |")
    L += ["", f"## Leave-one-out replay on {loo_n} questions with 2+ agent turns",
          "Remove the agent from that step (agent@block<step>) or the whole step, and re-run: "
          "'needed' = right becomes wrong; 'harmful' = wrong becomes right.",
          "| removed | uses | needed | harmful | no effect | mean cost saved |",
          "|---|---|---|---|---|---|"]
    g = defaultdict(list)
    for x in loo:
        g[x["where"]].append(x)
    for k, xs in sorted(g.items()):
        need = sum(x["was"] and not x["now"] for x in xs)
        harm = sum(not x["was"] and x["now"] for x in xs)
        L.append(f"| {k} | {len(xs)} | {need} | {harm} | {len(xs) - need - harm} | "
                 f"{statistics.mean(x['saved'] for x in xs):.0f} |")
    steps = [st for r in rows for st in r["plan"]["steps"]]
    used = Counter(a for st in steps for a in st["agents"])
    sk = Counter(x for st in steps for v in st["agents"].values() for x in v["skills"])
    bl = Counter(st["block"] for st in steps)
    cn = Counter(st["if"] for st in steps)
    L += ["", "## Orchestrator usage",
          "Recipes picked: " + (", ".join(f"{k} {v}" for k, v in Counter(
              r["plan"].get("recipe", "(own steps)") for r in rows).most_common()) or "none"),
          "Architectures: " + ", ".join(f"{k} {v}" for k, v in
                                         Counter(shape(r["plan"]) for r in rows).most_common(8)),
          "Blocks: " + ", ".join(f"{k} {v}" for k, v in bl.most_common())
          + "; never used: " + (", ".join(x for x in pool["blocks"] if x not in bl) or "none"),
          "Conditions: " + ", ".join(f"{k} {v}" for k, v in cn.most_common()),
          "Agent assignments: " + ", ".join(f"{k} {v}" for k, v in used.most_common()),
          "Skills switched on: " + (", ".join(f"{k} {v}" for k, v in sk.most_common()) or "none"),
          "Skills never switched on: " + (", ".join(x for x in pool["skills"] if x not in sk)
                                          or "none")]
    inv = [r for r in rows if r.get("invalid")]
    if inv:
        L.append("Invalid outputs, first problems: " + "; ".join(str(r["problems"]) for r in inv[:4]))
    bad = [r for r in rows if not r["correct"] and refd[r["id"]]["correct"]]
    L += ["", f"## Pool wrong, full system right ({len(bad)})"]
    for r in bad[:10]:
        L.append(f"- [{r['bucket']}] {r['question'][:280]}\n  plan: {plan_str(r['plan'])}; "
                 f"answered {r['pred']}, correct {r['gold']}")
    L.append(f"\nBoth wrong: {sum(not r['correct'] and not refd[r['id']]['correct'] for r in rows)}.")
    rich = sorted([r for r in rows if r["correct"]], key=lambda r: -r["cost"])[:5]
    L += ["", "## Most expensive correct questions (possible waste)"]
    for r in rich:
        L.append(f"- [{r['bucket']}, cost {r['cost']:.0f}] {r['question'][:180]}\n"
                 f"  plan: {plan_str(r['plan'])}")
    return "\n".join(L)


SYSTEM_DOC = f"""The organization (all agents and the orchestrator are the same 9B model):
- agents (name -> role, skills) and a library of skills (how-to texts an agent can switch on);
- the rule layer, which you may also change:
  * blocks: the building blocks a workflow is made of. A block = a kind + your instruction + params.
    Kinds and params (defaults):
      solve  {KINDS['solve']}   each agent answers n times; sees "earlier" = after reading earlier
             work; tool k = may run Python k times (program-of-thought with tool 1 and a "write a
             program" instruction; ReAct with tool > 1); n > 1 = self-consistency
      debate {KINDS['debate']}   from round 2 agents read all last outputs and revise; stops when
             all agree
      review {KINDS['review']}   agents check the earlier work, VERDICT PASS/FAIL + their answer
      refine {KINDS['refine']}   evaluator-optimizer / Reflexion: first agent drafts (or takes the
             latest output with the current answer), second (or the same) critiques; FAIL -> revise
      decide {KINDS['decide']}   agents pick the final answer from the earlier work
      exit   {{}}   stop the flow when its condition holds
    show: how the block's outputs appear to later steps (full text or only the answer).
  * conditions: named expressions that gate later steps, over free runtime signals: disagree
    (answers so far differ or one is missing), missing, unsure (an output said 'Confidence: low';
    only blocks with confidence: true ask for it), fail (a check said FAIL), tool_error, agree (share
    of answers equal to the current one, 0-1), answers, tokens (most generated tokens of one call in
    the last step), steps; operators and/or/not, <, <=, >, >=, ==, !=, parentheses. A condition may
    use conditions defined before it.
  * recipes: named plans {{"steps": [{{"block": id, "agents": {{agent: {{"thinking": "off|low|high",
    "skills": [ids]}}}}, "if": condition}}, ...]}}; the first step always runs and must be a solve,
    debate or refine block; at most {LIMITS['steps']} steps, {LIMITS['agents_per_step']} agents per
    step, {LIMITS['calls']} model calls per plan.
  * orchestrator: mode "llm" (the 9B reads its prompt and the problem and picks a recipe or writes
    steps; its prompt is paid on every problem) or "fixed" (always the given recipe, no orchestrator
    call); fallback = recipe used when its output is invalid; thinking off|low.
  * final: "last" (answer of the last step that ran) or "vote" (majority of all answers).
  * policy: the orchestrator's dispatch rules (unused in fixed mode).
Thinking budgets: off ~200 generated tokens per call; low up to ~1000 extra; high up to ~4000 extra."""

OPS_DOC = f"""Edit operations (a JSON list, applied in order):
{{"op": "add_agent", "name": "<name>", "role": "<role, <= {LIMITS['role_chars']} chars>", "skills": ["<id>"]}}
{{"op": "remove_agent", "name": "<agent>"}}
{{"op": "edit_role", "name": "<agent>", "role": "<new role>"}}
{{"op": "set_skills", "name": "<agent>", "skills": ["<id>", ...]}}
{{"op": "add_skill", "id": "<new_id>", "text": "<general how-to, <= {LIMITS['skill_chars']} chars>", "to": ["<agent>"]}}
{{"op": "edit_skill", "id": "<id>", "text": "<new text>"}}
{{"op": "remove_skill", "id": "<id>"}}
{{"op": "add_block", "id": "<new_id>", "block": {{"kind": "<kind>", "instruction": "<text>", ...params}}}}
{{"op": "edit_block", "id": "<id>", "block": {{<the complete new block>}}}}
{{"op": "remove_block", "id": "<id>"}}
{{"op": "set_condition", "name": "<name>", "expr": "<expression>"}}
{{"op": "remove_condition", "name": "<name>"}}
{{"op": "set_recipe", "name": "<name>", "plan": {{"steps": [...]}}}}
{{"op": "remove_recipe", "name": "<name>"}}
{{"op": "set_orchestrator", "mode": "llm|fixed", "recipe": "<name>", "fallback": "<name>", "thinking": "off|low"}}
{{"op": "set_final", "rule": "last|vote"}}
{{"op": "set_policy", "text": "<the complete dispatch policy, <= {LIMITS['policy_chars']} chars>"}}
Limits: <= {LIMITS['agents']} agents, {LIMITS['skills']} skills ({LIMITS['skills_per_agent']} per agent), {LIMITS['blocks']} blocks, {LIMITS['conditions']} conditions, {LIMITS['recipes']} recipes.
Recipes must stay valid after your edits (e.g. update recipes that use an agent or block you remove).
The policy must not mention removed agents, blocks or recipes."""

PROPOSE = """You design a multi-agent system of LLM agents that solves math problems, including its
rules: which building blocks exist, when later steps run, how the orchestrator works and how the final
answer is chosen.

{system_doc}

Objective: minimize the average cost per problem (generated tokens + 0.2 x prompt tokens, including the
orchestrator's) while keeping accuracy within {eps:.0%} of the full system on held-out problems.
Accuracy comes first.

Base each change on evidence in the report. Examples of what the evidence can support: a signal or
condition with high precision and useful recall is a good gate for an escalation step, and one with
low precision wastes calls; a later step that changes answers to wrong as often as to correct should
go or get a different block; a first-step block with low accuracy on some categories may need a
stronger block (more thinking, self-consistency, a program) there; agents whose removal never hurts
can go; if routing does not pay for the orchestrator's prompt, a fixed recipe may be cheaper. Skills
must be general techniques for error patterns that recur across several problems, not solutions to
specific problems. Prefer few, decisive changes over many small ones.

{ops_doc}

# Current organization (JSON)
{pool}

# Diagnostic report
{report}

# Earlier attempts (dev-B gate; full system on dev-B: acc {ref_acc:.1%}, cost {ref_cost:.0f})
{history}

Think about what the evidence shows, then output a JSON list of edit operations between <ops> and
</ops>. {hint}"""

DESIGN = """Design the initial multi-agent system of LLM agents that will solve problems like the samples
below, including its rules.

{system_doc}

Objective: high accuracy at low cost (generated tokens + 0.2 x prompt tokens, including the
orchestrator's). The building blocks of agentic-workflow libraries (I/O, chain-of-thought,
self-consistency, program-of-thought, ReAct, debate, review/verify, evaluator-optimizer/Reflexion,
ensemble/decide, early exit) are all expressible as blocks; keep only what this task needs.

# JSON format (an example organization; replace it with your own design)
{example}

# Sample problems
{samples}

Output the complete organization JSON between <pool> and </pool>."""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=["gsm8k", "math"], default="math")
    ap.add_argument("--init", choices=["hand", "design"], default="design")
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--eps", type=float, default=0.02)
    ap.add_argument("--n-dev-a", type=int, default=150)
    ap.add_argument("--n-dev-b", type=int, default=200)
    ap.add_argument("--n-test", type=int, default=156)
    ap.add_argument("--loo-n", type=int, default=60)
    ap.add_argument("--baselines", default=",".join(BASELINES),
                    help="fixed architectures on HAND evaluated on test ('' for none)")
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "search", "math_design"))
    ap.add_argument("--skip-test", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    llm = LLM()
    eng, cas = Engine(llm), Cascade(llm)
    dev_a = load_items(a.dataset, "train", 0, a.n_dev_a)
    dev_b = load_items(a.dataset, "train", a.n_dev_a, a.n_dev_a + a.n_dev_b)
    test = load_items(a.dataset, "test", 0, a.n_test)

    def log(msg):
        print(msg, flush=True)
        with open(os.path.join(a.out, "log.txt"), "a") as f:
            f.write(msg + "\n")

    def dump(name, obj):
        path = os.path.join(a.out, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(obj if isinstance(obj, str) else json.dumps(obj, indent=1))

    with ThreadPoolExecutor(2) as ex:
        ref_a, ref_b = ex.map(lambda xs: evaluate_ref(cas, V0, xs, FULL), [dev_a, dev_b])
    sa, sb = summarize_ref(ref_a), summarize_ref(ref_b)
    floor = sb["acc"] - a.eps
    log(f"full system: dev-A {sa}\n             dev-B {sb}\n             floor on dev-B {floor:.3f}")

    if a.init == "hand":
        pool = copy.deepcopy(HAND)
    else:
        samples = "\n".join(f"- {it['question']}" for it in dev_a[:30])
        pool, _, tries = ask_json(llm, DESIGN.format(system_doc=SYSTEM_DOC,
                                                     example=json.dumps(HAND, indent=1),
                                                     samples=samples), "pool",
                                  lambda o: (None, validate(o)), seed=7, max_tokens=8000)
        if pool is None:
            raise SystemExit("initial design failed: no valid pool after repair")
        log(f"designed initial pool (repair attempts: {tries})")
    pool0 = copy.deepcopy(pool)
    dump("round_0/pool.json", pool)

    def key(s):
        return (1, -s["cost"]) if s["acc"] >= floor else (0, s["acc"])

    inc_b = summarize(evaluate(eng, pool, dev_b))
    log(f"round 0 incumbent dev-B {inc_b}")
    history = [f"round 0 (initial organization): dev-B acc {inc_b['acc']:.1%}, "
               f"cost {inc_b['cost']:.0f}"]
    trace = [{"round": 0, "accepted": True, "dev_b": inc_b}]

    for t in range(1, a.rounds + 1):
        d = f"round_{t}"
        rows_a = evaluate(eng, pool, dev_a)
        loo, loo_n = leave_one_out(eng, pool, rows_a, a.loo_n)
        rep = report(rows_a, ref_a, loo, loo_n, pool)
        dump(f"{d}/pool.json", pool)
        dump(f"{d}/report.md", rep)
        log(f"round {t}: incumbent dev-A {summarize(rows_a)}; leave-one-out replays {len(loo)}")

        def propose(i):
            prompt = PROPOSE.format(system_doc=SYSTEM_DOC, eps=a.eps, ops_doc=OPS_DOC,
                                    pool=json.dumps(pool, indent=1), report=rep,
                                    history="\n".join(history), ref_acc=sb["acc"],
                                    ref_cost=sb["cost"], hint=HINTS[i % len(HINTS)])
            ops, new, tries = ask_json(llm, prompt, "ops", lambda o: apply_ops(pool, o),
                                       seed=1000 * t + 10 * i, max_tokens=6000)
            return {"ops": ops, "pool": new, "repairs": tries}
        with ThreadPoolExecutor(a.k) as ex:
            cands = list(ex.map(propose, range(a.k)))
        valid = [c for c in cands if c["pool"] is not None]
        with ThreadPoolExecutor(len(valid) or 1) as ex:
            gated = list(ex.map(lambda c: summarize(evaluate(eng, c["pool"], dev_b)), valid))
        for c, g in zip(valid, gated):
            c["dev_b"] = g
        for i, c in enumerate(cands):
            log(f"  cand {i}: " + ("invalid after repair" if c["pool"] is None else
                                   f"{len(c['ops'])} ops, repairs {c['repairs']}, dev-B {c['dev_b']}"))
        best = max(valid, key=lambda c: key(c["dev_b"])) if valid else None
        accepted = best is not None and key(best["dev_b"]) > key(inc_b)
        for c in cands:
            if c["pool"] is None:
                history.append(f"round {t} [invalid]")
                continue
            status = "ACCEPTED" if c is best and accepted else "rejected by gate"
            history.append(f"round {t} [{status}]: dev-B acc {c['dev_b']['acc']:.1%}, "
                           f"cost {c['dev_b']['cost']:.0f}, invalid outputs "
                           f"{c['dev_b']['invalid']}\n  {ops_summary(c['ops'])}")
        dump(f"{d}/candidates.json", [{k: v for k, v in c.items() if k != "pool"} for c in cands])
        if accepted:
            pool, inc_b = best["pool"], best["dev_b"]
        trace.append({"round": t, "accepted": accepted, "dev_b": inc_b})
        log(f"round {t}: {'accepted' if accepted else 'no change'}; incumbent dev-B {inc_b}")
        dump("trace.json", trace)

    dump("final_pool.json", pool)
    if not a.skip_test:
        jobs = {"full_system": lambda: summarize_ref(evaluate_ref(cas, V0, test, FULL)),
                "pool_round0": lambda: summarize(evaluate(eng, pool0, test)),
                "pool_final": lambda: summarize(evaluate(eng, pool, test))}
        for name in filter(None, a.baselines.split(",")):
            jobs[name] = lambda p=check_plan(HAND, BASELINES[name])[0]: summarize(
                evaluate(eng, HAND, test, p))
        with ThreadPoolExecutor(len(jobs)) as ex:
            res = dict(zip(jobs, ex.map(lambda f: f(), jobs.values())))
        dump("test.json", res)
        log(f"TEST: {json.dumps(res)}")


if __name__ == "__main__":
    main()
