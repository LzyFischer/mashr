#!/bin/bash
# v6 full runs, one benchmark at a time on the single local GPU (phase 1: accuracy)
cd ~/project/mas-hr
for ds in math aflow_math gsmhard aime; do
  results/rsi6/run.sh "$ds" "${ds}_acc" --objective acc --rounds 5 --k 3 --loo-n 60
done
