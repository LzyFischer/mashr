# Performance report (dev-A)

Organization: acc 92.0%, cost 13082/question. Full team: acc 91.3%, cost 27271. Invalid HR outputs (default plan used): 2.

## By category
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 6161 | 19590 | vote 7, hard 3, check 3, self 2, solo 2 |
| Algebra L5 | 18 | 89% | 100% | 7783 | 23083 | vote 8, check 4, hard 3, self 2, solo 1 |
| Counting & Probability L4 | 8 | 88% | 100% | 6078 | 22644 | vote 7, self 1 |
| Counting & Probability L5 | 9 | 89% | 89% | 11832 | 32029 | vote 8, check 1 |
| Geometry L4 | 5 | 100% | 100% | 12881 | 24771 | check 3, hard 2 |
| Geometry L5 | 7 | 71% | 57% | 33913 | 39998 | hard 7 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 17295 | 28859 | hard 7, vote 5, check 2 |
| Intermediate Algebra L5 | 17 | 82% | 71% | 22449 | 36267 | hard 9, vote 5, check 2, self 1 |
| Number Theory L4 | 9 | 100% | 100% | 7600 | 26425 | vote 7, check 1, solo 1 |
| Number Theory L5 | 16 | 100% | 88% | 9051 | 29063 | vote 14, solo 1, check 1 |
| Prealgebra L4 | 12 | 92% | 100% | 4322 | 15420 | vote 9, self 1, solo 1, check 1 |
| Prealgebra L5 | 9 | 100% | 100% | 14088 | 26009 | vote 5, hard 3, solo 1 |
| Precalculus L4 | 3 | 100% | 67% | 21371 | 31364 | hard 2, vote 1 |
| Precalculus L5 | 6 | 67% | 83% | 30141 | 38717 | hard 4, vote 2 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| check.check | 18 | 1 | 1 | 1 | 0 |
| check.draft | 18 | 18 | 0 | 0 | 0 |
| hard.r1 | 40 | 40 | 0 | 0 | 0 |
| hard.r2 | 40 | 40 | 12 | 10 | 1 |
| hard.r3 | 40 | 4 | 4 | 1 | 2 |
| solo.draft | 7 | 7 | 0 | 0 | 0 |
| vote.r1 | 78 | 78 | 0 | 0 | 0 |
| vote.r2 | 78 | 11 | 7 | 4 | 0 |
| vote.r3 | 78 | 3 | 3 | 1 | 0 |

## Employees: leave-one-out replay on 60 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| critic | 24 | 1 | 0 | 23 | 6603 |
| judge | 2 | 0 | 1 | 1 | 5945 |
| solver_A | 30 | 0 | 0 | 30 | 3646 |
| solver_B | 76 | 0 | 2 | 74 | 4844 |
| solver_C | 54 | 0 | 1 | 53 | 4116 |
Needed / uses by difficulty: critic@Algebra L4: 0/3; critic@Algebra L5: 0/2; critic@Counting & Probability L5: 0/1; critic@Geometry L4: 0/1; critic@Geometry L5: 0/1; critic@Intermediate Algebra L4: 0/3; critic@Intermediate Algebra L5: 0/7; critic@Prealgebra L5: 0/3; critic@Precalculus L5: 1/3; judge@Counting & Probability L5: 0/1; judge@Geometry L5: 0/1; solver_A@Algebra L4: 0/5; solver_A@Algebra L5: 0/3; solver_A@Counting & Probability L5: 0/2; solver_A@Geometry L4: 0/1; solver_A@Geometry L5: 0/1; solver_A@Intermediate Algebra L4: 0/3; solver_A@Intermediate Algebra L5: 0/5; solver_A@Number Theory L5: 0/1; solver_A@Prealgebra L4: 0/2; solver_A@Prealgebra L5: 0/4; solver_A@Precalculus L4: 0/1; solver_A@Precalculus L5: 0/2; solver_B@Algebra L4: 0/9; solver_B@Algebra L5: 0/7; solver_B@Counting & Probability L4: 0/3; solver_B@Counting & Probability L5: 0/5; solver_B@Geometry L4: 0/2; solver_B@Geometry L5: 0/2; solver_B@Intermediate Algebra L4: 0/9; solver_B@Intermediate Algebra L5: 0/12; solver_B@Number Theory L4: 0/4; solver_B@Number Theory L5: 0/8; solver_B@Prealgebra L4: 0/2; solver_B@Prealgebra L5: 0/7; solver_B@Precalculus L4: 0/1; solver_B@Precalculus L5: 0/5; solver_C@Algebra L4: 0/6; solver_C@Algebra L5: 0/4; solver_C@Counting & Probability L4: 0/3; solver_C@Counting & Probability L5: 0/3; solver_C@Geometry L4: 0/1; solver_C@Geometry L5: 0/1; solver_C@Intermediate Algebra L4: 0/6; solver_C@Intermediate Algebra L5: 0/7; solver_C@Number Theory L4: 0/4; solver_C@Number Theory L5: 0/7; solver_C@Prealgebra L4: 0/4; solver_C@Prealgebra L5: 0/5; solver_C@Precalculus L5: 0/3

## HR usage
Employees assigned (questions): solver_B 167, critic 135, judge 118, solver_C 111, solver_A 62
Skills switched on (times): reread_question 538, final_form 474, verify_by_substitution 178, check_units 112, diagram_coordinates 89, subtract_from 74, coordinate_max_area 56, near_power_count 50, common_roots_diff 43, region_perimeter 42, percent_base 37, roots_unity_count 36, complex_equilateral 32
Guide notes written: 140
Invalid HR outputs, first problems: ["bad JSON: Expecting ',' delimiter: line 67 column 4 (char 1329)"]; ["bad JSON: Expecting ',' delimiter: line 71 column 4 (char 1601)"]

## Saved wrong: org failed, full team succeeded (6)
- [Algebra L5] In the line $4x+7y+c=0$, the sum of the $x$- and $y$- intercepts is $22$. Find $c$.
  plan: self (answered -154); answered -154, correct -56
- [Intermediate Algebra L5] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  plan: self (answered 19); answered 19, correct 96
- [Prealgebra L4] The arithmetic mean of eight positive integers is 7. If one of the eight integers is removed, the mean becomes 6. What is the value of the integer that is removed?
  plan: self (answered 8); answered 8, correct 14
- [Algebra L5] The first term of a geometric sequence is 729, and the 7th term is 64. What is the positive, real value for the 5th term?
  plan: self (answered 243); answered 243, correct 144
- [Precalculus L5] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection = perspective(6,3,2);

triple A, B, C, D, E, F, G, H;

A = (1,1,0);
B = (1,-1,0);
C = (-1,-1,0);
D 
  plan: hard r1=[solver_A:low+diagram_coordinates/coordinate_max_area/reread_question/final_form, solver_B:high+diagram_coordinates/coordinate_max_area/reread_question/final_form, solver_C:low+diagram_coordinates/coordinate_max_area/reread_question/final_form] r2=[critic:high+diagram_coordinates/coordinate_max_area/reread_question/final_form/verify_by_substitution, solver_B:high+diagram_coordinates/coordinate_max_area/reread_question/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Double-check arithmetic in coordinate calculations and area summation."; critic: "Verify vertex coordinates satisfy both plane and prism constraints; check area formula."; solver_C: "Derive equations for intersection lines, find vertices, calculate area algebraically."; judge: "Select the most consistent and correctly calculated maximal area."; solver_A: "Find intersection polygon area by determining vertices from plane and prism boundaries."; answered 9, correct 225
- [Counting & Probability L4] In how many ways can the digits of $45,\!520$ be arranged to form a 5-digit number?  (Remember, numbers cannot begin with 0.)
  plan: self (answered 2160); answered 2160, correct 48

Both wrong: 6.

## Most expensive correctly-solved questions (possible waste)
- [Precalculus L5, cost 41434] Find the number of ordered quadruples $(a,b,c,d)$ of real numbers such that
\[\begin{pmatrix} a & b \\ c & d \end{pmatrix}^2 = \begin{pmatrix} c & a \\ d & b \end{pmatrix}.\]
  plan: hard r1=[solver_A:low+reread_question/final_form, solver_B:high+check_units/final_form, solver_C:low+reread_question/final_form] r2=[critic:high+reread_question/verify_by_substitution/final_form, solver_B:high+check_units/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Re-verify algebraic steps, check for missed cases, confirm units/forms."; critic: "Check logic of derived equations, verify arithmetic, ensure no extraneous roots."; solver_C: "Define variables, use algebraic manipulation, verify solutions."; judge: "Select correct count from verified solutions, ensure exact integer form."; solver_A: "Solve matrix equation directly, check constraints, simplify final count."
- [Geometry L5, cost 37534] Given a point $P$ on a triangular piece of paper $ABC,\,$ consider the creases that are formed in the paper when $A, B,\,$ and $C\,$ are folded onto $P.\,$ Let us call $P$ a fold p
  plan: hard r1=[solver_A:low+reread_question/region_perimeter/coordinate_max_area/final_form, solver_B:high+reread_question/region_perimeter/coordinate_max_area/check_units/final_form, solver_C:low+reread_question/region_perimeter/coordinate_max_area/final_form] r2=[critic:high+reread_question/region_perimeter/coordinate_max_area/final_form, solver_B:high+reread_question/region_perimeter/coordinate_max_area/check_units/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Double check coordinate geometry and integration limits."; critic: "Check all steps for logic errors and arithmetic accuracy."; solver_C: "Derive area formula, simplify to q*pi - r*sqrt(s)."; judge: "Select final answer, verify form q+r+s."; solver_A: "Model triangle, find locus of non-intersecting creases, compute area."
- [Intermediate Algebra L5, cost 37399] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes th
  plan: hard r1=[solver_A:low+reread_question/coordinate_max_area/diagram_coordinates/final_form, solver_B:high+reread_question/coordinate_max_area/diagram_coordinates/final_form, solver_C:low+reread_question/coordinate_max_area/diagram_coordinates/final_form] r2=[critic:high+reread_question/coordinate_max_area/verify_by_substitution/final_form, solver_B:high+reread_question/coordinate_max_area/diagram_coordinates/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Re-verify the critical point calculation and second derivative test."; critic: "Check all intersection logic and ensure area formula is correct before passing to judge."; solver_C: "Double-check algebraic simplification of the area function and its maximum."; judge: "Select the maximum valid area value and format as requested."; solver_A: "Model rotating lines, find intersection coordinates as functions of angle, compute area, maximize."
- [Intermediate Algebra L4, cost 35273] Find the largest constant $m,$ so that for any positive real numbers $a,$ $b,$ $c,$ and $d,$
\[\sqrt{\frac{a}{b + c + d}} + \sqrt{\frac{b}{a + c + d}} + \sqrt{\frac{c}{a + b + d}} 
  plan: hard r1=[solver_A:low+reread_question/final_form, solver_B:high+reread_question/final_form, solver_C:low+reread_question/final_form] r2=[critic:high+reread_question/final_form, solver_B:high+reread_question/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Re-evaluate the solution for tightness and potential counterexamples."; critic: "Check logic, arithmetic, and confirm if the bound is tight (approached as variables vary)."; solver_C: "Define variables, use inequalities, and verify the final form matches the constant."; judge: "Select the largest constant m proven or approached, ensuring exact form."; solver_A: "Solve directly, checking for standard inequality bounds like Holder or Cauchy-Schwarz."
- [Precalculus L4, cost 35212] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\
  plan: hard r1=[solver_A:low+reread_question/coordinate_max_area/final_form, solver_B:high+reread_question/final_form, solver_C:low+reread_question/roots_unity_count/coordinate_max_area/final_form] r2=[critic:high+reread_question/verify_by_substitution/final_form, solver_B:high+reread_question/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Double-check unit consistency and arithmetic. Verify final integer sum."; critic: "Check logic of root exclusion. Verify arithmetic in area summation. Ensure simplest form."; solver_C: "Define vertices explicitly. Use symmetry to simplify area calculation. Check final form constraints."; judge: "Select best answer. Ensure form matches (a+b*sqrt(c))/d. Sum a+b+c+d."; solver_A: "Identify roots as 8th roots of unity excluding -1. Calculate area via shoelace or decomposition."