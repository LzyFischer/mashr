"""Transfer test: organizations learned by RSI on MATH (integer L4-5), evaluated without further RSI on
AIME 2022-2025, GSM-Hard and AFlow's MATH Level 5 test split.

Systems: MAS-HR with the final organization, MAS-HR with the round-0 organization (no RSI), and the
single-solver max baseline (no HR). Numeric sets are graded by numeric equality (relative 1e-4);
AFlow MATH asks for an exact final answer and is graded with math-verify (after the run, in the main
thread). Writes results/transfer/<dataset>.json (summaries) and <dataset>_rows.jsonl (per question).

  PYTHONPATH=. $P results/transfer/run.py aime gsmhard aflow_math
"""
import json
import os
import re
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

from mashr.engine import cost
from mashr.exec5 import Engine
from mashr.llm import LLM
from mashr.mas import extract
from mashr.org5 import HAND, parse_program, shape

OUT = "results/transfer"
POOLS = {"mashr_final": "results/rsi5/math_acc/final_pool.json",
         "mashr_round0": "results/rsi5/math_acc/round_0/pool.json"}
SYM_FMT = ("End your response with a final line of the form '#### <final answer>', giving the final "
           "answer in simplest exact form (LaTeX is fine).")
WORKERS = 128


def extract_sym(text):
    if text is None:
        return None
    if "####" in text:
        a = text.rsplit("####", 1)[1].strip().splitlines()[0] if text.rsplit("####", 1)[1].strip() \
            else ""
    else:
        m = re.findall(r"\\boxed\{(.*)\}", text)
        a = m[-1] if m else (text.strip().splitlines()[-1] if text.strip() else "")
    a = a.strip().rstrip(".").strip().strip("$").rstrip(".").strip()
    return a or None


def grade_num(pred, gold):
    try:
        p, g = float(pred), float(gold)
    except (TypeError, ValueError):
        return False
    return abs(p - g) <= 1e-4 * max(1.0, abs(g))


def grade_sym(pred, gold):
    from math_verify import parse, verify
    if pred is None:
        return False
    if pred.replace(" ", "") == str(gold).replace(" ", ""):
        return True
    try:
        return bool(verify(parse(f"${gold}$"), parse(f"${pred}$")))
    except Exception:
        return False


def run_system(eng, pool, items, plan=None):
    def one(it):
        if plan is not None:
            p, pre, info = plan, [], {"retried": False, "fallback": False}
        else:
            p, pre, info = eng.orchestrate(pool, it["question"])
        out = eng.run(pool, it["question"], p)
        calls = pre + out["calls"]
        return {"id": it["id"], "pred": out["answer"], "cost": round(cost(calls), 1),
                "hr_cost": round(cost(pre), 1), "shape": shape(p), "nodes": len(p["nodes"]),
                "fallback": info["fallback"]}
    with ThreadPoolExecutor(WORKERS) as ex:
        return list(ex.map(one, items))


def summarize(rows, items, mask=None):
    sel = [(r, it) for r, it in zip(rows, items) if mask is None or mask(it)]
    n = len(sel)
    by = defaultdict(list)
    for r, it in sel:
        by[it["bucket"]].append(r["correct"])
    return {"n": n, "acc": round(sum(r["correct"] for r, _ in sel) / n, 4),
            "cost": round(sum(r["cost"] for r, _ in sel) / n, 1),
            "hr_cost": round(sum(r["hr_cost"] for r, _ in sel) / n, 1),
            "nodes": round(sum(r["nodes"] for r, _ in sel) / n, 2),
            "fallback": sum(r["fallback"] for r, _ in sel),
            "by_bucket": {b: round(sum(v) / len(v), 3) for b, v in sorted(by.items())}}


def main():
    llm = LLM()
    for ds in sys.argv[1:]:
        items = [json.loads(l) for l in open(f"data/transfer/{ds}.jsonl")]
        sym = ds == "aflow_math"
        eng = Engine(llm, answer_fmt=SYM_FMT, extract_fn=extract_sym) if sym else Engine(llm)
        grade = grade_sym if sym else grade_num
        jobs = {k: (json.load(open(v)), None) for k, v in POOLS.items()}
        jobs["single_max"] = (HAND, parse_program(HAND, 'a = solver("max")\nreturn a')[0])
        with ThreadPoolExecutor(len(jobs)) as ex:
            res = dict(zip(jobs, ex.map(lambda j: run_system(eng, j[0], items, j[1]),
                                        jobs.values())))
        summary = {}
        with open(f"{OUT}/{ds}_rows.jsonl", "w") as f:
            for name, rows in res.items():
                for r, it in zip(rows, items):
                    r["correct"] = grade(r["pred"], it["gold"])
                    f.write(json.dumps({"system": name, **r, "gold": it["gold"]}) + "\n")
                summary[name] = {"all": summarize(rows, items)}
                if sym:
                    summary[name]["excluding_dev_overlap"] = summarize(rows, items,
                                                                       lambda it: not it["in_dev"])
                if ds == "gsmhard":
                    summary[name]["integer_gold_only"] = summarize(rows, items,
                                                                   lambda it: it["integer_gold"])
                print(ds, name, {k: {kk: vv for kk, vv in v.items() if kk != "by_bucket"}
                                 for k, v in summary[name].items()}, flush=True)
        json.dump(summary, open(f"{OUT}/{ds}.json", "w"), indent=1)


if __name__ == "__main__":
    main()
