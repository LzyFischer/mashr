# Performance report (dev-A)

HR system: acc 96.0%, cost 4045 tokens/question. Full team: acc 97.5%, cost 13799. Invalid HR outputs (fell back to full team): 6.

## By difficulty (number of calculation steps in the reference solution)
| bucket | n | HR acc | team acc | HR cost | team cost | HR modes |
|---|---|---|---|---|---|---|
| 1-2 steps | 64 | 97% | 98% | 1991 | 12034 | single 46, team 17, self 1 |
| 3-4 steps | 89 | 97% | 98% | 3612 | 13702 | team 53, single 36 |
| 5-6 steps | 41 | 95% | 95% | 7323 | 16046 | team 35, single 6 |
| 7+ steps | 6 | 83% | 100% | 9960 | 18708 | team 5, single 1 |

## By HR decision
| decision | n | acc | mean cost |
|---|---|---|---|
| self | 1 | 0% | 258 |
| single thinking=low | 7 | 100% | 2285 |
| single thinking=off | 82 | 96% | 651 |
| team | 110 | 96% | 6721 |

## Saved wrong: HR plan failed, full team succeeded (4 questions)
- [1-2 steps] Alexis is applying for a new job and bought a new set of business clothes to wear to the interview. She went to a department store with a budget of $200 and spent $30 on a button-up shirt, $46 on suit pants, $38 on a suit coat, $11 on socks, and $18 on a belt. She also purchased a pair of shoes, but
  plan: self (answered 67); answered 67, correct 41
- [3-4 steps] A cleaning company produces two sanitizer sprays. One spray kills 50% of germs, and another spray kills 25% of germs. However, 5% of the germs they kill are the same ones. What percentage of germs would be left after using both sanitizer sprays together?
  plan: team [solver_A[1]:off, solver_B[1]:low, solver_C[1]:off, critic[2]:low, judge:off] stop_if_consensus=False; answered 28.57, correct 30
- [5-6 steps] Madeline has 5 boxes with 24 crayons in each. She noticed that 5/8 of the crayons in the 2 boxes were not yet used. In the 2 other boxes, only 2/3 of the crayons were used while the last box was not entirely used. How many unused crayons did Madeline have?
  plan: team [solver_A[1]:off, solver_B[1]:low, solver_C[1]:off, critic[2]:low, judge:off] stop_if_consensus=False; answered 1, correct 70
- [7+ steps] In a section of the forest, there are 100 weasels and 50 rabbits. Three foxes invade this region and hunt the rodents. Each fox catches an average of 4 weasels and 2 rabbits per week. How many rabbits and weasels will be left after 3 weeks?
  plan: single solver_B thinking=off; answered 64, correct 96

Both HR and full team wrong: 4 questions (likely beyond the team).

## Most expensive correctly-solved questions (possible waste)
- [5-6 steps, cost 20086] Gail has two fish tanks. The first tank is twice the size of the second tank. There are 48 gallons of water in the first tank. She follows the rule of one gallon of water per inch of fish. If she keep
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [7+ steps, cost 19926] Jesse and Mia are competing in a week long race. They have one week to run 30 miles. On the first three days Jesse averages (2/3) of a mile. On day four she runs 10 miles. Mia averages 3 miles a day o
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 18100] Janice can type 6 sentences per minute. Today at work, Janice continued working on a paper she started typing yesterday. She typed for 20 minutes, took a break, and typed 15 minutes longer. She then h
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 17974] Valerie needs to put stamps on the envelopes she is about to mail. She has thank you cards for each of her grandmother, uncle and aunt for the birthday presents they sent. She also has to pay the wate
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 16841] Five friends eat at a fast-food chain and order the following: 5 pieces of hamburger that cost $3 each; 4 sets of French fries that cost $1.20; 5 cups of soda that cost $0.5 each; and 1 platter of spa
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False
- [3-4 steps, cost 15223] An earthquake caused four buildings to collapse. Experts predicted that each following earthquake would have double the number of collapsing buildings as the previous one, since each one would make th
  plan: team [solver_A[1, 2]:low, solver_B[1, 2]:low, solver_C[1, 2]:low, critic[2]:low, judge:off] stop_if_consensus=False