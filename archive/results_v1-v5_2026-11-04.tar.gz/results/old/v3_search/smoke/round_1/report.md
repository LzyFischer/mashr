# Diagnostic report (dev-A)

Pool: acc 100.0%, cost 16505/question (15346 generated, 5794 prompt tokens; cost = generated + 0.2 x prompt). Full system: acc 83.3%, cost 17182. Orchestrator: mode fixed, recipe standard. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 4 | 100% | 100% | 13326 | 13214 | solve_team*3>verify_work>decide_final? 4 |
| Algebra L5 | 1 | 100% | 100% | 13789 | 16885 | solve_team*3>verify_work>decide_final? 1 |
| Counting & Probability L5 | 1 | 100% | 100% | 15360 | 16333 | solve_team*3>verify_work>decide_final? 1 |
| Intermediate Algebra L4 | 1 | 100% | 100% | 14589 | 17150 | solve_team*3>verify_work>decide_final? 1 |
| Intermediate Algebra L5 | 2 | 100% | 50% | 23778 | 23837 | solve_team*3>verify_work>decide_final? 2 |
| Prealgebra L4 | 1 | 100% | 100% | 8467 | 11068 | solve_team*3>verify_work>decide_final? 1 |
| Prealgebra L5 | 1 | 100% | 0% | 22819 | 23481 | solve_team*3>verify_work>decide_final? 1 |
| Precalculus L5 | 1 | 100% | 100% | 22181 | 20738 | solve_team*3>verify_work>decide_final? 1 |

## First steps (by block): accuracy of their answer
| block | uses | answer correct | mean cost |
|---|---|---|---|
| solve_team | 12 | 92% | 11885 |

## Later steps (block and condition): how often they ran and changed the answer
| step | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| decide_final if needs_check | 12 | 4 | 1 | 1 | 0 | 3660 |
| verify_work if always | 12 | 12 | 1 | 0 | 0 | 3400 |

## Signals after the first step (12 questions, 1 with a wrong answer at that point)
Would this signal/condition catch the wrong first answers? fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 4 | 25% | 100% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 0 | 0% | 0% |
| agree < 1 | 4 | 25% | 100% |
| agree < 0.67 | 4 | 25% | 100% |
| tokens > 1000 | 12 | 8% | 100% |
| tokens > 2000 | 12 | 8% | 100% |
| tokens > 4000 | 5 | 20% | 100% |
| [needs_check] disagree or fail or missing or tool_error | 4 | 25% | 100% |

## Leave-one-out replay on 6 questions with 2+ agent turns
Remove the agent from that step (agent@block<step>) or the whole step, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| solver_algebra@solve_team1 | 6 | 0 | 0 | 6 | 3324 |
| solver_code@solve_team1 | 6 | 0 | 0 | 6 | 5053 |
| solver_general@solve_team1 | 6 | 0 | 0 | 6 | 5463 |
| step decide_final3 if needs_check | 2 | 1 | 0 | 1 | 3719 |
| step verify_work2 | 6 | 0 | 0 | 6 | 3614 |

## Orchestrator usage
Recipes picked: standard 12
Architectures: solve_team*3>verify_work>decide_final? 12
Blocks: solve_team 12, verify_work 12, decide_final 12; never used: none
Conditions: always 24, needs_check 12
Agent assignments: solver_general 12, solver_algebra 12, solver_code 12, verifier 12, judge 12
Skills switched on: reread_question 24, exact_form 24, verify_by_substitution 24, geometry_diagram 12, case_counting 12, algebraic_structure 12, python_exact 12
Skills never switched on: none

## Pool wrong, full system right (0)

Both wrong: 0.

## Most expensive correct questions (possible waste)
- [Intermediate Algebra L5, cost 24721] During the car ride home, Michael looks back at his recent math exams. A problem on Michael's calculus mid-term gets him starting thinking about a particular quadratic,\[x^2-sx+p,\
  plan: solve_team[solver_general:low+reread_question/exact_form/geometry_diagram/case_counting, solver_algebra:low+algebraic_structure/exact_form, solver_code:low+python_exact/verify_by_substitution] > verify_work[verifier:low+verify_by_substitution/reread_question] > decide_final if needs_check[judge:low]
- [Intermediate Algebra L5, cost 22835] There is a unique polynomial $P(x)$ of degree $8$ with rational coefficients and leading coefficient $1,$ which has the number \[\sqrt{2} + \sqrt{3} + \sqrt{5}\]as a root. Compute 
  plan: solve_team[solver_general:low+reread_question/exact_form/geometry_diagram/case_counting, solver_algebra:low+algebraic_structure/exact_form, solver_code:low+python_exact/verify_by_substitution] > verify_work[verifier:low+verify_by_substitution/reread_question] > decide_final if needs_check[judge:low]
- [Prealgebra L5, cost 22819] The area of the shaded region is 78 square inches. All angles are right angles and all measurements are given in inches. What is the perimeter of the non-shaded region?

[asy]size(
  plan: solve_team[solver_general:low+reread_question/exact_form/geometry_diagram/case_counting, solver_algebra:low+algebraic_structure/exact_form, solver_code:low+python_exact/verify_by_substitution] > verify_work[verifier:low+verify_by_substitution/reread_question] > decide_final if needs_check[judge:low]
- [Precalculus L5, cost 22181] Let $\omega$ be a nonreal root of $x^3 = 1,$ and let
\[\mathbf{M} = \begin{pmatrix} -\omega^2 & - \omega \\ 1 & 0 \end{pmatrix}.\]Find the sum of the entries of $\mathbf{M} + \math
  plan: solve_team[solver_general:low+reread_question/exact_form/geometry_diagram/case_counting, solver_algebra:low+algebraic_structure/exact_form, solver_code:low+python_exact/verify_by_substitution] > verify_work[verifier:low+verify_by_substitution/reread_question] > decide_final if needs_check[judge:low]
- [Algebra L4, cost 15513] A line with slope equal to $1$ and a line with slope equal to $2$ intersect at the point $P(1,6),$ as shown. [asy]
unitsize(0.5 cm);
draw((0,-1)--(0,10),EndArrow);
draw((-10,0)--(5
  plan: solve_team[solver_general:low+reread_question/exact_form/geometry_diagram/case_counting, solver_algebra:low+algebraic_structure/exact_form, solver_code:low+python_exact/verify_by_substitution] > verify_work[verifier:low+verify_by_substitution/reread_question] > decide_final if needs_check[judge:low]