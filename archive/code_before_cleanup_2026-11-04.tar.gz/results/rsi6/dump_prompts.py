"""Write every prompt v6 uses (rendered with the real organizations of a run) and a few full example
runs on test questions into one Markdown file. Example calls are replayed from the sqlite cache.

  results/rsi6/run_dump_prompts.sh math_hrthink   -> results/rsi6/math_hrthink/prompts_and_examples.md
"""
import json
import os
import sys
import threading
from concurrent.futures import ThreadPoolExecutor

from mashr import org6
from mashr.engine import ANSWER_FMT, CODE, SHOW_CHARS
from mashr.exec6 import PY_RUNS, RETRY, Engine
from mashr.llm import LLM
from mashr.optimize import BIG, HINTS, REPAIR
from mashr.org6 import HAND, hr_prompt, parse_program, program_str, shape
from mashr.orgrsi import load_items
from mashr.rsi6 import DESIGN, OBJECTIVE, OPS_DOC, PROPOSE, SYSTEM_DOC, evaluate
from mashr.tools6 import TOOLS, tool_code

RUN = sys.argv[1] if len(sys.argv) > 1 else "math_hrthink"
D = os.path.join("results", "rsi6", RUN)
MAX_CHARS = 6000


def fence(text, lang=""):
    text = str(text)
    if len(text) > MAX_CHARS:
        text = text[:MAX_CHARS] + f"\n... [{len(text) - MAX_CHARS} more chars cut in this file]"
    tick = "````" if "```" in text else "```"
    return f"{tick}{lang}\n{text}\n{tick}"


class Recorder:
    """Wraps llm.chat and keeps (messages, reply) per thread."""
    def __init__(self, llm):
        self.llm, self.log, self.live = llm, [], 0
        self._chat, self._lock = llm.chat, threading.Lock()
        llm.chat = self.chat

    def chat(self, model, messages, **kw):
        r = self._chat(model, messages, **kw)
        with self._lock:
            self.live += not r.cached
            self.log.append({"model": model, "messages": [dict(m) for m in messages], "kw": kw,
                             "reply": r})
        return r


def main():
    pool0 = json.load(open(os.path.join(D, "round_0", "pool.json")))
    final = json.load(open(os.path.join(D, "final_pool.json")))
    pool1 = json.load(open(os.path.join(D, "round_1", "pool.json")))
    report1 = open(os.path.join(D, "round_1", "report.md")).read()
    log = open(os.path.join(D, "log.txt")).read()
    first = log.split("round 0 incumbent dev-B ")[1].split("\n")[0]
    acc0, cost0 = eval(first)["acc"], eval(first)["cost"]   # our own log line (a dict repr)
    llm = LLM()
    rec = Recorder(llm)
    eng = Engine(llm, seed=0, hr_thinking="medium")
    test = load_items("math", "test", 0, 156)
    dev_a = load_items("math", "train", 0, 150)

    out = [f"# MAS-HR v6: every prompt, and example runs ({RUN})", "",
           "Rendered from the real organizations of this run (employees thinking off, HR thinking "
           "medium = 2048 tokens, seed 0). Model: employees and HR = Qwen3.5-9B (local vLLM), "
           "designer/evolver = Qwen3.8-27B (Tinker, thinking high).", "",
           "## 0. Who is called, with which prompt", "",
           "| Step | Model | System prompt | User message |", "|---|---|---|---|",
           "| Design the initial organization (once) | 27B | - | §4.1 DESIGN |",
           "| Per question: HR writes the team | 9B, thinking medium | §1.1 HR prompt | §1.2 |",
           "| HR output unusable -> ask once more | 9B | same | §1.3 RETRY |",
           "| Per node: employee solves | 9B, thinking from the plan | §2.1 role + skills + tools | §2.2 / §2.3 (+ note) |",
           "| Node wrote Python -> output returned (at most 2 runs) | 9B | same | §2.4 |",
           "| Per round: evolver proposes edits (K=3, one hint each) | 27B | - | §4.2 PROPOSE |",
           "| Edit invalid -> repair once | 27B | - | §4.3 REPAIR |", "",
           f"Answer format appended to every employee message: `{ANSWER_FMT}`", ""]

    # 1. HR
    out += ["## 1. HR (meta-agent)", "",
            "### 1.1 HR system prompt (final organization of this run)", "",
            "Built by `org6.hr_prompt(pool)`: fixed instructions + the organization's employees, "
            "tools, skills and handbook (the parts the evolver edits).", "", fence(hr_prompt(final)), "",
            "<details><summary>Same prompt with the round-0 organization (designed by the 27B)</summary>",
            "", fence(hr_prompt(pool0)), "", "</details>", "",
            "### 1.2 HR user message", "", fence("Problem: {question}\n\nYour team:"), "",
            "### 1.3 Retry message (HR output could not be parsed)", "", fence(RETRY), "",
            "If the retry also fails: fixed fallback = the first employee alone, thinking low "
            "(capped to off here), tools=[\"python\"].", ""]

    # 2. Employees
    ex_node = {"agent": "verifier", "skills": list(final["skills"])[:1], "tools": ["check_answer"],
               "note": "{note from the HR}"}
    system = final["agents"][ex_node["agent"]]["role"] + "\n\nSkills to apply:\n" + "\n".join(
        f"- {final['skills'][k]}" for k in ex_node["skills"])
    helpers = [t for t in ex_node["tools"] if TOOLS[t]["code"].strip()]
    system += (f"\n\nYou can run Python (numpy and sympy available) up to {PY_RUNS} times: write one "
               "```python``` code block that prints what you need, then stop and wait for its output.")
    if helpers:
        system += " These functions are already defined:\n" + "\n".join(f"- {TOOLS[t]['doc']}" for t in helpers)
    out += ["## 2. Employees (task agents)", "",
            "### 2.1 Employee system prompt", "",
            "= its **role** (self harness, written by the evolver) + the **residual harness** the HR "
            "gave this node: skills (texts from the skill library) and tools (Python allowed only if "
            "it has tools; tool functions are preloaded). Example: a verifier given one skill and "
            "`check_answer`:", "", fence(system), "",
            "Roles in the final organization:", ""]
    out += [f"- **{n}**: {a['role']}" for n, a in final["agents"].items()]
    out += ["", "Skill library in the final organization:", ""]
    out += [f"- **{k}**: {v}" for k, v in final["skills"].items()]
    out += ["", "### 2.2 User message of a node without inputs", "",
            fence(f"Problem: {{question}}\n\n{ANSWER_FMT}"), "",
            "### 2.3 User message of a node with inputs (e.g. the verifier)", "",
            fence(f"Problem: {{question}}\n\nWork from your teammates:\n[solver (a)]\n{{last {SHOW_CHARS} "
                  f"chars of a's work}}\n\nGive your own solution and final answer.\n\n{ANSWER_FMT}"), "",
            "If the HR wrote a note for this node, the end of the message becomes:", "",
            fence(f"...\n\nNote from your manager: {{note}}\n\n{ANSWER_FMT}"), "",
            "### 2.4 After the node's Python runs", "",
            fence(f"Output:\n{{python output}}\n\nYou may run code again or give the final answer. {ANSWER_FMT}"),
            "", "On the last allowed run: `No more code runs. Give the final answer now.` instead.", "",
            "### 2.5 Tool library (fixed; preloaded code is hidden from the model, only the doc line is shown)", ""]
    out += [f"- **{t}**: {v['doc']}" for t, v in TOOLS.items()]
    out += ["", "<details><summary>Preloaded code of all tools</summary>", "",
            fence(tool_code(list(TOOLS)), "python"), "", "</details>", "",
            "### 2.6 Fixed baselines (no HR)", ""]
    out += [f"- **{k}**: `{v.replace(chr(10), '; ')}`" for k, v in org6.BASELINES.items()]

    # 3. Examples (replayed; the test stage of the run filled the cache)
    rows = evaluate(eng, final, test)
    by = lambda f: [r for r in rows if f(r)]
    picks = []
    for f, why in [
        (lambda r: r["correct"] and len(r["plan"]["nodes"]) == 1, "HR staffs one solver, correct"),
        (lambda r: r["correct"] and len(r["plan"]["nodes"]) >= 2 and r["hard"] and
         any(n["tools"] for n in r["plan"]["nodes"]) and any(n["note"] for n in r["plan"]["nodes"]),
         "hard problem, solver -> verifier with tools and notes, correct"),
        (lambda r: not r["correct"] and len(r["plan"]["nodes"]) >= 2, "multi-node team, wrong answer"),
        (lambda r: not r["correct"] and len(r["plan"]["nodes"]) == 1, "HR staffs one solver, wrong answer"),
    ]:
        c = [r for r in by(f) if r not in picks]
        if c:
            picks.append(c[0])
            c[0]["why"] = why
    rec.log.clear()
    out += ["", "## 3. Example runs (final organization, test questions)", "",
            f"Final organization on test: {sum(r['correct'] for r in rows)}/{len(rows)} correct.", ""]
    for k, r in enumerate(picks, 1):
        rec.log.clear()
        plan, pre, info = eng.orchestrate(final, r["question"])
        res = eng.run(final, r["question"], plan)
        calls = list(rec.log)
        out += [f"### Example {k}: {r['why']}", "",
                f"- {r['bucket']}; gold **{r['gold']}**, "
                f"answer **{res['answer']}** ({'correct' if res['answer'] == r['gold'] else 'wrong'}); "
                f"cost {r['cost']:.0f} (HR {r['hr_cost']:.0f})",
                f"- Architecture: `{shape(plan)}`", "", "**Problem**", "", fence(r["question"]), ""]
        for c in calls:
            msgs, rep = c["messages"], c["reply"]
            sysm = msgs[0]["content"] if msgs[0]["role"] == "system" else ""
            is_hr = sysm.startswith("You are the HR")
            who = "HR"
            if not is_hr:   # the nodes whose employee has this role
                ids = [n for n in plan["nodes"] if sysm.startswith(final["agents"][n["agent"]]["role"])]
                who = " / ".join(f"{n['id']} = {n['agent']}" for n in ids) or "employee"
            out += [f"#### {who} (thinking {c['kw'].get('thinking')}, {rep.prompt_tokens} prompt + "
                    f"{rep.gen_tokens} generated tokens)", ""]
            if is_hr:
                out += ["System prompt: §1.1. User message:", "", fence(msgs[-1]["content"]), ""]
            else:
                if len(msgs) == 2:
                    out += ["<details><summary>System prompt</summary>", "", fence(sysm), "", "</details>",
                            "", "User message:", "", fence(msgs[1]["content"]), ""]
                else:
                    out += ["Follow-up user message (Python output):", "", fence(msgs[-1]["content"]), ""]
            out += ["Response:", "", fence(rep.text), ""]
            if is_hr:
                p, probs = parse_program(final, rep.text)
                out += ["Parsed plan: " + (f"`{program_str(p)}`" if p else f"invalid: {probs}"), ""]

    # 4. Evolver
    samples = "\n".join(f"- {it['question']}" for it in dev_a[:30])
    design = DESIGN.format(system_doc=SYSTEM_DOC, objective=OBJECTIVE["acc"].format(eps=0.02),
                           example=json.dumps(HAND, indent=1), samples=samples)
    history = f"round 0 (initial organization): dev-B acc {acc0:.1%}, cost {cost0:.0f}"
    propose = PROPOSE.format(system_doc=SYSTEM_DOC, objective=OBJECTIVE["acc"], ops_doc=OPS_DOC,
                             pool=json.dumps(pool1, indent=1), report=report1, history=history,
                             ref_note="", hint=HINTS[0])
    rec.log.clear()
    reply = llm.chat(BIG, [{"role": "user", "content": propose}], thinking="high", max_tokens=6000,
                     seed=1000).text
    cached = not rec.live
    out += ["## 4. Evolver / designer (27B)", "",
            "### 4.1 DESIGN: initial organization (round 0)", "",
            "The 27B answers with the organization JSON; the round-0 organization it wrote for this "
            "run is in `round_0/pool.json` (its HR prompt is the collapsed block in §1.1).", "",
            fence(design), "",
            "### 4.2 PROPOSE: edits per round (round 1 of this run, candidate 0, exactly as sent)", "",
            "The report is built from the dev-A run of the current organization "
            "(`rsi6.report`); history lists earlier candidates and the gate's verdicts. Each of the "
            "K=3 candidates ends with a different hint:", ""]
    out += [f"- candidate {i}: {h!r}" for i, h in enumerate(HINTS)]
    out += ["", "Objectives (`--objective`):", ""] + [f"- **{k}**: {v}" for k, v in OBJECTIVE.items()]
    out += ["", fence(propose), "", "Its answer " + ("(from the cache of the real run)" if cached else
                                                     "(re-sampled; not in the cache)") + ":", "",
            fence(reply), "",
            "### 4.3 REPAIR: invalid edits are sent back once", "", fence(REPAIR), ""]

    path = os.path.join(D, "prompts_and_examples.md")
    open(path, "w").write("\n".join(out))
    print(path, "live calls:", rec.live, "examples:", len(picks))


if __name__ == "__main__":
    main()
