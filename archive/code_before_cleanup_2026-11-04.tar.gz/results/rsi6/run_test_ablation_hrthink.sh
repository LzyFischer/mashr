#!/bin/bash
cd ~/project/mas-hr
export MASHR_MAX_THINK=off MASHR_LOCAL_MODELS=Qwen/Qwen3.5-9B MASHR_LOCAL=http://localhost:8001/v1
PYTHONPATH=. ~/miniconda3/envs/tinker/bin/python results/rsi6/test_ablation_hrthink.py > results/rsi6/test_ablation_hrthink.out 2>&1
