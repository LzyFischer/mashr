# Diagnostic report (dev-A)

Organization: acc 80.0%, cost 12188/question, of which the HR 1733 (HR prompt 3093 chars). 3 distinct architectures, 3.0 nodes per question. HR outputs: repaired 0, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| GSM-Hard | 150 | 80% | - | 12188 | 0 | coder.low,solver.low>verifier.low 148, coder.low,coder.low>verifier.low 1, coder.low 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.low,solver.low>verifier.low | 148 | 80% | 12236 |
| coder.low,coder.low>verifier.low | 1 | 100% | 12097 |
| coder.low | 1 | 100% | 5151 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| coder.low | 151 | 75% | 95% | 3588 | - | - | - |
| verifier.low (with inputs) | 149 | 80% | 87% | 3145 | 24 | 10 | 3 |
| solver.low | 148 | 76% | 100% | 3769 | - | - | - |

## Leave-one-out on 60 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| coder.low (input) | 61 | 2 | 0 | 59 | 3566 |
| verifier.low (output) | 60 | 1 | 1 | 58 | 3196 |
| solver.low (input) | 59 | 0 | 1 | 58 | 3509 |

## Organization wrong (30)
- [GSM-Hard] Marty has 100 centimeters of ribbon that he must cut into 8361211 equal parts. Each of the cut parts must be divided into 5 equal parts. How long will each final cut be?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 20, correct 2.392e-06
- [GSM-Hard] Dale is selling butterscotch candies to raise money for his club at school. He doesn't have the candies yet and is instead just taking orders. He started off with 7310392 total that he ordered and wanted to sell, but he ended up selling 150 butterscotch candies. Then he ordered 7
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 14620634, correct 7310342.0
- [GSM-Hard] 20% of 7871124 people think horse
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 1574224.8, correct 2518759.68
- [GSM-Hard] Audrey has to take two math tests to pass 6th grade. She must correctly answer 4103049% of the total questions to move on to the 7th grade. The first test has 4103049 questions and she gets 60% of them correct. The second test has 40 questions. How many questions does she need to
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 168349290354.21, correct 410332.8999999999
- [GSM-Hard] Billy is buying some candy with $10 his father gave him. The candy costs $4808993 a pound. After buying candy, he takes half his change and spends it on gumballs, which cost $.05 each. If he bought 40 gumballs, how many pounds of candy did he buy?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 6, correct 1.2477e-06
- [GSM-Hard] James buys 5072217 pairs of shoes a month.  He spends $5072217640 on shoes each year.  How much does he pay on average for each pair of shoes?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 5, correct 4.33735e-05
- [GSM-Hard] Ellen and her sister, Lani, went to the mall to buy presents for their mom. Ellen bought a pair of leggings for $4915315 and a photo frame for $5. Lani bought a pair of sunglasses at $30 and two bathrobes at $4915315 each. How much did they spend in all?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 14745980, correct 4915550.0
- [GSM-Hard] James buys a new wardrobe.  He buys 1662810 suits and 1662810 dress pants.  He also buys 3 dress shirts per suit.  The suits cost $750 each and the dress pants cost 1/5 that cost.  The dress shirts were $60 each.  How much did everything cost?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 1795834800, correct 249430800.0
- [GSM-Hard] Judy teaches 8387270 dance classes, every day, on the weekdays and 8 classes on Saturday.  If each class has 18387270 students and she charges $18387270.00 per student, how much money does she make in 1 week?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 14178633676778930962432, correct 9435680550.0
- [GSM-Hard] A council met to vote on a new regulation. The vote passed with twice as many votes in favor of the new regulation as there were against it. If there are 4420075 people on the council, what was the number of votes in favor of the new regulation?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v; answered 8840150, correct 2946716.6666666665

## Most expensive correct questions (possible waste)
- [GSM-Hard, cost 18406] Candy has a chair rental business. During the weekdays, 60 chairs are rented each day; but during weekends, 4141490 chairs are rented each day. If this continues, how many chairs i
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v
- [GSM-Hard, cost 18052] Cody and Trevor had 7633966 sandwiches. Cody ate a third of the sandwiches, and Trevor ate a quarter of the sandwiches. How many sandwiches are left?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v
- [GSM-Hard, cost 16049] A company pays each of its employees $2543121 in a month. The company has a policy of increasing the salaries of each of its employees by 10% of the initial salary every year for t
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v
- [GSM-Hard, cost 15579] A simple folding newspaper or tabloid can be made by folding a piece of paper vertically and unfolding. Then, say, page 1 is printed on the left back, page 2 is printed on the left
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v
- [GSM-Hard, cost 15515] Emil is 19 years old now. When he turns 7450634, he will be half the age of his dad but twice as old as his brother.  What is the sum of the ages of his dad and his brother now?
  architecture: c = coder("low"); s = solver("low"); v = verifier("low", c, s); return v