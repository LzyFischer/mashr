"""Fixed architectures on dev-A (no orchestrator): accuracy and cost per level, and the oracle router
(the cheapest architecture that is right, per question). Writes plans.json (per-question matrix).

  PYTHONPATH=. $P results/rsi4/analysis/plans.py results/rsi4/analysis/plans.json
"""
import copy
import json
import sys
from concurrent.futures import ThreadPoolExecutor

from mashr.exec4 import Engine
from mashr.llm import LLM
from mashr.org4 import HAND, check_plan
from mashr.orgrsi import load_items
from mashr.rsi4 import evaluate

POOL = copy.deepcopy(HAND)
POOL["skills"]["python"] = {"text": "Use Python (sympy available) to compute or check any error-prone "
                                    "step; reason from its output.", "tool": 1}
POOL["agents"]["solver"]["skills"].append("python")

S = lambda *stages: {"stages": [dict(nodes=list(n), **kw) for n, kw in stages]}
PLANS = {
    "solver_off": S((["solver:off:cot"], {})),
    "solver_low": S((["solver:low:cot"], {})),
    "solver_high": S((["solver:high:cot"], {})),
    "solver_low_py": S((["solver:low:cot+python"], {})),
    "coder_pot_low": S((["coder:low:pot"], {})),
    "coder_react_low": S((["coder:low:react"], {})),
    "sc3_low": S((["solver:low:cot:x3"], {})),
    "solver+coder>judge?": S((["solver:low:cot", "coder:low:pot"], {}),
                             (["judge:low:"], {"if": "disagree"})),
    "solver+coder>verifier": S((["solver:low:cot", "coder:low:pot"], {}),
                               (["verifier:low:python_check"], {})),
    "solver_py>verifier": S((["solver:low:cot+python"], {}),
                            (["verifier:low:python_check"], {})),
}


def main():
    eng = Engine(LLM())
    items = load_items("math", "train", 0, 150)
    plans = {k: check_plan(POOL, v) for k, v in PLANS.items()}
    for k, (p, probs) in plans.items():
        assert p is not None and not probs, (k, probs)
    with ThreadPoolExecutor(len(plans)) as ex:
        res = dict(zip(plans, ex.map(lambda p: evaluate(eng, POOL, items, p[0]), plans.values())))
    out = {"items": [{"id": it["id"], "bucket": it["bucket"], "hard": it["hard"]} for it in items],
           "plans": {k: [{"correct": r["correct"], "cost": round(r["cost"], 1), "pred": r["pred"]} for r in rows]
                     for k, rows in res.items()}}
    json.dump(out, open(sys.argv[1], "w"))
    print("done")


if __name__ == "__main__":
    main()
