"""Slow loop v4: the designer builds the organization's parts (employees, skills, conditions,
policy); the orchestrator staffs every question (org4.py, exec4.py).

  P=~/miniconda3/envs/tinker/bin/python
  set -a; source ~/.config/hrsi/tinker.env; set +a
  $P -m mashr.rsi4 --dataset math --init design --out results/rsi4/math_design

Each round: dev-A run + leave-one-out (drop one node from a stage that ran, or one whole later stage)
-> diagnostic report -> K proposals of edit operations -> gate on dev-B.

Gate (dev-B): a candidate is admissible if acc >= full-system acc - eps (the floor) and acc >= the
best accepted acc so far - delta (--anchor current: the incumbent's acc - delta). Among the
incumbent and the admissible candidates, H = the most accurate (ties: cheaper); the winner is the
cheapest organization whose acc >= H's - delta and whose cost <= (1 - tau) x H's, else H. Before any
organization reaches the floor, the most accurate wins. The incumbent is replaced only by a winner
other than itself.
"""
import argparse
import copy
import json
import os
import statistics
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

from .blocks import BOOL_SIGNALS, compile_conditions, eval_cond
from .cascade import Cascade
from .engine import PROMPT_WEIGHT, cost
from .exec4 import Engine
from .llm import LLM
from .optimize import HINTS, ask_json, ops_summary, pct
from .optimize import evaluate as evaluate_ref
from .optimize import summarize as summarize_ref
from .org4 import BASELINES, FUNCTIONS, HAND, LIMITS, apply_ops, check_plan, drop_stage, \
    node_str, orchestrator_prompt, plan_str, shape, validate
from .orgrsi import load_items
from .pool import FULL, V0
from .rsi import ROOT

WORKERS = 128
TOL = 1e-9


def evaluate(eng, pool, items, plan=None):
    def one(it):
        if plan is not None:
            p, pre, info = plan, [], {"problems": [], "retried": False, "fallback": False}
        else:
            p, pre, info = eng.orchestrate(pool, it["question"])
        out = eng.run(pool, it["question"], p)
        calls = pre + out["calls"]
        return {**it, "plan": p, "trace": out["trace"], "probe": out["probe"], "pred": out["answer"],
                "correct": out["answer"] == it["gold"], "calls": calls, "cost": cost(calls),
                "gen_tokens": sum(c["gen_tokens"] for c in calls),
                "prompt_tokens": sum(c["prompt_tokens"] for c in calls), **info}
    with ThreadPoolExecutor(WORKERS) as ex:
        return list(ex.map(one, items))


def summarize(rows):
    n = len(rows)
    hard = [r for r in rows if r["hard"]]
    return {"n": n, "acc": round(sum(r["correct"] for r in rows) / n, 4),
            "cost": round(sum(r["cost"] for r in rows) / n, 1),
            "gen_tokens": round(sum(r["gen_tokens"] for r in rows) / n, 1),
            "prompt_tokens": round(sum(r["prompt_tokens"] for r in rows) / n, 1),
            "acc_hard": round(sum(r["correct"] for r in hard) / max(1, len(hard)), 4),
            "hr_cost": round(sum(cost([c for c in r["calls"] if c["agent"] == "orchestrator"])
                                 for r in rows) / n, 1),
            "shapes": dict(Counter(shape(r["plan"]) for r in rows).most_common(4)),
            "n_shapes": len({shape(r["plan"]) for r in rows}),
            "minor": sum(any(p.startswith("minor:") for p in r["problems"]) for r in rows),
            "repaired": sum(any(not p.startswith("minor:") for p in r["problems"])
                            and not r["retried"] for r in rows),
            "retried": sum(r["retried"] for r in rows),
            "fallback": sum(r["fallback"] for r in rows),
            "problems": dict(Counter(p for r in rows for p in r["problems"]).most_common(3))}


def gate(inc, cands, floor, anchor, delta, tau):
    """Index of the winning candidate, or None to keep the incumbent. inc/cands: summaries."""
    orgs = [inc] + list(cands)
    feas = [i for i, s in enumerate(orgs) if s["acc"] >= floor - TOL]
    if not feas:                                         # nobody at the floor yet: accuracy first
        best = max(range(len(orgs)), key=lambda i: (orgs[i]["acc"], -orgs[i]["cost"]))
        return None if best == 0 or orgs[best]["acc"] <= inc["acc"] + TOL else best - 1
    adm = [i for i in feas if i == 0 or orgs[i]["acc"] >= anchor - delta - TOL]
    if inc["acc"] < floor - TOL:                         # an infeasible incumbent is not compared
        adm = [i for i in adm if i != 0] or [0]
    h = max(adm, key=lambda i: (orgs[i]["acc"], -orgs[i]["cost"]))
    cheap = [i for i in adm if orgs[i]["acc"] >= orgs[h]["acc"] - delta - TOL
             and orgs[i]["cost"] <= (1 - tau) * orgs[h]["cost"]]
    win = min(cheap, key=lambda i: orgs[i]["cost"]) if cheap else h
    return None if win == 0 else win - 1


def leave_one_out(eng, pool, rows, n):
    """Drop one node from a stage that ran (if others remain in it), or one whole later stage."""
    jobs, seen = [], []
    for r in rows:
        stages = r["plan"]["stages"]
        ran = [t["stage"] for t in r["trace"] if t["ran"]]
        if sum(len(stages[i]["nodes"]) for i in ran) < 2:
            continue
        if len(seen) >= n:
            break
        seen.append(r["id"])
        for i in ran:
            if len(stages[i]["nodes"]) > 1:
                jobs += [(r, i, j) for j in range(len(stages[i]["nodes"]))]
            if i > 0:
                jobs.append((r, i, None))

    def one(job):
        r, i, j = job
        p = copy.deepcopy(r["plan"])
        st = p["stages"][i]
        if j is None:
            p = drop_stage(r["plan"], i)
            where = f"stage {i + 1} {st['function']}" + ("" if st["if"] == "always"
                                                         else f" if {st['if']}")
        else:
            where = f"{st['nodes'][j]['agent']}@{st['function']}{i + 1}"
            del st["nodes"][j]
        out = eng.run(pool, r["question"], p)
        own = cost([c for c in r["calls"] if c["agent"] != "orchestrator"])
        return {"where": where, "was": r["correct"], "now": out["answer"] == r["gold"],
                "saved": own - cost(out["calls"])}
    with ThreadPoolExecutor(WORKERS) as ex:
        return list(ex.map(one, jobs)), len(seen)


PROBES = [(s, s) for s in BOOL_SIGNALS] + [
    ("agreement < 1", ("agree", 1.0)), ("agreement < 0.67", ("agree", 0.67)),
    ("tokens > 1000", ("tokens", 1000)), ("tokens > 2000", ("tokens", 2000)),
    ("tokens > 4000", ("tokens", 4000))]


def report(rows, ref, loo, loo_n, pool) -> str:
    refd = {r["id"]: r for r in ref}
    s, sr = summarize(rows), summarize_ref(ref)
    L = ["# Diagnostic report (dev-A)", "",
         f"Organization: acc {s['acc']:.1%}, cost {s['cost']:.0f}/question ({s['gen_tokens']:.0f} "
         f"generated, {s['prompt_tokens']:.0f} prompt tokens; cost = generated + {PROMPT_WEIGHT} x "
         f"prompt, including the orchestrator's). Full system: acc {sr['acc']:.1%}, cost "
         f"{sr['cost']:.0f}. Orchestrator (HR): {s['hr_cost']:.0f}/question of that cost "
         f"({s['hr_cost'] / s['cost']:.0%}), prompt {len(orchestrator_prompt(pool))} chars, thinking "
         f"{pool['orchestrator'].get('thinking', 'off')}; {s['n_shapes']} distinct architectures. "
         f"Final rule: {pool['final']}.", "",
         "## By category", "| category | n | acc | full acc | cost | full cost | architectures |",
         "|---|---|---|---|---|---|---|"]
    by = defaultdict(list)
    for r in rows:
        by[r["bucket"]].append(r)
    for b in sorted(by):
        rs, rf = by[b], [refd[r["id"]] for r in by[b]]
        L.append(f"| {b} | {len(rs)} | {pct([r['correct'] for r in rs])} | "
                 f"{pct([r['correct'] for r in rf])} | {statistics.mean(r['cost'] for r in rs):.0f}"
                 f" | {statistics.mean(r['cost'] for r in rf):.0f} | "
                 + ", ".join(f"{k} {v}" for k, v in Counter(shape(r['plan']) for r in rs).most_common(3))
                 + " |")
    first = defaultdict(lambda: [0, 0, []])
    later = defaultdict(lambda: [0, 0, 0, 0, 0, []])
    for r in rows:
        for t in r["trace"]:
            st = r["plan"]["stages"][t["stage"]]
            if t["stage"] == 0:
                f = first[" + ".join(node_str(n) for n in st["nodes"])
                          + (f" (rounds {st['rounds']})" if st["rounds"] > 1 else "")]
                f[0] += 1
                f[1] += t["current"] == r["gold"]
                f[2].append(t["cost"])
                continue
            g = later[f"{st['function']} if {st['if']}" + (f" (rounds {st['rounds']})"
                                                           if st["rounds"] > 1 else "")
                      + (f" (loop {st['loop']})" if st["loop"] else "")]
            g[0] += 1
            if t["ran"]:
                g[1] += 1
                g[5].append(t["cost"])
                if t["before"] is not None and t["current"] != t["before"]:
                    g[2] += 1
                    g[3] += t["current"] == r["gold"]
                    g[4] += t["before"] == r["gold"]
    L += ["", "## First stages (staffing): accuracy of their answer",
          "| first stage | uses | answer correct | mean cost |", "|---|---|---|---|"]
    for k, v in sorted(first.items(), key=lambda kv: -kv[1][0])[:15]:
        L.append(f"| {k} | {v[0]} | {v[1] / v[0]:.0%} | {statistics.mean(v[2]):.0f} |")
    L += ["", "## Later stages (function and condition): how often they ran and changed the answer",
          "| stage | planned | ran | changed answer | to correct | to wrong | mean cost when ran |",
          "|---|---|---|---|---|---|---|"]
    for k, v in sorted(later.items(), key=lambda kv: -kv[1][0])[:15]:
        L.append(f"| {k} | {v[0]} | {v[1]} | {v[2]} | {v[3]} | {v[4]} | "
                 f"{statistics.mean(v[5]) if v[5] else 0:.0f} |")
    wrong = [r["probe"]["current"] != r["gold"] for r in rows]
    conds = compile_conditions(pool)[0]
    tests = [(name, (lambda sig, sp=sp: sig[sp] if isinstance(sp, str) else
                     (sig[sp[0]] < sp[1] if sp[0] == "agree" else sig[sp[0]] > sp[1])))
             for name, sp in PROBES]
    tests += [(f"[{k}] {pool['conditions'][k]}", (lambda sig, c=c: eval_cond(c, sig)))
              for k, c in conds.items()]
    L += ["", f"## Signals after the first stage ({len(rows)} questions, {sum(wrong)} with a wrong "
              "answer at that point)",
          "fires = how often it holds; precision = share of firings where the answer was wrong; "
          "recall = share of wrong answers it fires on.",
          "| signal / condition | fires | precision | recall |", "|---|---|---|---|"]
    for name, fn in tests:
        fire = [fn(r["probe"]["signals"]) for r in rows]
        tp = sum(f and w for f, w in zip(fire, wrong))
        L.append(f"| {name} | {sum(fire)} | {tp / sum(fire) if sum(fire) else 0:.0%} | "
                 f"{tp / sum(wrong) if sum(wrong) else 0:.0%} |")
    L += ["", f"## Leave-one-out replay on {loo_n} questions with 2+ nodes that ran",
          "Remove the employee from that stage (agent@function<stage>) or the whole stage, and "
          "re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.",
          "| removed | uses | needed | harmful | no effect | mean cost saved |",
          "|---|---|---|---|---|---|"]
    g = defaultdict(list)
    for x in loo:
        g[x["where"]].append(x)
    for k, xs in sorted(g.items(), key=lambda kv: -len(kv[1]))[:25]:
        need = sum(x["was"] and not x["now"] for x in xs)
        harm = sum(not x["was"] and x["now"] for x in xs)
        L.append(f"| {k} | {len(xs)} | {need} | {harm} | {len(xs) - need - harm} | "
                 f"{statistics.mean(x['saved'] for x in xs):.0f} |")
    nodes = [n for r in rows for st in r["plan"]["stages"] for n in st["nodes"]]
    stages = [st for r in rows for st in r["plan"]["stages"]]
    sk = Counter(x for n in nodes for x in n["skills"])
    L += ["", "## Orchestrator usage",
          "Architectures: " + ", ".join(f"{k} {v}" for k, v in
                                         Counter(shape(r["plan"]) for r in rows).most_common(8)),
          "Employees: " + ", ".join(f"{k} {v}" for k, v in Counter(n["agent"] for n in nodes)
                                    .most_common()) + "; never staffed: "
          + (", ".join(a for a in pool["agents"] if a not in {n["agent"] for n in nodes}) or "none"),
          "Thinking: " + ", ".join(f"{k} {v}" for k, v in Counter(n["thinking"] for n in nodes)
                                   .most_common()),
          "Skills switched on: " + (", ".join(f"{k} {v}" for k, v in sk.most_common()) or "none")
          + "; never: " + (", ".join(x for x in pool["skills"] if x not in sk) or "none"),
          "Conditions: " + ", ".join(f"{k} {v}" for k, v in Counter(
              st["if"] for st in stages if st is not None).most_common()),
          f"Copies > 1: {sum(n['copies'] > 1 for n in nodes)}; debate rounds > 1: "
          f"{sum(st['rounds'] > 1 for st in stages)}; check loops: {sum(st['loop'] > 0 for st in stages)}"]
    s_ = summarize(rows)
    fb = [r for r in rows if r["fallback"]]
    L += [f"Orchestrator outputs: minor fixes {s_['minor']} (skills an employee does not hold, "
          f"quoted conditions, missing commas), structural repairs {s_['repaired']}, asked again {sum(r['retried'] for r in rows)} "
          f"(valid on the 2nd try: {sum(r['retried'] and not r['fallback'] for r in rows)}), fixed "
          f"fallback {len(fb)} (acc {pct([r['correct'] for r in fb])})."]
    probs = Counter(p for r in rows for p in r["problems"])
    if probs:
        L.append("Most common problems: " + "; ".join(f"{k} ({v})" for k, v in probs.most_common(6)))
    bad = [r for r in rows if not r["correct"] and refd[r["id"]]["correct"]]
    L += ["", f"## Organization wrong, full system right ({len(bad)})"]
    for r in bad[:10]:
        L.append(f"- [{r['bucket']}] {r['question'][:280]}\n  plan: {plan_str(r['plan'])}; "
                 f"answered {r['pred']}, correct {r['gold']}")
    L.append(f"\nBoth wrong: {sum(not r['correct'] and not refd[r['id']]['correct'] for r in rows)}.")
    rich = sorted([r for r in rows if r["correct"]], key=lambda r: -r["cost"])[:5]
    L += ["", "## Most expensive correct questions (possible waste)"]
    for r in rich:
        L.append(f"- [{r['bucket']}, cost {r['cost']:.0f}] {r['question'][:180]}\n"
                 f"  plan: {plan_str(r['plan'])}")
    return "\n".join(L)


SYSTEM_DOC = f"""How the organization works (all employees and the orchestrator are the same 9B model):
- Employees: name -> role, function and skills. function: produce (solves), check (checks the current
  answer: PASS/FAIL plus the answer it believes) or decide (picks the final answer from the work).
- Skills: id -> {{"text": how-to, "tool": 0-{LIMITS['tool']}}}. Reasoning methods are skills too
  (chain-of-thought, program-of-thought, ReAct, self-check, confidence reporting), as are domain
  techniques. tool > 0 lets the employee run Python (numpy, sympy) that many times while the skill
  is on. An employee can only switch on skills it holds.
- Per question the orchestrator (the HR; same 9B, sees its prompt and the problem) staffs the
  problem: ordered stages of employees (a stage mixing functions runs produce, check, decide in
  order), each node with thinking off/low/high, its
  skills and copies (copies > 1 = self-consistency); per stage a condition ("if"), and for produce
  stages "sees" (a later produce stage reads the earlier work unless "none") and "rounds" (> 1 =
  debate), for check stages "loop" (> 0 = on FAIL the author of the current answer revises from the
  critique and the check reruns: evaluator-optimizer / Reflexion). The first stage always runs and
  must produce. At most {LIMITS['stages']} stages, {LIMITS['nodes_per_stage']} nodes per stage,
  {LIMITS['calls']} model calls.
- Conditions: named expressions over free runtime signals, used by the orchestrator to gate later
  stages: disagree (answers so far differ or one is missing), missing, unsure (an output said
  'Confidence: low'; only if a skill asks for it), fail (a check said FAIL), tool_error; numbers (need a
  comparison): agreement (share of answers equal to the current one, 0-1), answers, tokens (most
  tokens one call generated in the last stage), steps; and/or/not, parentheses; a condition may use
  earlier ones.
- final: "last" (answer after the last stage that ran) or "vote" (majority of all answers).
- orchestrator thinking: off or low (low costs up to ~1000 more tokens per problem).
- policy: the orchestrator's dispatch rules. It may describe architectures in words (which
  employees, skills and conditions suit which problems) but must not contain JSON plans. Its prompt
  (policy, employees, skills, conditions) is paid on every problem.
- If the orchestrator's output is unusable it is asked once more; if still unusable, the first
  produce employee answers alone with thinking low (fixed, not editable).
Thinking budgets: off ~200 generated tokens per call; low up to ~1000 extra; high up to ~4000 extra."""

OPS_DOC = f"""Edit operations (a JSON list, applied in order):
{{"op": "add_agent", "name": "<name>", "role": "<role, <= {LIMITS['role_chars']} chars>", "function": "produce|check|decide", "skills": ["<id>"]}}
{{"op": "remove_agent", "name": "<name>"}}
{{"op": "edit_role", "name": "<name>", "role": "<new role>"}}
{{"op": "set_function", "name": "<name>", "function": "produce|check|decide"}}
{{"op": "set_skills", "name": "<name>", "skills": ["<id>", ...]}}
{{"op": "add_skill", "id": "<new_id>", "text": "<general how-to, <= {LIMITS['skill_chars']} chars>", "tool": 0, "to": ["<agent>"]}}
{{"op": "edit_skill", "id": "<id>", "text": "<new text>", "tool": 0}}
{{"op": "remove_skill", "id": "<id>"}}
{{"op": "set_condition", "name": "<name>", "expr": "<expression>"}}
{{"op": "remove_condition", "name": "<name>"}}
{{"op": "set_final", "rule": "last|vote"}}
{{"op": "set_orchestrator", "thinking": "off|low"}}
{{"op": "set_policy", "text": "<the complete dispatch policy, <= {LIMITS['policy_chars']} chars>"}}
Limits: <= {LIMITS['agents']} employees, {LIMITS['skills']} skills ({LIMITS['skills_per_agent']} per employee), {LIMITS['conditions']} conditions.
The policy must not mention removed employees, skills or conditions."""

PROPOSE = """You design the organization of a multi-agent system that solves math problems: its employees,
their skills, the conditions the HR can use, and the HR's dispatch policy. You do not fix an
architecture; the HR staffs every problem itself.

{system_doc}

Objective: minimize the average cost per problem (generated tokens + 0.2 x prompt tokens, including the
HR's) while keeping accuracy within {eps:.0%} of the full system on held-out problems, and never
below the best accuracy reached so far. Accuracy comes first.

Base each change on evidence in the report. Examples: a signal or condition with high precision and
useful recall is a good gate for a later stage, one with low precision wastes calls; a later stage that
changes answers to wrong as often as to correct is not worth it; first-stage staffings with low
accuracy on some categories need a stronger staffing there (more thinking, a program, copies);
employees whose removal never hurts may go; if the HR's choices are poor or invalid, simplify the
policy or the employees so the choice is easier to make from the problem text. Skills must be
general techniques for error patterns that recur across several problems, not solutions to specific
problems. Prefer few, decisive changes.

{ops_doc}

# Current organization (JSON)
{pool}

# Diagnostic report
{report}

# Earlier attempts (dev-B gate; full system on dev-B: acc {ref_acc:.1%}, cost {ref_cost:.0f})
{history}

Think about what the evidence shows, then output a JSON list of edit operations between <ops> and
</ops>. {hint}"""

DESIGN = """Design the initial organization of a multi-agent system that will solve problems like the
samples below: its employees, their skills, the conditions the HR can use, and the HR's dispatch
policy. You do not fix an architecture; the HR staffs every problem itself.

{system_doc}

Objective: high accuracy at low cost (generated tokens + 0.2 x prompt tokens, including the HR's).
Methods from agentic-workflow libraries are available: chain-of-thought, program-of-thought and ReAct
as skills; self-consistency (copies), debate (rounds), review/verify (check employees, with Python
skills), evaluator-optimizer / Reflexion (check loops), ensemble/decide (decide employees), early
exit (conditions). Keep only what this task needs.

# JSON format (an example organization; replace it with your own design)
{example}

# Sample problems
{samples}

Output the complete organization JSON between <pool> and </pool>."""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=["gsm8k", "math"], default="math")
    ap.add_argument("--init", choices=["hand", "design"], default="design")
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--eps", type=float, default=0.02, help="floor = full-system acc - eps")
    ap.add_argument("--delta", type=float, default=0.005, help="largest accuracy drop allowed")
    ap.add_argument("--tau", type=float, default=0.10,
                    help="a less accurate organization wins only if this much cheaper")
    ap.add_argument("--anchor", choices=["best", "current"], default="best",
                    help="delta is measured from the best accepted acc or from the incumbent's")
    ap.add_argument("--n-dev-a", type=int, default=150)
    ap.add_argument("--n-dev-b", type=int, default=200)
    ap.add_argument("--n-test", type=int, default=156)
    ap.add_argument("--loo-n", type=int, default=60)
    ap.add_argument("--baselines", default=",".join(BASELINES),
                    help="fixed architectures on HAND evaluated on test ('' for none)")
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "rsi4", "math_design"))
    ap.add_argument("--skip-test", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    llm = LLM()
    eng, cas = Engine(llm), Cascade(llm)
    dev_a = load_items(a.dataset, "train", 0, a.n_dev_a)
    dev_b = load_items(a.dataset, "train", a.n_dev_a, a.n_dev_a + a.n_dev_b)
    test = load_items(a.dataset, "test", 0, a.n_test)

    def log(msg):
        print(msg, flush=True)
        with open(os.path.join(a.out, "log.txt"), "a") as f:
            f.write(msg + "\n")

    def dump(name, obj):
        path = os.path.join(a.out, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(obj if isinstance(obj, str) else json.dumps(obj, indent=1))

    with ThreadPoolExecutor(2) as ex:
        ref_a, ref_b = ex.map(lambda xs: evaluate_ref(cas, V0, xs, FULL), [dev_a, dev_b])
    sa, sb = summarize_ref(ref_a), summarize_ref(ref_b)
    floor = sb["acc"] - a.eps
    log(f"full system: dev-A {sa}\n             dev-B {sb}\n             floor on dev-B {floor:.3f}"
        f"; gate delta {a.delta}, tau {a.tau}, anchor {a.anchor}")

    if a.init == "hand":
        pool = copy.deepcopy(HAND)
    else:
        samples = "\n".join(f"- {it['question']}" for it in dev_a[:30])
        pool, _, tries = ask_json(llm, DESIGN.format(system_doc=SYSTEM_DOC,
                                                     example=json.dumps(HAND, indent=1),
                                                     samples=samples), "pool",
                                  lambda o: (None, validate(o)), seed=7, max_tokens=8000)
        if pool is None:
            raise SystemExit("initial design failed: no valid pool after repair")
        log(f"designed initial organization (repair attempts: {tries})")
    pool0 = copy.deepcopy(pool)
    dump("round_0/pool.json", pool)

    inc_b = summarize(evaluate(eng, pool, dev_b))
    best_acc = inc_b["acc"] if inc_b["acc"] >= floor - TOL else 0.0
    log(f"round 0 incumbent dev-B {inc_b}")
    history = [f"round 0 (initial organization): dev-B acc {inc_b['acc']:.1%}, "
               f"cost {inc_b['cost']:.0f}"]
    trace = [{"round": 0, "accepted": True, "dev_b": inc_b}]

    for t in range(1, a.rounds + 1):
        d = f"round_{t}"
        rows_a = evaluate(eng, pool, dev_a)
        loo, loo_n = leave_one_out(eng, pool, rows_a, a.loo_n)
        rep = report(rows_a, ref_a, loo, loo_n, pool)
        dump(f"{d}/pool.json", pool)
        dump(f"{d}/report.md", rep)
        log(f"round {t}: incumbent dev-A {summarize(rows_a)}; leave-one-out replays {len(loo)}")

        def propose(i):
            prompt = PROPOSE.format(system_doc=SYSTEM_DOC, eps=a.eps, ops_doc=OPS_DOC,
                                    pool=json.dumps(pool, indent=1), report=rep,
                                    history="\n".join(history), ref_acc=sb["acc"],
                                    ref_cost=sb["cost"], hint=HINTS[i % len(HINTS)])
            ops, new, tries = ask_json(llm, prompt, "ops", lambda o: apply_ops(pool, o),
                                       seed=1000 * t + 10 * i, max_tokens=6000)
            return {"ops": ops, "pool": new, "repairs": tries}
        with ThreadPoolExecutor(a.k) as ex:
            cands = list(ex.map(propose, range(a.k)))
        valid = [c for c in cands if c["pool"] is not None]
        with ThreadPoolExecutor(len(valid) or 1) as ex:
            gated = list(ex.map(lambda c: summarize(evaluate(eng, c["pool"], dev_b)), valid))
        for c, g in zip(valid, gated):
            c["dev_b"] = g
        for i, c in enumerate(cands):
            log(f"  cand {i}: " + ("invalid after repair" if c["pool"] is None else
                                   f"{len(c['ops'])} ops, repairs {c['repairs']}, dev-B {c['dev_b']}"))
        anchor = best_acc if a.anchor == "best" else inc_b["acc"]
        w = gate(inc_b, [c["dev_b"] for c in valid], floor, anchor, a.delta, a.tau)
        best = valid[w] if w is not None else None
        for c in cands:
            if c["pool"] is None:
                history.append(f"round {t} [invalid]")
                continue
            status = "ACCEPTED" if c is best else "rejected by gate"
            history.append(f"round {t} [{status}]: dev-B acc {c['dev_b']['acc']:.1%}, "
                           f"cost {c['dev_b']['cost']:.0f}, fallbacks {c['dev_b']['fallback']}\n  "
                           + ops_summary(c["ops"]))
        dump(f"{d}/candidates.json", [{k: v for k, v in c.items() if k != "pool"} for c in cands])
        if best is not None:
            pool, inc_b = best["pool"], best["dev_b"]
            if inc_b["acc"] >= floor - TOL:
                best_acc = max(best_acc, inc_b["acc"])
        trace.append({"round": t, "accepted": best is not None, "dev_b": inc_b})
        log(f"round {t}: {'accepted' if best is not None else 'no change'}; incumbent dev-B {inc_b}")
        dump("trace.json", trace)

    dump("final_pool.json", pool)
    if not a.skip_test:
        jobs = {"full_system": lambda: summarize_ref(evaluate_ref(cas, V0, test, FULL)),
                "org_round0": lambda: summarize(evaluate(eng, pool0, test)),
                "org_final": lambda: summarize(evaluate(eng, pool, test))}
        for name in filter(None, a.baselines.split(",")):
            jobs[name] = lambda p=check_plan(HAND, BASELINES[name])[0]: summarize(
                evaluate(eng, HAND, test, p))
        with ThreadPoolExecutor(len(jobs)) as ex:
            res = dict(zip(jobs, ex.map(lambda f: f(), jobs.values())))
        dump("test.json", res)
        log(f"TEST: {json.dumps(res)}")


if __name__ == "__main__":
    main()
