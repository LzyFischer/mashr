"""[hrthink org, seed 0, HR thinking medium] Where does MAS-HR lose? The final organization of each seed on MATH test: the same HR plans, with
parts of the residual harness removed from every node. Writes results/rsi6/test_ablation_hrthink.json.
  MASHR_MAX_THINK=off MASHR_LOCAL_MODELS=Qwen/Qwen3.5-9B PYTHONPATH=. $P results/rsi6/test_ablation.py
"""
import json
from concurrent.futures import ThreadPoolExecutor

from mashr.engine import cost
from mashr.exec6 import Engine
from mashr.llm import LLM
from mashr.orgrsi import load_items

VARIANTS = {"full": {}, "no_notes": {"note": ""}, "no_skills": {"skills": []}, "no_tools": {"tools": []},
            "no_notes_skills": {"note": "", "skills": []},
            "structure_only": {"note": "", "skills": [], "tools": []}}
llm, res = LLM(), {}
test = load_items("math", "test", 0, 156)
for s in (0,):
    eng = Engine(llm, seed=s, hr_thinking="medium")
    pool = json.load(open(f"results/rsi6/math_hrthink/final_pool.json"))
    with ThreadPoolExecutor(64) as ex:
        plans = list(ex.map(lambda it: eng.orchestrate(pool, it["question"]), test))

    def run(job):
        name, ch, it, (plan, calls, _) = job
        p = {**plan, "nodes": [{**n, **ch} for n in plan["nodes"]]}
        out = eng.run(pool, it["question"], p)
        return name, out["answer"] == it["gold"], cost(calls + out["calls"])
    jobs = [(k, ch, it, pl) for k, ch in VARIANTS.items() for it, pl in zip(test, plans)]
    tot = {k: [0, 0.0] for k in VARIANTS}
    with ThreadPoolExecutor(128) as ex:
        for k, ok, c in ex.map(run, jobs):
            tot[k][0] += ok
            tot[k][1] += c
    res[s] = {k: {"acc": round(v[0] / len(test), 4), "cost": round(v[1] / len(test), 1)} for k, v in tot.items()}
    print(s, res[s], flush=True)
    json.dump(res, open("results/rsi6/test_ablation_hrthink.json", "w"), indent=1)
