#!/bin/bash
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
PYTHONPATH=.:results/rsi5 ~/miniconda3/envs/tinker/bin/python results/rsi5/fixed_arch.py results/rsi5/references > results/rsi5/fixed.out 2>&1
