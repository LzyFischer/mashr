"""Controlled test of check loops: re-run the final v4 organization's dev-A questions whose plan has a
check stage with loop > 0, once as planned and once with every loop set to 0 (same plan otherwise)."""
import copy, json, sys
from concurrent.futures import ThreadPoolExecutor
from mashr.exec4 import Engine
from mashr.llm import LLM
from mashr.orgrsi import load_items
from mashr.rsi4 import evaluate

pool = json.load(open(sys.argv[1]))
eng = Engine(LLM())
rows = evaluate(eng, pool, load_items("math", "train", 0, 150))
loop_rows = [r for r in rows if any(s["loop"] for s in r["plan"]["stages"])]

def no_loop(r):
    p = copy.deepcopy(r["plan"])
    for s in p["stages"]:
        s["loop"] = 0
    out = eng.run(pool, r["question"], p)
    return out["answer"] == r["gold"], sum(c["gen_tokens"] + 0.2 * c["prompt_tokens"] for c in out["calls"])

with ThreadPoolExecutor(64) as ex:
    res = list(ex.map(no_loop, loop_rows))
n = len(loop_rows)
own = lambda r: sum(c["gen_tokens"] + 0.2 * c["prompt_tokens"] for c in r["calls"] if c["agent"] != "orchestrator")
print(f"questions with a check loop: {n} of {len(rows)}")
print(f"  as planned (loop):  acc {sum(r['correct'] for r in loop_rows) / n:.1%}, cost {sum(map(own, loop_rows)) / n:.0f}")
print(f"  loop set to 0:      acc {sum(c for c, _ in res) / n:.1%}, cost {sum(x for _, x in res) / n:.0f}")
print(f"  loop right, no-loop wrong: {sum(r['correct'] and not c for r, (c, _) in zip(loop_rows, res))}; "
      f"loop wrong, no-loop right: {sum(not r['correct'] and c for r, (c, _) in zip(loop_rows, res))}")
