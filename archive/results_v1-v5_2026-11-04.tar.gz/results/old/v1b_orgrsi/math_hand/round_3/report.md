# Performance report (dev-A)

Organization: acc 94.7%, cost 11543/question. Full team: acc 91.3%, cost 27271. Invalid HR outputs (default plan used): 7.

## By category
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 5648 | 19590 | vote 11, hard 3, check 3 |
| Algebra L5 | 18 | 100% | 100% | 8618 | 23083 | vote 13, hard 4, check 1 |
| Counting & Probability L4 | 8 | 100% | 100% | 5434 | 22644 | vote 8 |
| Counting & Probability L5 | 9 | 100% | 89% | 10900 | 32029 | vote 8, check 1 |
| Geometry L4 | 5 | 100% | 100% | 15648 | 24771 | hard 3, vote 2 |
| Geometry L5 | 7 | 71% | 57% | 23611 | 39998 | hard 7 |
| Intermediate Algebra L4 | 14 | 93% | 100% | 12414 | 28859 | vote 7, hard 6, solo 1 |
| Intermediate Algebra L5 | 17 | 82% | 71% | 22090 | 36267 | hard 13, vote 4 |
| Number Theory L4 | 9 | 100% | 100% | 7811 | 26425 | vote 8, check 1 |
| Number Theory L5 | 16 | 94% | 88% | 7750 | 29063 | vote 14, check 2 |
| Prealgebra L4 | 12 | 100% | 100% | 5021 | 15420 | vote 8, check 2, hard 1, solo 1 |
| Prealgebra L5 | 9 | 100% | 100% | 12225 | 26009 | vote 5, hard 3, solo 1 |
| Precalculus L4 | 3 | 100% | 67% | 15580 | 31364 | hard 2, vote 1 |
| Precalculus L5 | 6 | 83% | 83% | 22429 | 38717 | hard 5, vote 1 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| check.check | 10 | 0 | 0 | 0 | 0 |
| check.draft | 10 | 10 | 0 | 0 | 0 |
| hard.r1 | 47 | 47 | 0 | 0 | 0 |
| hard.r2 | 47 | 47 | 15 | 9 | 0 |
| hard.r3 | 47 | 6 | 6 | 1 | 0 |
| solo.draft | 3 | 3 | 0 | 0 | 0 |
| vote.r1 | 90 | 90 | 0 | 0 | 0 |
| vote.r2 | 90 | 13 | 10 | 9 | 0 |
| vote.r3 | 90 | 0 | 0 | 0 | 0 |

## Employees: leave-one-out replay on 60 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| critic | 30 | 8 | 0 | 22 | 6417 |
| judge | 1 | 0 | 0 | 1 | 5670 |
| solver_A | 20 | 0 | 0 | 20 | 4885 |
| solver_B | 49 | 2 | 0 | 47 | 4584 |
| solver_C | 51 | 1 | 0 | 50 | 3928 |
Needed / uses by difficulty: critic@Algebra L4: 0/2; critic@Algebra L5: 0/2; critic@Counting & Probability L5: 2/2; critic@Geometry L4: 0/2; critic@Geometry L5: 1/1; critic@Intermediate Algebra L4: 1/3; critic@Intermediate Algebra L5: 1/8; critic@Number Theory L4: 1/2; critic@Prealgebra L4: 1/1; critic@Prealgebra L5: 0/4; critic@Precalculus L5: 1/3; judge@Intermediate Algebra L5: 0/1; solver_A@Algebra L4: 0/2; solver_A@Algebra L5: 0/3; solver_A@Counting & Probability L5: 0/1; solver_A@Geometry L4: 0/2; solver_A@Geometry L5: 0/1; solver_A@Intermediate Algebra L4: 0/3; solver_A@Intermediate Algebra L5: 0/3; solver_A@Number Theory L5: 0/1; solver_A@Prealgebra L4: 0/1; solver_A@Prealgebra L5: 0/2; solver_A@Precalculus L5: 0/1; solver_B@Algebra L4: 0/6; solver_B@Algebra L5: 0/6; solver_B@Counting & Probability L4: 0/3; solver_B@Counting & Probability L5: 0/4; solver_B@Geometry L4: 0/3; solver_B@Geometry L5: 1/1; solver_B@Intermediate Algebra L4: 0/6; solver_B@Intermediate Algebra L5: 0/6; solver_B@Number Theory L4: 0/3; solver_B@Number Theory L5: 0/5; solver_B@Prealgebra L4: 1/2; solver_B@Prealgebra L5: 0/2; solver_B@Precalculus L5: 0/2; solver_C@Algebra L4: 0/7; solver_C@Algebra L5: 0/7; solver_C@Counting & Probability L4: 0/3; solver_C@Counting & Probability L5: 1/5; solver_C@Geometry L4: 0/3; solver_C@Geometry L5: 0/1; solver_C@Intermediate Algebra L4: 0/6; solver_C@Intermediate Algebra L5: 0/7; solver_C@Number Theory L4: 0/3; solver_C@Number Theory L5: 0/4; solver_C@Prealgebra L4: 0/1; solver_C@Prealgebra L5: 0/2; solver_C@Precalculus L5: 0/2

## HR usage
Employees assigned (questions): critic 146, judge 137, solver_B 134, solver_C 107, solver_A 48
Skills switched on (times): reread_question 545, final_form 530, verify_by_substitution 190, check_units 81, diagram_coordinates 67, subtract_from 63, coordinate_max_area 55, common_roots_diff 47, percent_base 36, roots_unity_count 36, near_power_count 29, coordinate_3d 28, region_perimeter 26, mean_removed 26, complex_equilateral 26, perm_repeats_zero 26, geometric_sequence 25, intercepts_linear 21, power_pair_recursion 21
Guide notes written: 126
Invalid HR outputs, first problems: ["bad JSON: Expecting ':' delimiter: line 1 column 589 (char 588)"]; ['bad JSON: Unterminated string starting at: line 1 column 472 (char 471)']; ["bad JSON: Expecting ',' delimiter: line 19 column 4 (char 1404)"]; ["bad JSON: Expecting ':' delimiter: line 1 column 503 (char 502)"]

## Saved wrong: org failed, full team succeeded (2)
- [Intermediate Algebra L4] The equations $x^3 + Ax + 10 = 0$ and $x^3 + Bx^2 + 50 = 0$ have two roots in common.  Then the product of these common roots can be expressed in the form $a \sqrt[b]{c},$ where $a,$ $b,$ and $c$ are positive integers, when simplified.  Find $a + b + c.$
  plan: hard r1=[solver_B:off+reread_question/common_roots_diff/final_form, solver_C:off+reread_question/common_roots_diff/verify_by_substitution/final_form] r2=[critic:off+reread_question/common_roots_diff/verify_by_substitution/final_form] r3=[judge:off+reread_question/final_form] guide: judge: "Select answer with correct form and verified steps."; critic: "Check subtraction logic. Confirm root count. Validate final form constraints."; solver_C: "Define common roots sum/product. Use polynomial subtraction. Ensure positive integers a,b,c."; solver_B: "Subtract equations to find common roots relation. Verify with Vieta. Format as a sqrt[b]{c}."; answered 3, correct 12
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: hard r1=[solver_A:low+reread_question/coordinate_max_area/diagram_coordinates/final_form, solver_B:high+reread_question/coordinate_max_area/diagram_coordinates/final_form/subtract_from, solver_C:high+reread_question/coordinate_max_area/diagram_coordinates/final_form/verify_by_substitution] r2=[critic:high+reread_question/check_units/verify_by_substitution/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Calculate intersections, derive area equation, check derivative for max."; critic: "Verify intersection logic, derivative calculation, and boundary conditions."; solver_C: "Define angle t, find vertices, use shoelace formula, optimize."; judge: "Select maximum valid area, ensure exact form."; solver_A: "Find intersection of rotating lines, express area as function of angle, maximize."; answered 17, correct 85

Both wrong: 6.

## Most expensive correctly-solved questions (possible waste)
- [Precalculus L5, cost 35106] Find the number of ordered quadruples $(a,b,c,d)$ of real numbers such that
\[\begin{pmatrix} a & b \\ c & d \end{pmatrix}^2 = \begin{pmatrix} c & a \\ d & b \end{pmatrix}.\]
  plan: hard r1=[solver_A:low+reread_question/final_form, solver_B:high+reread_question/final_form, solver_C:high+reread_question/final_form/verify_by_substitution] r2=[critic:high+reread_question/verify_by_substitution/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Solve step-by-step with arithmetic check."; critic: "Verify logic and arithmetic for all solutions."; solver_C: "Define variables and use algebraic manipulation."; judge: "Select final answer in exact form."; solver_A: "Solve matrix equation directly."
- [Intermediate Algebra L5, cost 30645] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  plan: hard r1=[solver_A:low+reread_question/final_form, solver_B:high+reread_question/power_pair_recursion/final_form, solver_C:high+reread_question/power_pair_recursion/verify_by_substitution/final_form] r2=[critic:high+reread_question/verify_by_substitution/final_form] r3=[judge:low+reread_question/final_form] guide: solver_B: "Solve step-by-step, verify logic, check arithmetic carefully."; critic: "Check all conditions hold, verify final calculation."; solver_C: "Define general form, verify with small integers, ensure exact form."; judge: "Select best verified answer in exact form."; solver_A: "Use recursion with 2^n pairs to find formula for f(x)."
- [Geometry L5, cost 30613] The graphs of the equations
$y=k, \qquad y=\sqrt{3}x+2k, \qquad y=-\sqrt{3}x+2k,$
are drawn in the coordinate plane for $k=-10,-9,-8,\ldots,9,10.\,$ These 63 lines cut part of the 
  plan: hard r1=[solver_A:low+reread_question/final_form, solver_B:high+reread_question/final_form/diagram_coordinates/coordinate_max_area, solver_C:high+reread_question/final_form/diagram_coordinates/coordinate_max_area] r2=[critic:high+reread_question/final_form/verify_by_substitution] r3=[judge:low+reread_question/final_form] guide: solver_B: "Map lines to a grid, count unit triangles, sum over k, verify edge cases."; critic: "Verify formula logic, arithmetic sum, and edge case inclusion."; solver_C: "Derive formula for triangles per strip, sum arithmetic series, check bounds."; judge: "Select consensus answer, ensure integer form."; solver_A: "Count triangles in the strip between y=2k and y=2(k+1) for each k from -10 to 9."
- [Precalculus L4, cost 29740] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\
  plan: hard r1=[solver_A:low+reread_question/coordinate_max_area/final_form, solver_B:high+reread_question/roots_unity_count/coordinate_max_area/final_form/complex_equilateral/percent_base, solver_C:high+reread_question/roots_unity_count/coordinate_max_area/final_form/complex_equilateral/verify_by_substitution] r2=[critic:high+reread_question/roots_unity_count/coordinate_max_area/final_form/check_units/verify_by_substitution] r3=[judge:low+reread_question/final_form] guide: solver_B: "Compute coordinates of vertices. Sum cross products to find area. Simplify radical form."; critic: "Verify arithmetic in cross product sum. Ensure a,b,c,d are positive integers and gcd(a,b,c,d)=1."; solver_C: "Use symmetry of roots. Sum areas of triangles formed with origin. Verify simplification."; judge: "Select the answer with correct simplified form and positive integers. Sum a+b+c+d."; solver_A: "Identify roots as 9th roots of unity excluding 1 and -1. Calculate area via polygon formula."
- [Geometry L5, cost 29573] $ABCD$, a rectangle with $AB = 12$ and $BC = 16$, is the base of pyramid $P$, which has a height of $24$. A plane parallel to $ABCD$ is passed through $P$, dividing $P$ into a frus
  plan: hard r1=[solver_A:low+reread_question/coordinate_3d/final_form, solver_B:high+reread_question/coordinate_3d/final_form, solver_C:high+reread_question/coordinate_3d/final_form/verify_by_substitution] r2=[critic:high+reread_question/coordinate_3d/final_form/verify_by_substitution] r3=[judge:low+reread_question/final_form] guide: solver_B: "Calculate volumes ratio to find cut height. Determine sphere center."; critic: "Verify volume ratio, coordinate calculations, and distance formula."; solver_C: "Define variables, set up equations for sphere center coordinates."; judge: "Ensure final answer is sum of relatively prime integers."; solver_A: "Use 3D coordinates for pyramid and plane. Find frustum center."