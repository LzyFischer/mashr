# Performance report (dev-A)

Organization: acc 90.7%, cost 11612/question. Full team: acc 91.3%, cost 27271. Invalid HR outputs (default plan used): 8.

## By category
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 94% | 100% | 4157 | 19590 | solo 11, draft_check 3, consensus_check 1, consensus_decide 1, hard_check 1 |
| Algebra L5 | 18 | 78% | 100% | 6541 | 23083 | solo 7, consensus_check 4, draft_check 3, consensus_decide 2, self 2 |
| Counting & Probability L4 | 8 | 88% | 100% | 6943 | 22644 | consensus_check 3, solo 3, consensus_decide 1, self 1 |
| Counting & Probability L5 | 9 | 89% | 89% | 15477 | 32029 | consensus_decide 5, hard_check 2, consensus_check 2 |
| Geometry L4 | 5 | 100% | 100% | 7604 | 24771 | consensus_check 2, solo 2, draft_check 1 |
| Geometry L5 | 7 | 57% | 57% | 27839 | 39998 | hard_check 5, consensus_check 2 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 15667 | 28859 | consensus_check 7, hard_check 5, draft_check 1, solo 1 |
| Intermediate Algebra L5 | 17 | 82% | 71% | 21755 | 36267 | hard_check 8, consensus_check 7, consensus_decide 2 |
| Number Theory L4 | 9 | 100% | 100% | 5240 | 26425 | solo 6, hard_check 1, consensus_check 1, draft_check 1 |
| Number Theory L5 | 16 | 100% | 88% | 10834 | 29063 | solo 5, hard_check 4, consensus_check 4, consensus_decide 2, draft_check 1 |
| Prealgebra L4 | 12 | 100% | 100% | 3483 | 15420 | solo 8, consensus_check 3, draft_check 1 |
| Prealgebra L5 | 9 | 100% | 100% | 10072 | 26009 | draft_check 2, solo 2, hard_check 2, consensus_decide 2, consensus_check 1 |
| Precalculus L4 | 3 | 100% | 67% | 17696 | 31364 | consensus_decide 1, hard_check 1, consensus_check 1 |
| Precalculus L5 | 6 | 83% | 83% | 21735 | 38717 | hard_check 5, consensus_decide 1 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| consensus_check.decide | 38 | 3 | 3 | 2 | 0 |
| consensus_check.review | 38 | 32 | 2 | 1 | 0 |
| consensus_check.solve | 38 | 38 | 0 | 0 | 0 |
| consensus_decide.decide | 17 | 3 | 2 | 2 | 0 |
| consensus_decide.solve | 17 | 17 | 0 | 0 | 0 |
| draft_check.check | 13 | 10 | 1 | 1 | 0 |
| draft_check.draft | 13 | 13 | 0 | 0 | 0 |
| hard_check.decide | 34 | 9 | 7 | 3 | 0 |
| hard_check.review | 34 | 34 | 10 | 3 | 0 |
| hard_check.solve | 34 | 34 | 0 | 0 | 0 |
| solo.draft | 45 | 45 | 0 | 0 | 0 |

## Employees: leave-one-out replay on 60 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| algebra | 38 | 1 | 1 | 36 | 5233 |
| careful | 43 | 2 | 0 | 41 | 4171 |
| counter | 38 | 1 | 0 | 37 | 4399 |
| critic | 42 | 5 | 0 | 37 | 4832 |
| fast | 7 | 0 | 0 | 7 | 1868 |
| geom | 7 | 0 | 0 | 7 | 5629 |
| judge | 4 | 1 | 0 | 3 | 7786 |
Needed / uses by difficulty: algebra@Algebra L4: 0/3; algebra@Algebra L5: 0/4; algebra@Counting & Probability L4: 0/2; algebra@Counting & Probability L5: 0/2; algebra@Geometry L5: 0/1; algebra@Intermediate Algebra L4: 0/8; algebra@Intermediate Algebra L5: 1/8; algebra@Number Theory L4: 0/2; algebra@Number Theory L5: 0/2; algebra@Prealgebra L4: 0/1; algebra@Precalculus L4: 0/2; algebra@Precalculus L5: 0/3; careful@Algebra L4: 0/4; careful@Algebra L5: 0/5; careful@Counting & Probability L4: 1/3; careful@Counting & Probability L5: 0/5; careful@Geometry L4: 0/2; careful@Geometry L5: 0/2; careful@Intermediate Algebra L4: 0/8; careful@Intermediate Algebra L5: 0/4; careful@Number Theory L4: 0/1; careful@Number Theory L5: 0/3; careful@Prealgebra L4: 1/1; careful@Prealgebra L5: 0/2; careful@Precalculus L4: 0/1; careful@Precalculus L5: 0/2; counter@Algebra L4: 0/1; counter@Algebra L5: 0/3; counter@Counting & Probability L4: 0/3; counter@Counting & Probability L5: 0/6; counter@Geometry L5: 0/2; counter@Intermediate Algebra L4: 0/3; counter@Intermediate Algebra L5: 1/8; counter@Number Theory L4: 0/2; counter@Number Theory L5: 0/5; counter@Prealgebra L4: 0/1; counter@Prealgebra L5: 0/1; counter@Precalculus L4: 0/1; counter@Precalculus L5: 0/2; critic@Algebra L4: 0/3; critic@Algebra L5: 0/2; critic@Counting & Probability L4: 1/1; critic@Counting & Probability L5: 0/1; critic@Geometry L4: 0/3; critic@Geometry L5: 0/1; critic@Intermediate Algebra L4: 0/7; critic@Intermediate Algebra L5: 3/8; critic@Number Theory L4: 0/3; critic@Number Theory L5: 0/4; critic@Prealgebra L4: 0/1; critic@Prealgebra L5: 1/4; critic@Precalculus L4: 0/1; critic@Precalculus L5: 0/3; fast@Counting & Probability L5: 0/3; fast@Intermediate Algebra L5: 0/1; fast@Number Theory L5: 0/3; geom@Algebra L4: 0/1; geom@Geometry L4: 0/2; geom@Geometry L5: 0/1; geom@Prealgebra L5: 0/1; geom@Precalculus L4: 0/1; geom@Precalculus L5: 0/1; judge@Counting & Probability L5: 0/1; judge@Geometry L5: 0/1; judge@Intermediate Algebra L5: 1/2

## HR usage
Employees assigned (questions): judge 89, critic 79, careful 79, fast 65, algebra 65, counter 64, geom 16
Skills switched on (times): final_format 383, sanity_check 317, reread_question 303, confidence_calibration 292, verify_by_substitution 211, algebraic_substitution 96, solve_linear 63, check_units 40, fraction_percent 38, geometry_area 25, exponent_rules 23, coordinate_lines 23, number_factors 22, polynomial_roots 19, counting_digits 18, diagram_extract 16, combinatorics_cases 14, inclusion_exclusion 10, parabola_vertex 9, complex_roots 8, divisibility 7, complete_square 7, permutations_restrictions 5, gcd_coprime 4, sequence_sum 4, matrix_power 3, functional_equation 1
Guide notes written: 98
Invalid HR outputs, first problems: ["first stage 'solve' has nobody assigned"]; ["first stage 'solve' has nobody assigned"]; ["first stage 'draft' has nobody assigned"]; ["first stage 'solve' has nobody assigned"]

## Saved wrong: org failed, full team succeeded (8)
- [Algebra L5] If $f(a) = \frac{1}{1-a}$, find the product $f^{-1}(a) \times a \times f(a)$.  (Assume $a \neq 0$ and $a \neq 1$.)
  plan: solo draft=[fast:off+reread_question/final_format/confidence_calibration]; answered 1, correct -1
- [Algebra L4] Homewood Middle School has 1200 students, and 730 of these students attend a summer picnic. If two-thirds of the girls in the school and one-half of the boys in the school attend the picnic, how many girls attend the picnic?  (Assume that each student in the school is either a bo
  plan: solo draft=[fast:off+reread_question/check_units/fraction_percent/solve_linear/sanity_check/final_format/confidence_calibration]; answered 780, correct 520
- [Algebra L5] If $n$ is a constant and if there exists a unique value of $m$ for which the quadratic equation $x^2 + mx + (m+n) = 0$ has one real solution, then find $n$.
  plan: self (answered 0); answered 0, correct -1
- [Algebra L5] A portion of the graph of $f(x)=ax^2+bx+c$ is shown below. The distance between grid lines on the graph is $1$ unit.

What is the value of $a+b+2c$?

[asy]
size(150);
real ticklen=3;
real tickspace=2;

real ticklength=0.1cm;
real axisarrowsize=0.14cm;
pen axispen=black+1.3bp;
rea
  plan: self (answered -2); answered -2, correct 11
- [Algebra L5] How many zeros are in the expansion of $999,\!999,\!999,\!998^2$?
  plan: solo draft=[fast:off+reread_question/check_units/solve_linear/fraction_percent/sanity_check/final_format/confidence_calibration]; answered 12, correct 11
- [Intermediate Algebra L5] Let
\[x^8 + 98x^4 + 1 = p(x) q(x),\]where $p(x)$ and $q(x)$ are monic, non-constant polynomials with integer coefficients.  Find $p(1) + q(1).$
  plan: consensus_check solve=[algebra:high+reread_question/algebraic_substitution/exponent_rules/verify_by_substitution/final_format/confidence_calibration, careful:low+reread_question/solve_linear/fraction_percent/verify_by_substitution/sanity_check/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/final_format/confidence_calibration] decide=[judge:high+sanity_check/final_format/confidence_calibration] guide: careful: "Verify factorization. Check monic/integer constraints. Calculate p(1)+q(1) carefully."; critic: "Check if factors are monic and have integer coefficients. Verify p(1)+q(1) arithmetic."; algebra: "Factor x^8+98x^4+1 via Sophie Germain identity. Find roots, construct monic integer factors p, q. Compute p(1)+q(1)."; judge: "Select best answer. Confirm no other factorization exists."; answered 1, correct 20
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: hard_check solve=[algebra:high+algebraic_substitution/exponent_rules/verify_by_substitution, geom:low+diagram_extract/coordinate_lines/geometry_area/verify_by_substitution, counter:low+sequence_sum/sanity_check] review=[critic:low+verify_by_substitution/sanity_check/coordinate_lines/geometry_area] decide=[judge:high+sanity_check/final_format/confidence_calibration] guide: algebra: "Model rotation angles t, find intersection points, maximize area function."; judge: "Select correct maximum value from candidates."; geom: "Verify coordinate geometry setup and area formula application."; critic: "Verify logic of vertex formation and derivative/maximization steps."; counter: "Check symmetry and boundary conditions for maximum area."; answered 2, correct 85
- [Counting & Probability L4] What is the nearest integer to $(5+2\sqrt7)^4$?
  plan: self (answered 1620); answered 1620, correct 11218

Both wrong: 6.

## Most expensive correctly-solved questions (possible waste)
- [Intermediate Algebra L5, cost 34598] Find the number of integers $n$ such that \[1+\left\lfloor\dfrac{100n}{101}\right\rfloor=\left\lceil\dfrac{99n}{100}\right\rceil.\]
  plan: consensus_check solve=[fast:low+reread_question/check_units/solve_linear/fraction_percent/sanity_check/final_format/confidence_calibration, careful:high+reread_question/solve_linear/fraction_percent/algebraic_substitution/verify_by_substitution/sanity_check/final_format/confidence_calibration, counter:low+reread_question/counting_digits/number_factors/divisibility/sanity_check/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/final_format/confidence_calibration] decide=[judge:high+sanity_check/final_format/confidence_calibration] guide: judge: "Finalize answer."; critic: "Check logic and bounds."; counter: "Verify count range."; fast: "Check bounds quickly."; careful: "Derive inequality and count integers."
- [Number Theory L5, cost 33721] Let $\tau (n)$ denote the number of positive integer divisors of $n$ (including $1$ and $n$). Find the sum of the six least positive integers $n$ that are solutions to $\tau (n) + 
  plan: hard_check solve=[counter:high+reread_question/number_factors/divisibility/combinatorics_cases/sanity_check/final_format/confidence_calibration, careful:low+reread_question/solve_linear/sanity_check/verify_by_substitution/final_format/confidence_calibration, algebra:low+reread_question/algebraic_substitution/verify_by_substitution/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/final_format/confidence_calibration] decide=[judge:high+sanity_check/final_format/confidence_calibration] guide: algebra: "Assume forms for n, n+1 based on tau values."; judge: "Select the correct sum of the 6 integers."; critic: "Verify all candidate sums and constraints."; counter: "Check n, n+1 factorizations for tau sum=7. Sum 6 least."; careful: "Verify arithmetic and logic step-by-step."
- [Intermediate Algebra L5, cost 28912] Consider the set of 30 parabolas defined as follows: all parabolas have as focus the point $(0,0)$ and the directrix lines have the form $y=ax+b$ with $a$ and $b$ integers such tha
  plan: hard_check solve=[algebra:high+algebraic_substitution/verify_by_substitution, counter:low+counting_digits/number_factors/sanity_check] review=[critic:low+verify_by_substitution/sanity_check] decide=[judge:high+sanity_check/final_format/confidence_calibration] guide: counter: "Count valid integer pairs (a,b) and distinct intersection points systematically."; judge: "Select final count based on solver consensus and critic validation."; algebra: "Derive intersection condition for parabolas with focus (0,0) and line directrix."; critic: "Check arithmetic in intersection count and verify no triple intersections occur."
- [Geometry L5, cost 28128] Square $ABCD$ has center $O,\ AB=900,\ E$ and $F$ are on $AB$ with $AE<BF$ and $E$ between $A$ and $F, m\angle EOF =45^\circ,$ and $EF=400.$ Given that $BF=p+q\sqrt{r},$ where $p,q
  plan: hard_check solve=[geom:high+reread_question/diagram_extract/coordinate_lines/parabola_vertex/check_units/verify_by_substitution/final_format/confidence_calibration, careful:low+reread_question/solve_linear/algebraic_substitution/verify_by_substitution/sanity_check/final_format/confidence_calibration] review=[critic:low+reread_question/verify_by_substitution/sanity_check/final_format/confidence_calibration] decide=[judge:high+sanity_check/final_format/confidence_calibration] guide: geom: "Set coords A(0,0), B(900,0), O(450,450). Solve for E,F using angle EOF=45."; judge: "Compare answers, ensure r is square-free, sum p+q+r."; careful: "Verify algebraic steps and arithmetic carefully."; critic: "Check setup, angle condition, and final calculation."
- [Intermediate Algebra L5, cost 27294] Let $x,$ $y,$ and $z$ be positive real numbers such that $xy + xz + yz = 1.$  Find the minimum value of $10x^2 + 10y^2 + z^2.$
  plan: hard_check solve=[algebra:high+algebraic_substitution/verify_by_substitution/reread_question/final_format, careful:low+algebraic_substitution/verify_by_substitution/reread_question/final_format/sanity_check] review=[critic:low+verify_by_substitution/sanity_check/reread_question/final_format/confidence_calibration] decide=[judge:high+sanity_check/final_format/confidence_calibration] guide: careful: "Verify the critical point found by the algebra specialist satisfies the constraint and yields a minimum."; critic: "Re-derive the minimum using a different method (e.g., substitution) to confirm the result."; algebra: "Use Lagrange multipliers or Cauchy-Schwarz to minimize the quadratic form subject to the constraint. Check boundary behavior."; judge: "Compare the derived minimums and select the lowest valid value."