# Diagnostic report (dev-A)

Organization: acc 88.0%, cost 12647/question (11728 generated, 4595 prompt tokens; cost = generated + 0.2 x prompt, including the orchestrator's). Full system: acc 91.3%, cost 17252. Orchestrator (HR): 2255/question of that cost (18%), prompt 6751 chars, thinking low; 16 distinct architectures. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 7322 | 13285 | solver>checkerL1 4, solver>checkerL1>judge? 4, solver 3 |
| Algebra L5 | 18 | 94% | 100% | 8649 | 15585 | solver>checkerL1>judge? 7, solver>checkerL1 6, solver 3 |
| Counting & Probability L4 | 8 | 88% | 100% | 10796 | 15676 | solver>checkerL1>judge? 4, solver+coder>checkerL1>judge? 2, solver+coder>checker>judge? 1 |
| Counting & Probability L5 | 9 | 78% | 89% | 15558 | 19103 | solver+coder>checkerL1>judge? 3, solver>checkerL1 2, solver>checker>judge? 2 |
| Geometry L4 | 5 | 100% | 100% | 10250 | 15889 | solver>checkerL1>judge? 2, solver+coder>checkerL1>judge? 1, solver+coder>checker 1 |
| Geometry L5 | 7 | 57% | 57% | 19902 | 22647 | solver+coder>checkerL1>judge? 4, solver>checker 1, solver+coder>checker>judge? 1 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 14571 | 18210 | solver>checker>judge? 4, solver+coder>checkerL1>judge? 2, solver>checker 2 |
| Intermediate Algebra L5 | 17 | 71% | 71% | 19532 | 21465 | solver+coder>checkerL1>judge? 6, solver>checker 3, solver+coder>checker>judge? 3 |
| Number Theory L4 | 9 | 100% | 100% | 10474 | 17149 | solver>checker>judge? 5, solver>checkerL1 3, solver>checkerL1>judge? 1 |
| Number Theory L5 | 16 | 88% | 88% | 13713 | 18165 | solver>checkerL1>judge? 6, solver+coder>checker>judge? 3, solver>checkerL1 2 |
| Prealgebra L4 | 12 | 100% | 100% | 6215 | 10794 | solver 7, solver>checkerL1>judge? 4, solver+coder>checkerL1>judge? 1 |
| Prealgebra L5 | 9 | 78% | 89% | 9319 | 17096 | solver>checker>judge? 3, solver+coder>checkerL1>judge? 2, solver+coder>checker? 1 |
| Precalculus L4 | 3 | 100% | 100% | 18064 | 20027 | solver>checkerL1 1, solver+coder&checker 1, solver+coder>checker>judge? 1 |
| Precalculus L5 | 6 | 67% | 83% | 22938 | 22960 | solver+coder>checkerL1>judge? 3, solver>checker 1, solver 1 |

## First stages (staffing): accuracy of their answer
| first stage | uses | answer correct | mean cost |
|---|---|---|---|
| solver:low+cot/reread/confidence/substitution | 66 | 89% | 4006 |
| solver:off+cot/reread/confidence/substitution | 17 | 82% | 994 |
| solver:low+cot/reread/confidence/substitution/case_analysis + coder:high+react/reread/confidence/substitution/case_analysis | 10 | 80% | 10050 |
| solver:low+cot/reread/confidence/substitution + coder:high+react/reread/confidence/substitution | 9 | 56% | 13122 |
| solver:low+cot/reread/confidence/substitution/case_analysis | 8 | 100% | 3872 |
| solver:low+cot/reread/confidence/substitution + coder:low+react/reread/confidence/substitution | 5 | 40% | 10485 |
| solver:high+cot/reread/confidence/substitution/case_analysis + coder:high+react/reread/confidence/substitution/case_analysis | 4 | 75% | 17498 |
| solver:high+cot/reread/confidence/substitution/case_analysis/diagram + coder:high+react/reread/confidence/substitution/case_analysis/diagram | 3 | 67% | 16418 |
| solver:low+cot/reread/substitution/confidence | 2 | 0% | 5172 |
| solver:low+cot/confidence/substitution + coder:low+react/confidence/substitution | 2 | 50% | 10370 |
| solver:off+cot/reread/confidence/substitution + coder:off+react/reread/confidence/substitution/diagram | 1 | 0% | 4277 |
| solver:high+cot/reread/confidence | 1 | 100% | 7696 |
| solver:low+cot/reread/confidence/case_analysis/substitution | 1 | 100% | 4076 |
| solver:high+cot/diagram/reread + coder:high+react/diagram/reread | 1 | 100% | 10406 |
| solver:low+cot/reread/confidence | 1 | 100% | 3838 |

## Later stages (function and condition): how often they ran and changed the answer
| stage | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| decide if failed | 90 | 5 | 1 | 0 | 1 | 4904 |
| check if always (loop 1) | 78 | 78 | 6 | 4 | 1 | 3944 |
| check if always | 54 | 53 | 20 | 12 | 0 | 4314 |
| check if failed | 2 | 0 | 0 | 0 | 0 | 0 |
| produce if failed | 2 | 0 | 0 | 0 | 0 | 0 |
| decide if always | 2 | 2 | 0 | 0 | 0 | 5074 |
| produce if disagree | 1 | 0 | 0 | 0 | 0 | 0 |

## Signals after the first stage (150 questions, 32 with a wrong answer at that point)
fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 21 | 90% | 59% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 2 | 0% | 0% |
| agreement < 1 | 21 | 90% | 59% |
| agreement < 0.67 | 21 | 90% | 59% |
| tokens > 1000 | 136 | 24% | 100% |
| tokens > 2000 | 135 | 24% | 100% |
| tokens > 4000 | 86 | 33% | 88% |
| [failed] fail | 0 | 0% | 0% |

## Leave-one-out replay on 60 questions with 2+ nodes that ran
Remove the employee from that stage (agent@function<stage>) or the whole stage, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| stage 2 check | 58 | 4 | 0 | 54 | 3905 |
| solver@produce1 | 16 | 0 | 0 | 16 | 4771 |
| coder@produce1 | 16 | 1 | 0 | 15 | 7089 |
| stage 3 check | 1 | 1 | 0 | 0 | 10845 |

## Orchestrator usage
Architectures: solver>checkerL1>judge? 30, solver+coder>checkerL1>judge? 25, solver>checkerL1 20, solver>checker>judge? 20, solver 17, solver>checker 13, solver+coder>checker>judge? 12, solver+coder>checker 4
Employees: solver 152, checker 134, judge 92, coder 51; never staffed: none
Thinking: low 351, high 59, off 19
Skills switched on: reread 414, substitution 321, cot 242, alternative 213, confidence 189, python_check 134, case_analysis 100, react 51, diagram 24; never: none
Conditions: always 284, failed 94, disagree 1
Copies > 1: 0; debate rounds > 1: 0; check loops: 78
Orchestrator outputs: minor fixes 14 (skills an employee does not hold, quoted conditions, missing commas), structural repairs 0, asked again 2 (valid on the 2nd try: 1), fixed fallback 1 (acc 0%).
Most common problems: minor: JSON syntax repaired (10); minor: a stage mixed functions; its parts run in order (4); bad JSON: Expecting ',' delimiter: line 1 column 232 (char 231) (1)

## Organization wrong, full system right (7)
- [Intermediate Algebra L5] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  plan: produce[solver:low+cot/reread/confidence/substitution, coder:low+react/reread/confidence/substitution] > check[checker:low+python_check/reread/substitution/alternative] > decide if failed[judge:low+reread/cot/alternative]; answered 2, correct 96
- [Counting & Probability L5] The number of increasing sequences of positive integers $a_1 \le a_2 \le a_3 \le \cdots \le a_{10} \le 2007$ such that $a_i-i$ is even for $1\le i \le 10$ can be expressed as ${m \choose n}$ for some positive integers $m > n$. Compute the remainder when $m$ is divided by 1000.
  plan: produce[solver:low+cot/reread/substitution/confidence] > check[checker:low+python_check/reread/substitution/alternative] > decide if failed[judge:low+reread/cot/alternative]; answered 1, correct 8
- [Precalculus L5] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection = perspective(6,3,2);

triple A, B, C, D, E, F, G, H;

A = (1,1,0);
B = (1,-1,0);
C = (-1,-1,0);
D 
  plan: produce[solver:low]; answered 7, correct 225
- [Algebra L5] How many zeros are in the expansion of $999,\!999,\!999,\!998^2$?
  plan: produce[solver:low+cot/reread/confidence/substitution] > check (loop 1)[checker:low+python_check/reread/substitution/alternative] > decide if failed[judge:low+reread/cot/alternative]; answered 12, correct 11
- [Prealgebra L5] Let $a$ and $b$ be distinct positive divisors of $80.$ What is the smallest possible value of $ab$ which is not a divisor of $80?$
  plan: produce[solver:low+cot/reread/confidence/substitution] > check[checker:low+python_check/reread/substitution]; answered 1, correct 32
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: produce[solver:high+cot/reread/confidence/substitution/case_analysis/diagram, coder:high+react/reread/confidence/substitution/case_analysis/diagram] > check[checker:low+python_check/reread/substitution/case_analysis/alternative/diagram] > decide if failed[judge:low+reread/cot/alternative]; answered -7, correct 85
- [Counting & Probability L4] What is the nearest integer to $(5+2\sqrt7)^4$?
  plan: produce[solver:low+cot/reread/confidence/substitution] > check (loop 1)[checker:low+python_check/reread/substitution/alternative]; answered 7, correct 11218

Both wrong: 11.

## Most expensive correct questions (possible waste)
- [Precalculus L5, cost 45095] Let $a$ and $b$ be two 12th roots of unity, not necessarily distinct.  Find the number of different possible values of $(a + b)^{12}.$
  plan: produce[solver:high+cot/reread/confidence/substitution/case_analysis, coder:high+react/reread/confidence/substitution/case_analysis] > check (loop 1)[checker:low+python_check/reread/substitution/alternative] > decide if failed[judge:low+reread/cot/alternative]
- [Intermediate Algebra L5, cost 35194] There is a unique polynomial $P(x)$ of degree $8$ with rational coefficients and leading coefficient $1,$ which has the number \[\sqrt{2} + \sqrt{3} + \sqrt{5}\]as a root. Compute 
  plan: produce[solver:low+cot/reread/confidence/substitution/case_analysis, coder:high+react/reread/confidence/substitution/case_analysis] > check (loop 1)[checker:low+python_check/reread/substitution/case_analysis/alternative] > decide if failed[judge:low+reread/cot/alternative]
- [Number Theory L5, cost 28405] What is the ones digit of $1^{2009} + 2^{2009} + 3^{2009} + \cdots + 2009^{2009}?$
  plan: produce[solver:low+cot/reread/confidence/substitution, coder:high+react/reread/confidence/substitution] > check[checker:low+python_check/reread/substitution/alternative] > decide if failed[judge:low+reread/cot/alternative]
- [Geometry L5, cost 27772] The grid below contains the $16$ points whose $x$- and $y$-coordinates are in the set $\{0,1,2,3\}$: [asy]
size(2.5cm);
for(int i=0; i<4; i+=1) { for(int j=0; j<4; j+=1) { dot((i,j
  plan: produce[solver:high+cot/reread/confidence/substitution/case_analysis/diagram, coder:high+react/reread/confidence/substitution/case_analysis/diagram] > check (loop 1)[checker:low+python_check/reread/substitution/case_analysis/alternative/diagram] > decide if failed[judge:low+reread/cot/alternative]
- [Precalculus L5, cost 25423] Find the number of ordered quadruples $(a,b,c,d)$ of real numbers such that
\[\begin{pmatrix} a & b \\ c & d \end{pmatrix}^2 = \begin{pmatrix} c & a \\ d & b \end{pmatrix}.\]
  plan: produce[solver:low+cot/reread/confidence/substitution, coder:high+react/reread/confidence/substitution/case_analysis] & check[checker:low+python_check/reread/substitution/alternative/case_analysis] & decide[judge:low+reread/cot/alternative] > check if failed[checker:low+python_check/reread/substitution/alternative/case_analysis] > decide if failed[judge:low+reread/cot/alternative]