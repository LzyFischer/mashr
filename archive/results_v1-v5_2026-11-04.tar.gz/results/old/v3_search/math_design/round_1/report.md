# Diagnostic report (dev-A)

Pool: acc 92.0%, cost 10223/question (9570 generated, 3267 prompt tokens; cost = generated + 0.2 x prompt). Full system: acc 91.3%, cost 17252. Orchestrator: mode fixed, recipe adaptive_checked. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 6546 | 13285 | base_solve>code_check?>repair*2?>final_pick? 17 |
| Algebra L5 | 18 | 100% | 100% | 6937 | 15585 | base_solve>code_check?>repair*2?>final_pick? 18 |
| Counting & Probability L4 | 8 | 100% | 100% | 8250 | 15676 | base_solve>code_check?>repair*2?>final_pick? 8 |
| Counting & Probability L5 | 9 | 89% | 89% | 12384 | 19103 | base_solve>code_check?>repair*2?>final_pick? 9 |
| Geometry L4 | 5 | 100% | 100% | 7045 | 15889 | base_solve>code_check?>repair*2?>final_pick? 5 |
| Geometry L5 | 7 | 57% | 57% | 18304 | 22647 | base_solve>code_check?>repair*2?>final_pick? 7 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 10851 | 18210 | base_solve>code_check?>repair*2?>final_pick? 14 |
| Intermediate Algebra L5 | 17 | 82% | 71% | 17057 | 21465 | base_solve>code_check?>repair*2?>final_pick? 17 |
| Number Theory L4 | 9 | 100% | 100% | 8158 | 17149 | base_solve>code_check?>repair*2?>final_pick? 9 |
| Number Theory L5 | 16 | 94% | 88% | 10786 | 18165 | base_solve>code_check?>repair*2?>final_pick? 16 |
| Prealgebra L4 | 12 | 100% | 100% | 5458 | 10794 | base_solve>code_check?>repair*2?>final_pick? 12 |
| Prealgebra L5 | 9 | 89% | 89% | 7745 | 17096 | base_solve>code_check?>repair*2?>final_pick? 9 |
| Precalculus L4 | 3 | 67% | 100% | 9233 | 20027 | base_solve>code_check?>repair*2?>final_pick? 3 |
| Precalculus L5 | 6 | 67% | 83% | 17625 | 22960 | base_solve>code_check?>repair*2?>final_pick? 6 |

## First steps (by block): accuracy of their answer
| block | uses | answer correct | mean cost |
|---|---|---|---|
| base_solve | 150 | 84% | 4381 |

## Later steps (block and condition): how often they ran and changed the answer
| step | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| code_check if proceed | 150 | 150 | 21 | 10 | 2 | 3918 |
| final_pick if shaky | 150 | 22 | 11 | 5 | 1 | 4761 |
| repair if shaky | 150 | 24 | 4 | 2 | 2 | 7659 |

## Signals after the first step (150 questions, 24 with a wrong answer at that point)
Would this signal/condition catch the wrong first answers? fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 0 | 0% | 0% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 1 | 0% | 0% |
| agree < 1 | 0 | 0% | 0% |
| agree < 0.67 | 0 | 0% | 0% |
| tokens > 1000 | 148 | 16% | 100% |
| tokens > 2000 | 144 | 17% | 100% |
| tokens > 4000 | 57 | 42% | 100% |
| [proceed] steps >= 0 | 150 | 16% | 100% |
| [shaky] disagree or fail or tool_error or missing | 1 | 0% | 0% |

## Leave-one-out replay on 60 questions with 2+ agent turns
Remove the agent from that step (agent@block<step>) or the whole step, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| critic@repair3 | 9 | 0 | 0 | 9 | 546 |
| solver@repair3 | 9 | 0 | 0 | 9 | -4 |
| step code_check2 if proceed | 60 | 3 | 0 | 57 | 5261 |
| step final_pick4 if shaky | 7 | 2 | 0 | 5 | 4378 |
| step repair3 if shaky | 9 | 0 | 0 | 9 | 4777 |

## Orchestrator usage
Recipes picked: adaptive_checked 150
Architectures: base_solve>code_check?>repair*2?>final_pick? 150
Blocks: base_solve 150, code_check 150, repair 150, final_pick 150; never used: none
Conditions: shaky 300, always 150, proceed 150
Agent assignments: solver 300, coder 150, critic 150, judge 150
Skills switched on: format_answer 750, reread_question 600, python_checks 600, exact_arithmetic 300, verify_by_substitution 300, case_enumeration 300
Skills never switched on: none

## Pool wrong, full system right (3)
- [Prealgebra L5] In the diagram, $AB,$ $BC,$ $CD,$ $DE,$ $EF,$ $FG,$ $GH,$ and $HK$ all have length $4,$ and all angles are right angles, with the exception of the angles at $D$ and $F.$

[asy]
draw((0,0)--(0,4)--(4,4)--(4,8)--(6.8284,5.1716)--(9.6569,8)--(9.6569,4)--(13.6569,4)--(13.6569,0)--cyc
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if proceed[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration] > repair if shaky[solver:low+format_answer/reread_question/exact_arithmetic/python_checks, critic:low+format_answer/reread_question/verify_by_substitution/case_enumeration/python_checks] > final_pick if shaky[judge:low+format_answer/reread_question]; answered 2, correct 8
- [Precalculus L4] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\frac{a + b \sqrt{c}}{d},$ where $a,$ $b,$ $c,$ $d$ are positive integers, in simplest form.  Find $a
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if proceed[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration] > repair if shaky[solver:low+format_answer/reread_question/exact_arithmetic/python_checks, critic:low+format_answer/reread_question/verify_by_substitution/case_enumeration/python_checks] > final_pick if shaky[judge:low+format_answer/reread_question]; answered 2, correct 8
- [Precalculus L5] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection = perspective(6,3,2);

triple A, B, C, D, E, F, G, H;

A = (1,1,0);
B = (1,-1,0);
C = (-1,-1,0);
D 
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if proceed[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration] > repair if shaky[solver:low+format_answer/reread_question/exact_arithmetic/python_checks, critic:low+format_answer/reread_question/verify_by_substitution/case_enumeration/python_checks] > final_pick if shaky[judge:low+format_answer/reread_question]; answered 4, correct 225

Both wrong: 9.

## Most expensive correct questions (possible waste)
- [Intermediate Algebra L5, cost 32663] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes th
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if proceed[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration] > repair if shaky[solver:low+format_answer/reread_question/exact_arithmetic/python_checks, critic:low+format_answer/reread_question/verify_by_substitution/case_enumeration/python_checks] > final_pick if shaky[judge:low+format_answer/reread_question]
- [Number Theory L5, cost 30877] Let $N$ be the number of ways to write $2010$ in the form $2010 = a_3 \cdot 10^3 + a_2 \cdot 10^2 + a_1 \cdot 10 + a_0$, where the $a_i$'s are integers, and $0 \le a_i \le 99$. An 
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if proceed[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration] > repair if shaky[solver:low+format_answer/reread_question/exact_arithmetic/python_checks, critic:low+format_answer/reread_question/verify_by_substitution/case_enumeration/python_checks] > final_pick if shaky[judge:low+format_answer/reread_question]
- [Geometry L5, cost 29818] Square $ABCD$ has center $O,\ AB=900,\ E$ and $F$ are on $AB$ with $AE<BF$ and $E$ between $A$ and $F, m\angle EOF =45^\circ,$ and $EF=400.$ Given that $BF=p+q\sqrt{r},$ where $p,q
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if proceed[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration] > repair if shaky[solver:low+format_answer/reread_question/exact_arithmetic/python_checks, critic:low+format_answer/reread_question/verify_by_substitution/case_enumeration/python_checks] > final_pick if shaky[judge:low+format_answer/reread_question]
- [Precalculus L5, cost 29542] Let $a$ and $b$ be two 12th roots of unity, not necessarily distinct.  Find the number of different possible values of $(a + b)^{12}.$
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if proceed[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration] > repair if shaky[solver:low+format_answer/reread_question/exact_arithmetic/python_checks, critic:low+format_answer/reread_question/verify_by_substitution/case_enumeration/python_checks] > final_pick if shaky[judge:low+format_answer/reread_question]
- [Intermediate Algebra L5, cost 28878] Let
\[x^8 + 98x^4 + 1 = p(x) q(x),\]where $p(x)$ and $q(x)$ are monic, non-constant polynomials with integer coefficients.  Find $p(1) + q(1).$
  plan: base_solve[solver:low+format_answer/reread_question/exact_arithmetic/python_checks] > code_check if proceed[coder:low+format_answer/python_checks/verify_by_substitution/case_enumeration] > repair if shaky[solver:low+format_answer/reread_question/exact_arithmetic/python_checks, critic:low+format_answer/reread_question/verify_by_substitution/case_enumeration/python_checks] > final_pick if shaky[judge:low+format_answer/reread_question]