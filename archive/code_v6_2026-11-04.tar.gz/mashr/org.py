"""The organization: the meta-agent (HR) gives every node a residual harness.

A task agent's full harness = its self harness (role; evolved, fixed) + the residual harness for
harnesses the HR writes for it on each problem: which tools it gets (Python functions preloaded in
its sandbox; no tools = no Python), which skills it gets (how-to texts), and a note (a problem-specific
instruction). The HR's own harness is its handbook (policy).

The designer edits: agents (roles), the skill library, the HR handbook. The tool library is fixed
(tools.TOOLS, version B); a later version lets the designer write tools.

HR output (code for the structure, free text for the notes):

    ```python
    a = coder("high", tools=["exact_solve"], skills=["case_split"])
    b = solver("high")
    v = verifier("max", a, b, tools=["check_answer"])
    return v
    ```
    ```notes
    a: Count n odd and n even separately; the answer is their sum.
    v: Re-check the boundary case n = 0.
    ```
"""
import ast
import copy
import json
import os
import re

from .tools import TOOLS

LEVELS = ("off", "low", "high", "xhigh", "max")
# MASHR_MAX_THINK caps every employee's thinking; levels above it are read as the cap
MAX_THINK = os.environ.get("MASHR_MAX_THINK", "max")
THINK = LEVELS[:LEVELS.index(MAX_THINK) + 1]
BUDGET_DOC = ("off (thinking is disabled in this system: employees reason in their written answer)"
              if MAX_THINK == "off" else
              "off ~0, low <=1k, high <=4k, xhigh <=8k, max <=16k reasoning tokens")


def lv(level):
    """The level, or the cap if it is lower."""
    return level if level in THINK else MAX_THINK


NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,30}$")
LIMITS = {"agents": 8, "role_chars": 600, "policy_chars": 2500, "nodes": 8, "skills": 20,
          "skill_chars": 400, "skills_per_node": 3, "tools_per_node": 3, "note_chars": 400}


def _strs(node):
    if isinstance(node, (ast.List, ast.Tuple)):
        return [x.value for x in node.elts if isinstance(x, ast.Constant) and isinstance(x.value, str)]
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return [node.value]
    return None


def split_output(text):
    """(code, notes text) from the HR's answer."""
    code = re.search(r"```(?:python)?\s*\n(.*?)```", text, re.S)
    notes = re.search(r"```notes\s*\n(.*?)(?:```|$)", text, re.S)
    if code and notes and code.start() == notes.start():
        code = None
    src = code.group(1) if code else text.split("```notes")[0]
    return src, notes.group(1) if notes else ""


def parse_notes(text, names=None):
    """{variable: note}; a line 'name: text' with a node variable starts a note, other lines continue
    the current one."""
    out, cur = {}, None
    for line in text.splitlines():
        m = re.match(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$", line)
        if m and (names is None or m.group(1) in names):
            cur = m.group(1)
            out[cur] = m.group(2).strip()
        elif cur and line.strip():
            out[cur] += " " + line.strip()
    return out


def parse_program(pool, text):
    """HR output -> ({"nodes": [...], "output": id}, problems) or (None, problems). A node is
    {id, agent, thinking, inputs, tools, skills, note}."""
    src, notes_text = split_output(text)
    lines = [l for l in src.strip().splitlines() if l.strip() and not l.strip().startswith("#")]
    try:
        tree = ast.parse("def _plan():\n" + "\n".join("    " + l.strip() for l in lines))
    except SyntaxError as e:
        return None, [f"syntax error: {e.msg} (line {(e.lineno or 2) - 1})"]
    notes = parse_notes(notes_text, set(re.findall(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=", src, re.M)))
    nodes, cur, out, probs, var_of = [], {}, None, [], {}
    for st in tree.body[0].body:
        final = isinstance(st, ast.Return) and isinstance(st.value, ast.Call)
        if final:
            st = ast.Assign(targets=[ast.Name(id="out")], value=st.value, lineno=st.lineno)
        if isinstance(st, ast.Return):
            if isinstance(st.value, ast.Name) and st.value.id in cur:
                out = cur[st.value.id]
            else:
                probs.append("return must name a node defined above")
            break
        if not (isinstance(st, ast.Assign) and len(st.targets) == 1
                and isinstance(st.targets[0], ast.Name) and isinstance(st.value, ast.Call)
                and isinstance(st.value.func, ast.Name)):
            probs.append(f"line {st.lineno - 1}: expected `x = employee(\"thinking\", inputs..., "
                         f"tools=[...], skills=[...])`")
            continue
        var, agent, args = st.targets[0].id, st.value.func.id, list(st.value.args)
        if agent not in pool["agents"]:
            probs.append(f"line {st.lineno - 1}: unknown employee {agent!r}")
            continue
        th = lv("low")
        if args and isinstance(args[0], ast.Constant) and isinstance(args[0].value, str):
            th = args.pop(0).value
        kw = {k.arg: k.value for k in st.value.keywords}
        if isinstance(kw.get("thinking"), ast.Constant):
            th = kw["thinking"].value
        if th in LEVELS and th not in THINK:
            probs.append(f"minor: line {st.lineno - 1}: thinking capped at {MAX_THINK}")
            th = MAX_THINK
        elif th not in THINK:
            probs.append(f"line {st.lineno - 1}: thinking must be one of {THINK}")
            th = lv("low")
        inputs = []
        for x in args:
            if isinstance(x, ast.Name) and x.id in cur:
                inputs.append(cur[x.id])
            elif isinstance(x, ast.Name):
                probs.append(f"line {st.lineno - 1}: input {x.id!r} is not a node defined above")
            else:
                probs.append(f"minor: line {st.lineno - 1}: non-node argument ignored")
        tools, skills = _strs(kw["tools"]) if "tools" in kw else [], \
            _strs(kw["skills"]) if "skills" in kw else []
        if tools is None or skills is None:
            probs.append(f"minor: line {st.lineno - 1}: tools/skills must be lists of names")
            tools, skills = tools or [], skills or []
        bad = [t for t in tools if t not in pool["tools"]] + [k for k in skills if k not in pool["skills"]]
        if bad:
            probs.append(f"minor: line {st.lineno - 1}: unknown tools/skills {bad} dropped")
        tools = [t for t in tools if t in pool["tools"]][:LIMITS["tools_per_node"]]
        skills = [k for k in skills if k in pool["skills"]][:LIMITS["skills_per_node"]]
        note = kw["note"].value if isinstance(kw.get("note"), ast.Constant) and \
            isinstance(kw["note"].value, str) else notes.get(var, "")
        if len(nodes) == LIMITS["nodes"]:
            probs.append(f"more than {LIMITS['nodes']} nodes")
            break
        nid = var if var not in cur and all(n["id"] != var for n in nodes) else f"{var}_{len(nodes)}"
        nodes.append({"id": nid, "agent": agent, "thinking": th, "inputs": inputs, "tools": tools,
                      "skills": skills, "note": note[:LIMITS["note_chars"]]})
        cur[var] = nid
        var_of[nid] = var
        if final:
            out = nid
            break
    if not nodes:
        return None, probs + ["no node"]
    if out is None:
        probs.append("no return; using the last node")
        out = nodes[-1]["id"]
    for k in notes:
        if k not in cur:
            probs.append(f"minor: note for unknown node {k!r} ignored")
    return {"nodes": nodes, "output": out}, probs


def fallback_plan(pool):
    """Fixed, not editable: the first employee alone, thinking low, plain Python."""
    a = next(iter(pool["agents"]))
    return {"nodes": [{"id": "a", "agent": a, "thinking": lv("low"), "inputs": [], "tools": ["python"],
                       "skills": [], "note": ""}], "output": "a"}


def program_str(p):
    def one(n):
        args = [f'"{n["thinking"]}"'] + n["inputs"]
        if n["tools"]:
            args.append(f"tools={n['tools']}")
        if n["skills"]:
            args.append(f"skills={n['skills']}")
        return f"{n['id']} = {n['agent']}({', '.join(args)})" + (f"  # note: {n['note'][:80]}"
                                                                   if n["note"] else "")
    return "; ".join([one(n) for n in p["nodes"]] + [f"return {p['output']}"])


def shape(p):
    """Canonical architecture: 'coder.high[T]>verifier.max' ([T] tools, [S] skills)."""
    depth = {}
    for n in p["nodes"]:
        depth[n["id"]] = 1 + max((depth[i] for i in n["inputs"]), default=-1)
    layers = {}
    for n in p["nodes"]:
        tag = ("[T]" if n["tools"] else "") + ("[S]" if n["skills"] else "")
        layers.setdefault(depth[n["id"]], []).append(f"{n['agent']}.{n['thinking']}{tag}")
    return ">".join(",".join(sorted(layers[d])) for d in sorted(layers))


def validate(pool):
    errs = [f"missing key {k!r}" for k in ("agents", "skills", "tools", "policy") if k not in pool]
    if errs:
        return errs
    if not pool["agents"] or len(pool["agents"]) > LIMITS["agents"]:
        errs.append(f"1..{LIMITS['agents']} employees required")
    for name, a in pool["agents"].items():
        if not NAME.match(name):
            errs.append(f"bad employee name {name!r}")
        if not isinstance(a, dict) or set(a) != {"role"} or not isinstance(a["role"], str) \
                or not a["role"].strip() or len(a["role"]) > LIMITS["role_chars"]:
            errs.append(f"{name!r}: {{\"role\": 1..{LIMITS['role_chars']} chars}}")
    if len(pool["skills"]) > LIMITS["skills"]:
        errs.append(f"too many skills: {len(pool['skills'])} > {LIMITS['skills']}")
    for sid, txt in pool["skills"].items():
        if not NAME.match(sid) or not isinstance(txt, str) or not txt.strip() \
                or len(txt) > LIMITS["skill_chars"]:
            errs.append(f"skill {sid!r}: id letters/digits/_ and text 1..{LIMITS['skill_chars']} chars")
    for t in pool["tools"]:
        if t not in TOOLS:
            errs.append(f"unknown tool {t!r} (the tool library is fixed: {', '.join(TOOLS)})")
    if not isinstance(pool["policy"], str) or len(pool["policy"]) > LIMITS["policy_chars"]:
        errs.append(f"policy must be a string of at most {LIMITS['policy_chars']} chars")
    return errs


def apply_ops(pool, ops):
    """Designer edits; every op must say why it belongs on that layer ("why")."""
    o = copy.deepcopy(pool)
    errs = []
    if not isinstance(ops, list) or not ops:
        return o, ["ops must be a non-empty list"]
    for i, op in enumerate(ops):
        try:
            if not str(op.get("why", "")).strip():
                raise ValueError("every op needs a 'why' (the evidence, and why this layer)")
            kind = op["op"]
            if kind == "add_agent":
                if op["name"] in o["agents"]:
                    raise ValueError(f"employee {op['name']!r} exists")
                o["agents"][op["name"]] = {"role": op["role"]}
            elif kind == "remove_agent":
                del o["agents"][op["name"]]
            elif kind == "edit_agent":
                o["agents"][op["name"]]["role"] = op["role"]
            elif kind in ("add_skill", "edit_skill"):
                if (op["id"] in o["skills"]) != (kind == "edit_skill"):
                    raise ValueError(f"skill {op['id']!r} " + ("exists" if kind == "add_skill"
                                                               else "does not exist"))
                o["skills"][op["id"]] = op["text"]
            elif kind == "remove_skill":
                del o["skills"][op["id"]]
            elif kind == "set_policy":
                o["policy"] = op["text"]
            else:
                raise ValueError(f"unknown op {kind!r}")
        except (KeyError, TypeError, ValueError, AttributeError) as e:
            errs.append(f"op {i} ({json.dumps(op)[:120]}): {type(e).__name__} {e}")
    for what in ("agents", "skills"):
        for name in set(pool[what]) - set(o[what]):
            if re.search(rf"\b{re.escape(name)}\b", o["policy"]):
                errs.append(f"policy still mentions removed {what[:-1]} {name!r}")
    return o, errs + validate(o)


def hr_prompt(pool):
    L = ["You are the HR of a team of employees that solve math problems. For each problem, before "
         "anyone works on it, you design the team: which employees work on it, how much each one "
         "thinks, who passes work to whom, and what each one is given for this problem: tools, "
         "skills and a short note. Spend as little as possible while getting the answer right.", "",
         "## How to write it",
         "First the structure as Python-like code (read, not executed), then optional notes:",
         "```python",
         f'a = coder("{lv("high")}", tools=["exact_solve"], skills=["case_split"])',
         f'b = solver("{lv("high")}")',
         f'v = verifier("{lv("max")}", a, b, tools=["check_answer"])',
         "return v", "```", "```notes",
         "a: Count n odd and n even separately; the answer is their sum.",
         "v: Re-check the boundary case n = 0.", "```",
         '- `x = employee("thinking", inputs..., tools=[...], skills=[...])` adds a node: the employee '
         "reads the problem, the full work of its input nodes, its skills and your note, then gives "
         "its own solution and answer.",
         "- Nodes without inputs work in parallel. A node can only take nodes defined above it. "
         "`return x`: x's answer is final.",
         f"- thinking: {BUDGET_DOC}." + ("" if MAX_THINK == "off" else " Longer thinking is more "
                                         "accurate on hard problems and costs more."),
         "- tools: Python functions the employee can call (no tools = no Python). skills: how-to "
         "texts. notes: one line per node, specific to this problem (optional).",
         f"- At most {LIMITS['nodes']} nodes, {LIMITS['tools_per_node']} tools and "
         f"{LIMITS['skills_per_node']} skills per node. Cost = generated tokens + 0.2 x prompt tokens.",
         "", "## Employees"]
    L += [f"- {n}: {a['role'][:300]}" for n, a in pool["agents"].items()]
    L += ["", "## Tools"] + [f"- {t}: {TOOLS[t]['doc']}" for t in pool["tools"]]
    if pool["skills"]:
        L += ["", "## Skills"] + [f"- {k}: {v[:150]}" for k, v in pool["skills"].items()]
    L += ["", "## Handbook", pool["policy"], "", "Output only the code block and the notes block."]
    return "\n".join(L)


HAND = {
    "agents": {
        "solver": {"role": "You are a careful math solver. Reason step by step."},
        "coder": {"role": "You are a math solver who computes with short, correct Python and reasons "
                           "about its output."},
        "verifier": {"role": "You check the solutions you are given: re-derive the answer "
                              "independently, find any error, and give the answer you believe is "
                              "correct."},
    },
    "skills": {
        "case_split": "Split the problem into disjoint, exhaustive cases; solve each; check that the "
                      "cases cover everything exactly once; combine.",
        "substitute_back": "After finding a candidate answer, substitute it into every condition of "
                           "the problem and confirm each one holds.",
        "small_cases": "Compute the first few small cases by hand or by code, find the pattern, then "
                       "prove or verify it before using it.",
    },
    "tools": list(TOOLS),
    "policy": "Easy problems: one solver. Harder problems: give the coder relevant tools, and add a "
              "verifier that reads the solution.",
}

BASELINES = {
    "single_off": 'a = solver("off")\nreturn a',
    "coder_off_tools": 'a = coder("off", tools=["python", "exact_solve", "brute_force"])\nreturn a',
    "solve_verify_off": 'a = solver("off")\nv = verifier("off", a, tools=["check_answer"])\nreturn v',
    "single_high": 'a = solver("high")\nreturn a',
    "single_max": 'a = solver("max")\nreturn a',
    "coder_max_tools": 'a = coder("max", tools=["python", "exact_solve", "brute_force"])\nreturn a',
}
