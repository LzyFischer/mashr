"""The organization v4: nodes are employees; reasoning methods are skills; the orchestrator (HR)
builds the topology per question.

The designer provides the parts, never an architecture:
  agents        name -> {"role": str, "function": "produce" | "check" | "decide", "skills": [ids]}
  skills        id -> {"text": str, "tool": 0..3}    how-to an agent can switch on. Methods (CoT,
                program-of-thought, ReAct, self-check) and domain techniques alike; tool > 0 lets the
                agent run Python up to that many times while the skill is on
  conditions    name -> expression over runtime signals (blocks.parse_cond)
  final         "last" (current answer after the last stage that ran) | "vote" (majority of all)
  orchestrator  {"thinking": "off" | "low"}
  policy        the orchestrator's dispatch rules; may describe architectures in words

Per question the orchestrator outputs the topology:
  {"stages": [{"nodes": ["agent:thinking:skill+skill[:xK]", ...] (or {"agent", "thinking", "skills",
               "copies"} objects), "if": <condition>, "sees": "earlier" | "none", "rounds": r,
               "loop": l}, ...]}
  a stage whose employees have different functions runs as consecutive parts (produce, check,
  decide); the later parts run if and only if the first part ran.
  produce  each node answers `copies` times (copies > 1 = self-consistency). The first stage works
           independently; a later produce stage reads the earlier work unless sees = "none".
           rounds > 1 = debate: the stage's nodes read each other's last outputs and revise.
  check    each node checks the earlier work against the current answer: VERDICT PASS/FAIL and
           the answer it believes. loop l > 0 = evaluator-optimizer / Reflexion: on FAIL the
           producer of the current answer revises with the critiques, and the stage checks again,
           up to l times.
  decide   each node picks the final answer from the earlier work.
  The first stage always runs and must produce; a later stage runs only if its "if" holds.

Invalid orchestrator output: (1) repair what can be repaired (unknown agents or skills dropped, bad
conditions -> "always", limits truncated); (2) if nothing usable is left, ask once more with the
errors; (3) else the fixed fallback (not editable): the first produce agent alone, thinking low.
"""
import copy
import json
import re

from .blocks import BOOL_SIGNALS, NUM_SIGNALS, NAME, THINK, compile_conditions, parse_cond

FUNCTIONS = ("produce", "check", "decide")
LIMITS = {"agents": 8, "skills": 30, "skills_per_agent": 6, "skill_chars": 500, "role_chars": 400,
          "policy_chars": 2500, "conditions": 10, "stages": 5, "nodes_per_stage": 4, "copies": 5,
          "rounds": 3, "loop": 3, "tool": 3, "calls": 30}


# ---------------------------------------------------------------- plans

def tool_budget(pool, skills) -> int:
    return max((pool["skills"][s].get("tool", 0) for s in skills), default=0)


def stage_calls(pool, st) -> int:
    """Upper bound on model calls of one stage."""
    per = [n["copies"] * (1 + tool_budget(pool, n["skills"])) for n in st["nodes"]]
    if st["function"] == "produce":
        return sum(per) * st["rounds"]
    if st["function"] == "check":
        return sum(per) * (1 + st["loop"]) + st["loop"] * (1 + LIMITS["tool"])
    return sum(per)


def _int(v, lo, hi, default):
    return min(hi, max(lo, v)) if isinstance(v, int) and not isinstance(v, bool) else default


def check_plan(pool: dict, p, conds: dict | None = None) -> tuple[dict | None, list[str]]:
    """Normalize a topology, repairing what can be repaired. Returns (plan or None, problems)."""
    if conds is None:
        conds = compile_conditions(pool)[0]
    if not isinstance(p, dict) or not isinstance(p.get("stages"), list):
        return None, ["the plan needs a 'stages' list"]
    probs, stages, calls, full = [], [], 0, False
    for raw in p["stages"]:
        if full:
            break
        if not isinstance(raw, dict):
            probs.append("a stage is not an object")
            continue
        nodes_raw = raw.get("nodes", raw.get("agents"))
        if isinstance(nodes_raw, (str, dict)):
            nodes_raw = [nodes_raw]
        if not isinstance(nodes_raw, list):
            probs.append("a stage has no 'nodes' list")
            continue
        groups: dict = {}                   # function -> nodes, in order of first appearance
        raw = dict(raw)
        for nd in nodes_raw:
            if isinstance(nd, str):
                nd = parse_node(nd)
            if isinstance(nd, dict) and nd.get("_stage"):
                for k, v in nd["_stage"].items():
                    raw.setdefault(k, v)
                probs.append(f"minor: stage option {nd['_stage']} written in a node")
                if nd["agent"] is None:
                    continue
            if not isinstance(nd, dict) or nd.get("agent") not in pool["agents"]:
                probs.append(f"unknown agent {nd.get('agent') if isinstance(nd, dict) else nd!r}")
                continue
            a = pool["agents"][nd["agent"]]
            sk = nd.get("skills") if isinstance(nd.get("skills"), list) else []
            sk = [x for x in sk if x not in ("none", "")]
            bad = [x for x in sk if x not in a["skills"]]
            if bad:
                probs.append(f"minor: {nd['agent']} does not hold {bad}")
            th = nd.get("thinking", "off")
            if th not in THINK:
                probs.append(f"minor: bad thinking {th!r}")
            groups.setdefault(a["function"], []).append(
                {"agent": nd["agent"], "thinking": th if th in THINK else "off",
                 "skills": [x for x in sk if x in a["skills"]],
                 "copies": _int(nd.get("copies", 1), 1, LIMITS["copies"], 1)})
        if len(groups) > 1:
            probs.append("minor: a stage mixed functions; its parts run in order")
        cond, lead = raw.get("if", "always"), None
        for fn in sorted(groups, key=FUNCTIONS.index):
            nodes = groups[fn]
            if len(nodes) > LIMITS["nodes_per_stage"]:
                probs.append(f"more than {LIMITS['nodes_per_stage']} nodes in a stage")
                nodes = nodes[:LIMITS["nodes_per_stage"]]
            if not stages and fn != "produce":
                probs.append(f"the first stage must produce; dropped a leading {fn} stage")
                continue
            c = "always"
            if stages and lead is None:
                c, p_ = clean_cond(cond, conds)
                probs += p_
            st = {"function": fn, "nodes": nodes, "if": c,
                  "sees": ("none" if not stages or raw.get("sees") == "none" else "earlier"),
                  "rounds": _int(raw.get("rounds", 1), 1, LIMITS["rounds"], 1) if fn == "produce"
                  else 1,
                  "loop": _int(raw.get("loop", 0), 0, LIMITS["loop"], 0) if fn == "check" else 0}
            if len(stages) == LIMITS["stages"]:
                probs.append(f"more than {LIMITS['stages']} stages")
                full = True
                break
            n = stage_calls(pool, st)
            if calls + n > LIMITS["calls"]:
                probs.append(f"more than {LIMITS['calls']} model calls; later stages dropped")
                full = True
                break
            calls += n
            if lead is None:
                lead = len(stages)
            else:
                st["with"] = lead                  # runs if and only if the stage's first part ran
            stages.append(st)
    if not stages:
        return None, probs + ["no usable stage"]
    return {"stages": stages}, probs


STAGE_OPT = re.compile(r"(loop|rounds)\W*(\d*)", re.I)


def parse_node(s: str) -> dict:
    """'agent:thinking:skill+skill[:xK]' (later fields optional) -> node dict. A stage option the HR
    wrote in a node ('loop', 'checker:low:python_check+loop1') goes to "_stage"."""
    f = [x.strip() for x in s.split(":")]
    opts = {}
    m = STAGE_OPT.fullmatch(f[0])
    if m:                                   # the whole node is a stage option: "loop", "loop:1"
        n = m.group(2) or (f[1] if len(f) > 1 and f[1].isdigit() else "1")
        return {"agent": None, "_stage": {m.group(1).lower(): int(n)}}
    nd = {"agent": f[0]}
    if len(f) > 1 and f[1]:
        nd["thinking"] = f[1]
    if len(f) > 2:
        skills = []
        for x in (x.strip() for x in re.split(r"[+,]", f[2])):
            m = STAGE_OPT.fullmatch(x)
            if m:
                opts[m.group(1).lower()] = int(m.group(2) or 1)
            elif x:
                skills.append(x)
        nd["skills"] = skills
    if len(f) > 3 and re.fullmatch(r"x?\d+", f[3]):
        nd["copies"] = int(f[3].lstrip("x"))
    if opts:
        nd["_stage"] = opts
    return nd


def clean_cond(cond, conds) -> tuple[str, list[str]]:
    """A usable condition: as written; else with quotes stripped, lower-cased, PASS/FAIL read as
    not fail/fail (minor); else 'always'."""
    try:
        parse_cond(str(cond), conds)
        return str(cond), []
    except ValueError as e:
        err = e
    c = re.sub(r"['\"`]", " ", str(cond)).strip()
    for cand in (c, c.lower()):
        cand = re.sub(r"\bpass\b", "not fail", cand)
        try:
            parse_cond(cand, conds)
            return cand, [f"minor: condition {cond!r} read as {cand!r}"]
        except ValueError:
            pass
    return "always", [f"{err}; using 'always'"]


def drop_stage(plan: dict, i: int) -> dict:
    """The plan without stage i and the parts that run with it."""
    p = copy.deepcopy(plan)
    gone = {i} | {j for j, st in enumerate(p["stages"]) if st.get("with") == i}
    keep = [j for j in range(len(p["stages"])) if j not in gone]
    new = {j: k for k, j in enumerate(keep)}
    p["stages"] = [p["stages"][j] for j in keep]
    for st in p["stages"]:
        if "with" in st:
            st["with"] = new[st["with"]]
    return p


def fallback_plan(pool: dict) -> dict:
    """Fixed, not editable: the first produce agent alone, thinking low, no skills."""
    a = next(n for n, x in pool["agents"].items() if x["function"] == "produce")
    return {"stages": [{"function": "produce", "if": "always", "sees": "none", "rounds": 1,
                        "loop": 0, "nodes": [{"agent": a, "thinking": "low", "skills": [],
                                              "copies": 1}]}]}


def node_str(n) -> str:
    return (n["agent"] + (f"x{n['copies']}" if n["copies"] > 1 else "") + f":{n['thinking']}"
            + (f"+{'/'.join(n['skills'])}" if n["skills"] else ""))


def plan_str(p) -> str:
    out = []
    for st in p["stages"]:
        extra = ([f"rounds {st['rounds']}"] if st["rounds"] > 1 else []) + \
                ([f"loop {st['loop']}"] if st["loop"] else []) + \
                (["sees none"] if st["sees"] == "none" and out else [])
        out.append(("& " if "with" in st else "") + f"{st['function']}"
                   + ("" if st["if"] == "always" or "with" in st else f" if {st['if']}")
                   + (f" ({', '.join(extra)})" if extra else "") + "["
                   + ", ".join(node_str(n) for n in st["nodes"]) + "]")
    return " > ".join(out).replace(" > & ", " & ")


def shape(p) -> str:
    """e.g. 'solver+coder>verifier?L2>judge?'  (? conditional, xk copies, Rr rounds, Ll loop)."""
    return "".join(("&" if "with" in st else ">" if i else "")
                   + "+".join(n["agent"] + (f"x{n['copies']}" if n["copies"] > 1 else "")
                              for n in st["nodes"])
                    + ("" if st["if"] == "always" or "with" in st else "?")
                    + (f"R{st['rounds']}" if st["rounds"] > 1 else "")
                    + (f"L{st['loop']}" if st["loop"] else "") for i, st in enumerate(p["stages"]))


# ---------------------------------------------------------------- the organization

def validate(pool: dict) -> list[str]:
    keys = ("agents", "skills", "conditions", "final", "orchestrator", "policy")
    errs = [f"missing key {k!r}" for k in keys if k not in pool]
    if errs:
        return errs
    for k in ("agents", "skills", "conditions"):
        if len(pool[k]) > LIMITS[k]:
            errs.append(f"too many {k}: {len(pool[k])} > {LIMITS[k]}")
    for sid, s in pool["skills"].items():
        if not NAME.match(sid):
            errs.append(f"bad skill id {sid!r} (letters, digits, underscores)")
        if not isinstance(s, dict) or not isinstance(s.get("text"), str) or not s["text"].strip() \
                or len(s["text"]) > LIMITS["skill_chars"]:
            errs.append(f"skill {sid!r} must be {{\"text\": 1..{LIMITS['skill_chars']} chars, "
                        f"\"tool\": 0..{LIMITS['tool']}}}")
            continue
        if set(s) - {"text", "tool"} or _int(s.get("tool", 0), 0, LIMITS["tool"], -1) != \
                s.get("tool", 0):
            errs.append(f"skill {sid!r}: only 'text' and 'tool' (0..{LIMITS['tool']})")
    for name, a in pool["agents"].items():
        if not NAME.match(name):
            errs.append(f"bad agent name {name!r}")
        if not isinstance(a, dict) or not str(a.get("role", "")).strip():
            errs.append(f"{name!r} needs a role")
            continue
        if a.get("function") not in FUNCTIONS:
            errs.append(f"{name!r}: function must be one of {FUNCTIONS}")
        if len(a["role"]) > LIMITS["role_chars"]:
            errs.append(f"{name!r}: role longer than {LIMITS['role_chars']} chars")
        sk = a.get("skills", [])
        if not isinstance(sk, list) or len(sk) > LIMITS["skills_per_agent"]:
            errs.append(f"{name!r} must hold at most {LIMITS['skills_per_agent']} skills")
            continue
        errs += [f"{name!r} holds unknown skill {s!r}" for s in sk if s not in pool["skills"]]
    if not any(isinstance(a, dict) and a.get("function") == "produce"
               for a in pool["agents"].values()):
        errs.append("the organization needs at least one produce agent")
    errs += compile_conditions(pool)[1]
    if pool["final"] not in ("last", "vote"):
        errs.append("final must be 'last' or 'vote'")
    o = pool["orchestrator"]
    if not isinstance(o, dict) or set(o) - {"thinking"} or o.get("thinking", "off") not in ("off",
                                                                                           "low"):
        errs.append("orchestrator must be {\"thinking\": \"off\" | \"low\"}")
    if not isinstance(pool["policy"], str) or len(pool["policy"]) > LIMITS["policy_chars"]:
        errs.append(f"policy must be a string of at most {LIMITS['policy_chars']} chars")
    elif re.search(r"\{\s*\"stages\"", pool["policy"]):
        errs.append("the policy may describe architectures in words but must not contain JSON plans")
    return errs


def apply_ops(pool: dict, ops) -> tuple[dict, list[str]]:
    """Apply designer edit operations; returns (new pool, errors incl. validation errors)."""
    o = copy.deepcopy(pool)
    errs = []
    if not isinstance(ops, list) or not ops:
        return o, ["ops must be a non-empty list"]
    for i, op in enumerate(ops):
        try:
            kind = op["op"]
            if kind == "add_agent":
                if op["name"] in o["agents"]:
                    raise ValueError(f"agent {op['name']!r} exists")
                o["agents"][op["name"]] = {"role": op["role"], "function": op["function"],
                                           "skills": list(op.get("skills", []))}
            elif kind == "remove_agent":
                del o["agents"][op["name"]]
            elif kind == "edit_role":
                o["agents"][op["name"]]["role"] = op["role"]
            elif kind == "set_function":
                o["agents"][op["name"]]["function"] = op["function"]
            elif kind == "set_skills":
                o["agents"][op["name"]]["skills"] = list(op["skills"])
            elif kind in ("add_skill", "edit_skill"):
                if (op["id"] in o["skills"]) != (kind == "edit_skill"):
                    raise ValueError(f"skill {op['id']!r} " + ("exists (use edit_skill)"
                                                               if kind == "add_skill"
                                                               else "does not exist"))
                o["skills"][op["id"]] = {"text": op["text"], "tool": op.get("tool", 0)}
                for name in op.get("to", []):
                    if op["id"] not in o["agents"][name]["skills"]:
                        o["agents"][name]["skills"].append(op["id"])
            elif kind == "remove_skill":
                del o["skills"][op["id"]]
                for a in o["agents"].values():
                    a["skills"] = [s for s in a["skills"] if s != op["id"]]
            elif kind == "set_condition":
                o["conditions"][op["name"]] = op["expr"]
            elif kind == "remove_condition":
                del o["conditions"][op["name"]]
            elif kind == "set_final":
                o["final"] = op["rule"]
            elif kind == "set_orchestrator":
                o["orchestrator"] = {"thinking": op["thinking"]}
            elif kind == "set_policy":
                o["policy"] = op["text"]
            else:
                raise ValueError(f"unknown op {kind!r}")
        except (KeyError, TypeError, ValueError, AttributeError) as e:
            errs.append(f"op {i} ({json.dumps(op)[:120]}): {type(e).__name__} {e}")
    for what in ("agents", "skills", "conditions"):
        for name in set(pool[what]) - set(o[what]):
            if re.search(rf"\b{re.escape(name)}\b", o["policy"]):
                errs.append(f"policy still mentions removed {what[:-1]} {name!r}")
    return o, errs + validate(o)


def orchestrator_prompt(pool: dict) -> str:
    final = ("the current answer after the last stage that ran" if pool["final"] == "last"
             else "the majority of all answers produced")
    L = ["You are the HR of a team of agents that solve math problems. For each problem, before "
         "anyone works on it, you staff it: which employees work on it in which stages, how much "
         "each one thinks, which of their skills to switch on, and when each later stage runs. "
         "Spend as little as possible while keeping accuracy.", "",
         "## How a staffing plan runs",
         "- Stages run in order. The first stage always runs and must produce answers; a later "
         "stage runs only if its \"if\" holds. Put employees of different functions in separate "
         "stages.",
         "- produce: each employee answers (\"copies\": k = answers k times independently). A later "
         "produce stage reads the earlier work (\"sees\": \"none\" = solves fresh). \"rounds\": r > 1 "
         "= debate: the stage's employees read each other's answers and revise.",
         "- check: each employee checks the earlier work against the current answer and says PASS or "
         "FAIL. \"loop\": l > 0 = on FAIL the author of the current answer revises from the critique "
         "and the check runs again, up to l times.",
         "- decide: each employee picks the final answer from the earlier work.",
         f"- The final answer is {final}.", "",
         "## Conditions for later stages",
         "\"always\", a named condition below, or an expression over the signals disagree (answers so "
         "far differ or one is missing), missing, unsure (someone said 'Confidence: low'), fail (a "
         "check said FAIL), tool_error, and the numbers agreement (share of answers equal to the "
         "current one, 0-1), answers, tokens (most tokens one call generated in the last stage), "
         "steps, which need a comparison such as \"agreement < 1\" or \"tokens > 3000\"; combine "
         "with and/or/not."]
    L += [f"- {k}: {v}" for k, v in pool["conditions"].items()]
    L += ["", "## Employees (thinking off ~200 generated tokens per call; low up to ~1000 extra; "
              "high up to ~4000 extra)"]
    for name, a in pool["agents"].items():
        L.append(f"- {name} ({a['function']}; can switch on: {', '.join(a['skills']) or 'nothing'})"
                 f": {a['role'][:200]}")
    used = [x for x in pool["skills"] if any(x in a["skills"] for a in pool["agents"].values())]
    if used:
        L += ["", "## Skills (switch on only what the problem needs)"]
        L += [f"- {x}{' [runs Python]' if pool['skills'][x].get('tool') else ''}: "
              f"{pool['skills'][x]['text'][:120]}" for x in used]
    L += ["", "## Output: exactly one JSON object, nothing else",
          '{"stages": [{"nodes": ["<employee>:<off|low|high>:<skill>+<skill>", ...]}, '
          '{"nodes": [...], "if": "<condition>"}]}',
          "A node is one string: employee, thinking, then skills joined by + (empty for none), e.g. "
          "\"solver:low:cot\" or \"judge:off:\"; add \":x3\" for 3 copies. Give each employee only "
          "skills from its own \"can switch on\" list. Optional per stage: \"sees\", \"rounds\" "
          f"(produce), \"loop\" (check). At most {LIMITS['stages']} stages and {LIMITS['nodes_per_stage']} employees "
          f"per stage.", "", "## Dispatch policy", pool["policy"]]
    return "\n".join(L)


# ---------------------------------------------------------------- the hand-written start

HAND = {
    "agents": {
        "solver": {"role": "You are a careful math solver.", "function": "produce",
                   "skills": ["cot", "reread_question", "verify_by_substitution"]},
        "algebraist": {"role": "You are a math solver who prefers algebra: define variables, write "
                                "equations, solve them.", "function": "produce",
                       "skills": ["cot", "reread_question"]},
        "coder": {"role": "You are a math solver who computes with short, correct Python programs "
                           "and reasons about their output.", "function": "produce",
                  "skills": ["pot", "react"]},
        "verifier": {"role": "You are a verifier. You check whether the current answer is correct.",
                     "function": "check", "skills": ["python_check", "reread_question"]},
        "critic": {"role": "You are a critic. You look for errors in reasoning, arithmetic and in what "
                            "the question asks.", "function": "check", "skills": ["reread_question"]},
        "judge": {"role": "You are the final decider. You read all the work and decide the single "
                           "correct answer.", "function": "decide", "skills": []},
    },
    "skills": {
        "cot": {"text": "Reason step by step, writing out each step before the next.", "tool": 0},
        "pot": {"text": "Write one Python program that computes the answer and prints it; answer "
                        "from its output.", "tool": 1},
        "react": {"text": "Reason step by step; run Python whenever a computation or a case check is "
                          "error-prone, and use its output.", "tool": 3},
        "python_check": {"text": "Check the answer with Python: substitute it into the conditions, "
                                 "brute-force small cases, or recompute it independently.",
                         "tool": 1},
        "reread_question": {"text": "Before answering, re-read the question and make sure your final "
                                    "number answers exactly what is asked.", "tool": 0},
        "verify_by_substitution": {"text": "After finding the answer, plug it back into the "
                                           "conditions of the problem and confirm each holds.",
                                   "tool": 0},
    },
    "conditions": {"shaky": "disagree or fail", "hard": "tokens > 4000 or missing or tool_error"},
    "final": "last",
    "orchestrator": {"thinking": "off"},
    "policy": "Routine problems: one solver with cot, thinking off. Standard problems: one solver "
              "(low), then a verifier if hard. Hard problems (extrema, counting with restrictions, "
              "geometry, many conditions): solver and coder in parallel, then a judge if shaky.",
}

# fixed architectures on HAND, evaluated on test for comparison (no orchestrator call)
BASELINES = {
    "single_off": {"stages": [{"nodes": [{"agent": "solver", "thinking": "off", "skills": ["cot"]}]}]},
    "single_low": {"stages": [{"nodes": [{"agent": "solver", "thinking": "low", "skills": ["cot"]}]}]},
    "single_high": {"stages": [{"nodes": [{"agent": "solver", "thinking": "high",
                                           "skills": ["cot"]}]}]},
    "sc3_low": {"stages": [{"nodes": [{"agent": "solver", "thinking": "low", "skills": ["cot"],
                                       "copies": 3}]}]},
    "pot_low": {"stages": [{"nodes": [{"agent": "coder", "thinking": "low", "skills": ["pot"]}]}]},
}
