"""Fast loop v3: the orchestrator's call and the executor for block-based workflows (blocks.py).

Model-written Python runs in a separate interpreter without network (unshare -rn when available),
with memory, CPU-time and file-size limits, in a temporary directory.
"""
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from .blocks import block, check_plan, compile_conditions, eval_cond, fallback_plan, \
    orchestrator_prompt, parse_cond
from .mas import MODEL, extract

ANSWER_FMT = "End your response with a final line of the form '#### <number>'."
VERDICT_FMT = ("Before the final line, add a line 'VERDICT: PASS' if the current answer is correct "
               "or 'VERDICT: FAIL' if it is not.")
CRITIQUE_FMT = ("End with a line 'VERDICT: PASS' if the draft's final answer is correct, otherwise "
                "explain the errors and end with 'VERDICT: FAIL'.")
CONF_FMT = "Before the final line, add a line 'Confidence: high' or 'Confidence: low'."
PROMPT_WEIGHT = 0.2   # cost = generated tokens + 0.2 * prompt tokens (all calls, incl. orchestrator)
SHOW_CHARS = 4000

PY = os.environ.get("MASHR_PY", "/usr/bin/python3")   # needs numpy/sympy; the tinker env has none
CODE = re.compile(r"```(?:python|py)\s*\n(.*?)```", re.S)
VERDICT = re.compile(r"VERDICT:\s*\**\s*(PASS|FAIL)", re.I)
_ISOLATE = (["unshare", "-rn"] if shutil.which("unshare") and subprocess.run(
    ["unshare", "-rn", "true"], capture_output=True).returncode == 0 else [])
_py_cache: dict = {}
_py_lock = threading.Lock()


def run_python(code: str, timeout: int = 10) -> tuple[str, bool]:
    """Run code; returns (stdout tail plus error, ok). Results are memoized per code string."""
    with _py_lock:
        if code in _py_cache:
            return _py_cache[code]
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "main.py")
        with open(path, "w") as f:
            f.write(code)
        cmd = ["prlimit", "--as=2000000000", f"--cpu={timeout}", "--fsize=10000000", "--",
               *_ISOLATE, PY, "-I", path]
        try:
            r = subprocess.run(cmd, cwd=d, capture_output=True, text=True, timeout=timeout + 5,
                               env={"PATH": "/usr/bin:/bin", "HOME": d})
            out, err, ok = r.stdout, r.stderr, r.returncode == 0
        except subprocess.TimeoutExpired:
            out, err, ok = "", "timed out", False
    text = out[-1500:].strip()
    if not ok:
        text += "\n[error] " + err.strip()[-800:]
    res = (text.strip() or "(no output)", ok)
    with _py_lock:
        _py_cache[code] = res
    return res


def majority(answers):
    """Most common non-missing answer; ties go to the earliest."""
    xs = [a for a in answers if a is not None]
    if not xs:
        return None
    c = Counter(xs)
    top = max(c.values())
    return next(a for a in xs if c[a] == top)


def cost(calls) -> float:
    return sum(c["gen_tokens"] + PROMPT_WEIGHT * c["prompt_tokens"] for c in calls)


def signals(st) -> dict:
    seen, cur = st["seen"], st["current"]
    vals = [a for a in seen if a is not None]
    return {"disagree": None in seen or len(set(seen)) > 1, "missing": cur is None,
            "unsure": st["last"].get("unsure", False), "fail": st["last"].get("fail", False),
            "tool_error": st["last"].get("tool_error", False),
            "agree": round(sum(a == cur for a in vals) / len(seen), 4) if seen and cur else 0.0,
            "answers": len(vals), "tokens": st["last"].get("tokens", 0), "steps": st["steps"]}


class Engine:
    def __init__(self, llm, model: str = MODEL, seed: int = 0):
        self.llm, self.model, self.seed = llm, model, seed

    # ------------------------------------------------------------ orchestrator

    def orchestrate(self, pool: dict, question: str):
        """Returns (plan, call or None). Fixed mode makes no call."""
        o = pool["orchestrator"]
        if o["mode"] == "fixed":
            return check_plan(pool, {"recipe": o["recipe"]})[0], None
        r = self.llm.chat(self.model, [{"role": "system", "content": orchestrator_prompt(pool)},
                                       {"role": "user", "content": f"Problem: {question}\n\n"
                                                                   "Your JSON:"}],
                          thinking=o.get("thinking", "off"), max_tokens=700, seed=self.seed)
        plan, probs = None, ["no JSON object"]
        m = re.search(r"\{.*\}", r.text, re.S)
        if m:
            try:
                plan, probs = check_plan(pool, json.loads(m.group(0)))
            except json.JSONDecodeError as e:
                probs = [f"bad JSON: {e}"]
        call = {"agent": "orchestrator", "step": None, "prompt_tokens": r.prompt_tokens,
                "gen_tokens": r.gen_tokens, "invalid": plan is None, "problems": probs[:3]}
        return (plan or fallback_plan(pool)), call

    # ------------------------------------------------------------ one agent call (with tool loop)

    def _call(self, pool, step, name, spec, b, user, seed_off=0):
        """One agent's turn: up to 1 + tool model calls; returns an output record."""
        system = pool["agents"][name]["role"]
        if spec.get("skills"):
            system += "\n\nSkills to apply:\n" + "\n".join(f"- {pool['skills'][x]}"
                                                           for x in spec["skills"])
        tool = b.get("tool", 0)
        if tool:
            system += (f"\n\nYou can run Python (numpy and sympy available) up to {tool} time(s): "
                       "write one ```python``` code block that prints what you need, then stop and "
                       "wait for its output.")
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        calls, shown, last_out, tool_error = [], [], None, False
        for k in range(tool + 1):
            r = self.llm.chat(self.model, msgs, thinking=spec["thinking"], max_tokens=2048,
                              seed=self.seed + seed_off)
            calls.append({"agent": name, "step": step, "block": b["id"],
                          "thinking": spec["thinking"], "prompt_tokens": r.prompt_tokens,
                          "gen_tokens": r.gen_tokens})
            shown.append(r.text)
            code = CODE.findall(r.text)
            if not code or "####" in r.text.split("```")[-1] or k == tool:
                break
            out, ok = run_python(code[-1])
            tool_error |= not ok
            last_out = out
            shown.append(f"[Python output]\n{out}")
            more = ("You may run code again or give the final answer." if k + 1 < tool
                    else "No more code runs. Give the final answer now.")
            msgs += [{"role": "assistant", "content": r.text},
                     {"role": "user", "content": f"Output:\n{out}\n\n{more} {ANSWER_FMT}"}]
        text = r.text
        if "####" in text or "boxed" in text or last_out is None:
            ans = extract(text)
        else:
            ans = extract(last_out)
        v = VERDICT.findall(text)
        return {"agent": name, "step": step, "block": b["id"], "text": "\n\n".join(shown),
                "answer": ans, "verdict": v[-1].upper() if v else None,
                "unsure": bool(re.search(r"Confidence:\s*\**\s*low", text, re.I)),
                "tool_error": tool_error, "calls": calls}

    @staticmethod
    def _shown(history, show):
        parts = []
        for h in history:
            body = (h["text"][-SHOW_CHARS:] if show.get(h["step"], "full") == "full"
                    else (f"Verdict: {h['verdict']}. " if h["verdict"] else "") +
                    f"Answer: {h['answer']}")
            parts.append(f"[{h['agent']}, step {h['step'] + 1} {h['block']}]\n{body}")
        return "\n\n".join(parts)

    def _par(self, fn, jobs):
        if len(jobs) == 1:
            return [fn(jobs[0])]
        with ThreadPoolExecutor(len(jobs)) as ex:
            return list(ex.map(fn, jobs))

    # ------------------------------------------------------------ block kinds

    def _solve(self, pool, i, st, b, agents, q, fmt):
        user = f"Problem: {q}\n\n{b['instruction']} {fmt}"
        if b.get("sees") == "earlier" and st["history"]:
            user = (f"Problem: {q}\n\nEarlier work:\n{self._shown(st['history'], st['show'])}\n\n"
                    f"{b['instruction']} {fmt}")
        jobs = [(a, s, k) for a, s in agents.items() for k in range(b.get("n", 1))]
        outs = self._par(lambda j: self._call(pool, i, j[0], j[1], b, user, seed_off=j[2]), jobs)
        return outs, outs, {}

    def _debate(self, pool, i, st, b, agents, q, fmt):
        rnd, _, _ = self._solve(pool, i, st, b, agents, q, fmt)
        calls = [c for o in rnd for c in o["calls"]]
        for _ in range(b["rounds"] - 1):
            ans = [o["answer"] for o in rnd]
            if None not in ans and len(set(ans)) == 1:
                break
            others = "\n\n".join(f"[{o['agent']}]\n{o['text'][-SHOW_CHARS:]}" for o in rnd)
            user = (f"Problem: {q}\n\nSolutions from the last round:\n{others}\n\nConsider them "
                    f"and give your revised solution. {b['instruction']} {fmt}")
            rnd = self._par(lambda kv: self._call(pool, i, kv[0], kv[1], b, user),
                            list(agents.items()))
            calls += [c for o in rnd for c in o["calls"]]
        rnd[0] = {**rnd[0], "calls": calls}           # every call is charged once, on the first
        for o in rnd[1:]:
            o["calls"] = []
        return rnd, rnd, {}

    def _review(self, pool, i, st, b, agents, q, fmt):
        user = (f"Problem: {q}\n\nEarlier work:\n{self._shown(st['history'], st['show'])}\n\n"
                f"The current answer is {st['current']}. {b['instruction']} {VERDICT_FMT} {fmt}")
        outs = self._par(lambda kv: self._call(pool, i, kv[0], kv[1], b, user), list(agents.items()))
        for o in outs:
            if o["answer"] is None and o["verdict"] == "PASS":
                o["answer"] = st["current"]
        v = [o["verdict"] for o in outs]
        return outs, outs, {"fail": v.count("FAIL") > v.count("PASS")}

    def _refine(self, pool, i, st, b, agents, q, fmt):
        names = list(agents)
        prod, crit = names[0], names[1] if len(names) > 1 else names[0]
        drafts = [h for h in st["history"] if h["answer"] is not None and h["answer"] == st["current"]]
        if drafts:
            draft = {**drafts[-1], "calls": []}
        else:
            draft = self._call(pool, i, prod, agents[prod], b,
                               f"Problem: {q}\n\n{b['instruction']} {fmt}")
        outs, fail = [draft], False
        cb = {**b, "tool": 0}
        for it in range(b["iters"]):
            c = self._call(pool, i, crit, agents[crit], cb,
                           f"Problem: {q}\n\nDraft solution:\n{draft['text'][-SHOW_CHARS:]}\n\n"
                           f"{b['critique']} {CRITIQUE_FMT}")
            c["answer"] = None
            outs.append(c)
            fail = c["verdict"] == "FAIL"
            if not fail:
                break
            draft = self._call(pool, i, prod, agents[prod], b,
                               f"Problem: {q}\n\nYour earlier draft:\n{draft['text'][-SHOW_CHARS:]}"
                               f"\n\nA reviewer's critique:\n{c['text'][-SHOW_CHARS:]}\n\nRevise "
                               f"the solution. {b['instruction']} {fmt}", seed_off=it + 1)
            outs.append(draft)
        return outs, [draft], {"fail": fail}

    def _decide(self, pool, i, st, b, agents, q, fmt):
        user = (f"Problem: {q}\n\nEarlier work:\n{self._shown(st['history'], st['show'])}\n\n"
                f"{b['instruction']} {fmt}")
        outs = self._par(lambda kv: self._call(pool, i, kv[0], kv[1], b, user), list(agents.items()))
        return outs, outs, {}

    # ------------------------------------------------------------ the flow

    def run(self, pool: dict, question: str, plan: dict) -> dict:
        conds = compile_conditions(pool)[0]
        st = {"seen": [], "current": None, "history": [], "show": {}, "last": {}, "steps": 0}
        calls, trace, probe = [], [], None
        for i, step in enumerate(plan["steps"]):
            b = {**block(pool, step["block"]), "id": step["block"]}
            sig = signals(st)
            if i == 1:
                probe = {"signals": sig, "current": st["current"]}
            if i > 0 and not eval_cond(parse_cond(step["if"], conds), sig):
                trace.append({"step": i, "block": step["block"], "ran": False, "signals": sig})
                continue
            if b["kind"] == "exit":
                trace.append({"step": i, "block": step["block"], "ran": True, "exit": True,
                              "signals": sig, "before": st["current"], "current": st["current"]})
                break
            fmt = ANSWER_FMT if not b.get("confidence") else f"{CONF_FMT} {ANSWER_FMT}"
            fn = {"solve": self._solve, "debate": self._debate, "review": self._review,
                  "refine": self._refine, "decide": self._decide}[b["kind"]]
            outs, counted, extra = fn(pool, i, st, b, step["agents"], question, fmt)
            step_calls = [c for o in outs for c in o["calls"]]
            calls += step_calls
            ans = [o["answer"] for o in counted]
            before = st["current"]
            m = majority(ans)
            st["current"] = m if m is not None else before
            st["seen"] += ans
            st["history"] += [o for o in outs if o["step"] == i]   # not a reused earlier draft
            st["show"][i] = b["show"]
            st["steps"] += 1
            st["last"] = {"unsure": any(o["unsure"] for o in outs),
                          "tool_error": any(o["tool_error"] for o in outs),
                          "tokens": max((c["gen_tokens"] for c in step_calls), default=0), **extra}
            trace.append({"step": i, "block": step["block"], "ran": True, "answers": ans,
                          "before": before, "current": st["current"], "signals": sig,
                          "cost": round(cost(step_calls), 1)})
        if probe is None:          # one-step plans: the state a second step would have seen
            probe = {"signals": signals(st), "current": st["current"]}
        final = st["current"] if pool["final"] == "last" else (majority(st["seen"]) or st["current"])
        return {"answer": final, "calls": calls, "trace": trace, "probe": probe}
