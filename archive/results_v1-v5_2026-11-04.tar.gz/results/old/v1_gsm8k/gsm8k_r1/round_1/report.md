# Performance report (dev-A)

HR system: acc 75.5%, cost 1618 tokens/question. Full team: acc 97.5%, cost 13799. Invalid HR outputs (fell back to full team): 0.

## By difficulty (number of calculation steps in the reference solution)
| bucket | n | HR acc | team acc | HR cost | team cost | HR modes |
|---|---|---|---|---|---|---|
| 1-2 steps | 64 | 80% | 98% | 1127 | 12034 | single 37, self 26, team 1 |
| 3-4 steps | 89 | 69% | 98% | 1421 | 13702 | single 56, self 30, team 3 |
| 5-6 steps | 41 | 83% | 95% | 2672 | 16046 | single 24, team 10, self 7 |
| 7+ steps | 6 | 83% | 100% | 2574 | 18708 | single 6 |

## By HR decision
| decision | n | acc | mean cost |
|---|---|---|---|
| self | 63 | 33% | 146 |
| single thinking=low | 117 | 96% | 2077 |
| single thinking=off | 6 | 100% | 332 |
| team | 14 | 86% | 4960 |

## Saved wrong: HR plan failed, full team succeeded (45 questions)
- [3-4 steps] James writes a 3-page letter to 2 different friends twice a week.  How many pages does he write a year?
  plan: self (answered 384); answered 384, correct 624
- [3-4 steps] Albert is wondering how much pizza he can eat in one day. He buys 2 large pizzas and 2 small pizzas. A large pizza has 16 slices and a small pizza has 8 slices. If he eats it all, how many pieces does he eat that day?
  plan: self (answered 40); answered 40, correct 48
- [1-2 steps] Joy can read 8 pages of a book in 20 minutes. How many hours will it take her to read 120 pages?
  plan: self (answered 1); answered 1, correct 5
- [3-4 steps] Tim rides his bike back and forth to work for each of his 5 workdays.  His work is 20 miles away.  He also goes for a weekend bike ride of 200 miles.    If he can bike at 25 mph how much time does he spend biking a week?
  plan: self (answered 32); answered 32, correct 16
- [1-2 steps] There are 5 houses on a street, and each of the first four houses has 3 gnomes in the garden. If there are a total of 20 gnomes on the street, how many gnomes does the fifth house have?
  plan: self (answered 1); answered 1, correct 8
- [3-4 steps] Noah is a painter. He paints pictures and sells them at the park. He charges $60 for a large painting and $30 for a small painting. Last month he sold eight large paintings and four small paintings. If he sold twice as much this month, how much is his sales for this month?
  plan: self (answered 2160); answered 2160, correct 1200
- [3-4 steps] Rachel and Sara want to attend a beauty and modeling contest. They both want to buy new pairs of shoes and dresses. Sara buys a pair of shoes which costs $50 and a dress which costs $200. How much should Rachel budget if she wants to spend twice as much as what Sara spent on the pair of shoes and dr
  plan: self (answered 450); answered 450, correct 500
- [3-4 steps] Carolyn practices the piano for 20 minutes a day and the violin for three times as long. If she practice six days a week, how many minutes does she spend practicing in a month with four weeks?
  plan: self (answered 1440); answered 1440, correct 1920
- [3-4 steps] Ann is cutting fabric to make curtains. She cuts a 4 foot by 6 foot rectangle for the living room, and a 2 foot by 4 foot rectangle for the bedroom. If the bolt of fabric is 16 feet by 12 feet, how much fabric is left in square feet?
  plan: self (answered 112); answered 112, correct 160
- [3-4 steps] There are 25 roses in a garden. There are 40 tulips. There are 35 daisies. What percentage of flowers are not roses?
  plan: self (answered 60); answered 60, correct 75

Both HR and full team wrong: 4 questions (likely beyond the team).

## Most expensive correctly-solved questions (possible waste)
- [5-6 steps, cost 7094] Valerie needs to put stamps on the envelopes she is about to mail. She has thank you cards for each of her grandmother, uncle and aunt for the birthday presents they sent. She also has to pay the wate
  plan: team [solver_C[1]:low, solver_B[1]:low, critic[1]:low, judge:off] stop_if_consensus=True
- [5-6 steps, cost 6118] Gail has two fish tanks. The first tank is twice the size of the second tank. There are 48 gallons of water in the first tank. She follows the rule of one gallon of water per inch of fish. If she keep
  plan: team [solver_C[1]:low, solver_B[1]:high, critic[2]:low, judge:off] stop_if_consensus=True
- [5-6 steps, cost 5982] Janice can type 6 sentences per minute. Today at work, Janice continued working on a paper she started typing yesterday. She typed for 20 minutes, took a break, and typed 15 minutes longer. She then h
  plan: team [solver_B[1]:low, critic[1]:low, judge:off] stop_if_consensus=False
- [5-6 steps, cost 5732] Sam and Jeff had a skipping competition at recess. The competition was split into four rounds. Sam completed 1 more skip than Jeff in the first round. Jeff skipped 3 fewer times than Sam in the second
  plan: team [solver_C[1]:low, solver_B[1]:low, critic[1]:off, judge:off] stop_if_consensus=True
- [5-6 steps, cost 5262] Simon wanted to buy flowers that his mom could plant for Mother's Day.  The garden center was offering 10% off all purchases.  He bought 5 pansies at $2.50 each, one hydrangea that cost $12.50 and 5 p
  plan: team [solver_C[1]:low, solver_B[1]:low, critic[2]:low, judge:off] stop_if_consensus=True
- [5-6 steps, cost 5082] A family of 12 monkeys collected 10 piles of bananas. 6 piles had 9 hands, with each hand having 14 bananas, while the remaining piles had 12 hands, with each hand having 9 bananas. How many bananas w
  plan: team [solver_C[1]:low, solver_B[1]:low, critic[2]:low, judge[2]:off] stop_if_consensus=True