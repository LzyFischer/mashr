# Diagnostic report (dev-A)

Organization: acc 92.0%, cost 14590/question, of which the HR 2163 (HR prompt 5823 chars). Full system: acc 91.3%, cost 17252. 39 distinct architectures, 1.8 nodes per question. HR outputs: repaired 1, written again 52, fallback 7.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 6740 | 13285 | solver.low 5, solver.high 5, coder.high 4 |
| Algebra L5 | 18 | 100% | 100% | 8487 | 15585 | solver.high 6, solver.low 5, algebraist.high 3 |
| Counting & Probability L4 | 8 | 100% | 100% | 9357 | 15676 | solver.low 2, combinator.high 2, planner.low>coder.high,solver.high>verifier.high 1 |
| Counting & Probability L5 | 9 | 78% | 89% | 18181 | 19103 | combinator.high 2, coder.high 2, combinator.high>verifier.high 2 |
| Geometry L4 | 5 | 100% | 100% | 8974 | 15889 | solver.low 3, coder.high 1, geometer.low>solver.high 1 |
| Geometry L5 | 7 | 71% | 57% | 34248 | 22647 | planner.low>coder.xhigh>verifier.high 1, solver.low 1, planner.low>coder.xhigh,geometer.xhigh,solver.xhigh>verifier.xhigh>judge.high 1 |
| Intermediate Algebra L4 | 14 | 100% | 100% | 15294 | 18210 | solver.high 3, solver.low 2, planner.low>solver.high 2 |
| Intermediate Algebra L5 | 17 | 82% | 71% | 27230 | 21465 | planner.low>coder.xhigh,solver.xhigh>verifier.xhigh 4, solver.high 3, planner.low>coder.high,solver.high>verifier.high 3 |
| Number Theory L4 | 9 | 100% | 100% | 10536 | 17149 | solver.high 3, coder.high 3, planner.low>coder.high,solver.high>verifier.high 1 |
| Number Theory L5 | 16 | 94% | 88% | 11309 | 18165 | solver.high 6, coder.high 4, solver.low 3 |
| Prealgebra L4 | 12 | 83% | 100% | 6338 | 10794 | solver.low 9, solver.high 1, coder.low 1 |
| Prealgebra L5 | 9 | 89% | 89% | 11589 | 17096 | solver.low 3, geometer.low 1, planner.low>geometer.xhigh,solver.xhigh>verifier.xhigh 1 |
| Precalculus L4 | 3 | 100% | 100% | 27883 | 20027 | solver.high>verifier.low 1, planner.low>coder.high,solver.high>verifier.high 1, planner.low>coder.xhigh,solver.xhigh>verifier.xhigh 1 |
| Precalculus L5 | 6 | 83% | 83% | 30201 | 22960 | planner.low>solver.xhigh 1, planner.low>solver.high>verifier.high 1, geometer.high>coder.xhigh,solver.xhigh>verifier.xhigh 1 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| solver.low | 33 | 94% | 6344 |
| solver.high | 27 | 100% | 9036 |
| coder.high | 16 | 100% | 7808 |
| combinator.high | 7 | 86% | 7545 |
| planner.low>coder.high,solver.high>verifier.high | 7 | 86% | 28968 |
| planner.low>coder.xhigh,solver.xhigh>verifier.xhigh | 6 | 67% | 43346 |
| coder.low | 6 | 100% | 4722 |
| planner.low>solver.high | 5 | 100% | 12971 |
| planner.low>solver.high>verifier.high | 4 | 75% | 21041 |
| algebraist.high | 3 | 100% | 7076 |
| planner.low>coder.high>verifier.high | 3 | 67% | 31510 |
| solver.high>verifier.high | 2 | 100% | 17389 |
| geometer.low | 2 | 50% | 6094 |
| planner.low>solver.xhigh | 2 | 100% | 17371 |
| combinator.high>verifier.high | 2 | 100% | 18510 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| planner.low | 40 | 40% | 100% | 4726 | - | - | - |
| solver.low | 33 | 94% | 97% | 3671 | - | - | - |
| solver.high | 31 | 100% | 94% | 6841 | - | - | - |
| verifier.high (with inputs) | 24 | 83% | 83% | 8449 | 5 | 4 | - |
| solver.high (with inputs) | 21 | 86% | 100% | 7410 | 5 | 4 | - |
| coder.high | 18 | 94% | 78% | 5992 | - | - | - |
| coder.high (with inputs) | 15 | 80% | 73% | 7493 | 10 | 7 | - |
| verifier.xhigh (with inputs) | 14 | 79% | 57% | 10566 | 9 | 6 | - |
| solver.xhigh (with inputs) | 14 | 57% | 86% | 11646 | 9 | 4 | - |
| coder.xhigh (with inputs) | 12 | 58% | 83% | 13627 | 10 | 6 | - |
| combinator.high | 10 | 90% | 80% | 7901 | - | - | - |
| coder.low | 6 | 100% | 67% | 2659 | - | - | - |
| geometer.low | 4 | 75% | 100% | 4308 | - | - | - |
| algebraist.high | 4 | 75% | 75% | 5982 | - | - | - |
| geometer.xhigh (with inputs) | 4 | 50% | 75% | 10760 | 3 | 2 | - |
| geometer.high (with inputs) | 2 | 50% | 100% | 7914 | 2 | 1 | - |
| geometer.high | 2 | 50% | 100% | 7606 | - | - | - |
| combinator.low | 2 | 100% | 100% | 3356 | - | - | - |
| algebraist.xhigh (with inputs) | 1 | 100% | 100% | 11144 | - | - | - |
| algebraist.low | 1 | 100% | 100% | 4012 | - | - | - |
| verifier.xhigh | 1 | 0% | 100% | 12335 | - | - | - |
| verifier.low (with inputs) | 1 | 100% | 100% | 7528 | - | - | - |
| verifier.max (with inputs) | 1 | 100% | 0% | 4588 | - | - | - |
| judge.high (with inputs) | 1 | 100% | 100% | 9085 | 1 | 1 | - |
| solver.low (with inputs) | 1 | 100% | 100% | 3899 | - | - | - |
| solver.max | 1 | 100% | 100% | 19199 | - | - | - |

## Leave-one-out on 51 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| planner.low (input) | 40 | 1 | 2 | 37 | 4991 |
| verifier.high (output) | 24 | 8 | 0 | 16 | 8449 |
| solver.high (input) | 19 | 0 | 0 | 19 | 7630 |
| coder.high (input) | 16 | 0 | 2 | 14 | 8061 |
| verifier.xhigh (output) | 13 | 8 | 0 | 5 | 9621 |
| solver.xhigh (input) | 12 | 0 | 0 | 12 | 10933 |
| coder.xhigh (input) | 12 | 3 | 0 | 9 | 12347 |
| solver.high (output) | 6 | 1 | 0 | 5 | 7099 |
| geometer.xhigh (input) | 4 | 0 | 0 | 4 | 10596 |
| combinator.high (input) | 3 | 0 | 0 | 3 | 11456 |
| geometer.high (input) | 3 | 0 | 0 | 3 | 389 |
| solver.xhigh (output) | 2 | 0 | 0 | 2 | 11139 |
| geometer.low (input) | 2 | 0 | 0 | 2 | 3770 |
| algebraist.xhigh (input) | 1 | 0 | 0 | 1 | 13641 |
| verifier.low (output) | 1 | 0 | 0 | 1 | 7528 |
| verifier.max (output) | 1 | 0 | 0 | 1 | 4588 |
| verifier.xhigh (input) | 1 | 1 | 0 | 0 | 22500 |
| judge.high (output) | 1 | 1 | 0 | 0 | 9085 |
| coder.high (output) | 1 | 1 | 0 | 0 | 12535 |
| solver.low (output) | 1 | 0 | 0 | 1 | 3899 |

HR output problems: return must name a node defined above (7); no node (7); nodes ['a', 'b'] feed nothing (1); minor: line 1: non-node argument ignored (1)

## Organization wrong, full system right (3)
- [Counting & Probability L5] The number of increasing sequences of positive integers $a_1 \le a_2 \le a_3 \le \cdots \le a_{10} \le 2007$ such that $a_i-i$ is even for $1\le i \le 10$ can be expressed as ${m \choose n}$ for some positive integers $m > n$. Compute the remainder when $m$ is divided by 1000.
  architecture: a = combinator("high"); b = coder("high"); c = verifier("xhigh"); return c; answered 4, correct 8
- [Prealgebra L4] As a prank, Tim decides to steal Nathan's fork at dinner, but so he doesn't get caught, he convinces other people to do it for him. On Monday, he convinces Joe to do it. On Tuesday, he could get either Ambie or John to do it. On Wednesday, he can't convince any of those three peo
  architecture: a = solver("low"); return a; answered 0, correct 40
- [Prealgebra L4] Subtract the number of positive multiples of $3$ that are less than $20$ from the number of positive multiples of $6$ that are less than $20$.
  architecture: a = solver("low"); return a; answered 20, correct -3

Both wrong: 9.

## Most expensive correct questions (possible waste)
- [Geometry L5, cost 77048] Given a point $P$ on a triangular piece of paper $ABC,\,$ consider the creases that are formed in the paper when $A, B,\,$ and $C\,$ are folded onto $P.\,$ Let us call $P$ a fold p
  architecture: p = planner("low"); a = solver("xhigh", p); b = coder("xhigh", p); c = geometer("xhigh", p); v = verifier("xhigh", p, a, b, c); j = judge("high", p, a, b, c, v); return j
- [Intermediate Algebra L5, cost 44778] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  architecture: p = planner("low"); a = solver("xhigh", p); b = coder("xhigh", p); v = verifier("xhigh", p, a, b); return v
- [Intermediate Algebra L5, cost 43644] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes th
  architecture: p = planner("low"); a = solver("xhigh", p); b = coder("xhigh", p); v = verifier("xhigh", p, a, b); return v
- [Precalculus L5, cost 42577] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection
  architecture: p = planner("low"); g = geometer("xhigh", p); c = coder("xhigh", p, g); v = verifier("xhigh", p, g, c); return v
- [Geometry L5, cost 40230] Square $ABCD$ has center $O,\ AB=900,\ E$ and $F$ are on $AB$ with $AE<BF$ and $E$ between $A$ and $F, m\angle EOF =45^\circ,$ and $EF=400.$ Given that $BF=p+q\sqrt{r},$ where $p,q
  architecture: p = planner("low"); a = solver("xhigh", p); b = coder("high", p); v = verifier("xhigh", p, a, b); return v