"""Slow loop v6 (residual harness for harnesses): the designer edits the employees' self harnesses
(roles), the skill library and the HR's handbook; on every question the HR writes the team and each
node's residual harness (tools, skills, note) (org6.py, exec6.py). Same protocol and gates as rsi5;
the report adds the residual harness's usage. An ablation of notes / skills / tools is saved per round
(round_N/ablation.json) for analysis and is not shown to the designer.

  P=~/miniconda3/envs/tinker/bin/python
  set -a; source ~/.config/hrsi/tinker.env; set +a
  MASHR_LOCAL_MODELS=Qwen/Qwen3.5-9B $P -m mashr.rsi6 --dataset math --init design --objective acc \
      --out results/rsi6/math_acc       # employees and HR on local vLLM, designer on Tinker
"""
import argparse
import copy
import json
import os
import statistics
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

from .cascade import Cascade
from .engine import cost
from .exec6 import Engine
from .ledger import Ledger
from .llm import LLM, THINK_BUDGET
from .optimize import HINTS, ask_json, ops_summary, pct
from .optimize import evaluate as evaluate_ref
from .optimize import summarize as summarize_ref
from .org6 import lv, BASELINES, BUDGET_DOC, HAND, LIMITS, THINK, apply_ops, hr_prompt, \
    parse_program, program_str, shape, validate
from .bench import SPEC
from .bench import load as bench_load
from .orgrsi import load_items
from .pool import FULL, V0
from .rsi import ROOT
from .rsi4 import TOL, gate

WORKERS = 128
GRADE = lambda pred, gold: pred is not None and pred == gold   # set per dataset in main()


def evaluate(eng, pool, items, plan=None):
    def one(it):
        if plan is not None:
            p, pre, info = plan, [], {"problems": [], "retried": False, "fallback": False}
        else:
            p, pre, info = eng.orchestrate(pool, it["question"])
        out = eng.run(pool, it["question"], p)
        calls = pre + out["calls"]
        return {**it, "plan": p, "nodes": out["nodes"], "pred": out["answer"],
                "correct": GRADE(out["answer"], it["gold"]), "calls": calls, "cost": cost(calls),
                "hr_cost": cost(pre), **info}
    with ThreadPoolExecutor(WORKERS) as ex:
        return list(ex.map(one, items))


def summarize(rows):
    n = len(rows)
    hard = [r for r in rows if r["hard"]]
    return {"n": n, "acc": round(sum(r["correct"] for r in rows) / n, 4),
            "cost": round(sum(r["cost"] for r in rows) / n, 1),
            "hr_cost": round(sum(r["hr_cost"] for r in rows) / n, 1),
            "acc_hard": round(sum(r["correct"] for r in hard) / max(1, len(hard)), 4),
            "nodes": round(sum(len(r["plan"]["nodes"]) for r in rows) / n, 2),
            "shapes": dict(Counter(shape(r["plan"]) for r in rows).most_common(4)),
            "n_shapes": len({shape(r["plan"]) for r in rows}),
            "repaired": sum(any(not p.startswith("minor:") for p in r["problems"])
                            and not r["retried"] for r in rows),
            "retried": sum(r["retried"] for r in rows), "fallback": sum(r["fallback"] for r in rows)}


def drop_node(plan, nid):
    """The plan without node nid; its consumers lose that input; if it was the output, its first
    input becomes the output (None if it had none)."""
    p = copy.deepcopy(plan)
    gone = next(n for n in p["nodes"] if n["id"] == nid)
    p["nodes"] = [n for n in p["nodes"] if n["id"] != nid]
    for n in p["nodes"]:
        n["inputs"] = [i for i in n["inputs"] if i != nid]
    if p["output"] == nid:
        if not gone["inputs"]:
            return None
        p["output"] = gone["inputs"][0]
    return p


def leave_one_out(eng, pool, rows, n):
    jobs, seen = [], 0
    for r in rows:
        if len(r["plan"]["nodes"]) < 2:
            continue
        if seen >= n:
            break
        seen += 1
        for nd in r["plan"]["nodes"]:
            p = drop_node(r["plan"], nd["id"])
            if p is not None:
                jobs.append((r, nd, p))

    def one(job):
        r, nd, p = job
        out = eng.run(pool, r["question"], p)
        role = "output" if nd["id"] == r["plan"]["output"] else "input"
        return {"where": f"{nd['agent']}.{nd['thinking']} ({role})", "was": r["correct"],
                "now": GRADE(out["answer"], r["gold"]),
                "saved": cost([c for c in r["calls"] if c["agent"] != "HR"]) - cost(out["calls"])}
    with ThreadPoolExecutor(WORKERS) as ex:
        return list(ex.map(one, jobs)), seen


def residual_ablation(eng, pool, rows, n):
    """Re-run up to n questions with one residual component removed from every node: the notes, the
    skills, or the tools (no tools = no Python). Returns {component: [(was, now)]}."""
    sample = [r for r in rows if any(nd["note"] or nd["skills"] or nd["tools"]
                                     for nd in r["plan"]["nodes"])][:n]
    strip = {"notes": lambda nd: {**nd, "note": ""}, "skills": lambda nd: {**nd, "skills": []},
             "tools": lambda nd: {**nd, "tools": []}}
    jobs = []
    for r in sample:
        for comp, f in strip.items():
            if any((nd["note"] if comp == "notes" else nd[comp]) for nd in r["plan"]["nodes"]):
                jobs.append((r, comp, {**r["plan"], "nodes": [f(nd) for nd in r["plan"]["nodes"]]}))

    def one(job):
        r, comp, p = job
        out = eng.run(pool, r["question"], p)
        return comp, r["correct"], GRADE(out["answer"], r["gold"])
    res = defaultdict(list)
    with ThreadPoolExecutor(WORKERS) as ex:
        for comp, was, now in ex.map(one, jobs):
            res[comp].append((was, now))
    return dict(res), len(sample)


def residual_report(rows, abl, abl_n):
    """The residual harness the HR handed out: usage, accuracy, ablation."""
    nodes = [(r, nd, pn) for r in rows for nd, pn in zip(r["nodes"], r["plan"]["nodes"])]
    L = ["", "## Residual harness (what the HR gave each node)",
         "| item | nodes given it | node answer correct when given | node answer correct otherwise |",
         "|---|---|---|---|"]
    items = Counter()
    for _, _, pn in nodes:
        items.update([f"tool:{t}" for t in pn["tools"]] + [f"skill:{k}" for k in pn["skills"]]
                     + (["note"] if pn["note"] else []) + (["no tools (no Python)"] if not pn["tools"]
                                                          else []))
    for it, cnt in items.most_common(20):
        has = lambda pn: (it == "note" and pn["note"]) or (it == "no tools (no Python)" and not
                                                           pn["tools"]) or \
            (it.startswith("tool:") and it[5:] in pn["tools"]) or \
            (it.startswith("skill:") and it[6:] in pn["skills"])
        yes = [GRADE(nd["answer"], r["gold"]) for r, nd, pn in nodes if has(pn)]
        no = [GRADE(nd["answer"], r["gold"]) for r, nd, pn in nodes if not has(pn)]
        L.append(f"| {it} | {cnt} | {pct(yes)} | {pct(no)} |")
    notes = [pn["note"] for _, _, pn in nodes if pn["note"]]
    if notes:
        L.append(f"Notes: {len(notes)} nodes got one, mean {statistics.mean(map(len, notes)):.0f} chars."
                 " Example: " + notes[0][:160])
    if abl:
        L += ["", f"## Residual ablation on {abl_n} questions (that component removed from every node)",
              "'needed' = right becomes wrong without it; 'harmful' = wrong becomes right without it.",
              "| removed | questions | needed | harmful | no effect |", "|---|---|---|---|---|"]
        for comp, xs in abl.items():
            need = sum(w and not n for w, n in xs)
            harm = sum(n and not w for w, n in xs)
            L.append(f"| {comp} | {len(xs)} | {need} | {harm} | {len(xs) - need - harm} |")
    return L


def report(rows, ref, loo, loo_n, pool, abl=None, abl_n=0) -> str:
    s = summarize(rows)
    refd = {r["id"]: r for r in ref} if ref else {r["id"]: {**r, "correct": False, "cost": 0}
                                                  for r in rows}
    full = (f"Full system: acc {summarize_ref(ref)['acc']:.1%}, cost "
            f"{summarize_ref(ref)['cost']:.0f}. " if ref else "")
    L = ["# Diagnostic report (dev-A)", "",
         f"Organization: acc {s['acc']:.1%}, cost {s['cost']:.0f}/question, of which the HR "
         f"{s['hr_cost']:.0f} (HR prompt {len(hr_prompt(pool))} chars). {full}"
         f"{s['n_shapes']} distinct architectures, "
         f"{s['nodes']:.1f} nodes per question. HR outputs: repaired {s['repaired']}, written again "
         f"{s['retried']}, fallback {s['fallback']}.", "",
         "## By category", "| category | n | acc | full acc | cost | full cost | architectures |",
         "|---|---|---|---|---|---|---|"]
    by = defaultdict(list)
    for r in rows:
        by[r["bucket"]].append(r)
    for b in sorted(by):
        rs, rf = by[b], [refd[r["id"]] for r in by[b]]
        L.append(f"| {b} | {len(rs)} | {pct([r['correct'] for r in rs])} | "
                 f"{pct([r['correct'] for r in rf]) if ref else '-'} | "
                 f"{statistics.mean(r['cost'] for r in rs):.0f}"
                 f" | {statistics.mean(r['cost'] for r in rf) if ref else 0:.0f} | "
                 + ", ".join(f"{k} {v}" for k, v in Counter(shape(r['plan']) for r in rs).most_common(3))
                 + " |")
    arch = defaultdict(list)
    for r in rows:
        arch[shape(r["plan"])].append(r)
    L += ["", "## Architectures the HR wrote", "| architecture | uses | acc | mean cost |",
          "|---|---|---|---|"]
    for k, rs in sorted(arch.items(), key=lambda kv: -len(kv[1]))[:15]:
        L.append(f"| {k} | {len(rs)} | {pct([r['correct'] for r in rs])} | "
                 f"{statistics.mean(r['cost'] for r in rs):.0f} |")
    nodes = defaultdict(lambda: [0, 0, 0, [], 0, 0, 0])
    for r in rows:
        ans = {nd["id"]: nd["answer"] for nd in r["nodes"]}
        for pn, nd in zip(r["plan"]["nodes"], r["nodes"]):
            g = nodes[f"{nd['agent']}.{pn['thinking']}" + (" (with inputs)" if pn["inputs"] else "")]
            g[0] += 1
            g[1] += GRADE(nd["answer"], r["gold"])
            g[2] += nd["cut"]
            g[3].append(nd["cost"])
            if pn["inputs"]:
                before = Counter(ans[i] for i in pn["inputs"]).most_common(1)[0][0]
                if nd["answer"] != before:
                    g[4] += 1
                    g[5] += GRADE(nd["answer"], r["gold"])
                    g[6] += GRADE(before, r["gold"])
    L += ["", "## Nodes (employee.thinking)",
          "answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking "
          "budget; for nodes with inputs: changed = its answer differs from its inputs' majority.",
          "| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |",
          "|---|---|---|---|---|---|---|---|"]
    for k, g in sorted(nodes.items(), key=lambda kv: -kv[1][0]):
        L.append(f"| {k} | {g[0]} | {g[1] / g[0]:.0%} | {g[2] / g[0]:.0%} | "
                 f"{statistics.mean(g[3]):.0f} | {g[4] or '-'} | {g[5] or '-'} | {g[6] or '-'} |")
    L += [] if not loo else ["", f"## Leave-one-out on {loo_n} questions with 2+ nodes",
          "Remove the node (its consumers lose that input; a removed output hands over to its first "
          "input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.",
          "| removed | uses | needed | harmful | no effect | mean cost saved |",
          "|---|---|---|---|---|---|"]
    g = defaultdict(list)
    for x in loo:
        g[x["where"]].append(x)
    for k, xs in sorted(g.items(), key=lambda kv: -len(kv[1]))[:20]:
        need = sum(x["was"] and not x["now"] for x in xs)
        harm = sum(not x["was"] and x["now"] for x in xs)
        L.append(f"| {k} | {len(xs)} | {need} | {harm} | {len(xs) - need - harm} | "
                 f"{statistics.mean(x['saved'] for x in xs):.0f} |")
    L += residual_report(rows, abl, abl_n)
    probs = Counter(p for r in rows for p in r["problems"])
    if probs:
        L += ["", "HR output problems: " + "; ".join(f"{k} ({v})" for k, v in probs.most_common(6))]
    bad = [r for r in rows if not r["correct"] and (refd[r["id"]]["correct"] or not ref)]
    L += ["", f"## Organization wrong{', full system right' if ref else ''} ({len(bad)})"]
    for r in bad[:10]:
        L.append(f"- [{r['bucket']}] {r['question'][:280]}\n  architecture: {program_str(r['plan'])}; "
                 f"answered {r['pred']}, correct {r['gold']}")
    if ref:
        L.append(f"\nBoth wrong: {sum(not r['correct'] and not refd[r['id']]['correct'] for r in rows)}.")
    rich = sorted([r for r in rows if r["correct"]], key=lambda r: -r["cost"])[:5]
    L += ["", "## Most expensive correct questions (possible waste)"]
    for r in rich:
        L.append(f"- [{r['bucket']}, cost {r['cost']:.0f}] {r['question'][:180]}\n"
                 f"  architecture: {program_str(r['plan'])}")
    return "\n".join(L)


SYSTEM_DOC = f"""How the system works (all employees and the HR are the same 9B model):
- A task agent's full harness = its SELF harness (its role; you write it; the same on every problem)
  + the RESIDUAL harness the HR gives it on each problem: tools (Python functions preloaded in its
  sandbox; no tools = no Python), skills (how-to texts from the skill library you maintain) and a note
  (a problem-specific instruction the HR writes). The HR's own harness is its handbook (you write it).
- Per problem the HR (reads its handbook, the employees, the tool and skill lists, and the problem)
  writes the team as code plus notes, e.g.
      a = coder("{lv('high')}", tools=["exact_solve"], skills=["case_split"])
      b = solver("{lv('high')}")
      v = verifier("{lv('max')}", a, b, tools=["check_answer"])
      return v
      notes:  a: Count n odd and n even separately.
  Each line is a node: an employee with a thinking level ({BUDGET_DOC}), reading the problem, the full
  work of its input nodes, its skills and its note. Nodes without inputs run in parallel; the returned
  node's answer is final. At most {LIMITS['nodes']} nodes.
- The tool library is fixed: {', '.join(HAND["tools"])}.
- If the HR's output is unusable it is asked once more; then the first employee answers alone with
  thinking low and plain Python (fixed).
- Cost = generated tokens + 0.2 x prompt tokens over all calls, including the HR's.

Where a lesson goes is part of your design:
- a basic practice an employee should always follow -> that employee's role (self harness);
- a technique that helps only some problems -> a skill (residual: the HR decides when to give it);
- how to staff, budget, wire, equip or brief the team for which problems -> the HR handbook.
Lessons put on the wrong layer pile up as residue (always-on text that rarely helps, or conditional
knowledge the HR never hands out). Every edit states why it belongs on its layer."""

OPS_DOC = f"""Edit operations (a JSON list, applied in order; every op has "why": the evidence and why this
layer):
{{"op": "add_agent", "name": "<name>", "role": "<instructions>", "why": "..."}}
{{"op": "remove_agent", "name": "<name>", "why": "..."}}
{{"op": "edit_agent", "name": "<name>", "role": "<new instructions>", "why": "..."}}
{{"op": "add_skill", "id": "<id>", "text": "<how-to, <= {LIMITS['skill_chars']} chars>", "why": "..."}}
{{"op": "edit_skill", "id": "<id>", "text": "<new how-to>", "why": "..."}}
{{"op": "remove_skill", "id": "<id>", "why": "..."}}
{{"op": "set_policy", "text": "<the complete handbook, <= {LIMITS['policy_chars']} chars>", "why": "..."}}
At most {LIMITS['agents']} employees and {LIMITS['skills']} skills. The handbook must not mention removed
employees or skills."""

PROPOSE = """You design the organization of a multi-agent system that solves math problems: its
employees (self harnesses), the skill library, and the handbook of its HR, which builds a team and a
residual harness (tools, skills, notes) for every problem. You do not fix an architecture.

{system_doc}

{objective}

Base each change on evidence in the report: which architectures, nodes, tools, skills and notes help
on which categories (usage, accuracy), how often reasoning is cut at the thinking budget, and where cost goes. Prefer few, decisive
changes, and remove residue the evidence does not support.

{ops_doc}

# Current organization (JSON)
{pool}

# Diagnostic report
{report}

# Earlier attempts (dev-B gate{ref_note})
{history}

Think about what the evidence shows, then output a JSON list of edit operations between <ops> and
</ops>. {hint}"""

OBJECTIVE = {
    "cost": "Objective: minimize the average cost per problem while keeping accuracy within "
            "{eps:.0%} of the full\nsystem on held-out problems, and never below the best accuracy "
            "reached so far. Accuracy comes first.",
    "acc": "Objective: maximize accuracy on held-out problems. Cost matters only between "
           "organizations of equal accuracy.",
    "keep": "Objective: minimize the average cost per problem while keeping accuracy at the level the "
            "current organization already reaches (at most {delta:.1%} below the best accuracy so far "
            "on held-out problems). The organization was already optimized for accuracy; now find "
            "where it spends more than it needs."}

DESIGN = """Design the initial organization of a multi-agent system that will solve problems like the
samples below: its employees (self harnesses), the skill library, and the handbook of its HR, which
builds a team and a residual harness (tools, skills, notes) for every problem. You do not fix an
architecture. Keep "tools" as the full fixed library.

{system_doc}

{objective}

# JSON format (an example organization; replace it with your own design)
{example}

# Sample problems
{samples}

Output the complete organization JSON between <pool> and </pool>."""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=list(SPEC), default="math")
    ap.add_argument("--init", choices=["hand", "design"], default="design")
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--eps", type=float, default=0.02)
    ap.add_argument("--delta", type=float, default=0.005)
    ap.add_argument("--tau", type=float, default=0.10)
    ap.add_argument("--hr-thinking", choices=list(THINK_BUDGET), default="medium",
                    help="the HR's reasoning budget (medium = 2048 tokens; employees choose their own)")
    ap.add_argument("--objective", choices=["cost", "acc"], default="cost",
                    help="acc: maximize accuracy (cost only breaks ties); the gate keeps the most "
                         "accurate organization")
    ap.add_argument("--n-dev-a", type=int, default=150)
    ap.add_argument("--n-dev-b", type=int, default=200)
    ap.add_argument("--n-test", type=int, default=156)
    ap.add_argument("--loo-n", type=int, default=0, help="leave-one-out questions per round (0 = off)")
    ap.add_argument("--abl-n", type=int, default=0, help="residual ablation questions per round (0 = off)")
    ap.add_argument("--baselines", default=",".join(BASELINES))
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "rsi6", "math_design"))
    ap.add_argument("--skip-test", action="store_true")
    ap.add_argument("--seed", type=int, default=0, help="sampling seed of the employees, HR and designer")
    ap.add_argument("--init-pool", help="start from this organization (JSON) instead of designing "
                                         "one; with --objective cost the floor is its own dev-B "
                                         "accuracy - delta (phase 2 of iterative RSI)")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    llm = LLM()
    global GRADE
    fmt, ext, GRADE = SPEC[a.dataset]
    eng, cas = Engine(llm, seed=a.seed, hr_thinking=a.hr_thinking, answer_fmt=fmt, extract_fn=ext), Cascade(llm)
    if a.dataset == "math":
        dev_a = load_items(a.dataset, "train", 0, a.n_dev_a)
        dev_b = load_items(a.dataset, "train", a.n_dev_a, a.n_dev_a + a.n_dev_b)
        test = load_items(a.dataset, "test", 0, a.n_test)
    else:          # own splits; no hand-written full-system reference (accuracy objective)
        dev_a, dev_b = bench_load(a.dataset, "dev_a", a.n_dev_a), bench_load(a.dataset, "dev_b",
                                                                               a.n_dev_b)
        test = bench_load(a.dataset, "test")

    def log(msg):
        print(msg, flush=True)
        with open(os.path.join(a.out, "log.txt"), "a") as f:
            f.write(msg + "\n")

    def dump(name, obj):
        path = os.path.join(a.out, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(obj if isinstance(obj, str) else json.dumps(obj, indent=1))

    led = Ledger(llm, log)

    if a.init_pool or a.objective == "acc":
        # no hand-written full-system reference: the accuracy objective needs no floor, and phase 2
        # takes its floor from the starting organization
        ref_a, floor, ref_note = None, 0.0, ""
    elif a.dataset == "math":
        with led.stage("reference (full system, dev-A + dev-B)"):
            with ThreadPoolExecutor(2) as ex:
                ref_a, ref_b = ex.map(lambda xs: evaluate_ref(cas, V0, xs, FULL), [dev_a, dev_b])
        sa, sb = summarize_ref(ref_a), summarize_ref(ref_b)
        floor = sb["acc"] - a.eps
        ref_note = f"; full system on dev-B: acc {sb['acc']:.1%}, cost {sb['cost']:.0f}"
        log(f"full system: dev-A acc {sa['acc']} cost {sa['cost']}; dev-B acc {sb['acc']} cost "
            f"{sb['cost']}; floor {floor:.3f}")
    else:
        if a.objective != "acc":
            raise SystemExit("datasets other than math have no reference floor: use --objective acc")
        ref_a, floor, ref_note = None, 0.0, ""
    log(f"dataset {a.dataset}: dev-A {len(dev_a)}, dev-B {len(dev_b)}, test {len(test)}; delta "
        f"{a.delta}, tau {a.tau}, HR thinking {a.hr_thinking}, objective {a.objective}")

    if a.init_pool:
        pool = json.load(open(a.init_pool))
        errs = validate(pool)
        if errs:
            raise SystemExit(f"invalid --init-pool: {errs}")
        log(f"starting organization: {a.init_pool}")
    elif a.init == "hand":
        pool = copy.deepcopy(HAND)
    else:
        samples = "\n".join(f"- {it['question']}" for it in dev_a[:30])
        with led.stage("design (27B designer)"):
            pool, _, tries = ask_json(llm, DESIGN.format(system_doc=SYSTEM_DOC,
                                                         objective=OBJECTIVE[a.objective].format(eps=a.eps),
                                                         example=json.dumps(HAND, indent=1),
                                                         samples=samples), "pool",
                                      lambda o: (None, validate(o)), seed=7 + 100000 * a.seed, max_tokens=6000)
        if pool is None:
            raise SystemExit("initial design failed")
        log(f"designed initial organization (repair attempts: {tries})")
    pool0 = copy.deepcopy(pool)
    dump("round_0/pool.json", pool)

    with led.stage("round 0 / dev-B eval"):
        inc_b = summarize(evaluate(eng, pool, dev_b))
    objective = OBJECTIVE[a.objective].format(eps=a.eps)
    if a.init_pool and a.objective == "cost":       # phase 2: keep the accuracy already reached
        floor, best_acc = inc_b["acc"] - a.delta, inc_b["acc"]
        objective = OBJECTIVE["keep"].format(delta=a.delta)
        ref_note = (f"; the starting organization on dev-B: acc {inc_b['acc']:.1%}, cost "
                    f"{inc_b['cost']:.0f}; floor {floor:.1%}")
        log(f"phase 2 (cost): floor on dev-B {floor:.3f}")
    else:
        best_acc = inc_b["acc"] if inc_b["acc"] >= floor - TOL else 0.0
    log(f"round 0 incumbent dev-B {inc_b}")
    history = [f"round 0 (initial organization): dev-B acc {inc_b['acc']:.1%}, cost {inc_b['cost']:.0f}"]
    trace = [{"round": 0, "accepted": True, "dev_b": inc_b}]

    for t in range(1, a.rounds + 1):
        d = f"round_{t}"
        with led.stage(f"round {t} / dev-A eval"):
            rows_a = evaluate(eng, pool, dev_a)
        loo, loo_n = [], 0
        if a.loo_n:
            with led.stage(f"round {t} / leave-one-out"):
                loo, loo_n = leave_one_out(eng, pool, rows_a, a.loo_n)
        if a.abl_n:         # kept for our analysis; not shown to the designer
            with led.stage(f"round {t} / residual ablation"):
                abl, abl_n = residual_ablation(eng, pool, rows_a, a.abl_n)
            dump(f"round_{t}/ablation.json", {"questions": abl_n, "results": {
                comp: {"uses": len(xs), "needed": sum(w and not n for w, n in xs),
                       "harmful": sum(n and not w for w, n in xs)} for comp, xs in abl.items()}})
        rep = report(rows_a, ref_a, loo, loo_n, pool)
        dump(f"{d}/pool.json", pool)
        dump(f"{d}/report.md", rep)
        log(f"round {t}: incumbent dev-A {summarize(rows_a)}; leave-one-out replays {len(loo)}")

        def propose(i):
            prompt = PROPOSE.format(system_doc=SYSTEM_DOC, objective=objective, ops_doc=OPS_DOC,
                                    pool=json.dumps(pool, indent=1), report=rep,
                                    history="\n".join(history), ref_note=ref_note,
                                    hint=HINTS[i % len(HINTS)])
            last = []

            def check(o):
                res, errs = apply_ops(pool, o)
                last[:] = errs
                return res, errs
            ops, new, tries = ask_json(llm, prompt, "ops", check,
                                       seed=1000 * t + 10 * i + 100000 * a.seed, max_tokens=6000)
            return {"ops": ops, "pool": new, "repairs": tries,
                    "fail": None if new is not None else (last[:5] or ["no <ops> block or bad JSON"])}
        with led.stage(f"round {t} / designer proposals (27B)"):
            with ThreadPoolExecutor(a.k) as ex:
                cands = list(ex.map(propose, range(a.k)))
        valid = [c for c in cands if c["pool"] is not None]
        with led.stage(f"round {t} / dev-B gate ({len(valid)} candidates)"):
            with ThreadPoolExecutor(len(valid) or 1) as ex:
                gated = list(ex.map(lambda c: summarize(evaluate(eng, c["pool"], dev_b)), valid))
        for c, g in zip(valid, gated):
            c["dev_b"] = g
        for i, c in enumerate(cands):
            log(f"  cand {i}: " + (f"invalid after repair: {c['fail']}" if c["pool"] is None else
                                   f"{len(c['ops'])} ops, repairs {c['repairs']}, dev-B {c['dev_b']}"))
        if a.objective == "acc":                 # most accurate wins; cost only breaks ties
            orgs = [inc_b] + [c["dev_b"] for c in valid]
            i = max(range(len(orgs)), key=lambda i: (orgs[i]["acc"], -orgs[i]["cost"]))
            w = None if i == 0 else i - 1
        else:
            w = gate(inc_b, [c["dev_b"] for c in valid], floor, best_acc, a.delta, a.tau)
        best = valid[w] if w is not None else None
        for c in cands:
            if c["pool"] is None:
                history.append(f"round {t} [invalid]")
                continue
            status = "ACCEPTED" if c is best else "rejected by gate"
            history.append(f"round {t} [{status}]: dev-B acc {c['dev_b']['acc']:.1%}, "
                           f"cost {c['dev_b']['cost']:.0f}\n  " + ops_summary(c["ops"]))
        dump(f"{d}/candidates.json", [{k: v for k, v in c.items() if k != "pool"} for c in cands])
        if best is not None:
            pool, inc_b = best["pool"], best["dev_b"]
            if inc_b["acc"] >= floor - TOL:
                best_acc = max(best_acc, inc_b["acc"])
        trace.append({"round": t, "accepted": best is not None, "dev_b": inc_b})
        log(f"round {t}: {'accepted' if best is not None else 'no change'}; incumbent dev-B {inc_b}")
        dump("trace.json", trace)
        led.dump(os.path.join(a.out, "costs.json"), quiet=True)

    dump("final_pool.json", pool)
    if not a.skip_test:
        jobs = {"org_round0": lambda: summarize(evaluate(eng, pool0, test)),
                "org_final": lambda: summarize(evaluate(eng, pool, test))}
        if a.dataset == "math" and ref_a is not None:
            jobs["full_system"] = lambda: summarize_ref(evaluate_ref(cas, V0, test, FULL))
        for name in filter(None, a.baselines.split(",")):
            jobs[name] = lambda p=parse_program(HAND, BASELINES[name])[0]: summarize(
                evaluate(eng, HAND, test, p))
        with led.stage(f"test ({len(jobs)} systems)"):
            with ThreadPoolExecutor(len(jobs)) as ex:
                res = dict(zip(jobs, ex.map(lambda f: f(), jobs.values())))
        dump("test.json", res)
        log(f"TEST: {json.dumps(res)}")
    led.dump(os.path.join(a.out, "costs.json"))


if __name__ == "__main__":
    main()
