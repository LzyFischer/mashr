"""The organization v5 (minimal): employees and the HR's handbook. Per question the HR writes the
team's architecture as a few lines of Python-like code, which is parsed (never executed):

    a = solver("max")
    b = coder("low")
    v = verifier("low", a, b)
    return v

Each call creates a node: an employee with a thinking level, reading the problem and the outputs of
the nodes passed to it. A node can only use earlier variables, so the graph is acyclic. The final
answer is the answer of the returned node.

The designer edits only:
  agents  name -> {"role": str, "python": bool}   (python: the employee may run Python)
  policy  the HR's handbook (free text)
"""
import ast
import copy
import json
import re

THINK = ("off", "low", "high", "xhigh", "max")
BUDGET_DOC = "off ~0, low <=1k, high <=4k, xhigh <=8k, max <=16k reasoning tokens"
NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]{1,30}$")
LIMITS = {"agents": 8, "role_chars": 600, "policy_chars": 2500, "nodes": 8}


def parse_program(pool: dict, text: str) -> tuple[dict | None, list[str]]:
    """HR output -> {"nodes": [{"id", "agent", "thinking", "inputs"}], "output": id} or None."""
    m = re.search(r"```(?:python)?\s*\n(.*?)```", text, re.S)
    src = m.group(1) if m else text
    lines = [l for l in src.strip().splitlines() if l.strip() and not l.strip().startswith("#")]
    try:
        tree = ast.parse("def _plan():\n" + "\n".join("    " + l.strip() for l in lines))
    except SyntaxError as e:
        return None, [f"syntax error: {e.msg} (line {(e.lineno or 2) - 1})"]
    nodes, cur, out, probs = [], {}, None, []         # cur: variable -> its latest node id
    for st in tree.body[0].body:
        final = isinstance(st, ast.Return) and isinstance(st.value, ast.Call)
        if final:   # `return employee("thinking", ...)`: a final node, as if assigned and returned
            st = ast.Assign(targets=[ast.Name(id="out")], value=st.value, lineno=st.lineno)
        if isinstance(st, ast.Return):
            if isinstance(st.value, ast.Name) and st.value.id in cur:
                out = cur[st.value.id]
            else:
                probs.append("return must name a node defined above")
            break
        if not (isinstance(st, ast.Assign) and len(st.targets) == 1
                and isinstance(st.targets[0], ast.Name) and isinstance(st.value, ast.Call)
                and isinstance(st.value.func, ast.Name)):
            probs.append(f"line {st.lineno - 1}: expected `x = employee(\"thinking\", inputs...)`")
            continue
        var, agent, args = st.targets[0].id, st.value.func.id, st.value.args
        if agent not in pool["agents"]:
            probs.append(f"line {st.lineno - 1}: unknown employee {agent!r}")
            continue
        th = "low"
        if args and isinstance(args[0], ast.Constant) and isinstance(args[0].value, str):
            th, args = args[0].value, args[1:]
            if th not in THINK:
                probs.append(f"line {st.lineno - 1}: thinking must be one of {THINK}")
                th = "low"
        kw = {k.arg: k.value for k in st.value.keywords}
        if isinstance(kw.get("thinking"), ast.Constant) and kw["thinking"].value in THINK:
            th = kw["thinking"].value
        inputs = []
        for x in args:
            if isinstance(x, ast.Name) and x.id in cur:
                inputs.append(cur[x.id])
            elif isinstance(x, ast.Name):
                probs.append(f"line {st.lineno - 1}: input {x.id!r} is not a node defined above")
            else:                               # the problem text, a hint, a number: ignored
                probs.append(f"minor: line {st.lineno - 1}: non-node argument ignored")
        if len(nodes) == LIMITS["nodes"]:
            probs.append(f"more than {LIMITS['nodes']} nodes")
            break
        nid = var if var not in cur and all(n["id"] != var for n in nodes) else f"{var}_{len(nodes)}"
        nodes.append({"id": nid, "agent": agent, "thinking": th, "inputs": inputs})
        cur[var] = nid
        if final:
            out = nid
            break
    if not nodes:
        return None, probs + ["no node"]
    if out is None:
        probs.append("no return; using the last node")
        out = nodes[-1]["id"]
    used = {i for n in nodes for i in n["inputs"]} | {out}
    unused = [n["id"] for n in nodes if n["id"] not in used]
    if unused:
        probs.append(f"nodes {unused} feed nothing")
    return {"nodes": nodes, "output": out}, probs


def fallback_plan(pool: dict) -> dict:
    """Fixed, not editable: the first employee alone, thinking low."""
    a = next(iter(pool["agents"]))
    return {"nodes": [{"id": "a", "agent": a, "thinking": "low", "inputs": []}], "output": "a"}


def program_str(p: dict) -> str:
    lines = [f"{n['id']} = {n['agent']}(\"{n['thinking']}\"" + "".join(f", {i}" for i in n["inputs"])
             + ")" for n in p["nodes"]]
    return "; ".join(lines + [f"return {p['output']}"])


def shape(p: dict) -> str:
    """Canonical architecture, ignoring variable names: e.g. 'solver.max' or
    'solver.low,coder.low>verifier.low' (layers by depth, '>' between layers)."""
    depth = {}
    for n in p["nodes"]:
        depth[n["id"]] = 1 + max((depth[i] for i in n["inputs"]), default=-1)
    layers = {}
    for n in p["nodes"]:
        layers.setdefault(depth[n["id"]], []).append(f"{n['agent']}.{n['thinking']}")
    return ">".join(",".join(sorted(layers[d])) for d in sorted(layers))


def validate(pool: dict) -> list[str]:
    errs = [f"missing key {k!r}" for k in ("agents", "policy") if k not in pool]
    if errs:
        return errs
    if not pool["agents"]:
        errs.append("no employees")
    if len(pool["agents"]) > LIMITS["agents"]:
        errs.append(f"too many employees: {len(pool['agents'])} > {LIMITS['agents']}")
    for name, a in pool["agents"].items():
        if not NAME.match(name) or name in ("return",):
            errs.append(f"bad employee name {name!r}")
        if not isinstance(a, dict) or not isinstance(a.get("role"), str) or not a["role"].strip() \
                or len(a["role"]) > LIMITS["role_chars"]:
            errs.append(f"{name!r}: role must be 1..{LIMITS['role_chars']} chars")
        elif set(a) - {"role", "python"} or not isinstance(a.get("python", False), bool):
            errs.append(f"{name!r}: only 'role' and 'python' (true/false)")
    if not isinstance(pool["policy"], str) or len(pool["policy"]) > LIMITS["policy_chars"]:
        errs.append(f"policy must be a string of at most {LIMITS['policy_chars']} chars")
    return errs


def apply_ops(pool: dict, ops) -> tuple[dict, list[str]]:
    o = copy.deepcopy(pool)
    errs = []
    if not isinstance(ops, list) or not ops:
        return o, ["ops must be a non-empty list"]
    for i, op in enumerate(ops):
        try:
            kind = op["op"]
            if kind == "add_agent":
                if op["name"] in o["agents"]:
                    raise ValueError(f"employee {op['name']!r} exists")
                o["agents"][op["name"]] = {"role": op["role"], "python": op.get("python", False)}
            elif kind == "remove_agent":
                del o["agents"][op["name"]]
            elif kind == "edit_agent":
                a = o["agents"][op["name"]]
                a.update({k: op[k] for k in ("role", "python") if k in op})
            elif kind == "set_policy":
                o["policy"] = op["text"]
            else:
                raise ValueError(f"unknown op {kind!r}")
        except (KeyError, TypeError, ValueError) as e:
            errs.append(f"op {i} ({json.dumps(op)[:120]}): {type(e).__name__} {e}")
    for name in set(pool["agents"]) - set(o["agents"]):
        if re.search(rf"\b{re.escape(name)}\b", o["policy"]):
            errs.append(f"policy still mentions removed employee {name!r}")
    return o, errs + validate(o)


def hr_prompt(pool: dict) -> str:
    L = ["You are the HR of a team of employees that solve math problems. For each problem, before "
         "anyone works on it, you design the team's architecture: which employees work on it, how "
         "much each one thinks, and who passes their work to whom. Spend as little as possible "
         "while getting the answer right.", "",
         "## How to write the architecture",
         "Write a few lines of Python-like code (it is read, not executed):",
         "```python", 'a = solver("max")', 'b = coder("low")', 'v = verifier("low", a, b)',
         "return v", "```",
         '- `x = employee("thinking", inputs...)` adds a node: that employee reads the problem and the '
         "full work of the input nodes, then gives its own solution and answer.",
         "- Nodes without inputs work independently and in parallel. A node can only take nodes "
         "defined above it.",
         "- `return x`: the answer of node x is the final answer.",
         f"- thinking: {BUDGET_DOC}. Longer thinking is more accurate on hard problems and costs "
         "more; a node with high/xhigh/max thinking costs roughly that many tokens.",
         f"- At most {LIMITS['nodes']} nodes. Cost = all generated tokens + 0.2 x prompt tokens.", "",
         "## Employees"]
    for name, a in pool["agents"].items():
        L.append(f"- {name}{' (can run Python)' if a.get('python') else ''}: {a['role'][:300]}")
    L += ["", "## Handbook", pool["policy"], "",
          "Output only the code, in one ```python block."]
    return "\n".join(L)


HAND = {
    "agents": {
        "solver": {"role": "You are a careful math solver. Reason step by step.", "python": False},
        "coder": {"role": "You are a math solver who computes with short, correct Python programs "
                           "and reasons about their output.", "python": True},
        "verifier": {"role": "You check the solutions you are given: re-derive the answer "
                              "independently (with Python where useful), find any error, and give "
                              "the answer you believe is correct.", "python": True},
        "judge": {"role": "You read the solutions you are given and decide the single correct answer, "
                           "explaining which reasoning holds.", "python": False},
    },
    "policy": "Easy problems: one solver with low thinking. Harder problems: give the solver more "
              "thinking (high, xhigh or max). When an error is likely, add a verifier that reads the "
              "solution.",
}

BASELINES = {
    "single_low": 'a = solver("low")\nreturn a',
    "single_high": 'a = solver("high")\nreturn a',
    "single_max": 'a = solver("max")\nreturn a',
    "solve_verify": 'a = solver("high")\nv = verifier("low", a)\nreturn v',
}
