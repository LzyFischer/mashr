#!/bin/bash
# in-distribution RSI (accuracy objective) on one benchmark: dev-A/dev-B/test from data/bench/
# usage: results/bench/run.sh <aflow_math|gsmhard|aime>
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
~/miniconda3/envs/tinker/bin/python -m mashr.rsi5 --dataset "$1" --init design --objective acc \
  --rounds 5 --k 3 --loo-n 60 --out "results/bench/$1" > "results/bench/$1.out" 2>&1
