# Diagnostic report (dev-A)

Organization: acc 82.7%, cost 9833/question (9015 generated, 4091 prompt tokens; cost = generated + 0.2 x prompt, including the orchestrator's). Full system: acc 91.3%, cost 17252. Orchestrator (HR): 2193/question of that cost (22%), prompt 5333 chars, thinking low; 25 distinct architectures. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 4096 | 13285 | solver 7, solver>checker?>judge? 4, solver>checker? 2 |
| Algebra L5 | 18 | 100% | 100% | 6676 | 15585 | solver 7, solver>checker?L1>judge? 3, solver>checker?>judge? 2 |
| Counting & Probability L4 | 8 | 100% | 100% | 12214 | 15676 | solver+coder>checker?L1>judge? 4, solver+coder>checker?>judge? 1, solver>checker?>judge? 1 |
| Counting & Probability L5 | 9 | 56% | 89% | 12286 | 19103 | solver 2, solver+coder>checker?L1>judge? 1, solver>coder?>checker?L1>judge? 1 |
| Geometry L4 | 5 | 80% | 100% | 5477 | 15889 | solver 3, solver>checker? 1, solver>checker?>judge? 1 |
| Geometry L5 | 7 | 43% | 57% | 21939 | 22647 | solver+coder>checker?L1>judge? 5, solver>checker?L1 1, solver+coder>checker? 1 |
| Intermediate Algebra L4 | 14 | 93% | 100% | 8646 | 18210 | solver 3, solver+coder>checker?>judge? 3, solver>checker?>judge? 3 |
| Intermediate Algebra L5 | 17 | 53% | 71% | 16063 | 21465 | solver+coder>checker?L1>judge? 3, solver+coder>checker?>judge? 3, solver+coder>checkerL1>judge? 2 |
| Number Theory L4 | 9 | 100% | 100% | 7130 | 17149 | solver 3, solver>checker?L1>judge? 2, solver>checkerL1>judge 1 |
| Number Theory L5 | 16 | 88% | 88% | 10276 | 18165 | solver 4, solver+coder>checker?>judge? 2, solver>checker?>judge? 2 |
| Prealgebra L4 | 12 | 92% | 100% | 3490 | 10794 | solver 9, solver>checker? 2, solver>checker?L1 1 |
| Prealgebra L5 | 9 | 78% | 89% | 11167 | 17096 | solver+coder>checker?L1>judge? 2, solver>checker?L1>judge? 2, solver+coder>checker?L1>judge 1 |
| Precalculus L4 | 3 | 67% | 100% | 7121 | 20027 | solver 1, solver>coder?&checker&judge 1, solver>checker?L1 1 |
| Precalculus L5 | 6 | 67% | 83% | 18240 | 22960 | solver+coder>checker? 2, solver+coder>checker?L1>judge? 2, solver>checker?L1>judge? 1 |

## First stages (staffing): accuracy of their answer
| first stage | uses | answer correct | mean cost |
|---|---|---|---|
| solver:off+cot/reread/confidence | 41 | 95% | 955 |
| solver:low+cot/reread/confidence/substitution | 37 | 89% | 4122 |
| solver:low+cot/reread/confidence/case_analysis/substitution + coder:low+react/reread/confidence/case_analysis | 22 | 50% | 9237 |
| solver:low+cot/reread/confidence | 11 | 55% | 4653 |
| solver:low+cot/reread/confidence/case_analysis/substitution | 6 | 50% | 4602 |
| solver:low+cot/reread/confidence/substitution + coder:low+react/reread/confidence | 6 | 50% | 9769 |
| solver:low+cot/reread/confidence/substitution + coder:low+react/reread/confidence/case_analysis | 3 | 100% | 8354 |
| solver:low+cot/reread/confidence/case_analysis + coder:low+react/reread/confidence/case_analysis | 3 | 0% | 10360 |
| solver:off+cot/reread/confidence/substitution | 2 | 100% | 891 |
| solver:low+cot/reread/confidence/case_analysis + coder:low+react/reread/confidence | 2 | 100% | 9435 |
| solver:low+cot/confidence/reread | 2 | 100% | 2528 |
| solver:low+cot/reread/confidence + coder:low+react/reread/confidence | 1 | 0% | 10397 |
| solver:low+cot/reread/confidence/case_analysis/substitution + coder:low+react/reread/confidence | 1 | 0% | 9420 |
| solver:high+cot/reread/confidence/substitution + solver:high+cot/reread/confidence/substitution | 1 | 0% | 16474 |
| solver:low+cot/reread/confidence/case_analysis | 1 | 100% | 4086 |

## Later stages (function and condition): how often they ran and changed the answer
| stage | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| decide if shaky | 48 | 14 | 4 | 1 | 0 | 4761 |
| check if shaky (loop 1) | 37 | 11 | 8 | 6 | 0 | 8995 |
| check if shaky | 27 | 4 | 4 | 4 | 0 | 4970 |
| check if always (loop 1) | 9 | 9 | 4 | 3 | 0 | 4841 |
| decide if always | 8 | 7 | 1 | 0 | 1 | 3406 |
| decide if disagree or fail or unsure | 5 | 1 | 1 | 0 | 0 | 6318 |
| decide if disagree or fail or unsure or tool_error | 4 | 3 | 1 | 0 | 0 | 5723 |
| check if always | 4 | 3 | 0 | 0 | 0 | 2941 |
| check if disagree or fail or unsure | 4 | 0 | 0 | 0 | 0 | 0 |
| decide if disagree or fail | 3 | 0 | 0 | 0 | 0 | 0 |
| check if disagree or fail or unsure or tool_error (loop 1) | 3 | 2 | 1 | 0 | 0 | 5720 |
| check if unsure | 3 | 0 | 0 | 0 | 0 | 0 |
| check if disagree or fail or unsure or tool_error | 3 | 2 | 2 | 0 | 0 | 5926 |
| check if disagree or fail or unsure (loop 1) | 3 | 1 | 1 | 0 | 0 | 5943 |
| produce if shaky | 2 | 0 | 0 | 0 | 0 | 0 |

## Signals after the first stage (150 questions, 42 with a wrong answer at that point)
fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 30 | 90% | 64% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 0 | 0% | 0% |
| agreement < 1 | 30 | 90% | 64% |
| agreement < 0.67 | 30 | 90% | 64% |
| tokens > 1000 | 120 | 35% | 100% |
| tokens > 2000 | 109 | 39% | 100% |
| tokens > 4000 | 77 | 52% | 95% |
| [shaky] disagree or fail or unsure or tool_error | 30 | 90% | 64% |

## Leave-one-out replay on 58 questions with 2+ nodes that ran
Remove the employee from that stage (agent@function<stage>) or the whole stage, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| solver@produce1 | 50 | 9 | 2 | 39 | 10736 |
| coder@produce1 | 48 | 16 | 0 | 32 | 10634 |
| stage 2 check if shaky | 15 | 3 | 0 | 12 | 7536 |
| stage 3 decide if shaky | 14 | 1 | 0 | 13 | 4761 |
| stage 2 check | 12 | 2 | 0 | 10 | 4310 |
| stage 3 decide | 7 | 0 | 1 | 6 | 3406 |
| stage 2 check if disagree or fail or unsure or tool_error | 4 | 0 | 0 | 4 | 5959 |
| stage 3 decide if disagree or fail or unsure or tool_error | 3 | 0 | 0 | 3 | 5723 |
| stage 2 check if disagree | 1 | 0 | 0 | 1 | 14587 |
| stage 3 decide if fail or disagree | 1 | 0 | 0 | 1 | 5192 |
| stage 2 produce | 1 | 0 | 0 | 1 | 1438 |
| stage 3 decide if disagree or fail or unsure or tool_error or agreement < 0.9 | 1 | 0 | 0 | 1 | 3727 |
| stage 2 check if disagree or tool_error | 1 | 0 | 0 | 1 | 18249 |
| stage 3 decide if fail or disagree or unsure | 1 | 1 | 0 | 0 | 6260 |
| stage 2 check if disagree or fail or unsure or tool_error or agreement < 1 | 1 | 1 | 0 | 0 | 4349 |
| stage 2 produce if true | 1 | 0 | 0 | 1 | 3526 |
| stage 2 check if disagree or fail or unsure | 1 | 0 | 0 | 1 | 6340 |
| stage 3 decide if disagree or fail or unsure | 1 | 0 | 0 | 1 | 6318 |

## Orchestrator usage
Architectures: solver 40, solver+coder>checker?L1>judge? 20, solver>checker?>judge? 15, solver>checker?L1>judge? 12, solver+coder>checker?>judge? 12, solver>checker? 11, solver>checker?L1 9, solver+coder>checker? 4
Employees: solver 151, checker 107, judge 76, coder 55; never staffed: none
Thinking: low 342, off 44, high 3
Skills switched on: reread 382, confidence 235, cot 222, substitution 188, python_check 107, case_analysis 77, react 55; never: none
Conditions: always 172, shaky 114, disagree or fail or unsure 12, disagree or fail or unsure or tool_error 11, disagree or unsure or fail 6, disagree or fail 4, unsure 3, unsure or fail 2, fail 2, fail or disagree or unsure 2, disagree or tool_error 2, disagree 1, fail or disagree 1, disagree or agreement < 1 1, unsure or fail or disagree 1, disagree or fail or missing 1, disagree or fail or unsure or tool_error or agreement < 0.9 1, disagree or fail or unsure or tool_error or agreement < 1 1, true 1
Copies > 1: 2; debate rounds > 1: 0; check loops: 57
Orchestrator outputs: minor fixes 21 (skills an employee does not hold, quoted conditions, missing commas), structural repairs 2, asked again 4 (valid on the 2nd try: 4), fixed fallback 0 (acc -).
Most common problems: minor: JSON syntax repaired (15); minor: judge does not hold ['confidence'] (3); minor: judge does not hold ['rereread'] (1); minor: judge does not hold ['ct'] (1); a stage has no 'nodes' list (1); cannot parse ':fail'; using 'always' (1)

## Organization wrong, full system right (16)
- [Intermediate Algebra L5] During the car ride home, Michael looks back at his recent math exams. A problem on Michael's calculus mid-term gets him starting thinking about a particular quadratic,\[x^2-sx+p,\]with roots $r_1$ and $r_2$. He notices that\[r_1+r_2=r_1^2+r_2^2=r_1^3+r_2^3=\cdots=r_1^{2007}+r_2^
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution] > produce if shaky[coder:low+react/reread/confidence/case_analysis] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if shaky[judge:low+reread/cot]; answered 0, correct 2
- [Intermediate Algebra L5] Find the sum of all complex numbers $z$ that satisfy
\[z^3 + z^2 - |z|^2 + 2z = 0.\]
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution] > check if shaky (loop 1)[checker:low+python_check/reread/substitution] > decide if shaky[judge:low+reread/cot]; answered 0, correct -2
- [Counting & Probability L5] The number of increasing sequences of positive integers $a_1 \le a_2 \le a_3 \le \cdots \le a_{10} \le 2007$ such that $a_i-i$ is even for $1\le i \le 10$ can be expressed as ${m \choose n}$ for some positive integers $m > n$. Compute the remainder when $m$ is divided by 1000.
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution] > produce if disagree or fail or unsure or tool_error[coder:low+react/reread/confidence/case_analysis] > check if disagree or fail or unsure or tool_error (loop 1)[checker:low+python_check/reread/substitution] > decide if disagree or fail or unsure or tool_error[judge:low+reread/cot]; answered 3, correct 8
- [Prealgebra L5] Triangle $ABC$ is a right triangle. If the measure of angle $PAB$ is $x^\circ$ and the measure of angle $ACB$ is expressed in the form $(Mx+N)^\circ$ with $M=1$, what is the value of $M+N$?

[asy]
draw((-10,0)--(20,0),linewidth(1),Arrows);
draw((0,0)--(10,10/sqrt(3))--(10+10/3,0)
  plan: produce[solver:low+cot/reread/confidence]; answered 1, correct -89
- [Intermediate Algebra L5] Let $(a_1, b_1),$ $(a_2, b_2),$ $\dots,$ $(a_n, b_n)$ be the real solutions to
\begin{align*}
a + \frac{17a + 6b}{a^2 + b^2} &= 6, \\
b + \frac{6a - 17b}{a^2 + b^2} &= 0.
\end{align*}Find $a_1 + b_1 + a_2 + b_2 + \dots + a_n + b_n.$

Hint: Use complex numbers.
  plan: produce[solver:low+cot/reread/confidence] > produce if disagree or unsure or fail[coder:low+react/reread/confidence]; answered 2, correct 6
- [Prealgebra L5] In the diagram, $AB,$ $BC,$ $CD,$ $DE,$ $EF,$ $FG,$ $GH,$ and $HK$ all have length $4,$ and all angles are right angles, with the exception of the angles at $D$ and $F.$

[asy]
draw((0,0)--(0,4)--(4,4)--(4,8)--(6.8284,5.1716)--(9.6569,8)--(9.6569,4)--(13.6569,4)--(13.6569,0)--cyc
  plan: produce[solver:low+cot/reread/confidence] > check if shaky (loop 1)[checker:low+python_check/reread/substitution] > decide if shaky[judge:low+reread/cot]; answered 0, correct 8
- [Precalculus L4] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\frac{a + b \sqrt{c}}{d},$ where $a,$ $b,$ $c,$ $d$ are positive integers, in simplest form.  Find $a
  plan: produce[solver:low+cot/reread/confidence] > produce if shaky[coder:low+react/reread/confidence] & check[checker:low+python_check/reread/substitution] & decide[judge:low+reread/cot]; answered 2, correct 8
- [Number Theory L5] Suppose that $ABC_4+200_{10}=ABC_9$, where $A$, $B$, and $C$ are valid digits in base 4 and 9. What is the sum when you add all possible values of $A$, all possible values of $B$, and all possible values of $C$?
  plan: produce[solver:low+cot/reread/case_analysis/substitution/confidence, coder:low+react/reread/confidence/case_analysis]; answered 9, correct 10
- [Geometry L4] A line with slope of $-2$ intersects the positive $x$-axis at $A$ and the positive $y$-axis at $B$. A second line intersects the $x$-axis at $C(8,0)$ and the $y$-axis at $D$. The lines intersect at $E(4,4)$. What is the area of the shaded quadrilateral $OBEC$? [asy]
draw((0,-1)--
  plan: produce[solver:low+cot/reread/confidence/substitution]; answered 16, correct 40
- [Precalculus L5] A prism is constructed so that its vertical edges are parallel to the $z$-axis.  Its cross-section is a square of side length 10.

[asy]
import three;

size(180);
currentprojection = perspective(6,3,2);

triple A, B, C, D, E, F, G, H;

A = (1,1,0);
B = (1,-1,0);
C = (-1,-1,0);
D 
  plan: produce[solver:low+cot/reread/confidence] > produce if disagree or unsure or fail[coder:low+react/reread/confidence] > check if disagree or unsure or fail (loop 1)[checker:low+python_check/reread/substitution] > decide if disagree or unsure or fail[judge:low+reread/cot]; answered 25, correct 225

Both wrong: 10.

## Most expensive correct questions (possible waste)
- [Precalculus L5, cost 35945] Let $a$ and $b$ be two 12th roots of unity, not necessarily distinct.  Find the number of different possible values of $(a + b)^{12}.$
  plan: produce[solver:low+cot/case_analysis/reread, coder:low+react/reread/confidence] > check if disagree or tool_error (loop 1)[checker:low+python_check/reread/substitution] > decide if fail or disagree or unsure[judge:low+cot/reread]
- [Intermediate Algebra L5, cost 35105] The real function $f$ has the property that, whenever $a,$ $b,$ $n$ are positive integers such that $a + b = 2^n,$ the equation
\[f(a) + f(b) = n^2\]holds.  What is $f(2002)$?
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution, coder:low+react/reread/confidence/case_analysis] > check (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if shaky[judge:low+reread/cot]
- [Counting & Probability L5, cost 34058] Let set $\mathcal{A}$ be a 90-element subset of $\{1,2,3,\ldots,100\},$ and let $S$ be the sum of the elements of $\mathcal{A}.$ Find the number of possible values of $S.$
  plan: produce[solverx2:low+cot/reread/confidence/case_analysis/substitution, coder:low+react/reread/confidence/case_analysis] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if shaky[judge:low+reread/cot]
- [Number Theory L5, cost 33296] Let $\tau (n)$ denote the number of positive integer divisors of $n$ (including $1$ and $n$). Find the sum of the six least positive integers $n$ that are solutions to $\tau (n) + 
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution, coderx2:low+react/reread/confidence/case_analysis] > check if disagree or fail or unsure or tool_error (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if disagree or fail or unsure or tool_error[judge:low+reread/cot]
- [Geometry L5, cost 32648] The grid below contains the $16$ points whose $x$- and $y$-coordinates are in the set $\{0,1,2,3\}$: [asy]
size(2.5cm);
for(int i=0; i<4; i+=1) { for(int j=0; j<4; j+=1) { dot((i,j
  plan: produce[solver:low+cot/reread/confidence/case_analysis/substitution, coder:low+react/reread/confidence/case_analysis] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/confidence] > decide if shaky[judge:low+reread/cot]