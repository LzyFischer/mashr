# Performance report (dev-A)

Organization: acc 100.0%, cost 3277/question. Full team: acc 100.0%, cost 13034. Invalid HR outputs (default plan used): 4.

## By difficulty (calculation steps in the reference solution)
| bucket | n | acc | team acc | cost | team cost | SOPs chosen |
|---|---|---|---|---|---|---|
| 1-2 steps | 4 | 100% | 100% | 2258 | 12770 | solo 3, vote 1 |
| 3-4 steps | 5 | 100% | 100% | 1506 | 12959 | solo 3, vote 2 |
| 5-6 steps | 2 | 100% | 100% | 5574 | 12930 | vote 1, debate 1 |
| 7+ steps | 1 | 100% | 100% | 11617 | 14675 | debate 1 |

## SOP stages (how often a stage ran, and whether it changed the running answer)
| sop.stage | chosen | ran | changed answer | changed to correct | changed to wrong |
|---|---|---|---|---|---|
| debate.final | 2 | 2 | 0 | 0 | 0 |
| debate.r1 | 2 | 2 | 0 | 0 | 0 |
| debate.r2 | 2 | 2 | 0 | 0 | 0 |
| solo.draft | 6 | 6 | 0 | 0 | 0 |
| vote.decide | 4 | 0 | 0 | 0 | 0 |
| vote.vote | 4 | 4 | 0 | 0 | 0 |

## Employees: leave-one-out replay on 6 multi-person questions
Removing the employee from that stage and re-running: 'needed' = answer was right and becomes wrong; 'harmful' = answer was wrong and becomes right.
| employee | stage uses | needed | harmful | no effect | mean tokens saved by removal |
|---|---|---|---|---|---|
| critic | 2 | 0 | 0 | 2 | 1161 |
| judge | 2 | 0 | 0 | 2 | 715 |
| solver_A | 6 | 0 | 0 | 6 | 902 |
| solver_B | 6 | 0 | 0 | 6 | 1034 |
| solver_C | 6 | 0 | 0 | 6 | 1324 |
Needed / uses by difficulty: critic@5-6 steps: 0/1; critic@7+ steps: 0/1; judge@5-6 steps: 0/1; judge@7+ steps: 0/1; solver_A@1-2 steps: 0/1; solver_A@3-4 steps: 0/2; solver_A@5-6 steps: 0/2; solver_A@7+ steps: 0/1; solver_B@1-2 steps: 0/1; solver_B@3-4 steps: 0/2; solver_B@5-6 steps: 0/2; solver_B@7+ steps: 0/1; solver_C@1-2 steps: 0/1; solver_C@3-4 steps: 0/2; solver_C@5-6 steps: 0/2; solver_C@7+ steps: 0/1

## HR usage
Employees assigned (questions): solver_B 10, solver_A 8, solver_C 6, judge 6, critic 2
Skills switched on (times): reread_question 10, check_units 8, percent_base 5, verify_by_substitution 4
Guide notes written: 8
Invalid HR outputs, first problems: ["first stage 'vote' has nobody assigned"]; ["first stage 'vote' has nobody assigned"]; ["first stage 'vote' has nobody assigned"]; ["first stage 'vote' has nobody assigned"]

## Saved wrong: org failed, full team succeeded (0)

Both wrong: 0.

## Most expensive correctly-solved questions (possible waste)
- [7+ steps, cost 11617] Tina makes $18.00 an hour.  If she works more than 8 hours per shift, she is eligible for overtime, which is paid by your hourly wage + 1/2 your hourly wage.  If she works 10 hours
  plan: debate r1=[solver_A:low+reread_question, solver_B:low+reread_question/percent_base/check_units, solver_C:low+verify_by_substitution] r2=[critic:low+check_units/verify_by_substitution] final=[judge:low] guide: judge: "Select the solution with correct overtime logic and arithmetic."; solver_A: "Calculate overtime pay as 1.5x base rate for hours over 8."; solver_C: "Define variables for base and overtime hours to form equation."; critic: "Verify unit consistency ($ vs hours) and math logic."; solver_B: "Double-check arithmetic on overtime calculation carefully."
- [5-6 steps, cost 9353] Tobias is buying a new pair of shoes that costs $95. He has been saving up his money each month for the past three months. He gets a $5 allowance a month. He also mows lawns and sh
  plan: debate r1=[solver_A:low+reread_question, solver_B:low+reread_question/check_units, solver_C:low+verify_by_substitution] r2=[critic:off+check_units/verify_by_substitution] final=[judge:off] guide: judge: "Select the most consistent and verified answer."; solver_A: "Calculate total saved, subtract allowance, find remaining from work."; solver_C: "Set up algebraic equation for number of driveways."; critic: "Review all solutions for calculation errors and logic."; solver_B: "Same as A but double-check arithmetic and unit consistency."
- [1-2 steps, cost 3036] A deep-sea monster rises from the waters once every hundred years to feast on a ship and sate its hunger. Over three hundred years, it has consumed 847 people. Ships have been buil
  plan: solo draft=[solver_B:low+reread_question/percent_base/check_units] guide: solver_B: "Solve geometric series for first term, verify arithmetic."
- [1-2 steps, cost 2476] Weng earns $12 an hour for babysitting. Yesterday, she just did 50 minutes of babysitting. How much did she earn?
  plan: solo draft=[solver_B:low+reread_question/check_units/percent_base] guide: solver_B: "Convert minutes to hours, then multiply by hourly rate."
- [1-2 steps, cost 2303] Alexis is applying for a new job and bought a new set of business clothes to wear to the interview. She went to a department store with a budget of $200 and spent $30 on a button-u
  plan: solo draft=[solver_A:low+reread_question] guide: solver_A: "Subtract all known expenses and remaining cash from the total budget to find the shoes cost."