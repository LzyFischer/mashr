#!/bin/bash
# v6: employees + HR on local vLLM (GPU 3, port 8001), designer (27B) on Tinker.
# usage: scripts/run.sh <dataset> <out-name> [extra mashr.rsi args...]
cd ~/project/mas-hr
set -a; source ~/.config/hrsi/tinker.env; set +a
export MASHR_LOCAL_MODELS=Qwen/Qwen3.5-9B MASHR_LOCAL=http://localhost:8001/v1
ds=$1; name=$2; shift 2
mkdir -p "results/v6/$name"
~/miniconda3/envs/tinker/bin/python -m mashr.rsi --dataset "$ds" --init design --out "results/v6/$name" "$@" \
  > "results/v6/$name/console.out" 2>&1
