"""The HR's best FIXED architecture (designed once, no per-question staffing, no all-employee
requirement), per organization, on test. Writes into results/rsi5/references/."""
import json, os, sys
from mashr.exec5 import Engine
from mashr.llm import LLM
from mashr.org5 import program_str, shape
from mashr.orgrsi import load_items
from mashr.rsi5 import evaluate, summarize
from references import design_full_team

out = sys.argv[1]
llm = LLM()
eng = Engine(llm, hr_thinking="low")
test = load_items("math", "test", 0, 156)
res = {}
for name, path in (("hr_fixed_round0", "results/rsi5/math_acc/round_0/pool.json"),
                   ("hr_fixed_final", "results/rsi5/math_acc/final_pool.json")):
    pool = json.load(open(path))
    plan, raw, tries = design_full_team(llm, pool, "low", require_all=False)
    print(f"{name}: {program_str(plan)}  (HR attempts {tries})", flush=True)
    json.dump({"plan": plan, "program": program_str(plan), "shape": shape(plan), "raw": raw,
               "attempts": tries}, open(os.path.join(out, f"{name}_design.json"), "w"), indent=1)
    res[name] = summarize(evaluate(eng, pool, test, plan))
    print(name, res[name], flush=True)
json.dump(res, open(os.path.join(out, "test_fixed.json"), "w"), indent=1)
