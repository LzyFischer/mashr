# Performance report (dev-A)

HR system: acc 80.0%, cost 1395 tokens/question. Full team: acc 100.0%, cost 13685. Invalid HR outputs (fell back to full team): 0.

## By difficulty (number of calculation steps in the reference solution)
| bucket | n | HR acc | team acc | HR cost | team cost | HR modes |
|---|---|---|---|---|---|---|
| 1-2 steps | 3 | 100% | 100% | 1328 | 13426 | single 2, self 1 |
| 3-4 steps | 5 | 60% | 100% | 1150 | 13280 | single 3, self 2 |
| 5-6 steps | 1 | 100% | 100% | 1599 | 12453 | single 1 |
| 7+ steps | 1 | 100% | 100% | 2618 | 17714 | single 1 |

## By HR decision
| decision | n | acc | mean cost |
|---|---|---|---|
| self | 3 | 33% | 143 |
| single thinking=low | 7 | 100% | 1932 |

## Saved wrong: HR plan failed, full team succeeded (2 questions)
- [3-4 steps] James writes a 3-page letter to 2 different friends twice a week.  How many pages does he write a year?
  plan: self (answered 384); answered 384, correct 624
- [3-4 steps] Albert is wondering how much pizza he can eat in one day. He buys 2 large pizzas and 2 small pizzas. A large pizza has 16 slices and a small pizza has 8 slices. If he eats it all, how many pieces does he eat that day?
  plan: self (answered 40); answered 40, correct 48

Both HR and full team wrong: 0 questions (likely beyond the team).

## Most expensive correctly-solved questions (possible waste)
- [1-2 steps, cost 2618] Alexis is applying for a new job and bought a new set of business clothes to wear to the interview. She went to a department store with a budget of $200 and spent $30 on a button-up shirt, $46 on suit
  plan: single solver_B thinking=low
- [7+ steps, cost 2618] Tina makes $18.00 an hour.  If she works more than 8 hours per shift, she is eligible for overtime, which is paid by your hourly wage + 1/2 your hourly wage.  If she works 10 hours every day for 5 day
  plan: single solver_B thinking=low
- [3-4 steps, cost 2494] Ken created a care package to send to his brother, who was away at boarding school.  Ken placed a box on a scale, and then he poured into the box enough jelly beans to bring the weight to 2 pounds.  T
  plan: single solver_B thinking=low
- [3-4 steps, cost 1628] Julie is reading a 120-page book. Yesterday, she was able to read 12 pages and today, she read twice as many pages as yesterday. If she wants to read half of the remaining pages tomorrow, how many pag
  plan: single solver_B thinking=low
- [5-6 steps, cost 1599] Mark has a garden with flowers. He planted plants of three different colors in it. Ten of them are yellow, and there are 80% more of those in purple. There are only 25% as many green flowers as there 
  plan: single solver_B thinking=low
- [3-4 steps, cost 1338] Betty is saving money for a new wallet which costs $100. Betty has only half of the money she needs. Her parents decided to give her $15 for that purpose, and her grandparents twice as much as her par
  plan: single solver_B thinking=low