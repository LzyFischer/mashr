"""Where do the final v4 organization's dev-A errors come from? For each wrong question: was the gold
answer produced by anyone (then the decision lost it) or by no one (solving failed)? Plus accuracy by
architecture and by level, against the full system."""
import json, sys
from collections import Counter, defaultdict
from mashr.cascade import Cascade
from mashr.exec4 import Engine
from mashr.llm import LLM
from mashr.optimize import evaluate as evaluate_ref
from mashr.org4 import shape
from mashr.orgrsi import load_items
from mashr.pool import FULL, V0
from mashr.rsi4 import evaluate

pool = json.load(open(sys.argv[1]))
llm = LLM()
items = load_items("math", "train", 0, 150)
rows = evaluate(Engine(llm), pool, items)
ref = {r["id"]: r for r in evaluate_ref(Cascade(llm), V0, items, FULL)}
wrong = [r for r in rows if not r["correct"]]
seen = lambda r: [a for t in r["trace"] if t["ran"] for a in t["answers"]]
print(f"acc {1 - len(wrong) / len(rows):.1%}; wrong {len(wrong)}: gold produced by someone "
      f"{sum(r['gold'] in seen(r) for r in wrong)}, by no one {sum(r['gold'] not in seen(r) for r in wrong)}; "
      f"full system right on {sum(ref[r['id']]['correct'] for r in wrong)} of them")
by = defaultdict(list)
for r in rows:
    by[shape(r["plan"])].append(r)
print("by architecture (n, acc, mean cost):")
for k, rs in sorted(by.items(), key=lambda kv: -len(kv[1]))[:8]:
    print(f"  {k:40s} {len(rs):3d} {sum(r['correct'] for r in rs) / len(rs):.0%} "
          f"{sum(r['cost'] for r in rs) / len(rs):6.0f}")
for lv in ("L4", "L5"):
    rs = [r for r in rows if r["bucket"].endswith(lv)]
    print(f"{lv}: n {len(rs)}, org {sum(r['correct'] for r in rs) / len(rs):.0%}, "
          f"full {sum(ref[r['id']]['correct'] for r in rs) / len(rs):.0%}")
print("wrong by subject:", Counter(r["bucket"] for r in wrong).most_common())
for r in wrong[:6]:
    print(f"- [{r['bucket']}] gold {r['gold']} pred {r['pred']} seen {seen(r)} | {shape(r['plan'])} | "
          f"full {'right' if ref[r['id']]['correct'] else 'wrong'}")
