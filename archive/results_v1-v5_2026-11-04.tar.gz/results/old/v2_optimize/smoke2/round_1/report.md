# Diagnostic report (dev-A)

Pool: acc 100.0%, cost 6654/question (6148 generated, 2528 prompt tokens; cost = generated + 0.2 x prompt). Full system: acc 83.3%, cost 17182. Orchestrator prompt: 7561 chars. Invalid orchestrator outputs: 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 4 | 100% | 100% | 5144 | 13214 | solve1>review1 2, solve1 2 |
| Algebra L5 | 1 | 100% | 100% | 4345 | 16885 | solve1>review1? 1 |
| Counting & Probability L5 | 1 | 100% | 100% | 4609 | 16333 | solve1>review1? 1 |
| Intermediate Algebra L4 | 1 | 100% | 100% | 4991 | 17150 | solve1>review1? 1 |
| Intermediate Algebra L5 | 2 | 100% | 50% | 9951 | 23837 | solve1>review1 1, solve1>review1? 1 |
| Prealgebra L4 | 1 | 100% | 100% | 3773 | 11068 | solve1 1 |
| Prealgebra L5 | 1 | 100% | 0% | 5735 | 23481 | solve1>review1? 1 |
| Precalculus L5 | 1 | 100% | 100% | 15909 | 20738 | solve1>solve1>review1?>decide1? 1 |

## Later stages (by type and condition): how often they ran and changed the answer
| stage | planned | ran | changed answer | to correct | to wrong |
|---|---|---|---|---|---|
| decide if disagree | 1 | 0 | 0 | 0 | 0 |
| review if always | 3 | 3 | 0 | 0 | 0 |
| review if disagree | 6 | 0 | 0 | 0 | 0 |
| solve if always | 1 | 1 | 0 | 0 | 0 |

## Agents: leave-one-out replay on 4 multi-agent questions
Remove the agent from that tier and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| agent@stage | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| careful_solver@solve2 | 1 | 0 | 0 | 1 | 7920 |
| critic@review2 | 3 | 0 | 0 | 3 | 3554 |

## Orchestrator usage
Architectures: solve1>review1? 5, solve1>review1 3, solve1 3, solve1>solve1>review1?>decide1? 1
Agent assignments: critic 9, algebra_solver 7, geometry_solver 3, counting_solver 1, fast_solver 1, careful_solver 1, judge 1
Skills switched on: check_arithmetic 22, reread_question 15, verify_by_substitution 13, answer_form 10, exact_form 9, compare_solutions 8, polynomial_roots 4, coordinate_setup 3, area_decomp 3, case_breakdown 2, maximum_check 2, unit_check 1, matrix_power 1, final_decision 1
Skills never switched on: inclusion_exclusion, symmetry_use

## Pool wrong, full system right (0)

Both wrong: 0.

## Most expensive correct questions (possible waste)
- [Precalculus L5, cost 15909] Let $\omega$ be a nonreal root of $x^3 = 1,$ and let
\[\mathbf{M} = \begin{pmatrix} -\omega^2 & - \omega \\ 1 & 0 \end{pmatrix}.\]Find the sum of the entries of $\mathbf{M} + \math
  plan: solve[algebra_solver:high+matrix_power/polynomial_roots/exact_form/check_arithmetic] > solve[careful_solver:high+verify_by_substitution/case_breakdown/exact_form/maximum_check/check_arithmetic] > review if disagree[critic:low+reread_question/check_arithmetic/verify_by_substitution/answer_form/compare_solutions] > decide if disagree[judge:low+answer_form/reread_question/final_decision/maximum_check]
- [Intermediate Algebra L5, cost 12085] During the car ride home, Michael looks back at his recent math exams. A problem on Michael's calculus mid-term gets him starting thinking about a particular quadratic,\[x^2-sx+p,\
  plan: solve[algebra_solver:high+polynomial_roots/verify_by_substitution/exact_form/check_arithmetic] > review[critic:low+reread_question/check_arithmetic/verify_by_substitution/answer_form/compare_solutions]
- [Intermediate Algebra L5, cost 7816] There is a unique polynomial $P(x)$ of degree $8$ with rational coefficients and leading coefficient $1,$ which has the number \[\sqrt{2} + \sqrt{3} + \sqrt{5}\]as a root. Compute 
  plan: solve[algebra_solver:high+polynomial_roots/exact_form/check_arithmetic] > review if disagree[critic:low+reread_question/check_arithmetic/verify_by_substitution/answer_form/compare_solutions]
- [Algebra L4, cost 6739] A line with slope equal to $1$ and a line with slope equal to $2$ intersect at the point $P(1,6),$ as shown. [asy]
unitsize(0.5 cm);
draw((0,-1)--(0,10),EndArrow);
draw((-10,0)--(5
  plan: solve[geometry_solver:low+reread_question/coordinate_setup/area_decomp/check_arithmetic] > review[critic:low+reread_question/check_arithmetic/verify_by_substitution/answer_form/compare_solutions]
- [Algebra L4, cost 6474] Solve for $Q$ if $\sqrt{Q^3} = 16\sqrt[8]{16}$.
  plan: solve[algebra_solver:low+exact_form/check_arithmetic] > review[critic:low+reread_question/check_arithmetic/verify_by_substitution/answer_form]