# Diagnostic report (dev-A)

Organization: acc 76.0%, cost 9005/question, of which the HR 1650 (HR prompt 3975 chars). 23 distinct architectures, 1.7 nodes per question. HR outputs: repaired 3, written again 0, fallback 0.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| GSM-Hard | 150 | 76% | - | 9005 | 0 | coder.low 84, coder.high,solver.high>verifier.high 14, coder.high 9 |

## Architectures the HR wrote
| architecture | uses | acc | mean cost |
|---|---|---|---|
| coder.low | 84 | 81% | 4233 |
| coder.high,solver.high>verifier.high | 14 | 64% | 19143 |
| coder.high | 9 | 56% | 8343 |
| coder.low,solver.low>verifier.low | 7 | 86% | 12185 |
| coder.high>verifier.high | 6 | 67% | 14247 |
| analyst.low>solver.high>coder.high>verifier.high | 5 | 80% | 14633 |
| solver.low>coder.low | 3 | 67% | 6568 |
| analyst.low,coder.high,solver.high>verifier.high | 3 | 67% | 31513 |
| solver.low | 3 | 67% | 4521 |
| coder.low>verifier.low | 2 | 50% | 12396 |
| coder.high>verifier.low | 2 | 100% | 9913 |
| coder.low,solver.low | 1 | 100% | 6839 |
| coder.high,solver.low>verifier.low | 1 | 100% | 18421 |
| analyst.low,coder.high>verifier.high | 1 | 100% | 18138 |
| solver.low>coder.low>verifier.low | 1 | 100% | 9981 |

## Nodes (employee.thinking)
answer correct = the node's own answer; hit budget = the reasoning was cut at the thinking budget; for nodes with inputs: changed = its answer differs from its inputs' majority.
| node | uses | answer correct | hit budget | mean cost | changed | to correct | to wrong |
|---|---|---|---|---|---|---|---|
| coder.low | 97 | 80% | 65% | 2725 | - | - | - |
| coder.high | 37 | 70% | 73% | 6662 | - | - | - |
| verifier.high (with inputs) | 33 | 64% | 64% | 5495 | 5 | 3 | 3 |
| solver.high | 22 | 64% | 91% | 6248 | - | - | - |
| solver.low | 18 | 83% | 100% | 3455 | - | - | - |
| verifier.low (with inputs) | 16 | 88% | 100% | 4191 | - | - | - |
| analyst.low | 11 | 64% | 100% | 3761 | - | - | - |
| coder.high (with inputs) | 7 | 71% | 29% | 3302 | - | - | - |
| solver.high (with inputs) | 5 | 80% | 0% | 3279 | - | - | - |
| coder.low (with inputs) | 4 | 75% | 50% | 1453 | - | - | - |
| coder.max | 2 | 0% | 100% | 20528 | - | - | - |
| analyst.high | 1 | 100% | 100% | 6752 | - | - | - |
| solver.max | 1 | 100% | 0% | 9895 | - | - | - |

## Leave-one-out on 54 questions with 2+ nodes
Remove the node (its consumers lose that input; a removed output hands over to its first input) and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| coder.high (input) | 34 | 1 | 1 | 32 | 5091 |
| verifier.high (output) | 33 | 1 | 1 | 31 | 5495 |
| solver.high (input) | 27 | 0 | 1 | 26 | 4140 |
| verifier.low (output) | 16 | 0 | 0 | 16 | 4191 |
| solver.low (input) | 15 | 0 | 0 | 15 | 2356 |
| coder.low (input) | 13 | 0 | 0 | 13 | 3119 |
| analyst.low (input) | 11 | 0 | 0 | 11 | 1082 |
| coder.low (output) | 3 | 0 | 0 | 3 | 1700 |
| coder.max (input) | 2 | 0 | 0 | 2 | 20566 |
| coder.high (output) | 1 | 0 | 0 | 1 | 6895 |
| analyst.high (input) | 1 | 1 | 0 | 0 | 5980 |
| solver.max (input) | 1 | 1 | 0 | 0 | 9137 |

HR output problems: nodes ['a'] feed nothing (3)

## Organization wrong (36)
- [GSM-Hard] Mrs. Tatiana owns a grocery store that sells different fruits and vegetables, which includes carrots. The price of carrots in the grocery store increases by 5% of the original price every year. What would be the price of carrots after three years if it was $1604814 initially? (Ro
  architecture: a = coder("high"); return a; answered 1857773, correct 1845536.0
- [GSM-Hard] Dale is selling butterscotch candies to raise money for his club at school. He doesn't have the candies yet and is instead just taking orders. He started off with 7310392 total that he ordered and wanted to sell, but he ended up selling 150 butterscotch candies. Then he ordered 7
  architecture: a = coder("low"); return a; answered 14620634, correct 7310342.0
- [GSM-Hard] 20% of 7871124 people think horse
  architecture: c = coder("low"); return c; answered 1574224.8, correct 2518759.68
- [GSM-Hard] Audrey has to take two math tests to pass 6th grade. She must correctly answer 4103049% of the total questions to move on to the 7th grade. The first test has 4103049 questions and she gets 60% of them correct. The second test has 40 questions. How many questions does she need to
  architecture: p = analyst("low"); a = solver("high"); b = coder("high"); v = verifier("high", p, a, b); return v; answered 168349290354.21, correct 410332.8999999999
- [GSM-Hard] Billy is buying some candy with $10 his father gave him. The candy costs $4808993 a pound. After buying candy, he takes half his change and spends it on gumballs, which cost $.05 each. If he bought 40 gumballs, how many pounds of candy did he buy?
  architecture: c = coder("high"); v = verifier("high", c); return v; answered 1.24765269, correct 1.2477e-06
- [GSM-Hard] The red car is 40% cheaper than the blue car. The price of the blue car is $8699599. How much do both cars cost?
  architecture: c = coder("low"); return c; answered 5244599.4, correct 13919358.399999999
- [GSM-Hard] James buys 5072217 pairs of shoes a month.  He spends $5072217640 on shoes each year.  How much does he pay on average for each pair of shoes?
  architecture: c = coder("low"); return c; answered 83.33334384818863, correct 4.33735e-05
- [GSM-Hard] Ellen and her sister, Lani, went to the mall to buy presents for their mom. Ellen bought a pair of leggings for $4915315 and a photo frame for $5. Lani bought a pair of sunglasses at $30 and two bathrobes at $4915315 each. How much did they spend in all?
  architecture: c = coder("low"); return c; answered 14745980, correct 4915550.0
- [GSM-Hard] A simple folding newspaper or tabloid can be made by folding a piece of paper vertically and unfolding. Then, say, page 1 is printed on the left back, page 2 is printed on the left front, and then, perhaps page 6235671 is printed on the right back, and page 31 is printed on the r
  architecture: c = coder("low"); return c; answered 623567, correct 1558917.0
- [GSM-Hard] James buys a new wardrobe.  He buys 1662810 suits and 1662810 dress pants.  He also buys 3 dress shirts per suit.  The suits cost $750 each and the dress pants cost 1/5 that cost.  The dress shirts were $60 each.  How much did everything cost?
  architecture: c = coder("low"); return c; answered 1795834800, correct 249430800.0

## Most expensive correct questions (possible waste)
- [GSM-Hard, cost 46999] Four students scored a total of 251 points in a board game. Naomi scored 1972193 of the points. Yuri scored 10 more than half as many points as Naomi and Brianna scored 17 points m
  architecture: p = analyst("high"); s = solver("max"); c = coder("max"); v = verifier("high", p, s, c); return v
- [GSM-Hard, cost 37807] Faraday owns a flower shop. He sells a sunflower that costs $2 each and a bouquet of sunflower that costs $8420035. If Faraday earned $26 from the sunflower and $56 from the bouque
  architecture: a = analyst("low"); b = solver("high"); c = coder("high"); v = verifier("high", a, b, c); return v
- [GSM-Hard, cost 27729] Diane gave a number train a starting value of 5562984. This starting value plus half the number was divided by 5 and the resulting value was multiplied by the starting value minus 
  architecture: a = solver("high"); c = coder("high"); v = verifier("high", a, c); return v
- [GSM-Hard, cost 23511] Mike decides he wants to replace his movie collection with digital versions.  He has 2262804 movies.  A third of the movies are in various series and he knows he can get those for 
  architecture: s = solver("high"); c = coder("high"); v = verifier("high", s, c); return v
- [GSM-Hard, cost 22292] An interior design firm offers installation for $7754471.  It includes hanging 4 mirrors, 2 shelves, 1 chandelier, and 10 pictures.  They will install additional items for an extra
  architecture: a = analyst("low"); s = solver("high"); c = coder("high"); v = verifier("high", s, c); return v