# Diagnostic report (dev-A)

Organization: acc 86.7%, cost 11200/question (10414 generated, 3928 prompt tokens; cost = generated + 0.2 x prompt, including the orchestrator's). Full system: acc 91.3%, cost 17252. Orchestrator (HR): 2281/question of that cost (20%), prompt 6169 chars, thinking low; 19 distinct architectures. Final rule: last.

## By category
| category | n | acc | full acc | cost | full cost | architectures |
|---|---|---|---|---|---|---|
| Algebra L4 | 17 | 100% | 100% | 4737 | 13285 | solver 14, solver>checker?>judge? 2, solver+coder>checker?L1>judge? 1 |
| Algebra L5 | 18 | 94% | 100% | 7904 | 15585 | solver 10, solver+coder>checker?>judge? 3, solver+coder>checker?L1>judge? 1 |
| Counting & Probability L4 | 8 | 100% | 100% | 8596 | 15676 | solver+coder>checker?L1>judge? 2, solver>checker?>judge? 2, solver>checker? 2 |
| Counting & Probability L5 | 9 | 89% | 89% | 17986 | 19103 | solver+coder>checker?L1>judge? 4, solver+coder>checker?>judge? 3, solver>checker?>judge? 1 |
| Geometry L4 | 5 | 100% | 100% | 9449 | 15889 | solver 2, solver>checker?>judge? 1, solver+coder>checker? 1 |
| Geometry L5 | 7 | 43% | 57% | 24931 | 22647 | solver+coder>checker?L1>judge? 3, solver+coder>checker?>judge? 2, solver+coder>checker? 1 |
| Intermediate Algebra L4 | 14 | 93% | 100% | 9740 | 18210 | solver 4, solver+coder>checker?L1>judge? 3, solver>checker?>judge? 2 |
| Intermediate Algebra L5 | 17 | 71% | 71% | 19188 | 21465 | solver+coder>checker?>judge? 5, solver+coder>checker?L1>judge? 4, solver>checker?>judge? 2 |
| Number Theory L4 | 9 | 100% | 100% | 6521 | 17149 | solver>checker? 4, solver 3, solver>checker?L1>judge? 1 |
| Number Theory L5 | 16 | 88% | 88% | 11187 | 18165 | solver 6, solver+coder>checker?>judge? 3, solver>checker? 2 |
| Prealgebra L4 | 12 | 92% | 100% | 3353 | 10794 | solver 11, solver>checkerL1 1 |
| Prealgebra L5 | 9 | 78% | 89% | 9819 | 17096 | solver>checker? 2, solver 2, solver+coder>checker?>judge? 2 |
| Precalculus L4 | 3 | 67% | 100% | 13484 | 20027 | solver 1, solver+coder 1, solver+coder>checker?L1>judge 1 |
| Precalculus L5 | 6 | 67% | 83% | 22572 | 22960 | solver+coder>checker?>judge? 3, solver+coder>checker?L1>judge? 1, solver+coder 1 |

## First stages (staffing): accuracy of their answer
| first stage | uses | answer correct | mean cost |
|---|---|---|---|
| solver:low+cot/reread/confidence/substitution | 40 | 95% | 4021 |
| solver:off+cot/reread/confidence | 36 | 97% | 898 |
| solver:high+cot/reread/confidence/case_analysis/substitution + coder:low+react/reread/confidence/case_analysis | 17 | 82% | 10996 |
| solver:high+cot/reread/confidence/substitution + coder:low+react/reread/confidence | 9 | 78% | 12380 |
| solver:high+cot/reread/confidence/substitution | 6 | 50% | 7623 |
| solver:high+cot/reread/confidence/substitution/case_analysis + coder:low+react/reread/confidence/case_analysis | 4 | 50% | 12016 |
| solver:high+cot/reread/confidence/case_analysis/substitution/diagram + coder:low+react/reread/confidence/case_analysis/diagram | 4 | 50% | 11644 |
| solver:high+cot/reread/confidence/substitution/case_analysis | 2 | 50% | 7857 |
| solver:high+cot/reread/confidence/diagram/substitution + coder:low+react/reread/confidence/diagram | 2 | 100% | 10881 |
| solver:high+cot/reread/confidence/substitution/diagram + coder:low+react/reread/confidence/case_analysis | 2 | 50% | 12338 |
| solver:high+cot/reread/confidence/substitution + coder:low+react/reread/confidence/case_analysis | 2 | 50% | 14678 |
| solver:high+cot/reread/confidence/case_analysis/diagram + coder:low+react/reread/confidence/case_analysis/diagram | 1 | 100% | 12625 |
| solver:low+cot/reread/confidence/case_analysis/substitution | 1 | 100% | 4357 |
| solver:high+cot/reread/case_analysis/substitution + coder:low+react/reread/confidence | 1 | 100% | 10852 |
| solver:high+cot/reread/confidence/substitution/case_analysis + coder:low+react/reread/confidence | 1 | 0% | 13427 |

## Later stages (function and condition): how often they ran and changed the answer
| stage | planned | ran | changed answer | to correct | to wrong | mean cost when ran |
|---|---|---|---|---|---|---|
| decide if shaky | 41 | 12 | 4 | 1 | 0 | 5236 |
| check if shaky | 32 | 4 | 1 | 1 | 0 | 4595 |
| check if shaky (loop 1) | 21 | 8 | 6 | 2 | 0 | 10261 |
| decide if disagree or fail or unsure | 10 | 3 | 0 | 0 | 0 | 4891 |
| check if disagree or fail or unsure | 10 | 2 | 1 | 1 | 0 | 4714 |
| decide if disagree or fail or unsure or tool_error | 10 | 4 | 1 | 0 | 0 | 5732 |
| check if disagree or fail or unsure or tool_error | 10 | 3 | 3 | 2 | 0 | 4856 |
| decide if always | 4 | 4 | 1 | 0 | 0 | 4505 |
| check if always (loop 1) | 3 | 2 | 1 | 0 | 0 | 14531 |
| check if always | 3 | 3 | 1 | 1 | 0 | 4426 |
| check if disagree or fail or unsure or tool_error (loop 1) | 3 | 2 | 2 | 1 | 0 | 11966 |
| check if disagree or fail or unsure or tool_error or agreement < 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| decide if disagree or fail or unsure or tool_error or agreement < 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| produce if disagree or fail or unsure | 1 | 0 | 0 | 0 | 0 | 0 |
| check if disagree or fail or unsure (loop 1) | 1 | 0 | 0 | 0 | 0 | 0 |

## Signals after the first stage (150 questions, 31 with a wrong answer at that point)
fires = how often it holds; precision = share of firings where the answer was wrong; recall = share of wrong answers it fires on.
| signal / condition | fires | precision | recall |
|---|---|---|---|
| disagree | 27 | 74% | 65% |
| missing | 0 | 0% | 0% |
| unsure | 0 | 0% | 0% |
| fail | 0 | 0% | 0% |
| tool_error | 0 | 0% | 0% |
| agreement < 1 | 27 | 74% | 65% |
| agreement < 0.67 | 27 | 74% | 65% |
| tokens > 1000 | 122 | 25% | 100% |
| tokens > 2000 | 115 | 27% | 100% |
| tokens > 4000 | 83 | 34% | 90% |
| [shaky] disagree or fail or unsure or tool_error | 27 | 74% | 65% |

## Leave-one-out replay on 60 questions with 2+ nodes that ran
Remove the employee from that stage (agent@function<stage>) or the whole stage, and re-run: 'needed' = right becomes wrong; 'harmful' = wrong becomes right.
| removed | uses | needed | harmful | no effect | mean cost saved |
|---|---|---|---|---|---|
| solver@produce1 | 57 | 11 | 2 | 44 | 11415 |
| coder@produce1 | 57 | 7 | 0 | 50 | 8899 |
| stage 2 check if shaky | 11 | 0 | 0 | 11 | 7699 |
| stage 3 decide if shaky | 11 | 1 | 0 | 10 | 5260 |
| stage 2 check | 5 | 1 | 0 | 4 | 9596 |
| stage 2 check if disagree or fail or unsure or tool_error | 5 | 1 | 0 | 4 | 8081 |
| stage 3 decide | 4 | 0 | 0 | 4 | 4505 |
| stage 3 decide if disagree or fail or unsure or tool_error | 4 | 0 | 0 | 4 | 5732 |
| stage 3 decide if disagree or fail or unsure | 3 | 0 | 0 | 3 | 4891 |
| stage 2 check if disagree or fail or unsure | 2 | 1 | 0 | 1 | 4480 |
| stage 2 check if disagree or fail | 1 | 0 | 0 | 1 | 5816 |
| stage 3 decide if disagree or fail | 1 | 0 | 0 | 1 | 5488 |
| stage 2 check if tokens > 3000 or disagree or fail or tool_error | 1 | 0 | 0 | 1 | 18085 |
| stage 3 decide if disagree or fail or tool_error | 1 | 0 | 0 | 1 | 5318 |
| stage 2 check if disagree or fail or unsure or tool_error or agreement < 0.5 | 1 | 0 | 0 | 1 | 6304 |
| stage 3 decide if disagree or fail or unsure or tool_error or agreement < 0.5 | 1 | 0 | 0 | 1 | 6283 |

## Orchestrator usage
Architectures: solver 54, solver+coder>checker?>judge? 23, solver+coder>checker?L1>judge? 20, solver>checker?>judge? 14, solver>checker? 13, solver+coder 6, solver+coder>checker? 5, solver>checker?L1>judge? 4
Employees: solver 152, checker 89, judge 70, coder 59; never staffed: none
Thinking: low 259, high 68, off 43
Skills switched on: reread 368, cot 220, confidence 211, substitution 191, alternative 148, python_check 89, case_analysis 84, react 59, diagram 27; never: none
Conditions: always 160, shaky 94, disagree or fail or unsure or tool_error 23, disagree or fail or unsure 22, disagree or fail or unsure or tool_error or agreement < 1 5, disagree or fail 2, disagree or fail or unsure or tool_error or agreement < 0.5 2, disagree 1, tokens > 3000 or disagree or fail or tool_error 1, disagree or fail or tool_error 1
Copies > 1: 0; debate rounds > 1: 0; check loops: 29
Orchestrator outputs: minor fixes 22 (skills an employee does not hold, quoted conditions, missing commas), structural repairs 2, asked again 1 (valid on the 2nd try: 1), fixed fallback 0 (acc -).
Most common problems: minor: trailing characters ignored (7); minor: coder does not hold ['substitution'] (6); minor: JSON syntax repaired (5); minor: a stage mixed functions; its parts run in order (3); minor: coder does not hold ['alternative'] (2); unknown agent 'rounds' (2)

## Organization wrong, full system right (9)
- [Prealgebra L5] In the diagram, $AB,$ $BC,$ $CD,$ $DE,$ $EF,$ $FG,$ $GH,$ and $HK$ all have length $4,$ and all angles are right angles, with the exception of the angles at $D$ and $F.$

[asy]
draw((0,0)--(0,4)--(4,4)--(4,8)--(6.8284,5.1716)--(9.6569,8)--(9.6569,4)--(13.6569,4)--(13.6569,0)--cyc
  plan: produce[solver:high+cot/reread/confidence/diagram] > check if disagree or fail or unsure or tool_error[checker:low+python_check/reread/substitution/alternative]; answered 2, correct 8
- [Precalculus L4] Let $P$ be the convex polygon in the complex plane whose vertices are the roots of
\[z^7 + z^6 + z^5 + z^4 + z^3 + z^2 + z + 1 = 0.\]The area of $P$ can be expressed in the form $\frac{a + b \sqrt{c}}{d},$ where $a,$ $b,$ $c,$ $d$ are positive integers, in simplest form.  Find $a
  plan: produce[solver:high+cot/reread/confidence/diagram, coder:low+react/reread/confidence]; answered 0, correct 8
- [Intermediate Algebra L4] Find the largest constant $m,$ so that for any positive real numbers $a,$ $b,$ $c,$ and $d,$
\[\sqrt{\frac{a}{b + c + d}} + \sqrt{\frac{b}{a + c + d}} + \sqrt{\frac{c}{a + b + d}} + \sqrt{\frac{d}{a + b + c}} > m.\]
  plan: produce[solver:high+cot/reread/confidence/substitution] > check if disagree or fail or unsure[checker:low+python_check/reread/substitution/alternative] > decide if disagree or fail or unsure[judge:low+reread/cot/alternative]; answered 0, correct 2
- [Prealgebra L4] What is the sum of the positive integers that are solutions of $-3n +3 >-11?$
  plan: produce[solver:off+cot/reread/confidence]; answered 15, correct 10
- [Algebra L5] How many zeros are in the expansion of $999,\!999,\!999,\!998^2$?
  plan: produce[solver:high+cot/reread/confidence/substitution] > check if shaky[checker:low+python_check/reread/substitution/alternative] > decide if shaky[judge:low+reread/cot/alternative]; answered 996000, correct 11
- [Prealgebra L5] Let $a$ and $b$ be distinct positive divisors of $80.$ What is the smallest possible value of $ab$ which is not a divisor of $80?$
  plan: produce[solver:low+cot/reread/confidence/substitution]; answered 1, correct 32
- [Intermediate Algebra L5] In the coordinate plane, consider points $A = (0, 0)$, $B = (11, 0)$, and $C = (18, 0)$.  Line $\ell_A$ has slope 1 and passes through $A$.  Line $\ell_B$ is vertical and passes through $B$.  Line $\ell_C$ has slope $-1$ and passes through $C$.  The three lines $\ell_A$, $\ell_B$
  plan: produce[solver:high+cot/reread/confidence/case_analysis/substitution, coder:low+react/reread/confidence/case_analysis]; answered 2, correct 85
- [Precalculus L5] Find the number of ordered quadruples $(a,b,c,d)$ of real numbers such that
\[\begin{pmatrix} a & b \\ c & d \end{pmatrix}^2 = \begin{pmatrix} c & a \\ d & b \end{pmatrix}.\]
  plan: produce[solver:high+cot/reread/confidence/case_analysis/substitution] > produce if disagree or fail or unsure or tool_error or agreement < 1[coder:low+react/reread/confidence] > check if disagree or fail or unsure or tool_error or agreement < 1[checker:low+python_check/reread/substitution/alternative] > decide if disagree or fail or unsure or tool_error or agreement < 1[judge:low+reread/cot/alternative]; answered 0, correct 4
- [Geometry L5] Square $ABCD$ has center $O,\ AB=900,\ E$ and $F$ are on $AB$ with $AE<BF$ and $E$ between $A$ and $F, m\angle EOF =45^\circ,$ and $EF=400.$ Given that $BF=p+q\sqrt{r},$ where $p,q,$ and $r$ are positive integers and $r$ is not divisible by the square of any prime, find $p+q+r.$
  plan: produce[solver:high+cot/reread/confidence/substitution/case_analysis] > check if disagree or fail or unsure[checker:low+python_check/reread/substitution/alternative] > decide if disagree or fail or unsure[judge:low+reread/cot/alternative]; answered 50, correct 307

Both wrong: 11.

## Most expensive correct questions (possible waste)
- [Number Theory L5, cost 43131] What is the ones digit of $1^{2009} + 2^{2009} + 3^{2009} + \cdots + 2009^{2009}?$
  plan: produce[solver:high+cot/reread/confidence/case_analysis/substitution, coder:low+react/reread/confidence/case_analysis] > check if tokens > 3000 or disagree or fail or tool_error (loop 1)[checker:low+python_check/reread/substitution/alternative] > decide if disagree or fail or tool_error[judge:low+reread/cot/alternative]
- [Precalculus L5, cost 42608] Three unit circles are drawn so they are mutually tangent, as shown below.  A blue circle that is externally tangent to all three unit circles is drawn.  Finally, three red circles
  plan: produce[solver:high+cot/reread/confidence/diagram/case_analysis/substitution, coder:low+react/reread/confidence] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/alternative] > decide if shaky[judge:low+reread/cot/alternative]
- [Intermediate Algebra L5, cost 39678] A nonzero polynomial with rational coefficients has all of the numbers \[1+\sqrt{2}, \; 2+\sqrt{3}, \;3+\sqrt{4},\; \dots, \;1000+\sqrt{1001}\]as roots. What is the smallest possib
  plan: produce[solver:high+cot/reread/confidence/case_analysis, coder:low+react/reread/confidence/case_analysis, solver:high+cot/reread/confidence/case_analysis, coder:low+react/reread/confidence/case_analysis] > check if disagree or fail[checker:low+python_check/reread/substitution/alternative] > decide if disagree or fail[judge:low+reread/cot/alternative]
- [Counting & Probability L5, cost 39313] The number of increasing sequences of positive integers $a_1 \le a_2 \le a_3 \le \cdots \le a_{10} \le 2007$ such that $a_i-i$ is even for $1\le i \le 10$ can be expressed as ${m \
  plan: produce[solver:high+cot/reread/confidence/substitution/case_analysis, coder:low+react/reread/confidence] > check if disagree or fail or unsure or tool_error (loop 1)[checker:low+python_check/reread/substitution/alternative] > decide if disagree or fail or unsure or tool_error[judge:low+reread/cot/alternative]
- [Geometry L5, cost 38648] The grid below contains the $16$ points whose $x$- and $y$-coordinates are in the set $\{0,1,2,3\}$: [asy]
size(2.5cm);
for(int i=0; i<4; i+=1) { for(int j=0; j<4; j+=1) { dot((i,j
  plan: produce[solver:high+cot/reread/confidence/case_analysis/diagram, coder:low+react/reread/confidence/case_analysis] > check if shaky (loop 1)[checker:low+python_check/reread/substitution/alternative] > decide if shaky[judge:low+reread/cot/alternative]